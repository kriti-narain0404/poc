const LoginData = {
  isLoggedIn: false,
  username: "",
  password: "",
  path: "/home",
  userData: [],
  required: false,
  isQueryError: false,
  queryErrorResult: "",
  version: "Version  2.5",
  isUsersignedUp: true,
  userId: 1,
  role:"ADMIN",
  username:"",
  projectId: 0,
  accessToken:"",
  noProjectAssigned: false,
  isDarkMode: false,
  loginScreen: true,
  authScreen: false,
  isAccountLocked: false
}

export default LoginData;
