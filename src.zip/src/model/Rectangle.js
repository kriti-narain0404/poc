const Rectangle = {

    originX: "left",
    originY: "top",
    angle: 0,
    //strokeWidth: 1,
    stroke: "white",
    opacity: 1,
    selectable: true,
    visible: true,
    transparentCorners: true,
    points: []
}
export default Rectangle;
