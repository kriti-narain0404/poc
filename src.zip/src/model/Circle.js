const Circle = {
   // strokeWidth: 1,
    fill: "#fff",
    stroke: "#666",
    opacity: 1,
    hasControls: false,
    hasBorders: true,
    selectable: true,
    borderColor: "white",
    padding: 3,
    hoverCursor: "pointer"
}
export default Circle;
