const Line = {
    fill: "transparent",
    stroke: "white",
    strokeWidth: 1,
    selectable: true,
    hasControls: false,
    labelType: 'polygonLine',
    score: 0.0,
    hoverCursor: "default"
}
export default Line;

