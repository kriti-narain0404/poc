import keys from "../constants/keyboard.js";
const AuthPinData = {
  authPinErrorMsg: false,
  authPINCode: "",
  getAuthPINError: false,
  isPINMatchError: false,
  secret: "",
  otp: "",
  qr: "",
  isTfaSetupSuccess: false,
  isAccountLocked: false,
  isOtpIncorrect: false
}

export default AuthPinData;
