const Cube = {
   // strokeWidth: 1,
    fill: "#fff",
    stroke: "#666",
    opacity: 0.8,
    hasControls: false,
    hasBorders: true,
    selectable: true,
    borderColor: "white",
    padding: 3,
    hoverCursor: "pointer"
}

export default Cube;
