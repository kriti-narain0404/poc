const POLYGON_LABEL = "polygon";
const Polygon = {
    //strokeWidth: 1,
    fill: "#fff",
    stroke: "#666",
    opacity: 0.5,
    hasControls: false,
    hasBorders: true,
    selectable: true,
    borderColor: "white",
    padding: 3,
    hoverCursor: "pointer"
}

const defaultPolygonPty = {
    selectable: false,
    objectCaching: false,
    opacity: 0.5,
    hasControls: false,
    hasBorders: true,
    borderColor: "transparent",
    cornerStyle: "circle",
    cornerColor: "white",
    cornerSize: 3,
    labelType: POLYGON_LABEL,
    score: 0.0,
}
export { Polygon, defaultPolygonPty };
