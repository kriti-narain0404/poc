
let buildKeymap = function () {
    let map = {};
    for (let k of KEYS) {
        map[k.code] = k;
    }
    return map;
}

const KEYS = [
    {
        'key' : 'ctrl + b',
        'key1': 'ctrl',
        'key2': 'b',
        'key3': '',
        'code': 68,
        'combo': false,
        'desc': 'Draw rectangle mode'
    },
    {
        'key' : 'ctrl + l',
        'key1': 'ctrl',
        'key2': 'l',
        'key3': '',
        'code': 69,
        'combo': false,
        'desc': 'Line mode'
    },
    {
        'key' : 'ctrl + q',
        'key1': 'ctrl',
        'key2': 'q',
        'key3': '',
        'code': 67,
        'combo': false,
        'desc': 'Extreme click mode'
    },
    {
        'key' : 'ctrl + p',
        'key1': 'ctrl',
        'key2': 'p',
        'key3': '',
        'code': null,
        'combo': true,
        'desc': 'Polygon mode'
    },
    {
        'key' : 'ctrl + z',
        'key1': 'ctrl',
        'key2': 'z',
        'key3': '',
        'code': null,
        'combo': true,
        'desc': 'Clear all annotations'
    },
    {
        'key' : 'ctrl + f',
        'key1': 'ctrl',
        'key2': 'f',
        'key3': '',
        'code': null,
        'combo': true,
        'desc': 'Free Hand mode'
    },
    {
        'key' : 'ctrl + y',
        'key1': 'ctrl',
        'key2': 'y',
        'key3': '',
        'code': null,
        'combo': true,
        'desc': 'Dot mode'
    },
    
    {
        'key' : 'ctrl + +',
        'key1': 'ctrl',
        'key2': '+',
        'key3': '',
        'code': 68,
        'combo': false,
        'desc': 'Zoom-in'
    },
    {
        'key' : 'ctrl + -',
        'key1': 'ctrl',
        'key2': '-',
        'key3': '',
        'code': 68,
        'combo': false,
        'desc': 'Zoom-out'
    },
    {
        'key' : 'ctrl + n',
        'key1': 'ctrl',
        'key2': 'n',
        'key3': '',
        'code': null,
        'combo': true,
        'desc': 'Next image'
    },
    {
        'key' : 'delete',
        'key1': 'delete',
        'key2': '',
        'key3': '',
        'code': 46,
        'combo': false,
        'desc': 'Delete object'
    },
    {
        'key' : 'ctrl + s',
        'key1': 's',
        'key2': '',
        'key3': '',
        'code': null,
        'combo': true,
        'desc': 'Save annotations'
    },
    {
        'key' : 'esc',
        'key1': 'esc',
        'key2': '',
        'key3': '',
        'code': 27,
        'combo': false,
        'desc': 'Deselect object'
    },
    {
        'key' : 'p',
        'key1': 'p',
        'key2': '',
        'key3': '',
        'code': null,
        'combo': false,
        'desc': 'Previous image'
    },
    {
        'key' : 'a',
        'key1': 'a',
        'key2': '',
        'key3': '',
        'code': 65,
        'combo': false,
        'desc': 'Previous image'
    },
    {
        'key' : 'd',
        'key1': 'd',
        'key2': '',
        'key3': '',
        'code': 65,
        'combo': false,
        'desc': 'Next image'
    },
    {
        'key' : 'h',
        'key1': 'ctrl',
        'key2': 'h',
        'key3': '',
        'code': null,
        'combo': true,
        'desc': 'Ratio box mode'
    },
    {
        'key' : 'ctrl + i',
        'key1': 'ctrl',
        'key2': 'i',
        'key3': '',
        'code': null,
        'combo': true,
        'desc': 'Free Text mode(Image Tag)'
    },
    {
        'key' : 'shift + arrow',
        'key1': 'shift',
        'key2': 'arrow',
        'key3': '',
        'code': null,
        'combo': true,
        'desc': 'Stretch selected bounding box'
    },

    {
        'key' : 'shift + alt + arrow',
        'key1': 'shift',
        'key2': 'alt',
        'key3': 'arrow',
        'code': null,
        'combo': true,
        'desc': 'Shrink selected bounding box'
    },
    
    
    {
        'key' : 'ctrl + right-arrow',
        'key1': 'ctrl',
        'key2': '→',
        'key3': '',
        'code': 37,
        'combo': false,
        'desc': 'Move selected bounding box left'
    },
    {
        'key' : 'ctrl + up-arrow',
        'key1': 'ctrl',
        'key2': '↑',
        'key3': '',
        'code': 38,
        'combo': false,
        'desc': 'Move selected bounding box  up'
    },
    {
        'key' : 'ctrl + left-arrow',
        'key1': 'ctrl',
        'key2': '←',
        'key3': '',
        'code': 39,
        'combo': false,
        'desc': 'Move selected box right'
    },
    {
        'key' : 'ctrl + down-arrow',
        'key1': 'ctrl',
        'key2': '↓',
        'key3': '',
        'code': 40,
        'combo': false,
        'desc': 'Move selected bounding box down'
    },
    
    
]

const KEY_MAP = buildKeymap()

const keys = {
    KEYS: KEYS,
    KEY_MAP: KEY_MAP
}

export default keys;
