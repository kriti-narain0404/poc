const KEYS = [

  
    {
        'key' : 'N',
        'key1': 'n',
        'key2': '',
        'key3': '',
        'code': null,
        'combo': false,
        'desc': 'Next image'
    },
    {
        'key' : 'delete',
        'key1': 'delete',
        'key2': '',
        'key3': '',
        'code': 46,
        'combo': false,
        'desc': 'Delete object'
    },
    {
        'key' : 's',
        'key1': 's',
        'key2': '',
        'key3': '',
        'code': null,
        'combo': true,
        'desc': 'Save annotations'
    },
    {
        'key' : 'esc',
        'key1': 'esc',
        'key2': '',
        'key3': '',
        'code': 27,
        'combo': false,
        'desc': 'Deselect object'
    },
    {
        'key' : 'p',
        'key1': 'p',
        'key2': '',
        'key3': '',
        'code': null,
        'combo': false,
        'desc': 'Previous image'
    },
      
    
    {
        'key' : 'ctrl + right-arrow',
        'key1': 'ctrl',
        'key2': '→',
        'key3': '',
        'code': 37,
        'combo': false,
        'desc': 'Move selected bounding box left'
    },
    {
        'key' : 'ctrl + up-arrow',
        'key1': 'ctrl',
        'key2': '↑',
        'key3': '',
        'code': 38,
        'combo': false,
        'desc': 'Move selected bounding box up'
    },
    {
        'key' : 'ctrl + left-arrow',
        'key1': 'ctrl',
        'key2': '←',
        'key3': '',
        'code': 39,
        'combo': false,
        'desc': 'Move selected box right'
    },
    {
        'key' : 'ctrl + down-arrow',
        'key1': 'ctrl',
        'key2': '↓',
        'key3': '',
        'code': 40,
        'combo': false,
        'desc': 'Move selected bounding box down'
    },
    {
        'key' : 'shift + alt + right-arrow',
        'key1': 'shift',
        'key2': 'alt',
        'key3': 'arrow',
        'code': null,
        'combo': true,
        'desc': 'change position selected bounding box'
    },
    {
        'key' : 'shift + alt + left-arrow',
        'key1': 'shift',
        'key2': 'alt',
        'key3': 'arrow',
        'code': null,
        'combo': true,
        'desc': 'change position selected bounding box'
    },
    {
        'key' : 'shift + arrow',
        'key1': 'shift',
        'key2': 'arrow',
        'key3': '',
        'code': null,
        'combo': true,
        'desc': 'Stretch selected bounding box'
    },

    {
        'key' : 'shift + alt + arrow',
        'key1': 'shift',
        'key2': 'alt',
        'key3': 'arrow',
        'code': null,
        'combo': true,
        'desc': 'Shrink selected bounding box'
    },
  
    
    
]



export default KEYS;
