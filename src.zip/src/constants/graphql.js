import gql from "graphql-tag";

export const SAVE_OBJ_DETECT_IMAGE = gql`
  mutation SaveObjDetectImage(
    $id: String!
    $project: String!
    $annotations: [AnnotationInput]
    $classwise_data: String!
    $videopath: String!
    $videoid: Int!
    $width: Int!
    $height: Int!
    $userid: Int!
    $projectid: Int!
    $is_blur_mode_active: Boolean
  ) {
    saveObjDetectImage(
      id: $id
      project: $project
      annotations: $annotations
      classwise_data: $classwise_data
      videopath: $videopath
      videoid: $videoid
      width: $width
      height: $height
      userid: $userid
      projectid: $projectid
      is_blur_mode_active: $is_blur_mode_active
    ) {
      id
      project
      videopath
      videoid
      annos_json
    }
  }
`;
// ##########################################################
export const CHECK_SAVE_OBJ_DETECT_IMAGE_FORWARD = gql`
  mutation CheckSaveObjDetectImageForward(
    $id: String!
    $project: String!
    $annotations: [AnnotationInput]
    $videopath: String!
    $videoid: Int!
  ) {
    checkSaveObjDetectImageForward(
      id: $id
      project: $project
      annotations: $annotations
      videopath: $videopath
      videoid: $videoid
    ) {
      id
      project
      videopath
      videoid
      annos_json
    }
  }
`;
export const CHECK_SAVE_OBJ_DETECT_IMAGE_BACKWARD = gql`
  mutation CheckSaveObjDetectImageBackward(
    $id: String!
    $project: String!
    $annotations: [AnnotationInput]
    $videopath: String!
    $videoid: Int!
  ) {
    checkSaveObjDetectImageBackward(
      id: $id
      project: $project
      annotations: $annotations
      videopath: $videopath
      videoid: $videoid
    ) {
      id
      project
      videopath
      videoid
      annos_json
    }
  }
`;
export const CHECK_SAVE_OBJ_DETECT_IMAGE = gql`
  mutation CheckSaveObjDetectImage(
    $id: String!
    $project: String!
    $annotations: [AnnotationInput]
    $videopath: String!
    $videoid: Int!
  ) {
    checkSaveObjDetectImage(
      id: $id
      project: $project
      annotations: $annotations
      videopath: $videopath
      videoid: $videoid
    ) {
      id
      project
      videopath
      videoid
      annos_json
    }
  }
`;
// ##########################################################
export const UPDATE_SETTINGS = gql`
  mutation UpdateSettings($userid: Int!) {
    updateSettings(userid: $userid) {
      status
    }
  }
`;
export const AFTER_SAVE_FRAME = gql`
  mutation AfterSaveFrame($videoid: Int!, $videoname: String!) {
    afterSaveFrame(videoid: $videoid, videoname: $videoname) {
      status
    }
  }
`;
export const SAVE_OBJ_USER_MUTATION = gql`
  mutation SaveUserListObj($userList: [UserListInput]) {
    saveUserListObj(userList: $userList) {
      status
    }
  }
`;

export const SAVE_USER_ID_MUTATION = gql`
  mutation SaveUserId($userId: Int!) {
    saveUserId(userId: $userId) {
      userId
    }
  }
`;

export const SAVE_SETTING_OBJ_DATA = gql`
  mutation SaveSettingObject(
    $userid: Int!
    $projectId: Int!
    $settingObject: [SettingDataInput]
    $predType: String!
    $modelType: String!
    $outputFormat: String!
    $folderPath: String!
    $minHeight: Int!
    $minWidth: Int!
    $annoTip: String!
    $class_added: [ClassAddedDataInput]
    $frames_to_interpolate: Int!
  ) {
    saveSettingObject(
      userid: $userid
      projectId: $projectId
      settingObject: $settingObject
      predType: $predType
      modelType: $modelType
      outputFormat: $outputFormat
      folderPath: $folderPath
      minHeight: $minHeight
      minWidth: $minWidth
      annoTip: $annoTip
      class_added: $class_added
      frames_to_interpolate: $frames_to_interpolate
    ) {
      status
    }
  }
`;

export const SAVE_PREVIEW_VIDEO_DATA_MUTATION = gql`
  mutation SavePreviewVideoData(
    $videoid: Int!
    $videoname: String!
    $taskName: String!
    $total_duration: String!
    $timestamp: [TimeStampInput]
  ) {
    savePreviewVideoData(
      videoid: $videoid
      videoname: $videoname
      taskName: $taskName
      total_duration: $total_duration
      timestamp: $timestamp
    ) {
      status
    }
  }
`;

export const ACKNOWLEDGMENT_DATA_PIPELINE = gql`
  mutation AcknowledgeDataPipeline($projectid: Int!) {
    acknowledgeDataPipeline(projectid: $projectid) {
      acknowledge
    }
  }
`;

export const GET_SETTING_OBJ_DATA = gql`
  query GetSettingObject(
    $userid: Int!
    $projectId: Int!
    $fromFile: Int!
    $video_id: Int!
  ) {
    getSettingObject(
      userid: $userid
      projectId: $projectId
      fromFile: $fromFile
      video_id: $video_id
    ) {
      predType
      modelType
      outputFormat
      folderPath
      minHeight
      minWidth
      annoTip
      settingObject
      classData
      interpolate_data
    }
  }
`;

export const OBJ_DETECT_LABEL_OPT_QUERY = gql`
  query ObjDetectLabelOptQuery($project: String!) {
    objDetectLabelOpts(project: $project) {
      labels {
        value
        text
        color
      }
    }
  }
`;

export const PREV_OBJ_VIDEO_IMG_QUERY = gql`
  mutation PrevObjVideoImage(
    $project: String!
    $videoname: String!
    $videoid: Int!
    $imageid: Int!
    $video_type: Int!
    $file: String!
    $base64Image: String!
    $auto_annotations: [AnnotationInput]
    $copy_mode: String!
    $configure_flag: Int!
    $project_id: Int!
    $userid: Int!
  ) {
    prevObjVideoImage(
      project: $project
      videoname: $videoname
      videoid: $videoid
      imageid: $imageid
      video_type: $video_type
      file: $file
      base64Image: $base64Image
      auto_annotations: $auto_annotations
      copy_mode: $copy_mode
      configure_flag: $configure_flag
      project_id: $project_id
      userid: $userid
    ) {
      id
      is_blur_mode_active
      project
      src
      imageId
      videoId
      videopath
      imagecount
      videoname
      orientation
      annos_json
      width
      height
      annotations {
        id
        label
        bbox {
          id
          annoId
          track
          label
          score
          xmin
          ymin
          xmax
          ymax
          parameters {
            nam
            val
          }
          points {
            id
            x
            y
          }
        }
        polygon {
          id
          annoId
          track
          label
          score
          look
          points {
            id
            x
            y
          }
          parameters {
            nam
            val
          }
        }
      }
      labels {
        color
        text
        value
      }
    }
  }
`;

export const NEXT_OBJ_VIDEO_IMG_QUERY = gql`
  mutation NextObjVideoImage(
    $project: String!
    $videoname: String!
    $videoid: Int!
    $imageid: Int!
    $video_type: Int!
    $file: String!
    $base64Image: String!
    $auto_annotations: [AnnotationInput]
    $copy_mode: String!
    $configure_flag: Int!
    $project_id: Int!
    $userid: Int!
  ) {
    nextObjVideoImage(
      project: $project
      videoname: $videoname
      videoid: $videoid
      imageid: $imageid
      video_type: $video_type
      file: $file
      base64Image: $base64Image
      auto_annotations: $auto_annotations
      copy_mode: $copy_mode
      configure_flag: $configure_flag
      project_id: $project_id
      userid: $userid
    ) {
      id
      is_blur_mode_active
      project
      src
      imageId
      videoId
      videopath
      imagecount
      videoname
      orientation
      annos_json
      video_type
      width
      height
      annotations {
        id
        label
        bbox {
          id
          annoId
          track
          label
          score
          ratio
          xmin
          ymin
          xmax
          ymax
          parameters {
            nam
            val
          }
          points {
            id
            x
            y
          }
        }
        polygon {
          id
          annoId
          track
          label
          score
          look
          points {
            id
            x
            y
          }
          parameters {
            nam
            val
          }
        }
      }
      labels {
        color
        text
        value
      }
    }
  }
`;

export const ALL_VIDEO_MUTATION = gql`
  mutation AllVideoData($userid: Int!, $project_id: Int!) {
    allVideoData(userid: $userid, project_id: $project_id) {
      last_project
      videos {
        videoid
        videoname
        assigneuserid
        assigned
        processed
        submitted
        videodate
        validatorassignid
        annotatorusername
        validatorusername
        no_frames
        no_labeljsons
        video_type
      }
    }
  }
`;

export const ALL_VIDEO_VALIDATOR_MUTATION = gql`
  mutation AllVideoDataValidator(
    $userid: Int!
    $role: String!
    $project_id: Int!
  ) {
    allVideoDataValidator(
      userid: $userid
      role: $role
      project_id: $project_id
    ) {
      last_project
      videos {
        videoid
        videoname
        assigneuserid
        assigned
        processed
        submitted
        videodate
        validatorassignid
        annotatorusername
        validatorusername
        no_frames
        no_labeljsons
        video_type
      }
    }
  }
`;

export const ALL_PROJECT_MUTATION = gql`
  mutation AllProjectData($userid: Int!, $role: String!) {
    allProjectData(userid: $userid, role: $role) {
      projects {
        project_id
        project_name
      }
    }
  }
`;
/////////////////////////////////////

export const UPDATE_PROJECT_MUTATION = gql`
  mutation UpdateProject($userid: Int!, $role: String!, $project_id: Int!) {
    updateProject(userid: $userid, role: $role, project_id: $project_id) {
      project_id
    }
  }
`;
////////////////////////////////////

export const USER_NOTIFICATION_MUTATION = gql`
  mutation UserNotifications($userid: Int!) {
    userNotifications(userid: $userid) {
      notificationcount
    }
  }
`;

export const UPLOAD_VIDEO_MUTATION = gql`
  mutation UploadVideoMutation($videopath: String!) {
    uploadVideoData(videopath: $videopath) {
      videopath
    }
  }
`;
export const GET_VIDEO_DATA_MUTATION = gql`
  mutation GetVideoData($videoid: Int!, $imageid: Int!) {
    getVideoData(videoid: $videoid, imageid: $imageid) {
      videoid
      videoname
      videourl
      videopath
      imageid
      imagecount
    }
  }
`;
export const GET_PREVIEW_VIDEO_DATA_MUTATION = gql`
  mutation GetPreviewVideoData($videoid: Int!, $taskName: String) {
    getPreviewVideoData(videoid: $videoid, taskName: $taskName) {
      videoid
      videoname
      videourl
      total_duration
      timestamp {
        eventtype
        starttime {
          hh
          mm
          ss
        }
        endtime {
          hh
          mm
          ss
        }
      }
    }
  }
`;

export const VIDEO_ASSIGNE_MUTATION = gql`
  mutation VideoAssigneMutation(
    $videoid: [Int!]
    $assignuserid: Int!
    $userid: Int!
  ) {
    updateVideoAssigned(
      videoid: $videoid
      assignuserid: $assignuserid
      userid: $userid
    ) {
      status
    }
  }
`;

export const VIDEO_ASSIGNE_VALIDATOR_MUTATION = gql`
  mutation VideoAssigneValidatorMutation(
    $videoid: [Int!]
    $assignuserid: Int!
    $userid: Int!
  ) {
    updateVideoAssignedValidator(
      videoid: $videoid
      assignuserid: $assignuserid
      userid: $userid
    ) {
      status
    }
  }
`;

export const VIDEO_PROCESSED_MUTATION = gql`
  mutation VideoProcessedMutation($videoid: Int!) {
    updateVideoProcessed(videoid: $videoid) {
      videoid
    }
  }
`;

export const DELETE_VIDEO_MUTATION = gql`
  mutation DeleteVideoMutation($videoid: [Int!]) {
    deleteVideo(videoid: $videoid) {
      videoid
    }
  }
`;

export const ACCEPT_REJECT_VIDEO_MUTATION = gql`
  mutation AcceptRejectVideoMutation(
    $userid: Int!
    $submitted: Int!
    $videoid: Int!
  ) {
    acceptRejectVideo(
      userid: $userid
      submitted: $submitted
      videoid: $videoid
    ) {
      userid
    }
  }
`;

export const GET_METRICS_DATA_MUTATION = gql`
  query GetMetricsData($videoid: Int!) {
    getMetricsDetails(videoid: $videoid) {
      status
    }
  }
`;

export const ALL_IMAGE_DETAIL_MUTATION = gql`
  mutation AllImageDetail($videoid: String!) {
    allImageDetail(videoid: $videoid) {
      images
      jsons
    }
  }
`;
export const SIGNUP_MUTATION = gql`
  mutation SignupMutation(
    $username: String!
    $email: String!
    $password: String!
  ) {
    createUser(username: $username, email: $email, password: $password) {
      id
      username
      email
    }
  }
`;

export const OBJ_LOGIN_USER = gql`
  mutation ObjLoginUser($username: String!, $password: String!) {
    loginUser(username: $username, password: $password) {
      userid
      username
      role
      activated
      last_project
      access_token
      auth_pin
    }
  }
`;

export const OBJ_TFA_LOGIN = gql`
  mutation ObjLoginUser($username: String!, $otp: Int!, $secret: String!) {
    loginTfa(username: $username, otp: $otp, secret: $secret) {
      activated
    }
  }
`;

export const GENERATE_TFA = gql`
  mutation ObjLoginUser($username: String!) {
    generateSecret(username: $username) {
      secret
      qr
    }
  }
`;

export const TFA_WRITE = gql`
  mutation ObjLoginUser($username: String!, $otp: Int!, $secret: String!) {
    writeTfa(username: $username, otp: $otp, secret: $secret) {
      activated
    }
  }
`;

export const IMG_PROC_PARAMETER_SEND = gql`
  mutation DoFloodFill(
    $videoid: Int!
    $imageid: Int!
    $videoname: String!
    $clickPointX: Int!
    $clickPointY: Int!
    $tolerance: Int!
  ) {
    doFloodFill(
      videoid: $videoid
      imageid: $imageid
      videoname: $videoname
      clickPointX: $clickPointX
      clickPointY: $clickPointY
      tolerance: $tolerance
    ) {
      points {
        x
        y
      }
    }
  }
`;

export const RESET_NOTIFICATION_MUTATION = gql`
  mutation ResetNotifications($userid: Int!, $username: String!) {
    resetNotifications(userid: $userid, username: $username) {
      count
      msg
    }
  }
`;
export const IMAGE_UPLOAD_MUTATION = gql`
  mutation ImageUploadCloud(
    $userid: Int!
    $file: String!
    $location: String!
    $base64Image: String!
  ) {
    imageUploadCloud(
      userid: $userid
      file: $file
      location: $location
      base64Image: $base64Image
    ) {
      status
    }
  }
`;

export const FILE_DOWNLOAD_MUTATION = gql`
  mutation FileDownloadCloud(
    $imageid: Int!
    $videoid: Int!
    $imagename: String!
    $serverpath: String!
  ) {
    fileDownloadCloud(
      imageid: $imageid
      videoid: $videoid
      imagename: $imagename
      serverpath: $serverpath
    ) {
      annos_json
    }
  }
`;

export const VIDEO_PUSH_MUTATION = gql`
  mutation VideoPushExecute(
    $userid: Int!
    $username: String!
    $interim_ids: [Int!]
    $final_ids: [Int!]
  ) {
    pushVideo(
      userid: $userid
      username: $username
      interim_ids: $interim_ids
      final_ids: $final_ids
    ) {
      videoids
      count
    }
  }
`;
/*export const CREATE_USER_MUTATION = gql`
  mutation CreateUserMutation($name: String!, $email: String!, $password: String!) {
    createUser(
      name: $name,
      authProvider: {
        email: {
          email: $email,
          password: $password
        }
      }
    ) {
      id
    }

    signinUser(email: {
      email: $email,
      password: $password
    }) {
      token
      user {
        id
      }
    }
  }
`;
export const SIGNIN_USER_MUTATION = gql`
  mutation SigninUserMutation($email: String!, $password: String!) {
    signinUser(email: {
      email: $email,
      password: $password
    }) {
      token
      user {
        id
      }
    }
  }
`;*/

/*export const NEXT_OBJ_VIDEO_IMG_QUERY = gql`
query NextObjVideoImage($project:String!,$videoid: Int!,$imageid: Int) {
    nextObjVideoImage(project: $project,videoid: $videoid, imageid: $imageid) {
        id
        project
        src
        ImageDetail {
            imageid
            imagename
            imagepath
            imagelocation
        }

    }
  }
`;*/

export const USERS_ASSIGNATION_LIST = gql`
  mutation ObjLoginUser($userid: Int!, $role: String!, $projectId: Int!) {
    usersAssignationList(userid: $userid, role: $role, projectId: $projectId) {
      users {
        userid
        username
        role
        activated
      }
    }
  }
`;

export const GET_OBJ_USER_MUTATION = gql`
  query GetUserListObj($userid: Int!, $proId: Int!) {
    getUserListObj(userid: $userid, proId: $proId) {
      userList {
        project
        project_id
        changed
        projectEditmode
        username
        editmode
        role
        changed
        validators {
          status_1
          status_2
          username
          editmode
          role
          annotators {
            status_1
            status_2
            username
            editmode
            role
          }
        }
      }
      workDiv {
        userid
        projectid
        sourcebucket
        sourcepath
        destBucket
        destpath
        projectType
        divisionType
        requiredays
        avgFrame
        availannotator
        annoratio
        availdays
        productivity
        totalFrame
        requireannotator
        availvalidator
        conversionScript
        time
        frequency
        filetype
        pipelineseq
        status
      }
    }
  }
`;

export const SAVE_OBJ_SCRIPT_MUTATION = gql`
  mutation SaveScriptObj($scriptList: [ScriptDataInput]) {
    saveScriptObj(scriptList: $scriptList) {
      scriptList {
        scriptname
        flag
      }
    }
  }
`;

export const INIT_PROJECT = gql`
  mutation InitProject(
    $userid: Int!
    $folderpath: String!
    $projectType: String!
    $divisionType: String!
    $availdays: Int!
    $requiredays: Int!
    $productivity: Int!
    $avgFrame: Int!
    $totalFrame: Int!
    $availannotator: Int!
    $requireannotator: Int!
    $annoratio: Int!
    $availvalidator: Int!
    $scriptList: [ScriptDataInput]
    $conversionScripts: [String!]
    $conversionScript: String!
  ) {
    initProject(
      userid: $userid
      folderpath: $folderpath
      projectType: $projectType
      divisionType: $divisionType
      availdays: $availdays
      requiredays: $requiredays
      productivity: $productivity
      avgFrame: $avgFrame
      totalFrame: $totalFrame
      availannotator: $availannotator
      requireannotator: $requireannotator
      annoratio: $annoratio
      availvalidator: $availvalidator
      scriptList: $scriptList
      conversionScripts: $conversionScripts
      conversionScript: $conversionScript
    ) {
      count
      msg
    }
  }
`;

export const GET_PROJECT_DETAILS = gql`
  mutation GetProjectDetails($projectType: String!) {
    getProjectDetails(projectType: $projectType) {
      msg
    }
  }
`;
export const INIT_PROJECT_REPORT = gql`
  mutation InitProjectReport($userid: Int!) {
    initProjectReport(userid: $userid) {
      text
    }
  }
`;

export const VIDEO_TO_FRAMES = gql`
  mutation VideoToFrames($folderpath: String!) {
    videoToFrames(folderpath: $folderpath) {
      path
      frames_count
      json_count
      scripts_list
      conversion_scripts
    }
  }
`;

export const GET_PRODUCTIVITY_METRICS_QUERY = gql`
  mutation GetProductivityMetricsData(
    $userid: Int!
    $username: String!
    $userrole: String!
    $from_date: String!
    $to_date: String!
    $pid: Int!
    $active_tab: String!
  ) {
    getProductivityMetrics(
      userid: $userid
      username: $username
      userrole: $userrole
      from_date: $from_date
      to_date: $to_date
      p_id: $pid
      active_tab: $active_tab
    ) {
      productivity_data
    }
  }
`;

export const REOPEN_VIDEO = gql`
  mutation reopenVideo($videoid: [Int!]) {
    reopenVideo(videoid: $videoid) {
      status
    }
  }
`;

export const GET_PERFORMANCE_CHART = gql`
  mutation GetPerformanceChartData(
    $userid: Int!
    $username: String!
    $userrole: String!
    $pid: Int!
  ) {
    getPerformanceChart(
      userid: $userid
      username: $username
      userrole: $userrole
      p_id: $pid
    ) {
      status
    }
  }
`;
export const CHANGE_ORIENTATION = gql`
  mutation changeOrientation(
    $videoname: String!
    $filename: String!
    $orientation: Int!
  ) {
    changeOrientation(
      videoname: $videoname
      filename: $filename
      orientation: $orientation
    ) {
      status
    }
  }
`;
export const GET_PROJECT_CONFIG_MUTATION = gql`
  mutation GetProjectConfig($projectid: Int!) {
    getProjectConfig(projectid: $projectid) {
      projectType
      folderpath
      divisionType
      availdays
      requiredays
      productivity
      avgFrame
      totalFrame
      availannotator
      requireannotator
      annoratio
      availvalidator
      scriptList {
        scriptname
        flag
      }
      conversionScript
      conversionScripts
    }
  }
`;

export const GET_PIPELINE_CONFIG_MUTATION = gql`
  mutation GetPipelineConfig($projectid: Int!) {
    getPipelineConfig(projectid: $projectid) {
      pipeline_data
    }
  }
`;

export const SIGNUP = gql`
  mutation Signup(
    $username: String!
    $password: String!
    $first_name: String!
    $last_name: String!
    $mobile_number: String!
    $role: String!
    $security_question: String!
    $security_answer: String!
    $auto_captcha: Int!
    $user_captcha: Int!
  ) {
    signup(
      username: $username
      password: $password
      first_name: $first_name
      last_name: $last_name
      mobile_number: $mobile_number
      role: $role
      security_question: $security_question
      security_answer: $security_answer
      auto_captcha: $auto_captcha
      user_captcha: $user_captcha
    ) {
      username
      role
      userid
      first_name
      last_name
      mobile_number
      newuser
      auto_captcha
      user_captcha
    }
  }
`;
export const GETQUESTION = gql`
  mutation GetQuestion($username: String!) {
    getquestion(username: $username) {
      question
      answer
    }
  }
`;
export const RESETPASSWORD = gql`
  mutation ResetPassword($username: String!, $newPass: String!) {
    resetpassword(username: $username, newPass: $newPass) {
      status
    }
  }
`;

export const NEXT_OBJ_MASK_IMG_QUERY = gql`
  mutation NextObjMaskImage($imageid: Int!, $videoname: String!) {
    nextObjMaskImage(imageid: $imageid, videoname: $videoname) {
      imageId
      imagename
      videoname
      src
      encoded_string
      imagecount
    }
  }
`;

export const SAVE_MASK_MUTATION = gql`
  mutation SaveMask(
    $imageid: Int!
    $videoid: Int!
    $imagename: String!
    $serverpath: String!
    $base64Image: String!
  ) {
    saveMask(
      imageid: $imageid
      videoid: $videoid
      imagename: $imagename
      serverpath: $serverpath
      base64Image: $base64Image
    ) {
      annos_json
    }
  }
`;

// ***************************** //
// 3D GraphQL Queries & Mutations //

export const LOAD_JSON_CONFIG_MUTATION = gql`
  mutation JsonConfigLoader3D($video_id: Int!) {
    jsonConfigLoader3d(video_id: $video_id) {
      jsonData
    }
  }
`;

export const SAVE_JSON_DATA_MUTATION = gql`
  mutation SaveJsonData3d(
    $video_id: Int!
    $image_id: Int!
    $json_data: String!
    $project_id: Int!
    $auto_annotations: String!
  ) {
    saveJsonData3d(
      video_id: $video_id
      image_id: $image_id
      json_data: $json_data
      project_id: $project_id
      auto_annotations: $auto_annotations
    ) {
      status
    }
  }
`;

export const UI_VIEWER_MUTATION = gql`
  mutation UiViewer3d(
    $video_id: Int!
    $image_id: Int!
    $signal: Int!
    $project_id: Int
    $auto_annotations: String!
    $configure_type: Int!
    $copy_direction: String!
  ) {
    uiViewer3d(
      video_id: $video_id
      image_id: $image_id
      signal: $signal
      project_id: $project_id
      auto_annotations: $auto_annotations
      configure_type: $configure_type
      copy_direction: $copy_direction
    ) {
      images_data
      annos_json
      pcd_data
      image_id
      image_name
    }
  }
`;

export const GET_TEXT_MODERATION_QUERY = gql`
  mutation getTextModerationObject(
    $project_id: Int!
    $userid: Int!
    $videoid: Int!
    $video_type: Int!
    $file: String!
  ) {
    getTextModerationObject(
      project_id: $project_id
      userid: $userid
      videoid: $videoid
      video_type: $video_type
      file: $file
    ) {
      id
      videoname
      text
      annos
      fileId
      videoId
      video_type
    }
  }
`;

export const SAVE_TEXT_MODERATION_QUERY = gql`
  mutation saveTextModerationObject(
    $project_id: Int!
    $userid: Int!
    $videoid: Int!
    $annos: String!
    $video_type: Int!
    $file: String!
  ) {
    saveTextModerationObject(
      project_id: $project_id
      userid: $userid
      videoid: $videoid
      annos: $annos
      video_type: $video_type
      file: $file
    ) {
      id
      videoname
      text
      annos
      fileId
      videoId
      video_type
    }
  }
`;
