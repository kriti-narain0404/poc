<template>
  <v-app light>
    <main>
        <section class="">
            <div style="text-align: center;">
            Select Validator:
            <label>
            <select id="validators" style="border: 1px solid black; webkit-appearance: listitem !important;">
            </select>
            </label>
            </div>
            <div style="display:none;">
            <input type="checkbox" id="sort">
            Toggle sort
            </div>
            <svg id="chart" width="1000" height="450" style="margin-left: 100px;"></svg>
            <svg id="chart2" width="1000" height="450" style="margin-left: 100px;"></svg>
          </section>
    </main>
  </v-app>
</template>
<script src="./ToolsJS/Productivity.js"></script>
<style scoped>

</style>
