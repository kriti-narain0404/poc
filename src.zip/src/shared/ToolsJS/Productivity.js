import axios from "axios";
import accuracyObject from "@/components/accuracyObject";
import accuracyVideo from "@/components/accuracyVideo";
import changesVideo from "@/components/changesVideo";
import changesObject from "@/components/changesObject";
import { ALL_VIDEO_QUERY } from "../../constants/graphql";
import { GET_METRICS_DATA_MUTATION } from "../../constants/graphql";
import { ALL_IMAGE_DETAIL_MUTATION } from "../../constants/graphql";
import Appfooter from "../../shared/Appfooter.vue";
import ProductivityHeader from "../../shared/Productivity.vue";
import * as d3 from 'd3';

export default {
  name: "Productivity",
  components: {
    "productivity-component": ProductivityHeader
  },
  props: [],
  data() {
  },
  computed: {
  },
  methods: {
    productivity_chart(csv) {
			var keys = csv.columns.slice(2);
			console.log('keys', keys)

			var val_list = ["All"].concat(csv.map(d => d.Validator))
			var validator = [...new Set(val_list)]
			var annotator = [...new Set(csv.map(d => d.Annotator))]

			var options = d3.select("#validators").selectAll("option")
				.data(validator)
        .enter().append("option")
				.text(d => d)

			var svg = d3.select("#chart"),
				margin = { top: 35, left: 35, bottom: 0, right: 0 },
				width = +svg.attr("width") - margin.left - margin.right,
				height = +svg.attr("height") - margin.top - margin.bottom;

      var x = d3.scaleBand()
				.range([margin.left, width - margin.right])
				.padding(0.1)

			var y = d3.scaleLinear()
				.rangeRound([height - margin.bottom, margin.top])

			var color = d3.scaleOrdinal()
				.range(["#99c2ff", "#99ffbb"]);

      // Add the x Axis
			var xAxis = svg.append("g")
				.attr("transform", `translate(0,${height - margin.bottom})`)
        .attr("class", "x-axis")
        
      // text label for the x axis
      svg.append("text")             
      .attr("transform",
            "translate(" + (width/2) + " ," + 
                          (height + margin.top) + ")")
      .style("text-anchor", "middle")
      .text("Annotator Name");

      // Add the y Axis
			var yAxis = svg.append("g")
				.attr("transform", `translate(${margin.left},0)`)
        .attr("class", "y-axis")
        
      // text label for the y axis
      svg.append("text")
      .attr("transform", "rotate(-90)")
      .attr("y", -5)
      .attr("x",0 - (height / 2))
      .attr("dy", "1em")
      .style("text-anchor", "middle")
      .text("Annotation Count");  

			var z = d3.scaleOrdinal()
				.range(["#c2c2d6", "#99c2ff"])
				.domain(keys);

			update(d3.select("#validators").property("value"), 750)

			function update(input, speed) {
				if (input == "All") {
					var data = '';
					data = csv
				} else {
					var data = '';
					data = csv.filter(f => f.Validator == input)
				}
				console.log(data);

				data.forEach(function (d) {
					d.total = d3.sum(keys, k => +d[k])
					return d
				})

				y.domain([0, d3.max(data, d => d3.sum(keys, k => +d[k]))]).nice();

				svg.selectAll(".y-axis").transition().duration(speed)
					.call(d3.axisLeft(y).ticks(null, "s"))

				data.sort(d3.select("#sort").property("checked")
					? (a, b) => b.total - a.total
					: (a, b) => annotator.indexOf(a.Annotator) - annotator.indexOf(b.Annotator))

				x.domain(data.map(d => d.Annotator));

				svg.selectAll(".x-axis").transition().duration(1000)
					.call(d3.axisBottom(x).tickSizeOuter(0))

				var group = svg.selectAll("g.layer")
					.data(d3.stack().keys(keys)(data), d => d.key)

				group.exit().remove()

				group.enter().append("g")
					.classed("layer", true)
					.attr("fill", d => z(d.key));

				var bars = svg.selectAll("g.layer").selectAll("rect")
					.data(d => d, e => e.data.Annotator, a => e[0]);

				// Define the div for the tooltip
				var div = d3.select("body").append("div")
					.attr("class", "tooltip")
					.style("opacity", 0);

				bars.exit().remove()

				bars.enter().append("rect")
					.attr("width", x.bandwidth())
					.merge(bars)
					.on('click', function (d) {
						productivity_chart_2(d.data.Annotator)
					})
					.attr("x", d => x(d.data.Annotator))
					.attr("y", d => y(d[1]))
					.attr("height", d => y(d[0]) - y(d[1]))
					.attr("annotator", a => a)
					.on("mouseover", function (d) {
						div.transition()
							.duration(200)
							.style("opacity", 1);
						div.html(d.data.Success)
							.style("left", (d3.event.pageX) + "px")
							.style("top", (d3.event.pageY - 28) + "px");
					})
					.on("mouseout", function (d) {
						div.transition()
							.duration(500)
							.style("opacity", 0);
					});

				bars.transition().duration(speed)

				var text = svg.selectAll(".text")
					.data(data, d => d.Annotator);

				text.exit().remove()

				text.enter().append("text")
					.attr("class", "text")
					.attr("text-anchor", "middle")
					.merge(text)
					.transition().duration(speed)
					.attr("x", d => x(d.Annotator) + x.bandwidth() / 2)
					.attr("y", d => y(d.total) - 5)
					.text(d => d.total)

				// Draw legend
				// var legend = svg.selectAll(".legend")
				// .data(color)
				// .enter().append("g")
				// .attr("class", "legend")
				// .attr("transform", function(d, i) { return "translate(30," + i * 19 + ")"; });

				// legend.append("rect")
				// .attr("x", width - 18)
				// .attr("width", 18)
				// .attr("height", 18)
				// .style("fill", function(d, i) {return color.slice().reverse()[i];});

				// legend.append("text")
				// .attr("x", width + 5)
				// .attr("y", 9)
				// .attr("dy", ".35em")
				// .style("text-anchor", "start")
				// .text(function(d, i) { 
				// 	switch (i) {
				// 	case 0: return "Success";
				// 	case 1: return "Fail";
				// 	}
				// });

			}
			var select = d3.select("#validators")
				.on("change", function () {
					update(this.value, 750)
				})

			var checkbox = d3.select("#sort")
				.on("click", function () {
					update(select.property("value"), 750)
        })
  
      function productivity_chart_2(value) {
        d3.csv("static/productivity2.csv").then(d => chart(d))
        console.log(d3.select("#chart2"))

        function chart(csv) {
            var keys = csv.columns.slice(2);

          var annotator = [...new Set(csv.map(d => d.Annotator))]
          var date = [...new Set(csv.map(d => d.Date))]

          var svg = d3.select("#chart2"),
            margin = { top: 35, left: 35, bottom: 0, right: 0 },
            width = +svg.attr("width") - margin.left - margin.right,
            height = +svg.attr("height") - margin.top - margin.bottom;

          var x = d3.scaleBand()
            .range([margin.left, width - margin.right])
            .padding(0.1)

          var y = d3.scaleLinear()
            .rangeRound([height - margin.bottom, margin.top])

          var color = d3.scaleOrdinal()
            .range(["#99c2ff", "#99ffbb"]);

          // Add the x Axis
          var xAxis = svg.append("g")
            .attr("transform", `translate(0,${height - margin.bottom})`)
            .attr("class", "x-axis")

          // text label for the x axis
          svg.append("text")             
          .attr("transform",
                "translate(" + (width/2) + " ," + 
                              (height + margin.top) + ")")
          .style("text-anchor", "middle")
          .text("Date");

          // Add the y Axis
          var yAxis = svg.append("g")
            .attr("transform", `translate(${margin.left},0)`)
            .attr("class", "y-axis")

          // text label for the y axis
          svg.append("text")
          .attr("transform", "rotate(-90)")
          .attr("y", -5)
          .attr("x",0 - (height / 2))
          .attr("dy", "1em")
          .style("text-anchor", "middle")
          .text("Annotation Count");  

          var z = d3.scaleOrdinal()
            .range(["#c2c2d6", "#99c2ff"])
            .domain(keys);

          update(value, annotator, date, 750)

          function update(value, input, date, speed) {
            if (value) {
              var data = csv.filter(f => f.Annotator == value)
            }

            data.forEach(function (d) {
              d.total = d3.sum(keys, k => +d[k])
              return d
            })
            console.log(data)

            y.domain([0, d3.max(data, d => d3.sum(keys, k => +d[k]))]).nice();

            svg.selectAll(".y-axis").transition().duration(speed)
              .call(d3.axisLeft(y).ticks(null, "s"))

            // data.sort(d3.select("#sort").property("checked")
            // 	? (a, b) => b.total - a.total
            // 	: (a, b) => date.indexOf(a.Date) - date.indexOf(b.Date))

            x.domain(data.map(d => d.Date));

            svg.selectAll(".x-axis").transition().duration(1000)
              .call(d3.axisBottom(x).tickSizeOuter(0))

            // 				svg.append('g')
            //    .attr('id', '-x-axis')
            //    .attr('class', 'x axis')
            //    .attr('transform', 'translate(0,' + 40 + ')')
            //    .call(xAxis);


            var group = svg.selectAll("g.layer")
              .data(d3.stack().keys(keys)(data), d => d.key)

            group.exit().remove()

            group.enter().append("g")
              .classed("layer", true)
              .attr("fill", d => z(d.key));

            var bars = svg.selectAll("g.layer").selectAll("rect")
              .data(d => d, e => e.data.Annotator);

            bars.exit().remove()

            bars.enter().append("rect")
              .attr("width", x.bandwidth())
              .merge(bars)
              .transition().duration(speed)
              .attr("x", d => x(d.data.Date))
              .attr("y", d => y(d[1]))
              .attr("height", d => y(d[0]) - y(d[1]))

            var text = svg.selectAll(".text")
              .data(data, d => d.Date);

            text.exit().remove()

            text.enter().append("text")
              .attr("class", "text")
              .attr("text-anchor", "middle")
              .merge(text)
              .transition().duration(speed)
              .attr("x", d => x(d.Date) + x.bandwidth() / 2)
              .attr("y", d => y(d.total) - 5)
              .text(d => d.total)
          }

          // var checkbox = d3.select("#sort")
          // 	.on("click", function () {
          // 		update(select.property("value"), 750)
          // 	})
        }
      }
    }
  }, // methods end
  'apollo': {
    getProductivityMetrics: {
      query: GET_PRODUCTIVITY_METRICS_QUERY,
      variables() {
        const userid = 3;
        const username = 'demouser';
        const userrole = 'annotator';
        const from_date = '2019-09-20';
        const to_date = '2019-09-28';
        return {
          userid,
          username,
          userrole,
          from_date,
          to_date
        };
      },
      result({ data, loader, networkStatus }) {
      // const csv = require("@/assets/csv/productivity1.csv")
        console.log("getMetricsDetails")
        console.log(data.getProductivityMetrics.status);
          d3.csv("static/productivity1.csv")
          .then(d => this.productivity_chart(d))
      }
    }
  }
};
