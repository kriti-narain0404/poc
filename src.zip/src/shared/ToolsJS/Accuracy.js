import axios from "axios";
import accuracyObject from "@/components/accuracyObject";
import accuracyVideo from "@/components/accuracyVideo";
import changesVideo from "@/components/changesVideo";
import changesObject from "@/components/changesObject";
import { ALL_VIDEO_QUERY } from "../../constants/graphql";
import { GET_METRICS_DATA_MUTATION } from "../../constants/graphql";
import { ALL_IMAGE_DETAIL_MUTATION } from "../../constants/graphql";
import Appfooter from "../../shared/Appfooter.vue";
import AccuracyHeader from "../../shared/Accuracy.vue";

export default {
  name: "Accuracy",
  components: {
    "accuracy-component": AccuracyHeader
  },
  props: [],
  data() {
    return {
    };
  },
  computed: {}


};
