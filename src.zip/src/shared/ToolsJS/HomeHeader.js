import { RESET_NOTIFICATION_MUTATION } from "../../constants/graphql";
import { USER_NOTIFICATION_MUTATION } from "../../constants/graphql";
import SettingService from "../../services/SettingService.js";
import { VIDEO_PUSH_MUTATION } from "../../constants/graphql";
import { IMAGE_UPLOAD_MUTATION } from "../../constants/graphql";
import { validationMixin } from "vuelidate";
import { required } from "vuelidate/lib/validators";

var count = 0;
var checkValue = false;
export default {
  name: "homeHeader",
  mixins: [validationMixin],
  validations: {
    filePath: { required },
  },
  data() {
    return {
      currentScreen: "",
      base64Image: "",
      userId: 1,
      username: "",
      role: "",
      folderPath: "",
      homePath: "/home",
      dashBoardPath: "/dashboard",
      settingPath: "/setting",
      userPath: "/userList",
      //textEditorPath: "/textEditor",
      notificationCount: 0,
      showDialogNoVideos: false,
      showDialogHavingVideos: false,
      downloadDialog: false,
      uploadDialog: false,
      isQueryError: false,
      queryErrorResult: "",
      submitNotification: false,
      mainItems: [],
      updatedMainitems: [],
      file: "",
      fileName: "",
      filePath: "",
      partialselectedList: [],
      finalselectedList: [],
      isSubmitSuccessful: false,
      showUploadMsg: false,
      initials: "",
      notificationInterval: 25000,
      // projectId: 0,
    };
  },

  computed: {
    pathErrors() {
      const errors = [];
      if (!this.$v.filePath.$dirty) return errors;
      !this.$v.filePath.required && errors.push("Folder Path is required.");
      return errors;
    },
  },

  methods: {
    getFile: function() {
      try {
        this.fileName = this.$refs.file.files[0].name;
        this.file = this.$refs.file.files[0];
      } catch (error) {
        console.log("Error:", error);
      }
    },
    getImageBase64: function(file, onLoadCallback) {
      try {
        return new Promise(function(resolve, reject) {
          var reader = new FileReader();
          reader.onload = function() {
            resolve(reader.result);
          };
          reader.onerror = reject;
          reader.readAsDataURL(file);
        });
      } catch (error) {
        console.log("Error:", error);
      }
    },
    uploadFile: async function() {
      try {
        var self = this;
        var promise = this.getImageBase64(this.file);
        this.base64Image = await promise;
        this.$v.$touch();
        if (this.file != "" && this.filePath != "") {
          var div = document.createElement("div");
          var img = document.createElement("img");
          img.src = "static/loading.gif";
          img.style.cssText = "margin-top:20%;width:5%;height:10%;";
          div.style.cssText =
            "width: 100%;height: 100%;top: 0px;left: 0px;position: fixed;display: block;opacity: 0.7;background-color: #fff;z-index: 99;text-align: center";
          div.appendChild(img);
          document.body.appendChild(div);
          this.$apollo
            .mutate({
              mutation: IMAGE_UPLOAD_MUTATION,
              variables: {
                userid: this.userId,
                file: this.fileName,
                location: this.filePath,
                base64Image: this.base64Image,
              },
            })
            .then((data) => {
              div.style.display = "none";
              this.isQueryError = false;
              if (data.data.imageUploadCloud.status == false) {
                this.uploadDialog = false;
                this.showUploadMsg = true;
                setTimeout(function() {
                  self.showUploadMsg = false;
                }, 1000);
              } else {
                location.reload();
              }
            })
            .catch((error) => {
              div.style.display = "none";
              this.isQueryError = true;
              this.queryErrorResult = /:(.+)/.exec(error.message)[1];
            });
        }
      } catch (error) {
        div.style.display = "none";
        console.log("Error:", error);
      }
    },
    selectedVideo: function(event, id) {
      try {
        if (!event.target.checked) {
          this.count--;
          var finalindex = this.finalselectedList.indexOf(id);
          this.finalselectedList.splice(finalindex, 1);
        } else {
          this.count++;
          this.finalselectedList.push(id);
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },
    getAnnoVideo: function() {
      try {
        this.mainItems = [];
        this.updatedMainitems = [];
        this.mainItems = SettingService.getAllVideo();
        for (var i = 0; i < this.mainItems.length; i++) {
          if (this.mainItems[i].video_type == 0) {
            this.updatedMainitems.push(this.mainItems[i]);
          }
        }
        this.submitVideoList();
      } catch (error) {
        console.log("Error:", error);
      }
    },
    finalSubmit: function() {
      try {
        var div = document.createElement("div");
        var img = document.createElement("img");
        img.src = "static/loading.gif";
        img.style.cssText = "margin-top:20%;width:5%;height:10%;";
        div.style.cssText =
          "width: 100%;height: 100%;top: 0px;left: 0px;position: fixed;display: block;opacity: 0.7;background-color: #fff;z-index: 99;text-align: center";
        div.appendChild(img);
        document.body.appendChild(div);
        this.$apollo
          .mutate({
            mutation: VIDEO_PUSH_MUTATION,
            variables: {
              userid: this.userId,
              username: this.username,
              interim_ids: this.partialselectedList,
              final_ids: this.finalselectedList,
            },
          })
          .then((data) => {
            div.style.display = "none";
            var self = this;
            this.isQueryError = false;
            if (data.data.pushVideo.count == 0) {
              this.noFilesSubmitted = true;
              setTimeout(function() {
                self.noFilesSubmitted = false;
                location.reload();
              }, 1000);
            } else {
              this.isSubmitSuccessful = true;
              this.totalModifiedFile = data.data.pushVideo.count;
              setTimeout(function() {
                self.isSubmitSuccessful = false;
              }, 1000);
              setTimeout(function() {
                location.reload();
              }, 1050);
            }
          })
          .catch((error) => {
            div.style.display = "none";
            this.isQueryError = true;
            this.queryErrorResult = /:(.+)/.exec(error.message)[1];
          });
      } catch (error) {
        console.log("Error:", error);
      }
    },
    savefolder: function() {
      try {
        var div = document.createElement("div");
        this.$apollo
          .mutate({
            mutation: RESET_NOTIFICATION_MUTATION,
            variables: {
              userid: this.userId,
              username: this.username,
            },
          })
          .then((data) => {
            location.reload();
          })
          .catch((error) => {
            div.style.display = "none";
            this.isQueryError = true;
            this.queryErrorResult = /:(.+)/.exec(error.message)[1];
          });
      } catch (error) {
        console.log("Error:", error);
      }
    },
    callDashBoard: function(event) {
      try {
        this.dashBoardPath = event;
        this.$router.push({ path: this.dashBoardPath });
      } catch (error) {
        console.log("Error:", error);
      }
    },

    getUserNotifications: function() {
      try {
        this.$apollo
          .mutate({
            mutation: USER_NOTIFICATION_MUTATION,
            variables: {
              userid: this.userId,
            },
          })
          .then((data) => {
            this.notificationCount =
              data.data.userNotifications.notificationcount;
          })
          .catch((error) => {
            this.isQueryError = true;
            this.queryErrorResult = /:(.+)/.exec(error.message)[1];
          });
      } catch (error) {
        console.log("Error:", error);
      }
    },
    refreshNotifications: function() {
      var self = this;
      setInterval(function() {
        self.getUserNotifications();
      }, this.notificationInterval);
    },

    callInbox: function() {
      // this.userId = this.$route.query.plan;
      this.userId = SettingService.getSelectedUserId();
      this.username = SettingService.getSelectedUserName();
      this.initials = this.username[0];
      this.role = SettingService.getSelectedUserRole();
      // this.getUserNotifications();
      return this.$parent.callInbox;
    },
    //   highlightCurrentScreen(){
    //   let currentScreen = this.$router.currentRoute.path;

    //   if(currentScreen == this.dashBoardPath){
    //     $("#call-dashboard-btn").addClass("header-btn--selected");
    //   }
    //   if(currentScreen == this.homePath){
    //     $("#call-home-btn").addClass("header-btn--selected");
    //   }
    //   if(currentScreen == this.settingPath){
    //     $("#call-setting-btn").html("header-btn--selected");
    //   }
    //   if(currentScreen == this.userPath){
    //     $("#call-project-btn").addClass("header-btn--selected");
    //   }
    // },
    submitVideoList: function() {
      try {
        this.partialselectedList = [];
        this.finalselectedList = [];
        for (var i = 0; i < this.mainItems.length; i++) {
          this.partialselectedList.push(this.mainItems[i].videoid);
          if (this.mainItems[i].no_frames == this.mainItems[i].no_labeljsons) {
            this.finalselectedList.push(this.mainItems[i].videoid);
          }
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },

    callHome: function(link) {
      this.$router.push({ path: link });
    },
    callSetting: function(link) {
      this.$router.push({ path: link });
    },
    callUser: function(link) {
      this.$router.push({ path: link });
    },
    // callTextEditor: function(link) {
    //   this.$router.push({ path: link });
    // },
  },
  mounted: function() {
    this.callInbox();
    this.refreshNotifications();
    // this.highlightCurrentScreen()
  },
};
