<template>
	<v-toolbar class="toolbar-container" id="homeHeader">
		<v-toolbar-title class="toolbar-title">
			<img
				@click="callHome(homePath)"
				src="../assets/icon/logo2.png"
				class="toolbar-title--image"
			/>
		</v-toolbar-title>

		<v-toolbar-items class="toolbar-item-container">
			<v-btn
				flat
				@click="callHome(homePath)"
				class="uppercase navigation-btn white header-btn"
				id="call-home-btn"
			>
				<img class="btn-icon" src="../assets/icon/inbox-2.svg" />
				<span class="icon-heading-margin">Inbox</span>
			</v-btn>

			<v-btn
				flat
				@click="callDashBoard(dashBoardPath)"
				class="uppercase navigation-btn white header-btn"
				id="call-dashboard-btn"
				v-if="role != 'ANNOTATOR'"
			>
				<img class="btn-icon" src="../assets/icon/dashboard.svg" /><span
					class="icon-heading-margin"
					>DashBoard</span
				>
			</v-btn>

			<v-btn
				flat
				@click="callSetting(settingPath)"
				class="uppercase navigation-btn white header-btn"
				id="call-setting-btn"
			>
				<img class="btn-icon" src="../assets/icon/setting-2.svg" /><span
					class="icon-heading-margin"
					>Settings</span
				>
			</v-btn>
			<!-- <v-btn
        flat
        @click="callTextEditor(textEditorPath)"
        class="uppercase navigation-btn white header-btn"
        id="call-setting-btn"
      >
        <img class="btn-icon" src="../assets/icon/textEditor.svg" /><span
          class="icon-heading-margin"
          >Text Editor</span
        >
      </v-btn> -->

			<v-btn
				flat
				@click="callUser(userPath)"
				class="uppercase navigation-btn white header-btn"
				id="call-project-btn"
				v-if="role == 'ADMIN'"
			>
				<img
					class="btn-icon"
					src="../assets/icon/blocks-group-svgrepo-com.svg"
				/><span class="icon-heading-margin">Project</span>
			</v-btn>
		</v-toolbar-items>
		<div class="download-corner">
			<v-menu offset-y>
				<v-btn flat slot="activator" class="uppercase white avatar_menu-btn">
					<div
						:class="[notificationCount > 0 ? 'show' : 'notification-dot']"
						class="notification-dot blink"
					></div>
					<span class="avatar-title" v-if="role == 'ANNOTATOR'"
						><v-avatar color="orange" size="22"
							><span class="black--text text-h5">{{ initials }}</span></v-avatar
						><img class="menu-arrow" src="../assets/icon/angle.svg"
					/></span>
					<span class="avatar-title" v-if="role == 'VALIDATOR'"
						><v-avatar color="orange" size="22"
							><span class="black--text text-h5">{{ initials }}</span></v-avatar
						><img class="menu-arrow" src="../assets/icon/angle.svg"
					/></span>
					<span class="avatar-title" v-if="role == 'ADMIN'"
						><v-avatar color="orange" size="22"
							><span class="black--text text-h5">{{ initials }}</span></v-avatar
						><img class="menu-arrow" src="../assets/icon/angle.svg"
					/></span>
				</v-btn>
				<div class="account-option-popup">
					<v-btn disabled flat class="uppercase white">
						<span class="avatar-title" v-if="role == 'ANNOTATOR'"
							><div>
								<v-avatar color="orange" size="22"
									><span class="black--text text-h5">{{
										initials
									}}</span></v-avatar
								>
							</div>
							<div>
								{{ username }} <br />
								Annotator
							</div></span
						>
						<span class="avatar-title" v-if="role == 'VALIDATOR'"
							><div>
								<v-avatar color="orange" size="22"
									><span class="black--text text-h5">{{
										initials
									}}</span></v-avatar
								>
							</div>
							<div>
								{{ username }} <br />
								Validator
							</div></span
						>
						<span class="avatar-title" v-if="role == 'ADMIN'"
							><div>
								<v-avatar color="orange" size="22"
									><span class="black--text text-h5">{{
										initials
									}}</span></v-avatar
								>
							</div>
							<div>
								{{ username }} <br />
								Admin
							</div></span
						>
					</v-btn>
					<v-btn
						disabled
						flat
						class="uppercase white notification-btn"
						v-if="notificationCount == 0"
					>
						<span class="notification-btn-container"
							><div class="notification-dot show"></div>
							<img
								class="notification-bell-icon"
								src="../assets/icon/notification-bell.svg"
							/>No Alert</span
						>
					</v-btn>
					<v-btn
						flat
						class="uppercase white notification-btn"
						@click="savefolder()"
						v-if="notificationCount > 0"
					>
						<span class="notification-btn-container"
							><img
								class="notification-bell-icon"
								src="../assets/icon/notification-bell-active.svg"
							/>New Alert</span
						>
					</v-btn>
					<v-btn
						flat
						to="/login"
						@click="sessionStorage.clear()"
						class="uppercase white logout-btn"
					>
						<img class="btn-icon" src="../assets/icon/logout2.svg" />
						<span class="icon-heading-margin">Log Out</span>
					</v-btn>
				</div>
			</v-menu>
		</div>
	</v-toolbar>
</template>
<script src="./ToolsJS/HomeHeader.js"></script>
<style scoped src="@/assets/css/home-header.css"></style>
