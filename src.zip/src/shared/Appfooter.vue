<template>
  <div id="footer">
    <v-footer class="darken-2 footer-section">
      <v-layout row wrap align-center>
        <v-flex xs7 class="rights-info">
          <div class="white--text">All Rights Reserved.</div>
        </v-flex>
        <v-flex xs4>
          <p class="message tool-support-section">
            <a onclick="window.open('static/HCL_NAT_User_Manual_v1.6.pdf', '_blank');">Tool Support</a>
          </p>
        </v-flex>
        <v-flex xs0>
          <div class="white--text version-info">Version  2.5</div>
        </v-flex>
      </v-layout>
    </v-footer>
  </div>
</template>

<script>
export default {
  name: "footer"
};
</script>
<style scoped src="@/assets/css/footer.css"></style>


