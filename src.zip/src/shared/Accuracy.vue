<template>
  <v-app light>

    <main>
    Hellooooooooooooooooooooooooooooooooo
    <input type="text" name :value="disableBack" style="display:none">
      <section class="dashboard-section">
        <v-container fluid class="dashboard-container">
          <v-layout row wrap class="main-layout">
            <v-flex xs2>
              <h6 class="filter-heading">Metric Filter</h6>
            </v-flex>
            <v-flex xs3>
              <v-select
                class="filter-dropdown"
                :items="videos"
                v-model="e1"
                item-text="text"
                item-value="text"
                return-object
              ></v-select>
            </v-flex>
            <v-flex xs3>
              <v-select
                class="filter-dropdown"
                :items="frames"
                v-model="e2"
                label="Select Frame"
                single-line
              ></v-select>
            </v-flex>
            <v-flex xs2>
              <v-select
                class="filter-dropdown"
                :items="Users"
                v-model="e3"
                label="Select User"
                single-line
              ></v-select>
            </v-flex>
            <v-flex xs2>
              <v-select
                class="filter-dropdown"
                :items="Type"
                v-model="e4"
                label="Select Type"
                single-line
              ></v-select>
            </v-flex>
          </v-layout>
          <v-layout row wrap>
            <v-flex xs12>
              <h6 class="accuracy-header">Object Detection Accuracy</h6>
              <accuracy-object
                :chart-data="datacollection"
                :styles="{position: 'relative'}"
                :height=100
              ></accuracy-object>
            </v-flex>
            <v-flex xs12>
              <h6 class="accuracy-header">Object Updated Count</h6>
              <accuracy-video
                :chart-data="datacollection2"
                :styles="{position: 'relative'}"
                :height=100
              ></accuracy-video>
            </v-flex>
            <v-flex xs12>
              <h6 class="accuracy-header">Object Deleted Count</h6>

              <changes-video
                :chart-data="datacollection2"
                :styles="{position: 'relative'}"
                :height=100
              ></changes-video>
            </v-flex>
            <v-flex xs12>
              <h6 class="accuracy-header">Object Localization Accuracy</h6>
              <changes-object
                :chart-data="datacollection3"
                :styles="{position: 'relative'}"
                :height=100
              ></changes-object>
            </v-flex>
          </v-layout>
        </v-container>
      </section>
      <app-footer/>
    </main>
  </v-app>
</template>
<script src="./ToolsJS/Accuracy.js"></script>
<style scoped>
.dashboard-section {
  min-height: 600px;
}
.dashboard-container {
  border: 1px solid #d3d3d3;
}
.main-layout {
  border: 1px solid #999;
  height: 56px;
}
.filter-heading {
  padding-left: 12px;
  line-height: 3;
}

.filter-dropdown {
  padding: 10px;
  padding-left: 0px;
}

.changes-video {
  height: "200px";
  position: "relative";
}

.accuracy-header {
  padding-top: 17px;
  margin-bottom: 16px;
}
.footer-container {
  background: rgb(40, 40, 40);
}
</style>
