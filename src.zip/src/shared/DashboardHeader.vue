<template>
  <v-toolbar class="header-container">
    <v-toolbar-title class="toolbar-title" @click="callInbox(homePath)">
    <img src="../assets/icon/logo2.png" class="toolbar-title--logo"/>
    </v-toolbar-title>
    
    <v-toolbar-items class="header-item-container">
      <v-btn flat v-on:click="callInbox(homePath)" class="uppercase white header-btn">
        <img class="btn-icon" src="../assets/icon/inbox-2.svg"><span class="icon-heading-margin">Inbox</span>
      </v-btn>
      <v-btn flat @click="callDashbord(dashbordPath)" class="uppercase white header-btn" v-if="role !='ANNOTATOR'">
         <img class="btn-icon" src="../assets/icon/dashboard.svg"><span class="icon-heading-margin">DashBoard</span>
      </v-btn>

      <v-btn flat @click="callSetting(settingPath)" class="uppercase white header-btn">
        <img class="btn-icon" src="../assets/icon/setting-2.svg"><span class="icon-heading-margin">Settings</span>
      </v-btn>

      <v-btn flat @click="callUser(userPath)" class="uppercase white header-btn" v-if="role =='ADMIN'">
        <img class="btn-icon" src="../assets/icon/blocks-group-svgrepo-com.svg"> <span class="icon-heading-margin">Project</span>
      </v-btn>

    </v-toolbar-items>

    <v-toolbar-items class="header-menu-container">
    <v-menu offset-y style="right:0!important; backround-color: #000;" class="User-Type">
        <v-btn flat slot="activator" class="uppercase white">
          <span class="avatar-title" v-if="role =='ANNOTATOR'"><v-avatar color="orange" size="22"><span class="black--text text-h5">{{initials}}</span></v-avatar><img class="menu-arrow" src="../assets/icon/angle.svg"></span>
          <span class="avatar-title" v-if="role =='VALIDATOR'"><v-avatar color="orange" size="22"><span class="black--text text-h5">{{initials}}</span></v-avatar><img class="menu-arrow" src="../assets/icon/angle.svg"></span>
          <span class="avatar-title" v-if="role =='ADMIN'" ><v-avatar color="orange" size="22"><span class="black--text text-h5">{{initials}}</span></v-avatar><img class="menu-arrow" src="../assets/icon/angle.svg"></span>
        </v-btn>
        <div class="account-option-popup">
          <v-btn disabled flat class="uppercase white">
            <span class="avatar-title" v-if="role =='ANNOTATOR'"><div><v-avatar color="orange" size="22"><span class="black--text text-h5">{{initials}}</span></v-avatar></div><div>{{username}} <br> Annotator</div></span>
            <span class="avatar-title" v-if="role =='VALIDATOR'"><div><v-avatar color="orange" size="22"><span class="black--text text-h5">{{initials}}</span></v-avatar></div><div>{{username}} <br> Validator</div></span>
            <span class="avatar-title" v-if="role =='ADMIN'" ><div><v-avatar color="orange" size="22"><span class="black--text text-h5">{{initials}}</span></v-avatar></div> <div>{{username}} <br> Admin</div></span>

          </v-btn>
          <v-btn flat to="/login" class="uppercase white logout-btn">
            <img class="btn-icon" src="../assets/icon/logout2.svg">
            <span class="icon-heading-margin">Log Out</span>
          </v-btn>
        </div>
      </v-menu>
    </v-toolbar-items>

      



      <input type="text" name :value="getUserId" style="display:none">
  </v-toolbar>
</template>
<script>
import SettingService from "../services/SettingService.js";

export default {
  data() {
    return {
      userId: 1,
      role:"ADMIN",
      username:"",
      homePath: "/home",
      dashbordPath: "/dashboard",
      settingPath: "/setting",
      userPath: "/userList",
      projectId: 0,
      initials: ""
    };
  },
  methods: {
    callInbox(link) {
      this.$router.push({ path: link });
    },

    callDashbord(event) {
      this.dashBoardPath = event;
      this.$router.push({
        path: this.dashBoardPath });
    },
    callSetting(link) {
      this.$router.push({ path: link });
    },
    callUser: function(link) {
      this.$router.push({ path: link });
    }
  },
  computed: {
    getUserId() {
      this.userId = SettingService.getSelectedUserId();
      this.username = SettingService.getSelectedUserName();
      this.initials = this.username[0];
      this.role = SettingService.getSelectedUserRole();
      this.projectId = SettingService.getSelectedProject();
      }
  }
};
</script>
<style scoped src="@/assets/css/dashboard-header.css"></style>
