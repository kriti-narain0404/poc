import fabric from "fabric";
import Line from "../model/Line.js";
import { getRandId } from "./commonMethods.js";

function loadPolygonLine(coord, coord1) {
    let coords = [coord.x, coord.y, coord1.x, coord1.y];
    return new fabric.Line(coords, {
        id: getRandId(),
        ...Line
    });
}

export default loadPolygonLine;
