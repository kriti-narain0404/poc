
function extractPolygon(obj) {
    let poly = {};
    poly.id = obj.get("id");
    poly.annoId = obj.get("annoId");
    poly.label = obj.get("label");
    poly.score = obj.get("score");
    poly.look = obj.get("look");
    poly.points = obj.get("points");
    return poly;
}
function deselectObject(canvas) {
    canvas.discardActiveObject();
    canvas.renderAll();
}

function modifyShape(e, key, obj) {
    // Shrink box
    if (key === "left" && e.shiftKey && e.altKey) {
        obj.set({ width: (obj.width -= 5) });
    } else if (key === "right" && e.shiftKey && e.altKey) {
        obj.set({ width: (obj.width -= 5) });
        obj.set({ left: (obj.left += 5) });
    } else if (key === "up" && e.shiftKey && e.altKey) {
        obj.set({ height: (obj.height -= 5) });
    } else if (key === "down" && e.shiftKey && e.altKey) {
        obj.set({ height: (obj.height -= 5) });
        obj.set({ top: (obj.top += 5) });

        // Stretch box
    } else if (key === "left" && e.shiftKey) {
        obj.set({ width: (obj.width += 5) });
        obj.set({ left: (obj.left -= 5) });
    } else if (key === "right" && e.shiftKey) {
        obj.set({ width: (obj.width += 5) });
    } else if (key === "up" && e.shiftKey) {
        obj.set({ height: (obj.height += 5) });
        obj.set({ top: (obj.top -= 5) });
    } else if (key === "down" && e.shiftKey) {
        obj.set({ height: (obj.height += 5) });

        // Move Box
    } else if (key === "left") {
        obj.set({ left: (obj.left -= 5) });
    } else if (key === "right") {
        obj.set({ left: (obj.left += 5) });
    } else if (key === "up") {
        obj.set({ top: (obj.top -= 5) });
    } else if (key === "down") {
        obj.set({ top: (obj.top += 5) });
    }
}

function makePointsFromCoords(coords) {
    let self = this;
    coords.map(function (o) {
        o.id = self.getRandId();
    });
    return coords;
}
function getCurLabel(radioSelect) {
    if (radioSelect) return radioSelect;
}

function getRandId() {
    return Math.random()
        .toString(36)
        .substr(2, 10);
}

export { extractPolygon, deselectObject, modifyShape, makePointsFromCoords, getCurLabel, getRandId }