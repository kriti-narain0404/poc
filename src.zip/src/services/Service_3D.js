import {labelTool} from "../components/ToolsJS/3D_js/config_3D_tool.js";
import {drawLine, classesBoundingBox} from "../components/ToolsJS/3D_js/util/boundingbox.js";
import * as THREE from "three";

function PrismGeometry(vertices, height) {
    let shape = new THREE.Shape();
    (function f(ctx) {

        ctx.moveTo(vertices[0].x, vertices[0].y);
        for (let i = 1; i < vertices.length; i++) {
            ctx.lineTo(vertices[i].x, vertices[i].y);
        }
        ctx.lineTo(vertices[0].x, vertices[0].y);

    })(shape);

    let settings = {};
    settings.amount = height;
    settings.bevelEnabled = false;
    new THREE.ExtrudeGeometry(shape, settings);
    // const geometry = new THREE.ExtrudeGeometry(shape, settings);

};
PrismGeometry.prototype = Object.create(THREE.ExtrudeGeometry.prototype);

export default new class Service3D {

    

    getChannelIndexByName(camChannel) {
        for (let channelObj in labelTool.camChannels) {
            if (labelTool.camChannels.hasOwnProperty(channelObj)) {
                let channelObject = labelTool.camChannels[channelObj];
                if (camChannel === channelObject.channel) {
                    return labelTool.camChannels.indexOf(channelObject);
                }
            }
        }
    }
    
    calculateAndDrawLineSegments(channelObj, className, horizontal, selected) {
        let channel = channelObj.channel;
        let lineArray = [];
        let channelIdx = this.getChannelIndexByName(channel);
        // temporary color bottom 4 lines in yellow to check if projection matrix is correct
        // uncomment line to use yellow to color bottom 4 lines
        let color;
        if (selected === true) {
            color = "#ff0000";
        } else {
            color = classesBoundingBox[className].color;
        }
    
        // bottom four lines
        lineArray.push(drawLine(channelIdx, channelObj.projectedPoints[0], channelObj.projectedPoints[1], color));
        lineArray.push(drawLine(channelIdx, channelObj.projectedPoints[1], channelObj.projectedPoints[2], color));
        lineArray.push(drawLine(channelIdx, channelObj.projectedPoints[2], channelObj.projectedPoints[3], color));
        lineArray.push(drawLine(channelIdx, channelObj.projectedPoints[3], channelObj.projectedPoints[0], color));
    
        // draw line for orientation
        let pointZero;
        let pointOne;
        let pointTwo;
        let pointThree;
        if (horizontal) {
            pointZero = channelObj.projectedPoints[4].clone();
            pointOne = channelObj.projectedPoints[5].clone();
            pointTwo = channelObj.projectedPoints[6].clone();
            pointThree = channelObj.projectedPoints[7].clone();
        } else {
            pointZero = channelObj.projectedPoints[6].clone();
            pointOne = channelObj.projectedPoints[4].clone();
            pointTwo = channelObj.projectedPoints[5].clone();
            pointThree = channelObj.projectedPoints[7].clone();
        }
    
    
        let startPoint = pointZero.add(pointThree.sub(pointZero).multiplyScalar(0.5));
        let startPointCloned = startPoint.clone();
        let helperPoint = pointOne.add(pointTwo.sub(pointOne).multiplyScalar(0.5));
        let helperPointCloned = helperPoint.clone();
        let endPoint = startPointCloned.add(helperPointCloned.sub(startPointCloned).multiplyScalar(0.2));
        lineArray.push(drawLine(channelIdx, startPoint, endPoint, color));
    
    
        // top four lines
        lineArray.push(drawLine(channelIdx, channelObj.projectedPoints[4], channelObj.projectedPoints[5], color));
        lineArray.push(drawLine(channelIdx, channelObj.projectedPoints[5], channelObj.projectedPoints[6], color));
        lineArray.push(drawLine(channelIdx, channelObj.projectedPoints[6], channelObj.projectedPoints[7], color));
        lineArray.push(drawLine(channelIdx, channelObj.projectedPoints[7], channelObj.projectedPoints[4], color));
    
        // vertical lines
        lineArray.push(drawLine(channelIdx, channelObj.projectedPoints[0], channelObj.projectedPoints[4], color));
        lineArray.push(drawLine(channelIdx, channelObj.projectedPoints[1], channelObj.projectedPoints[5], color));
        lineArray.push(drawLine(channelIdx, channelObj.projectedPoints[2], channelObj.projectedPoints[6], color));
        lineArray.push(drawLine(channelIdx, channelObj.projectedPoints[3], channelObj.projectedPoints[7], color));
    
        return lineArray;
    }

    createPlane(name, angle, xpos, ypos, channel) {
        let channelIdx = this.getChannelIndexByName(channel);
        let geometryRightPlane = new THREE.BoxGeometry(labelTool.camChannels[channelIdx].fieldOfView, 2, 0.08);
        geometryRightPlane.rotateX(Math.PI / 2);
        geometryRightPlane.rotateZ(angle);
        geometryRightPlane.translate(ypos, xpos, -0.7);//y/x/z
        let material = new THREE.MeshBasicMaterial({
            color: 0x525252,
            side: THREE.DoubleSide,
            transparent: true,
            opacity: 0.9
        });
        let planeRight = new THREE.Mesh(geometryRightPlane, material);
        planeRight.name = name;
        labelTool.scene.add(planeRight);
    }

    createPrism(angle, posx, posy, width, openingLength, offsetX) {
        console.log(posx, posy);
        let posXCenter = 0 * Math.cos(angle) - offsetX * Math.sin(angle);
        let posYCenter = 0 * Math.sin(angle) + offsetX * Math.cos(angle);
        let positionCornerCenter = new THREE.Vector2(posXCenter, posYCenter);
        let posXLeft = -width * Math.cos(angle) - openingLength / 2 * Math.sin(angle);
        let posYLeft = -width * Math.sin(angle) + openingLength / 2 * Math.cos(angle);
        let positionCornerLeft = new THREE.Vector2(posXLeft, posYLeft);
        let posXRight = width * Math.cos(angle) - openingLength / 2 * Math.sin(angle);
        let posYRight = width * Math.sin(angle) + openingLength / 2 * Math.cos(angle);
        let positionCornerRight = new THREE.Vector2(posXRight, posYRight);
        let materialPrism = new THREE.MeshBasicMaterial({color: 0xff0000, transparent: true, opacity: 0.5});
        let height = 2;
        let geometryPrism = new PrismGeometry([positionCornerCenter, positionCornerLeft, positionCornerRight], height);
        geometryPrism.translate(-posy, posx, -1.7);
        let prismMesh = new THREE.Mesh(geometryPrism, materialPrism);
        prismMesh.name = "prism";
        labelTool.scene.add(prismMesh);
    }

    drawFieldOfView() {
        switch (labelTool.currentCameraChannelIndex) {
            case 0:
                // front left
                this.createPlane('rightplane', Math.PI / 2 - 340 * 2 * Math.PI / 360, labelTool.camChannels[0].positionCameraNuScenes[0] - labelTool.positionLidarNuscenes[0] + labelTool.camChannels[0].fieldOfView / 2 * Math.cos(340 * 2 * Math.PI / 360), -labelTool.camChannels[0].positionCameraNuScenes[1] + labelTool.camChannels[0].fieldOfView / 2 * Math.sin(340 * 2 * Math.PI / 360), "CAM_FRONT_LEFT");
                this.createPlane('leftplane', Math.PI / 2 - 270 * 2 * Math.PI / 360, labelTool.camChannels[0].positionCameraNuScenes[0] - labelTool.positionLidarNuscenes[0] + labelTool.camChannels[0].fieldOfView / 2 * Math.cos(270 * 2 * Math.PI / 360), -labelTool.camChannels[0].positionCameraNuScenes[1] + labelTool.camChannels[0].fieldOfView / 2 * Math.sin(270 * 2 * Math.PI / 360), "CAM_FRONT_LEFT");
                // this.createPrism(-305 * 2 * Math.PI / 360, labelTool.camChannels[0].positionCameraNuScenes[0] - labelTool.positionLidarNuscenes[0], labelTool.camChannels[0].positionCameraNuScenes[1], 0.3, 1.0, 0.073);
                break;
            case 1:
                // front
                this.createPlane('rightplane', Math.PI / 2 - 35 * 2 * Math.PI / 360, labelTool.camChannels[1].positionCameraNuScenes[0] - labelTool.positionLidarNuscenes[0] + labelTool.camChannels[1].fieldOfView / 2 * Math.cos(35 * 2 * Math.PI / 360), -labelTool.camChannels[1].positionCameraNuScenes[1] + labelTool.camChannels[1].fieldOfView / 2 * Math.sin(35 * 2 * Math.PI / 360), "CAM_FRONT");
                this.createPlane('leftplane', Math.PI / 2 - (-35) * 2 * Math.PI / 360, labelTool.camChannels[1].positionCameraNuScenes[0] - labelTool.positionLidarNuscenes[0] + labelTool.camChannels[1].fieldOfView / 2 * Math.cos(-35 * 2 * Math.PI / 360), -labelTool.camChannels[1].positionCameraNuScenes[1] + labelTool.camChannels[1].fieldOfView / 2 * Math.sin(-35 * 2 * Math.PI / 360), "CAM_FRONT");
                // this.createPrism(0 * 2 * Math.PI / 360, labelTool.camChannels[1].positionCameraNuScenes[0] - labelTool.positionLidarNuscenes[0], labelTool.camChannels[1].positionCameraNuScenes[1], 0.3, 1.0, 0.073);
                break;
            case 2:
                // front right
                this.createPlane('rightplane', Math.PI / 2 - 90 * 2 * Math.PI / 360, labelTool.camChannels[2].positionCameraNuScenes[0] - labelTool.positionLidarNuscenes[0] + labelTool.camChannels[2].fieldOfView / 2 * Math.cos(90 * 2 * Math.PI / 360), -labelTool.camChannels[2].positionCameraNuScenes[1] + labelTool.camChannels[2].fieldOfView / 2 * Math.sin(90 * 2 * Math.PI / 360), "CAM_FRONT_RIGHT");
                this.createPlane('leftplane', Math.PI / 2 - 20 * 2 * Math.PI / 360, labelTool.camChannels[2].positionCameraNuScenes[0] - labelTool.positionLidarNuscenes[0] + labelTool.camChannels[2].fieldOfView / 2 * Math.cos(20 * 2 * Math.PI / 360), -labelTool.camChannels[2].positionCameraNuScenes[1] + labelTool.camChannels[2].fieldOfView / 2 * Math.sin(20 * 2 * Math.PI / 360), "CAM_FRONT_RIGHT");
                // this.createPrism(-55 * 2 * Math.PI / 360, labelTool.camChannels[2].positionCameraNuScenes[0] - labelTool.positionLidarNuscenes[0], labelTool.camChannels[2].positionCameraNuScenes[1], 0.3, 1.0, 0.073);
                break;
            case 3:
                // back right
                this.createPlane('rightplane', Math.PI / 2 - 145 * 2 * Math.PI / 360, labelTool.camChannels[3].positionCameraNuScenes[0] - labelTool.positionLidarNuscenes[0] + labelTool.camChannels[3].fieldOfView / 2 * Math.cos(145 * 2 * Math.PI / 360), -labelTool.camChannels[3].positionCameraNuScenes[1] + labelTool.camChannels[3].fieldOfView / 2 * Math.sin(145 * 2 * Math.PI / 360), "CAM_BACK_RIGHT");
                this.createPlane('leftplane', Math.PI / 2 - 75 * 2 * Math.PI / 360, labelTool.camChannels[3].positionCameraNuScenes[0] - labelTool.positionLidarNuscenes[0] + labelTool.camChannels[3].fieldOfView / 2 * Math.cos(75 * 2 * Math.PI / 360), -labelTool.camChannels[3].positionCameraNuScenes[1] + labelTool.camChannels[3].fieldOfView / 2 * Math.sin(75 * 2 * Math.PI / 360), "CAM_BACK_RIGHT");
                // this.createPrism(-110 * 2 * Math.PI / 360, labelTool.camChannels[3].positionCameraNuScenes[0] - labelTool.positionLidarNuscenes[0], labelTool.camChannels[3].positionCameraNuScenes[1], 0.3, 1.0, 0.073);
                break;
            case 4:
                // back
                this.createPlane('rightplane', Math.PI / 2 - 245 * 2 * Math.PI / 360, labelTool.camChannels[4].positionCameraNuScenes[0] - labelTool.positionLidarNuscenes[0] + labelTool.camChannels[4].fieldOfView / 2 * Math.cos(245 * 2 * Math.PI / 360), -labelTool.camChannels[4].positionCameraNuScenes[1] + labelTool.camChannels[4].fieldOfView / 2 * Math.sin(245 * 2 * Math.PI / 360), "CAM_BACK");
                this.createPlane('leftplane', Math.PI / 2 - 115 * 2 * Math.PI / 360, labelTool.camChannels[4].positionCameraNuScenes[0] - labelTool.positionLidarNuscenes[0] + labelTool.camChannels[4].fieldOfView / 2 * Math.cos(115 * 2 * Math.PI / 360), -labelTool.camChannels[4].positionCameraNuScenes[1] + labelTool.camChannels[4].fieldOfView / 2 * Math.sin(115 * 2 * Math.PI / 360), "CAM_BACK");
                // this.createPrism(-180 * 2 * Math.PI / 360, labelTool.camChannels[4].positionCameraNuScenes[0] - labelTool.positionLidarNuscenes[0], labelTool.camChannels[4].positionCameraNuScenes[1], 0.97, 1.0, 0.046);
                break;
            case 5:
                // back left
                this.createPlane('rightplane', Math.PI / 2 - 285 * 2 * Math.PI / 360, labelTool.camChannels[5].positionCameraNuScenes[0] - labelTool.positionLidarNuscenes[0] + labelTool.camChannels[5].fieldOfView / 2 * Math.cos(285 * 2 * Math.PI / 360), -labelTool.camChannels[5].positionCameraNuScenes[1] + labelTool.camChannels[5].fieldOfView / 2 * Math.sin(285 * 2 * Math.PI / 360), "CAM_BACK_LEFT");
                this.createPlane('leftplane', Math.PI / 2 - 215 * 2 * Math.PI / 360, labelTool.camChannels[5].positionCameraNuScenes[0] - labelTool.positionLidarNuscenes[0] + labelTool.camChannels[5].fieldOfView / 2 * Math.cos(215 * 2 * Math.PI / 360), -labelTool.camChannels[5].positionCameraNuScenes[1] + labelTool.camChannels[5].fieldOfView / 2 * Math.sin(215 * 2 * Math.PI / 360), "CAM_BACK_LEFT");
                // this.createPrism(-250 * 2 * Math.PI / 360, labelTool.camChannels[5].positionCameraNuScenes[0] - labelTool.positionLidarNuscenes[0], labelTool.camChannels[5].positionCameraNuScenes[1], 0.3, 1.0, 0.073);
                break;
        }
    }
}
