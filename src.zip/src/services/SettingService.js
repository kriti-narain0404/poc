export default new class SettingService {
    settingData = [];
    allVideoData = [];
    projectLists = [];
    videoData = '';
    projectData = 0;
    userIdData = 0;
    userNameData = '';
    userRoleData = '';
    darkMode = false;

    setSettingData(data) {
        this.settingData.push(data);
        sessionStorage.setItem('annotator', JSON.stringify(this.settingData));
    }
    getSettingData() {
        if (sessionStorage.getItem('annotator')) {
            return JSON.parse(sessionStorage.getItem('annotator'));
        } else {
            return this.settingData;
        }

    }

    setSelectedVideo(data) {
        sessionStorage.setItem('video', JSON.stringify(data));
        this.videoData = data;
    }

    getSelectedVideo() {
        if (sessionStorage.getItem('video')) {
            return JSON.parse(sessionStorage.getItem('video'));
        } else {
            return this.videoData;
        }

    }

    setAllVideo(data) {
        sessionStorage.setItem('allvideo', JSON.stringify(data));
        this.allVideoData = data;
    }

    getAllVideo() {
        if (sessionStorage.getItem('allvideo')) {
            return JSON.parse(sessionStorage.getItem('allvideo'));
        } else {
            return this.allVideoData;
        }

    }

    setSelectedProject(data) {
        sessionStorage.setItem('selectedProject', JSON.stringify(data));
        this.projectData = data;
    }

    getSelectedProject() {
        if (sessionStorage.getItem('selectedProject')) {
            return JSON.parse(sessionStorage.getItem('selectedProject'));
        } else {
            return this.projectData;
        }

    }

    setSelectedUserId(data) {
        sessionStorage.setItem('selectedUserId', JSON.stringify(data));
        this.userIdData = data;
    }

    getSelectedUserId() {
        if (sessionStorage.getItem('selectedUserId')) {
            return JSON.parse(sessionStorage.getItem('selectedUserId'));
        } else {
            return this.userIdData;
        }

    }

    setSelectedUserName(data) {
        sessionStorage.setItem('selectedUserName', JSON.stringify(data));
        this.userNameData = data;
    }

    getSelectedUserName() {
        if (sessionStorage.getItem('selectedUserName')) {
            return JSON.parse(sessionStorage.getItem('selectedUserName'));
        } else {
            return this.userNameData;
        }

    }

    setSelectedUserRole(data) {
        sessionStorage.setItem('selectedUserRole', JSON.stringify(data));
        this.userRoleData = data;
    }

    getSelectedUserRole() {
        if (sessionStorage.getItem('selectedUserRole')) {
            return JSON.parse(sessionStorage.getItem('selectedUserRole'));
        } else {
            return this.userRoleData;
        }

    }

    setProjectList(data) {
        sessionStorage.setItem('projectLists', JSON.stringify(data));
        this.projectLists = data;
    }

    getProjectList() {
        if (sessionStorage.getItem('projectLists')) {
            return JSON.parse(sessionStorage.getItem('projectLists'));
        } else {
            return this.projectLists;
        }

    }

    setDarkMode(data) {
        sessionStorage.setItem('selectedDarkMode', JSON.stringify(data));
        this.darkMode = data;
    }

    getDarkMode() {
        if (sessionStorage.getItem('selectedDarkMode')) {
            return JSON.parse(sessionStorage.getItem('selectedDarkMode'));
        } else {
            return this.darkMode;
        }

    }

    
}
