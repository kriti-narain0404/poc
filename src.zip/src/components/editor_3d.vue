<template>
  <v-app :dark="isDarkMode == true" id="VTool" class="edit-container">
    <home-header style="z-index: 99999; position: fixed;" />
    <hsc-window-style-metal>
      <hsc-window
        positionHint="-300 / 200"
        title="Tools Settings"
        class="field-settings-tool"
        :closeButton="true"
        :resizable="true"
        :isOpen.sync="isToolSettingsOpen"
      >
        <div class="field-settings-tool--display">
          <table>
            <tr>
              <td>
                <strong class="field-tools-name"
                  >Point Size({{ pointSize }})</strong
                >
              </td>
              <td>
                <input
                  type="range"
                  v-on:change="setPointSize()"
                  v-model="pointSize"
                  max="1"
                  min="0.01"
                  step="0.01"
                />
              </td>
              <td></td>
            </tr>
            <tr>
              <td>
                <strong class="field-tools-name">Field-Of-View</strong>
              </td>
              <td>
                <input
                  type="checkbox"
                  slot="activator"
                  v-bind:true-value="'true'"
                  v-bind:false-value="'false'"
                  v-model="showfieldOfView"
                  @click="fieldOfView()"
                />
              </td>
              <td></td>
            </tr>
            <tr>
              <td>
                <strong class="field-tools-name">Show Grid</strong>
              </td>
              <td>
                <input
                  type="checkbox"
                  slot="activator"
                  v-bind:true-value="'true'"
                  v-bind:false-value="'false'"
                  v-model="showGridView"
                  @click="gridView()"
                />
              </td>
              <td></td>
            </tr>
            <tr>
              <td>
                <strong class="field-tools-name">Filter Ground</strong>
              </td>
              <td>
                <input
                  type="checkbox"
                  slot="activator"
                  v-bind:true-value="'true'"
                  v-bind:false-value="'false'"
                  v-model="filterGroundStatus"
                  @click="filterGround()"
                />
              </td>
              <td></td>
            </tr>
          </table>
        </div>
      </hsc-window>
    </hsc-window-style-metal>
    <!-- <v-list
            class="show-pcd-view"
            :closeButton="false"
            v-if="camViews == true"
          >
          <table class="show-pcd-view-style">
            <tr v-for="(channel,index) in camChannelList"
                      :key="index" class="close">
              <td>
                <input
                  name="channel"
                  type="radio"
                  v-bind:value="channel.channel"
                  v-model="channelSelect"
                  @click="selectCamView()"
                >
                <span class="setting-lbl">{{channel.channel}}</span>
                
                </td>
                </tr>                 
                </table>
              </v-list>               -->
    <hsc-window-style-white>
      <hsc-window
        :isOpen.sync="isRightPanelOpen"
        positionHint="-90 / 180"
        :closeButton="true"
        :resizable="false"
        :isScrollable="false"
        :isDraggable="true"
        class="dialog-box-container"
        style="z-index: 2"
      >
        <img
          src="../assets/icon/close-cross.svg"
          @click="openRightPanel()"
          class="close-dialog-btn"
          id="right-panel-close-btn"
          alt=""
        />
        <v-flex class="inner-dialog-box-container">
          <div class="dialog-box">
            <v-layout class="dialog-box-sub-container">
                  <v-flex row wrap style="display: flex">
                    <v-flex xs6>
                      <h3 class="radio-input-label">Label Count</h3>
                    </v-flex>
                  <v-flex xs7>
                    <h3 class="radio-input-label"><span class="seek-image-count">{{ sortedLabelList.length }}</span> </h3>
                </v-flex>
              </v-flex>
            </v-layout>
            <v-layout class="dialog-box-sub-container switch-btn-container">
                <v-flex xs6 class="switch-btn-label-container">
                <h3 class="radio-input-label">Interpolation Type</h3>
                </v-flex>
                <v-flex xs6 class="switch-btn-container">
                  <v-btn-toggle mandatory v-model="copyMode" class="switch-btn-group">
                   <v-btn class="switch-btn left-btn" name="myfield" value=manual v-model="copyMode" title="manual"><img src="../assets/icon/manual.svg"></v-btn>
                   <v-btn class="switch-btn right-btn" name="myfield" value=automatic v-model="copyMode" title="automatic"><img src="../assets/icon/robot-3.svg"></v-btn>
                  </v-btn-toggle>
                </v-flex>
              </v-layout>
              <v-layout class="dialog-box-sub-container switch-btn-container">
                <v-flex xs6 class="switch-btn-label-container">
                <h3 class="radio-input-label">Interpolation</h3>
                </v-flex>
                <v-flex xs6 class="switch-btn-container">
                  <v-btn-toggle mandatory v-model="copyDirection" class="switch-btn-group">
                   <v-btn class="switch-btn left-btn" name="myfield_1" value="Backward" v-model="copyDirection" title="Backward"><img src="../assets/icon/backward-interpolation.svg"></v-btn>
                   <v-btn class="switch-btn right-btn" name="myfield_1" value="Forward" v-model="copyDirection" title="Forward"><img src="../assets/icon/forward-interpolation.svg"></v-btn>
                  </v-btn-toggle>
                </v-flex>
              </v-layout>
          </div>
          <div class="dialog-box" v-if="camViews">
            <v-layout class="dialog-box-sub-container">
              <v-flex class="channel" xs6>
                <h3 class="radio-input-label">Select Channel</h3>
                <div class="channel">
                  <table class="channel">
                    <tr
                      v-for="(channel, index) in camChannelList"
                      :key="index"
                      class="close"
                    >
                      <td>
                        <input
                          name="channel"
                          type="radio"
                          v-bind:value="channel.channel"
                          v-model="channelSelect"
                          @change="selectCamView()"
                        />
                        <span class="setting-lbl1">{{ channel.channel }}</span>
                      </td>
                    </tr>
                  </table>
                </div>
              </v-flex>
            </v-layout>
          </div>
          <div class="dialog-box" id="label-list-dialog" v-if="isAnnotationListOpen == true">
              <img src="../assets/icon/close-cross.svg" class="close-dialog-btn" alt="" @click="openLabelList()">
              <v-layout class="lock-unlock-toggler">
              <v-flex row wrap>
                <v-flex xs12 class="lock-unlock-toggler-container">
                        <input type="checkbox" slot="activator" v-bind:true-value="'true'" v-bind:false-value="'false'" v-model="lockUnlockFlag" @click="lockUnlockAllObjects()">
                        <h3 class="radio-input-label">Lock/Unlock All</h3>
                </v-flex>
              </v-flex>
              </v-layout>
              <v-layout>
              <v-flex row wrap>
                <v-flex xs12>
                  <v-flex class="single-class-container" v-for="(settingItem,i) in sortedLabelList" :key="i" >
                    <v-flex class="label-class-name-container" v-if="settingItem.bbox != null">                      
                      <span class="lock-icon-container">
                        <img
                          v-if="settingItem.bbox && settingItem.bbox.track ==false"
                          class="annotation-list--icons unlock-icon"
                          @click="toggleLocks(i, true, settingItem.bbox.annoId)"
                          src="../assets/icon/unlock.svg"
                        >
                        <img
                          v-if="settingItem.bbox && settingItem.bbox.track ==true"
                          class="annotation-list--icons lock-icon"
                          @click="toggleLocks(i, false, settingItem.bbox.annoId)"
                          src="../assets/icon/lock.svg"
                        >
                      </span>
                      <span
                      v-if="(sortedLabelList[i].bbox != null)"
                      class="setting-lbl-error single-class-name" :title="settingItem.label"
                      ><p :title="settingItem.label" class="label">{{settingItem.label}}</p><span class="bb-id"> [{{ settingItem.id }}]</span></span>                    
                      <span>
                        <img
                          v-if="settingItem.bbox"
                          class="annotation-list--icons-coords"
                          @click="openCoordinatesWindow(settingItem.bbox.annoId)"
                          src="../assets/icon/coords-1.svg"
                        >
                      </span>
                    </v-flex>
                    <v-flex class="attributes-container">
                      <v-layout class="attributes-sub-group" row wrap v-for="element in classObj" v-if="settingItem.bbox != null && element.name == settingItem.label">
                          <v-flex :key="index" class="single-attribute"  v-for="(extraObject1,index) in element.param" v-if="extraObject1.name!='Id' && element.name == settingItem.label">
                            <p class="attribute-label" :title=extraObject1.name>{{extraObject1.name}}</p>
                            <select v-model="parameterLabel1[i][index]"
                            size="1" v-on:change="fetchParam(i,settingItem.label,settingItem.bbox.track,extraObject1.name,parameterLabel1[i][index],settingItem.id,index)" onblur="this.size=0;">
                            <option v-for="objects in element.param[index].subClass" :value="objects.name" :key="objects.id"
                            class="select-option">{{objects.name}}</option>
                          </select>
                         </v-flex>
                      </v-layout>
                    </v-flex>
                  </v-flex>
                </v-flex>
              </v-flex>
              </v-layout>
            </div>
          </v-flex>
          </hsc-window>
        </hsc-window-style-white>
          <!-- <hsc-window-style-metal>
          <hsc-window
            title="Label List"
            positionHint="-83 / 120"
            :closeButton="true"
            :isOpen.sync="isAnnotationListOpen"
            :resizable="true"
            :isScrollable="true"
            class="label-list-container"
          >
            <div class = "span-class"> Label count: {{ sortedLabelList.length }} </div>
            <div v-if="isAnnotationListOpen">
            <v-layout row wrap class="annotation-list">
                  <v-flex xs12>
                    <v-layout row wrap>
                      <v-flex xs12>
                      <v-layout row wrap>                      
                      <span class="header-index-label">
                        <input type="checkbox" slot="activator" v-bind:true-value="'true'" v-bind:false-value="'false'" v-model="lockUnlockFlag" @click="lockUnlockAllObjects()">
                        Lock/Unlock All
                      </span>
                        </v-layout>
                      </v-flex>
                    </v-layout>
                  </v-flex>
            </v-layout>
            <table>
               <span class="span-class">{{sortedLabelList}}</span> -->

                <!-- <tr v-for="(settingItem,i) in sortedLabelList" :key="i"> -->
                  <!-- <span class="span-class">{{settingItem.bbox.track}}</span> -->
                  <!-- <td class="annotation-list--table" v-if="settingItem.bbox != null">
                    <img
                      v-if="settingItem.bbox && settingItem.bbox.track ==false"
                      class="annotation-list--icons"
                      @click="toggleLocks(i, true, settingItem.bbox.annoId)"
                      src="../assets/icon/unlock.png"
                    >
                    <img
                      v-if="settingItem.bbox && settingItem.bbox.track ==true"
                      class="annotation-list--icons"
                      @click="toggleLocks(i, false, settingItem.bbox.annoId)"
                      src="../assets/icon/lock.png"
                    >
                    <span
                      v-if="(sortedLabelList[i].bbox != null)"
                      style="cursor:pointer;"
                      class="setting-lbl-error" 
                    >{{settingItem.label}}
                    
                    <img 
                    class="annotation-list--icons-coords"
                    src="../assets/icon/coords-1.svg"
                    @click="openCoordinatesWindow(settingItem.bbox.annoId)"
                    >
                    </span>
                  </td>
                    <span v-for="element in classObj" v-if="settingItem.bbox != null && element.name == settingItem.label" class="setting-item">
                      
                    <td
                      v-for="(extraObject1,index) in element.param"
                      :key="index" v-if="extraObject1.name!='Id'"
                    >
                        <select v-model="parameterLabel1[i][index]" class="fill-box-select" v-if="element.name == settingItem.label"
                    size="1" v-on:change="fetchParam(i,settingItem.label, settingItem.bbox.track,extraObject1.name,parameterLabel1[i][index],settingItem.id,index)" onblur="this.size=0;">
                      <option v-for="objects in element.param[index].subClass" :value="objects.name" :key="objects.id"
                      class="select-option">{{objects.name}}</option>
                    </select>
                    </td>
                    </span>
                </tr>
            </table>
            </div>
          </hsc-window>
        </hsc-window-style-metal> -->
    <hsc-window-style-metal>
      <hsc-window
        positionHint="-300 / 200"
        title="BBOX Settings"
        class="coordinates-settings-tool"
        :closeButton="true"
        :resizable="true"
        :isOpen.sync="isCoordinatesListOpen"
      >
        <div class="coordinates-settings-tool--display">
          <table>
            <tr>
              <td>
                <strong class="bbox-settings-head">Position</strong>
              </td>
            </tr>
            <tr>
              <td>
                <strong class="field-tools-name">x({{ xCoord }})</strong>
              </td>
              <td>
                <input
                  type="range"
                  v-on:change="changeXCoord()"
                  v-model="xCoord"
                  max="150"
                  min="-150"
                  step="0.01"
                />
              </td>
            </tr>
            <tr>
              <td>
                <strong class="field-tools-name">y({{ yCoord }})</strong>
              </td>
              <td>
                <input
                  type="range"
                  v-on:change="changeYCoord()"
                  v-model="yCoord"
                  max="150"
                  min="-150"
                  step="0.01"
                />
              </td>
            </tr>
            <tr>
              <td>
                <strong class="field-tools-name">z({{ zCoord }})</strong>
              </td>
              <td>
                <input
                  type="range"
                  v-on:change="changeZCoord()"
                  v-model="zCoord"
                  max="3"
                  min="-3"
                  step="0.01"
                />
              </td>
            </tr>
            <tr>
              <td></td>
            </tr>
            <br />
            <tr>
              <td>
                <strong class="bbox-settings-head">Rotation</strong>
              </td>
            </tr>
            <tr>
              <td>
                <strong class="field-tools-name"
                  >rotationYaw({{ rotationYaw }})</strong
                >
              </td>
              <td>
                <input
                  type="range"
                  v-on:change="changeRotationYaw()"
                  v-model="rotationYaw"
                  max="3.14"
                  min="-3.14"
                  step="0.01"
                />
              </td>
            </tr>
            <tr>
              <td>
                <strong class="field-tools-name"
                  >rotationPitch({{ rotationPitch }})</strong
                >
              </td>
              <td>
                <input
                  type="range"
                  v-on:change="changeRotationPitch()"
                  v-model="rotationPitch"
                  max="3.14"
                  min="-3.14"
                  step="0.01"
                />
              </td>
            </tr>
            <tr>
              <td>
                <strong class="field-tools-name"
                  >rotationRoll({{ rotationRoll }})</strong
                >
              </td>
              <td>
                <input
                  type="range"
                  v-on:change="changeRotationRoll()"
                  v-model="rotationRoll"
                  max="3.14"
                  min="-3.14"
                  step="0.01"
                />
              </td>
            </tr>
            <br />
            <tr>
              <td>
                <strong class="bbox-settings-head">Size</strong>
              </td>
            </tr>
            <tr>
              <td>
                <strong class="field-tools-name"
                  >length({{ bboxLength }})</strong
                >
              </td>
              <td>
                <input
                  type="range"
                  v-on:change="changeBboxLength()"
                  v-model="bboxLength"
                  max="20"
                  min="0.3"
                  step="0.01"
                />
              </td>
            </tr>
            <tr>
              <td>
                <strong class="field-tools-name">width({{ bboxWidth }})</strong>
              </td>
              <td>
                <input
                  type="range"
                  v-on:change="changeBboxWidth()"
                  v-model="bboxWidth"
                  max="20"
                  min="0.3"
                  step="0.01"
                />
              </td>
            </tr>
            <tr>
              <td>
                <strong class="field-tools-name"
                  >height({{ bboxHeight }})</strong
                >
              </td>
              <td>
                <input
                  type="range"
                  v-on:change="changeBboxHeight()"
                  v-model="bboxHeight"
                  max="20"
                  min="0.3"
                  step="0.01"
                />
              </td>
            </tr>
          </table>
        </div>
      </hsc-window>
    </hsc-window-style-metal>

    <hsc-window-style-metal>
      <hsc-window
        title="Image View"
        positionHint="600/120"
        :closeButton="true"
        :isOpen.sync="isImageViewOpen"
        :resizable="false"
        :isScrollable="false"
        id="image-container"
      >
        <div class="loadSVG">
          <canvas ref="canvas" id="c" class="canvas-image"> </canvas>
          <!-- <svg
            id="channelSvg"
            xmlns="http://www.w3.org/2000/svg"
            xmlns:xlink="http://www.w3.org/1999/xlink"
          >
            <image id="channelImage" />
          </svg>
          <svg
            id="annoSVG"
            xmlns="http://www.w3.org/2000/svg"
            xmlns:xlink="http://www.w3.org/1999/xlink"
          >
            
          </svg> -->
        </div>
      </hsc-window>
    </hsc-window-style-metal>
    <v-toolbar>
      <v-toolbar-items xs4 sm4 class="save-style">
        <span class="header-index-label">{{ currentImageId + 1 }}.</span>
        <a id="download">
      <v-btn
      small dark
        icon
        @click="saveAnnos()"        
        title = "Save"        
      >
        <i class="fa fa-save save-icon"></i>
      </v-btn>
      </a>
      </v-toolbar-items>
    </v-toolbar>

<input type="file" accept="image/*" id="file" ref="file" name="myfile" v-on:change="nextImage()" style="display:none"/>
    <div class="prev-img-container">
      <v-btn small class="prev-img" icon @click="prev_image()" v-tooltip:right="{ html: 'Previous image' }">
        <i class="fa fa-chevron-left save-icon"></i>
      </v-btn>
    </div>
    <div class="next-img-container">
      <v-btn small class="next-img" icon @click="next_image()" v-tooltip:left="{ html: 'Next image' }">
        <i class="fa fa-chevron-right save-icon"></i>
      </v-btn>
    </div>
  <div class="sidebar-icons">
    <v-flex class="sidebar-icons--list">
            <v-flex v-tooltip:right="{ html: 'Save' }" class="sidebar-icon-container save-btn-container" id="save-btn"  @click="saveAnnos(), showCheck = true" title = "Save annotations" :class="[ isAnychange ==true ? 'notification-unsaved-work' : '']">
              <img class="save-btn-icon" src="../assets/icon/save.svg">
            </v-flex>
            <v-flex class="sidebar-icon-container no-hover">
              <div class="cust-divider"></div>
              </v-flex>
              <v-flex v-tooltip:right="{ html: 'Orthographic View' }" class="sidebar-icon-container annotation-tool" id="ortho-view-tool" @click="selectPcdView(pcdViewList[0])"  title="Orthographic View">
                <img class="sidebar-icon" src="../assets/icon/pcd_view.svg">
              </v-flex>
              <v-flex v-tooltip:right="{ html: 'Perspective View' }" class="sidebar-icon-container annotation-tool" id="persp-view-tool" @click="selectPcdView(pcdViewList[1])"  title="Perspective View">
                <img class="sidebar-icon" src="../assets/icon/perspective_view.svg">
              </v-flex> 
              <v-flex v-tooltip:right="{ html: 'Camera Views' }" class="sidebar-icon-container annotation-tool" id="camera-view-tool" @click="setCameraView()"  title="Camera Views">
                <img class="sidebar-icon" src="../assets/icon/camera_view.svg">
              </v-flex>
              <v-flex v-tooltip:right="{ html: 'View Settings' }" class="sidebar-icon-container annotation-tool" id="setting-tool" @click="setSettingView()"  title="View Settings">
                <img class="sidebar-icon" src="../assets/icon/3d_settings.svg">
              </v-flex>
              <v-flex v-tooltip:right="{ html: 'Right Panel' }" @click="openRightPanel()" class="sidebar-icon-container dialog-toggler active-tool" id="right-panel-btn" title="Right Panel">
                <img class="sidebar-icon" src="../assets/icon/right-toolbox.svg">
              </v-flex>
              <v-flex v-tooltip:right="{ html: 'Label List' }" @click="openLabelList()" class="sidebar-icon-container dialog-toggle active-tool" id="label-list-btn" title="Label List">
                <img class="sidebar-icon" src="../assets/icon/label-list.svg">
              </v-flex>
              <v-flex
          v-tooltip:right="{ html: 'Shortcuts' }"
          class="toolbar-list-width sidebar-icon-container"
          id="keyboard-shortcut-btn"
          title="Shortcuts"
          style="cursor:pointer"
        >
          <v-bottom-sheet v-model="shortcutSheet" class="keyboard-sc-container">
            <img
              class="sidebar-icon"
              slot="activator"
              src="../assets/icon/keyboard.svg"
            />
            <v-layout row wrap class="keyboard-shortcut-container">
              <v-flex xs4 v-for="shortcut in KEYS" :key="shortcut.key">
                <v-layout row wrap class="single-key-container">
                  <v-flex xs7 class="key-desc-container">
                    {{ shortcut.desc }}
                  </v-flex>
                  <v-flex xs5 class="key-group-container">
                    <div class="key-container" v-if="shortcut.key1 != ''">
                      <span class="shortcut-key" v-if="shortcut.key1 != ''">{{
                        shortcut.key1
                      }}</span>
                    </div>
                    <div class="key-container" v-if="shortcut.key2 != ''">
                      + <span class="shortcut-key"> {{ shortcut.key2 }} </span>
                    </div>
                    <div class="key-container" v-if="shortcut.key3 != ''">
                      + <span class="shortcut-key"> {{ shortcut.key3 }} </span>
                    </div>
                  </v-flex>
                </v-layout>
              </v-flex>
            </v-layout>
          </v-bottom-sheet>
        </v-flex>
            </v-flex>
  </div>
              <!-- <v-list-tile @click="isAnnotationListOpen=true" class="toolbar-list-width"  title="Label List">
                <img src="../assets/icon/labelList.png">
              </v-list-tile> -->
  <v-card id="set" style="display:none;" class="annotation-setting-parameters--height">
 <v-card-actions class="setting-card-action">
 <table class="setting-card-parameters">
 <tr
 v-for="(settingItem, i) in classObj"
 :key="i"
 class="close"
 >
 <td>
 <input
 name="myfield"
 type="radio"
 v-bind:value="settingItem.name"
 v-model="radioSelect"
 @click="setClass(settingItem,i)"
 >
 <span class="setting-lbl">{{settingItem.name}}</span>
 </td> 
 </tr>
 </table>
 </v-card-actions>
 </v-card>

  <v-dialog
        v-model="showDialog"
        width="auto"
        class="dialog-container"
        v-if="isAnychange==true && showDialog==true"
      >
        <v-card>
          <v-card-title class="dialog-title">
            <v-layout row wrap>
              <v-flex>
                <v-subheader>
                  <p class="dialog-header">Please save your changes first.</p>
                </v-subheader>
              </v-flex>
            </v-layout>
          </v-card-title>

          <v-card-actions>
            <v-spacer></v-spacer>
            <v-btn small class="action-button" @click.native="showDialog = false" @click="saveAnnos()">OK</v-btn>
            <v-btn small class="action-button" @click.native="showDialog = false" @click="discardChanges()">Cancel</v-btn>
            <v-spacer></v-spacer>
          </v-card-actions>
        </v-card>
      </v-dialog>     
  <v-dialog
            v-model="isQueryError"
            persistent
            width="auto"
            class="dialog-container"
            v-if="isQueryError ==true"
          >
            <v-card>
              <v-card-title class="dialog-title">
                <v-layout row wrap>
                  <v-flex>
                    <v-subheader>
                      <p class="dialog-header"><b>Something went wrong, please contact with admin.</b>  <br> {{"Error Message: "}} {{this.queryErrorResult}}</p>
                    </v-subheader>
                  </v-flex>
                </v-layout>
              </v-card-title>
              <v-card-actions>
                <v-spacer></v-spacer>
            <v-btn small class="action-button" flat to="/login" @click="sessionStorage.clear()" @click.native="isQueryError = false">OK</v-btn>
              </v-card-actions>
            </v-card>
          </v-dialog>
          <v-dialog
            v-model="saveStatus"
            width="auto"
            v-if="saveStatus==true"
          >
            <v-card>
              <v-card-title class="dialog-title">
                <v-layout row wrap>
                  <v-flex>
                    <v-subheader>
                      <p class="dialog-header">Your changes has been saved successfully.</p>
                    </v-subheader>
                  </v-flex>
                </v-layout>
              </v-card-title>
            </v-card>
          </v-dialog> 
          <div id="wrapper">
    <div id="label-tool-wrapper"></div>
  </div>
  <!-- <div class="frame-selector">
      <div class="current">1/900</div>
      <div class="list-wrapper">
          <div class="frame-selector__frames"></div>
      </div>
  </div> -->
  </v-app>
</template>   
<script src="./ToolsJS/3D_js/editor_3d.js"></script>
<style src="@/assets/css/main.css"></style>
<style src="@/assets/css/w2ui-1.5.rc1.min.css"></style>
<style src="@/assets/css/jspanel.css"></style>
<style src="@/assets/css/label_tool.css"></style>
<style scoped src="@/assets/css/editor.css"></style>
<style scoped src="@/assets/css/editor_3d.css"></style>
<style src="@/assets/css/editor_3d.css"></style>