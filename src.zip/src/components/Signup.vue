<template>
  <v-app :dark="isDarkMode == true" class="page-container">
    <main>
      <v-layout row wrap class="main-container">
        <v-flex xs6 xm6 class="left-container">
          <div class="action-box-container">
            <!-- <p class="item-1">Annotate</p>
            <p class="item-2">Validate</p>
            <p class="item-3">Evaluate</p>
            <p class="item-4">Annotate</p>
            <p class="item-5">Validate</p> -->
            <p class="item-1">Annotate</p>
            <p class="item-2">Validate</p>
            <p class="item-3">Evaluate</p>
            <p class="item-4">Moderate</p>
          </div>
          <v-flex class="background-overlay left-inner-container">
            <img
              class="nat-logo"
              src="../assets/icon/PurifAI_boxed.svg"
              alt=""
            />
            <img
              class="noises-logo"
              src="../assets/icon/noises-logo.png"
              alt=""
            />
          </v-flex>
        </v-flex>

        <v-flex xs6 xm6 class="right-container">
          <div class="form-container">
            <h3 class="form-title">Create an account</h3>
            <!-- <form @click.native.prevent="login">
              <v-flex xs12 class="input-field-container">
                <input
                  v-model="username"
                  type="text"
                  placeholder="username"
                  required
                  class="cust-input-field username-field"
                />
              </v-flex>
              <v-flex xs12 xm12 class="input-field-container">
                <input
                  v-model="password"
                  type="password"
                  placeholder="password"
                  @keyup.enter="login(username, password, path)"
                  required
                  class="cust-input-field"
                />
              </v-flex>
              <v-flex class="btn-container">
                <v-flex xs6>
                  <v-btn
                    class="login-btn"
                    @click="login(username, password, path)"
                    @keyup.enter="login(username, password, path)"
                    >log In</v-btn
                  >
                </v-flex>
                <v-flex xs6 class="forget-password-container">
                  <span class="forget-password-link">
                    <a class="link" @click="callSignup()">Fogot Password?</a>
                  </span>
                </v-flex>
                <span class="sign-up-link">Don't have an account? 
                  <a class="link" @click="callSignup()">Create account</a>
                </span>
              </v-flex>
            </form> -->

            <form @click.native.prevent="login">
              <v-flex xs12 class="input-field-container username-container">
                <v-flex xs6 class="username-field-container">
                  <input
                    v-model="firstname"
                    class="cust-input-field username-field"
                    type="text"
                    placeholder="First Name"
                    @blur="
                      hideErrorMessage();
                      firstnameError();
                    "
                    @focus="
                      firstnameerror = true;
                      firstnameLength = false;
                    "
                  />

                  <div
                    class="username-password-title  error-message"
                    v-if="firstnameerror == false"
                    :value="true"
                    type="error"
                  >
                    First name accept alphabet only.
                  </div>
                  <div
                    class="username-password-title  error-message"
                    v-if="firstnameLength == true"
                    :value="true"
                    type="error"
                  >
                    First name should not be blank.
                  </div>
                </v-flex>
                <v-flex xs5>
                  <input
                    v-model="lastname"
                    class="cust-input-field username-field"
                    type="text"
                    placeholder="Last Name"
                    @blur="
                      hideErrorMessage();
                      lastnameError();
                    "
                    @focus="
                      lastnameerror = true;
                      lastnameLength = false;
                    "
                  />
                  <div
                    class="username-password-title  error-message"
                    v-if="lastnameerror == false"
                    :value="true"
                    type="error"
                  >
                    Last name accept alphabet only.
                  </div>
                  <div
                    class="username-password-title  error-message"
                    v-if="lastnameLength == true"
                    :value="true"
                    type="error"
                  >
                    Last name should not be blank.
                  </div>
                </v-flex>
              </v-flex>

              <v-flex xs12 class="input-field-container">
                <input
                  class="cust-input-field username-field"
                  v-model="username"
                  type="text"
                  placeholder="Username"
                  @focus="
                    showTip = true;
                    userLength = false;
                    usernameType = false;
                  "
                  @blur="
                    hideErrorMessage();
                    usernameValidate();
                  "
                />
                <div
                  class="username-password-title  error-message"
                  v-if="userLength == true"
                >
                  username should not be less than 6 and more than 20
                  characters.
                </div>
                <div
                  class="username-password-title  error-message"
                  v-if="usernameType == true"
                >
                  Invalid username.
                </div>
              </v-flex>
              <v-flex xs12 class="input-field-container username-container">
                <v-flex xs6 class="username-field-container">
                  <input
                    v-model="password"
                    class="cust-input-field username-field"
                    type="password"
                    placeholder="Password"
                    @blur="hideErrorMessage(), validatePassword()"
                    @focus="
                      passwordWeak = false;
                      passwordMedium = false;
                      passwordStrong = false;
                      passwordLength = false;
                      passwordError = false;
                    "
                  />

                  <div
                    class="username-password-title  error-message"
                    v-if="passwordWeak == true"
                  >
                    WEAK! Your password should be atleast 8 characters long.
                  </div>
                  <div
                    v-if="passwordMedium == true"
                    class="medium-password error-message"
                  >
                    Medium!
                  </div>
                  <div
                    v-if="passwordStrong == true"
                    class="strong-password error-message"
                  >
                    Strong!
                  </div>
                  <div
                    v-if="passwordLength == true"
                    class="username-password-title  error-message"
                  >
                    Your password should not be more than 12 characters long.
                  </div>
                  <div
                    v-if="passwordError == true"
                    class="username-password-title  error-message"
                  >
                    Password must contain:
                    <ul>
                      <li>At least one capital letter</li>
                      <li>At least one small letter</li>
                      <li>At least one special character</li>
                      <li>At least one numeric value</li>
                    </ul>
                  </div>
                </v-flex>
                <v-flex xs5 class="">
                  <input
                    v-model="confirmpassword"
                    class="cust-input-field username-field"
                    type="password"
                    placeholder="Confirm Password"
                    @blur="
                      comparePassword();
                      hideErrorMessage();
                    "
                    @focus="isPasswordSame = false"
                  />
                  <div
                    v-if="isPasswordSame == true"
                    class="username-password-title  error-message"
                    :value="true"
                    type="error"
                  >
                    Password and Confirm Password is not same.
                  </div>
                </v-flex>
              </v-flex>
              <v-flex xs12 class="input-field-container">
                <input
                  class="cust-input-field username-field"
                  v-model="contact"
                  type="text"
                  placeholder="Contact Number"
                  @blur="
                    hideErrorMessage();
                    contactlength();
                  "
                />
                <div
                  class="username-password-title  error-message"
                  v-if="iscontactlength == false || contactint == false"
                  :value="true"
                  type="error"
                >
                  Invalid contact number
                </div>
              </v-flex>
              <!-- <v-flex xs12 class="input-field-container username-container">
              <v-flex xs6 class="">
                <input
                  class="cust-input-field username-field"
                  v-model="authPIN"
                  type="password"
                  placeholder="Six Digits Authentication PIN"
                  @blur="hideErrorMessage(); authPinError()"
                  @focus="authPinErrorMsg = false; sequentialVal = false"
                />
                <div
                  class="username-password-title  error-message"
                  v-if="authPinErrorMsg == true"
                >                  
                  Authentication PIN should be a 6 digits number only.
                </div>
                <div
                  class="username-password-title  error-message"
                  v-if="sequentialVal == true && authPinErrorMsg == false"
                >                  
                  Enter Strong Authentication PIN.
                </div>
              </v-flex>
              <v-flex xs5 class=" ">
                <input
                  class="cust-input-field username-field"
                  v-model="confirmAuthPIN"
                  type="password"
                  placeholder="Confirm Authentication PIN"
                  @blur="hideErrorMessage(); compareAuthPIN()"
                  @focus="isAuthPINSame = true;"
                />
                <div
                  class="username-password-title  error-message"
                  v-if="isAuthPINSame == false"
                >                  
                  Auth. PIN and Confirm Auth. PIN is not same.
                </div>
              </v-flex>
            </v-flex> -->
              <v-flex xs12 class="input-field-container .question-dropdown">
                <v-select
                  class="form-group del question-dropdown cust-input-field"
                  v-model="securityQuestion"
                  :items="securityQuestions"
                  label="Select a security question"
                  solo
                  @change="changeSecurityQuestion($event)"
                >
                  <option value="" selected disabled
                    >Choose a security question</option
                  >
                  <option
                    v-for="question in securityQuestions"
                    :value="question.name"
                    :key="question.id"
                    >{{ question.name }}</option
                  >
                </v-select>
              </v-flex>
              <v-flex xs12 class="input-field-container">
                <input
                  v-model="securityAnswer"
                  class="cust-input-field username-field"
                  type="password"
                  placeholder="Answer"
                  @blur="hideErrorMessage(), validateAnswer()"
                />
                <div
                  v-if="answerError == true"
                  class="username-password-title  error-message"
                  :value="true"
                  type="error"
                >
                  Answer should not be blank.
                </div>
              </v-flex>

              <v-flex xs12 class="input-field-container">
                <div class="captcha-container">
                  <!-- <div xs12 class="title-container">
                    <v-flex class="captcha-font">CAPTCHA</v-flex>
                  </div> -->
                  <div class="captcha-input-container">
                    <div class="captcha-code-container">
                      <v-flex class="captcha-code">{{ captcha_code }}</v-flex>
                      <img
                        slot="activator"
                        class="captcha-refresh"
                        src="../assets/icon/refresh.svg"
                        @click="newCaptcha()"
                        title="Change CAPTCHA"
                      />
                    </div>
                    <span>
                      <input
                        class="cust-input-field captcha-field"
                        v-model="captcha"
                        type="text"
                        placeholder="Enter CAPTCHA"
                        @focus="isCaptchaMatch = true"
                      />
                      <div
                        v-if="isCaptchaMatch == false"
                        :value="true"
                        type="error"
                        class="error-message"
                        style="text-align:center;"
                      >
                        CAPTCHA doesn't match.
                      </div>
                    </span>
                  </div>
                </div>
                <div
                  class="error-message"
                  v-if="showError == true"
                  :value="true"
                  type="error"
                >
                  Please enter valid values.
                </div>
              </v-flex>
              <v-btn
                class="login-btn full-width-btn cust-primary-btn"
                @click="
                  registerUser(
                    firstname,
                    lastname,
                    username,
                    password,
                    contact,
                    securityQuestion,
                    securityAnswer
                  )
                "
                @keyup.enter="
                  registerUser(
                    firstname,
                    lastname,
                    username,
                    password,
                    contact,
                    securityQuestion,
                    securityAnswer
                  )
                "
                >Sign Up</v-btn
              >
              <div
                v-if="userSave && isUserRegistered == true"
                class="error-message green-message"
              >
                You have registered successfully.
                <a class="link " @click="callLogin()">Login Now</a>
              </div>
              <div
                v-if="isUserRegisteredconfirm && isUserRegistered == false"
                class="error-message"
              >
                User already exist. Try with different username.
              </div>
              <div v-if="isQueryError == true" class="error-message">
                Something went wrong
              </div>

              <v-flex xs6 class="forget-password-container">
                <span class="back-to-login-link"
                  >Back To
                  <a class="link" @click="callLogin()">Login</a>
                </span>
              </v-flex>
            </form>
          </div>
        </v-flex>
      </v-layout>

      <!-- <div class="header-wrapper">
        <div class="zoominheader">
          
        </div>
      </div>
      <div class="action-box-container">
        <p class="item-1">Annotate</p>
        <p class="item-2">Validate</p>
        <p class="item-3">Evaluate</p>
        <p class="item-4">Annotate</p>
        <p class="item-5">Validate</p>
      </div>
      <div class="shape-box-container">
        <p class="item-1">B Boxes</p>
        <p class="item-2">Polygon</p>
        <p class="item-3">3D Cube</p>
        <p class="item-4">Line</p>
        <p class="item-5">Dot</p>
      </div>
      <section>
        <v-container class="login-page-container">
          <div class="login-page">
            <div class="login-form">
              <img src="../assets/icon/logo2.png"/>
              <form @click.native.prevent ="login">
                <input v-model="username" type="text" placeholder="username" required>
                <input v-model="password" type="password" placeholder="password"
                @keyup.enter="login(username,password,path)" required>
                <v-btn primary dark @click="login(username,password,path)"
                @keyup.enter="login(username,password,path)">login</v-btn>
                <div>
                <span class="message login-tool-support-section">
                  <a onclick="window.open('static/HCL_NAT_User_Manual_v1.6.pdf', '_blank');">Tool Support</a>
                </span>
                <span class="tool-signup-style"></span>
                 <span class="message login-tool-support-section">
                  <a @click="callSignup()">Sign Up</a> 
                </span>
                </div>
              </form>
              <v-alert v-if="required==true && noProjectAssigned==false" :value="true" type="error">Login Failed - Please Check your Credentials
               and try again</v-alert>
              <v-alert v-if="noProjectAssigned==true && required==false" :value="true" type="error">No Project Assigned Please Contact your Admin
               </v-alert> 
               <v-alert v-if="required==false && isUsersignedUp==false && noProjectAssigned==true" :value="true" type="error">You are not registered. Please click "Sign UP" to continue.</v-alert>
               <span class="version-info-style">{{version}}</span>
            </div>
          </div>
          <v-dialog
            v-model="isQueryError"
            persistent
            width="auto"
            class="dialog-container"
            v-if="isQueryError ==true">
            <v-card>
              <v-card-title class="dialog-title">
                <v-layout row wrap>
                  <v-flex>
                    <v-subheader>
                    <p class="dialog-header"><b>Something went wrong, please contact with admin.</b>  <br> {{"Error Message: "}} {{this.queryErrorResult}}</p>
                    </v-subheader>
                  </v-flex>
                </v-layout>
              </v-card-title>
              <v-card-actions>
                <v-spacer></v-spacer>
                <v-btn small class="action-button" flat to="/login" @click="sessionStorage.clear()" @click.native="isQueryError = false">OK</v-btn>
              </v-card-actions>
            </v-card>
          </v-dialog>
        </v-container>
      </section>
      <Appfooter/> -->
    </main>
  </v-app>
</template>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<script src="./ToolsJS/2D_js/Signup.js"></script>
<style scoped src="@/assets/css/main.css"></style>
<style scoped src="@/assets/css/login-signup.css"></style>
