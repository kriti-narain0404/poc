import Appfooter from "../../../shared/Appfooter.vue";
import authPinModel from "../../../model/authPinModel.js";
import SettingService from "../../../services/SettingService.js";
import { GENERATE_TFA, OBJ_TFA_LOGIN, TFA_WRITE } from "../../../constants/graphql";

export default {
  name: "authPin",
  props: [],
  components: {
    Appfooter
  },
  data() {
    return authPinModel; // Moved to model SignupModel
  },  
  methods: {
    verify: function(username, otp, secret){
      this.active = 0;
      this.$apollo
          .mutate({
              mutation: OBJ_TFA_LOGIN,
              variables: {
                  username: username,
                  otp: otp,
                  secret: secret,
              }
       })
          .then(data=>{
              this.active = data.data.loginTfa.activated;
              if (this.active == 1){
                if (this.secret){
                  this.isTfaSetupSuccess = true;
                }else{
                  this.callHome();
                }
                
              }
              else{if(this.active == 2){
                      this.isAccountLocked = true;
                  }else{
                    this.isOtpIncorrect = true;
                }
              }
          })
    },
    callLogin: function () {
      this.$router.push({ name: 'login' });
    },
    callHome: function () {
      this.$router.push({path: "home"});
    },

    logintfa: function(otp){
      var specialch = /^\d{6}$/;
      this.getAuthPINError = false;

      try {
          if (this.otp != "" && specialch.test(this.otp)) {
              let username = sessionStorage.getItem('login');
              let secret = this.secret;
              this.verify(username, otp, secret);
          } 
          else {
            this.getAuthPINError = true;
            return;
          }
        } catch (error) {
          console.log("Error:", error);
        }
    },

    
    clearFields: function () {
      try{
            this.authPINCode = "";
            this.getAuthPINError = false;
            this.isPINMatchError = false;
            this.isTfaSetupSuccess = false;
            this.isAccountLocked = false;
            this.isOtpIncorrect = false;
            this.otp = "";     
      } catch (error) {
        console.log("Error:", error);
      }
    },

    makeid: function(username) {
      this.secret = "";
      this.response = "";
      if (sessionStorage.getItem('authUserPin') == ""){
        this.$apollo
          .mutate({
            mutation: GENERATE_TFA,
            variables: {
              username: username,
            }
          })
          .then(data=>{
            this.secret = data.data.generateSecret.secret;
            this.qr = data.data.generateSecret.qr;
            // this.secret = this.response;
            this.createqr()
            // alert(this.secret);
            return this.qr;
          })
          .catch(error=>{
            console.log(error)
          })

        }
        return this.secret
      },

      createqr: function(){
        var x = 0;
            var y = 0;
            // const ctx = canvas.getContext("2d");
            for (let i = 0 ; i < this.qr.length ; i++){
              if (this.qr.charAt(i) == '\n'){
                y = y + 4;
                x = 0;
              }else{
                if (this.qr.charAt(i) == '1' ){
                  // console.log(this.qr.charAt(i));
                  // this.vueCanvas.beginPath();
            this.vueCanvas.fillRect(x, y, 4, 4);
            // this.vueCanvas.fill();
            x = x + 4;
              }else{
                x = x + 4;
              }
            }}

          // if (canvas.getContext) {
            // console.log(canvas.getContext)
            
        return;
      },
    // submitUser: function () {
    //   try{
    //     this.isPINMatchError = false;
    //     let savedAuthPIN = atob(sessionStorage.getItem('authUserPin'));
    //     if(this.authPINCode != "" && this.authPINCode == savedAuthPIN){
    //       this.$router.push({ path: "home" });
    //     } 
    //     else{
    //       this.isPINMatchError = true; 
    //     }       

    //   } catch (error) {
    //     console.log("Error:", error);
    //   }
    // },
    getThemeMode: function() {
      this.isDarkMode = SettingService.getDarkMode();
    },
  },
  
  mounted: function () {
    // this.getAuthPINError = false;
    // this.vueCanvas.clearRect(0, 0, 200, 200);
    this.qr = '';
    this.makeid(sessionStorage.getItem('login'));
    const canvas = document.getElementById('canvas');  
    // console.log(canvas);
    const ctx = canvas.getContext("2d");
    this.vueCanvas = ctx;
    this.secret = "";
    // console.log("secret:");
    this.clearFields();
  }, 
  beforeMount() {
    this.getThemeMode();
  },
};
