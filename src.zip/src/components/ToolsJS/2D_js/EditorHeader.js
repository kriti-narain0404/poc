import HomeHeader from "../../../shared/HomeHeader.vue";
import Appfooter from "../../../shared/Appfooter.vue";

export default {
  name: "home",
  components: {},
  props: ["project"],
  components: {
    "home-header": HomeHeader,
    "app-footer": Appfooter
  },
  data() {
      return {
        submitDialog: false
      }
  },
  methods: { 
  callInbox(link) {
    this.$emit("inboxEvent", { data: "inbox" });
    this.$router.push({ path: link, query: { plan: this.fwdUserId,username: this.username, role: this.role } });
  },
  callDashbord(link) {
    this.$router.push({ path: link, query: { plan: this.fwdUserId,username: this.username, role: this.role } });
  },
  callSetting: function(link) {
    this.$router.push({ path: link, query: { plan: this.fwdUserId,username: this.username, role: this.role } });
  },
  finalSubmit: function(link) {
      this.$apollo
        .mutate({
          mutation: VIDEO_PROCESSED_MUTATION,
          variables: {
            videoid: this.videoId
          }
        })
        .then(data => {
          this.image = data.data.updateVideoProcessed;
          this.callInbox(this.homePath);
        });
      this.submitDialog = false;
  },
  mounted: function() {
    EventBus.$emit("adjustthreshold", true);
  },

  onLoad: function() {
  }
}
  }

