import { fabric } from "fabric";
import RangeSlider from "vue-range-slider";
import Swatches from "vue-swatches";
import keys from "../../../constants/keyboard.js";
import "vue-range-slider/dist/vue-range-slider.css";
import { SAVE_OBJ_DETECT_IMAGE } from "../../../constants/graphql";
import { CHECK_SAVE_OBJ_DETECT_IMAGE } from "../../../constants/graphql";
import { CHECK_SAVE_OBJ_DETECT_IMAGE_FORWARD } from "../../../constants/graphql";
import { CHECK_SAVE_OBJ_DETECT_IMAGE_BACKWARD } from "../../../constants/graphql";
import { NEXT_OBJ_VIDEO_IMG_QUERY } from "../../../constants/graphql";
import { PREV_OBJ_VIDEO_IMG_QUERY } from "../../../constants/graphql";
import { CHANGE_ORIENTATION } from "../../../constants/graphql";
import { ALL_IMAGE_DETAIL_MUTATION } from "../../../constants/graphql";
import { IMG_PROC_PARAMETER_SEND } from "../../../constants/graphql";
import { GET_SETTING_OBJ_DATA } from "../../../constants/graphql";
import { AFTER_SAVE_FRAME } from "../../../constants/graphql";
import Rectangle from "../../../model/Rectangle.js";
import { Polygon, defaultPolygonPty } from "../../../model/Polygon.js";
import { Circle } from "../../../model/Circle.js";
import Appfooter from "../../../shared/Appfooter.vue";
import HomeHeader from "../../../shared/HomeHeader.vue";
import EditorModel from "../../../model/EditorModel.js";
import Line from "../../../model/Line.js";
import loadPolygonLine from "../../../utils/drawLine.js";
import { FILE_DOWNLOAD_MUTATION } from "../../../constants/graphql";
import { getNextZoomInFactor, getNextZoomOutFactor } from "./zoom_handling.js";
import SettingService from "../../../services/SettingService.js";

const BOX_LABEL = "box";
const EC_LABEL = "extremeClick";
const POLY_CLICK_LABEL = "polygonClick";
const POINT_CLICK_LABEL = "pointClick";
const POLYGON_LABEL = "polygon";
const POLY_LINE_LABEL = "polygonLine";
const LINE_LABEL = "Line";
const TAG_LABEL = "Image_Tag";
const LABEL_TYPES = [
  BOX_LABEL,
  EC_LABEL,
  POLYGON_LABEL,
  POLY_CLICK_LABEL,
  POLY_LINE_LABEL,
  LINE_LABEL,
  POINT_CLICK_LABEL,
  TAG_LABEL,
];
const RESOLUTION_WIDTH = 1920;
const RESOLUTION_HEIGHT = 1080;

var print = function(text) {};

var LabeledRect = fabric.util.createClass(fabric.Rect, {
  type: "labeledRect",
  initialize: function(options) {
    options || (options = {});
    this.callSuper("initialize", options);
    this.set("label", options.label || "");
  },

  toObject: function() {
    return fabric.util.object.extend(this.callSuper("toObject"), {
      label: this.get("label"),
    });
  },
  _render: function(ctx) {
    this.callSuper("_render", ctx);
    let text = this.label;
    ctx.font = "1px Helvetica";
    ctx.fillStyle = "#ffffff";
    ctx.fillText(text, -this.width / 2, -this.height / 2 + 8);
  },
});

var canvas;
var drawRect,
  drawRatioRectLine,
  prevSelected,
  polyCircle,
  drawPolygon,
  drawLine,
  drawExtremeClick;
var drawCircle,
  selectedProp = null,
  drawFreeDraw,
  drawfloodfill,
  origX,
  origY;
let editRatioLineMode = false,
  activeAnnoMode = null;
var parameterVal = [],
  borderColorProp = [];
var allAnnos = [];
var editPolygon = [];
var circleArray = [];
var rectParam = [];
var polyParam = [];
var jsonArray = [];
var jsonResult = [];

var fromFile = 1;

export default {
  name: "editor",
  components: {
    "home-header": HomeHeader,
    fabric,
    RangeSlider,
    Appfooter,
    Swatches,
  },
  props: ["project"],

  data() {
    return EditorModel; // Moved to model EditorModel
  },

  apollo: {
    getSettingObject: {
      query: GET_SETTING_OBJ_DATA,
      variables() {
        const userid = SettingService.getSelectedUserId();
        const projectId = SettingService.getSelectedProject();
        const video_id = SettingService.getSelectedVideo().videoid;
        return {
          userid,
          projectId,
          fromFile,
          video_id,
        };
      },
      result({ data, loader, networkStatus }) {
        var settingData = [];
        settingData = JSON.parse(data.getSettingObject.settingObject);
        this.radioValue = data.getSettingObject.predType;
        this.modelSelection = data.getSettingObject.modelType;
        this.folderPath = data.getSettingObject.folderPath;
        this.minheight = data.getSettingObject.minHeight;
        this.minwidth = data.getSettingObject.minWidth;
        this.annotationTip = data.getSettingObject.annoTip;
        this.consolidated_annotation_change_info = JSON.parse(
          data.getSettingObject.classData
        );
        try {
          this.paramObj = [];
          this.imageTagObj = [];
          this.classObj = [];
          this.subclassObj = [];
          this.classObjNames = [];
          let cnt = 0;
          let paramCnt = 0;
          if (settingData != null) {
            for (var i = 0; i < settingData.length; i++) {
              if (settingData[i].selected === true) {
                this.classObj.push({
                  id: settingData[i].id,
                  name: settingData[i].name,
                  selected: settingData[i].selected,
                  type: settingData[i].type,
                  color: settingData[i].color,
                  length: settingData[i].length,
                });
                this.classObjNames.push(settingData[i].name);
                if (settingData[i].parameters) {
                  for (var j = 0; j < settingData[i].parameters.length; j++) {
                    if (settingData[i].parameters[j].selected === true) {
                      this.paramObj.push({
                        id: settingData[i].parameters[j].id,
                        name: settingData[i].parameters[j].name,
                        selected: settingData[i].parameters[j].selected,
                        type: settingData[i].parameters[j].type,
                        color: settingData[i].parameters[j].color,
                        paralength: settingData[i].parameters[j].length,
                      });
                      this.classObj[cnt]["param"] = this.paramObj;
                      if (
                        settingData[i].parameters[j].subClass &&
                        settingData[i].parameters[j].subClass !== undefined
                      ) {
                        for (
                          var k = 0;
                          k < settingData[i].parameters[j].subClass.length;
                          k++
                        ) {
                          if (
                            settingData[i].parameters[j].subClass[k]
                              .selected === true
                          ) {
                            this.subclassObj.push({
                              id: settingData[i].parameters[j].subClass[k].id,
                              name:
                                settingData[i].parameters[j].subClass[k].name,
                              selected:
                                settingData[i].parameters[j].subClass[k]
                                  .selected,
                              type:
                                settingData[i].parameters[j].subClass[k].type,
                              color:
                                settingData[i].parameters[j].subClass[k].color,
                              paralength:
                                settingData[i].parameters[j].subClass[k].length,
                            });
                            this.classObj[cnt].param[paramCnt][
                              "subClass"
                            ] = this.subclassObj;
                          }
                        }
                        this.subclassObj = [];
                      }
                      paramCnt = paramCnt + 1;
                    }
                  }
                  this.paramObj = [];
                  paramCnt = 0;
                }
                cnt = cnt + 1;
              }
            }
            this.imageId = this.$route.query.imageid;
            if (this.imageId == 0) this.first_image();
            else this.requestImage(this.imageId, null, 2);
          }
        } catch (error) {
          console.log("Error:", error);
        }
      },
    },
  },

  computed: {
    filters() {
      const toDash = (str) =>
        str.replace(/([a-z])([A-Z])/g, "$1-$2").toLowerCase();
      this.filter = {
        filter:
          "grayscale(" +
          this.grayscale +
          ") brightness(" +
          this.brightness +
          ") contrast(" +
          this.contrast +
          ")",
      };
    },
    filteredImageList: function() {
      return this.allImagesList.filter((e) =>
        e.toLowerCase().includes(this.search.toLowerCase())
      );
    },
  },

  filters: {
    capitalize: function(value) {
      if (!value) return "";
      value = value.toString();
      return value.charAt(0).toUpperCase() + value.splice(1);
    },
  },

  destroyed: function() {
    window.removeEventListener("keyup", this.keyupTextfn);
    window.removeEventListener("keyup", this.keydownTextfn);
    window.removeEventListener("keyup", this.keyupfn);
    window.removeEventListener("keydown", this.keydownfn);

    window.removeEventListener("mouseup", this.mouseHandlerWindow);
    window.removeEventListener("mousedown", this.mouseHandlerWindow);
    window.removeEventListener("mousemove", this.mouseHandlerWindow);
    window.removeEventListener("mousemoving", this.mouseHandlerWindow);
    window.removeEventListener("mouseover", this.mouseHandlerWindow);
    window.removeEventListener("mouseout", this.mouseHandlerWindow);
    window.removeEventListener("mousewheel", this.mouseHandlerWindow);
    window.removeEventListener("scroll", this.scrollView);
  },
  created: function() {
    let self = this;
    window.addEventListener("mouseup", this.mouseHandlerWindow);
    window.addEventListener("mousedown", this.mouseHandlerWindow);
    window.addEventListener("mousemove", this.mouseHandlerWindow);
    window.addEventListener("mousemoving", this.mouseHandlerWindow);
    window.addEventListener("mouseover", this.mouseHandlerWindow);
    window.addEventListener("mouseout", this.mouseHandlerWindow);
    window.addEventListener("mousewheel", this.mouseHandlerWindow);
    window.removeEventListener("keyup", this.keyupfn);
    window.removeEventListener("keydown", this.keydownfn);
    window.addEventListener("keyup", this.keyupfn);
    window.addEventListener("keydown", this.keydownfn);
    window.addEventListener("scroll", this.scrollView);
    this.screenWidth = screen.width;
    this.screenHeight = screen.height;
  },

  methods: {
    disableBack: function() {
      history.pushState(null, null, location.href);
      window.onpopstate = function() {
        history.go(1);
      };
    },
    callSettingScreen: function() {
      this.$router.push({ name: "setting" });
    },

    /**
     * function to load image on page load
     */

    consolidate_annotations: function(data) {
      if (this.consolidated_annotation_change_info) {
        //for second time run
        for (var key in data) {
          if (this.consolidated_annotation_change_info[key]) {
            for (var operation_type in data[key]) {
              this.consolidated_annotation_change_info[key][operation_type] =
                this.consolidated_annotation_change_info[key][operation_type] +
                data[key][operation_type];
            }
          } else {
            this.consolidated_annotation_change_info[key] = data[key];
          }
        }
      } else {
        // this is for first time run
        this.consolidated_annotation_change_info = data;
      }
    },

    method_classes_formatter: function(data) {
      //to make a dictionary for classwise data
      const class_counts = {};
      for (var j = 0; j < data.length; j++) {
        class_counts[data[j]] = {
          editlabel_m: 0,
          editcoord_m: 0,
          editparam_m: 0,
          editlabel_a: 0,
          editcoord_a: 0,
          editparam_a: 0,
          interpolated: 0,
          added_m: 0,
          added_a: 0,
          deleted_a: 0,
          deleted_m: 0,
        };
      }
      return class_counts;
    },

    method_counter: function(
      annotation_labels_info,
      annotation_ids_info,
      unique_classes,
      operation_type_input
    ) {
      // this method counts classes for case 2 and 3 in the anno_currator method
      let class_counts = this.method_classes_formatter(unique_classes);
      let operation_type = null;
      for (var i = 0; i < annotation_labels_info.length; i++) {
        if (annotation_ids_info[i].includes("M-", 0)) {
          operation_type = operation_type_input + "_m";
        } else {
          operation_type = operation_type_input + "_a";
        }
        class_counts[annotation_labels_info[i]][operation_type] =
          1 + (class_counts[annotation_labels_info[i]][operation_type] || 0);
      }
      console.log("operation_type", operation_type_input);
      return class_counts;
    },

    method_comparator_label: function(previous_data, new_data) {
      // this method compares the labels, parameters, bbox or coordinates.
      if (JSON.stringify(previous_data) === JSON.stringify(new_data)) {
        return 0;
      } else {
        return 1;
      }
    },

    attribute_formatter: function(data, key_name, value_name) {
      let response = {};
      for (let attribute_no = 0; attribute_no < data.length; attribute_no++) {
        response[data[attribute_no][key_name]] = data[attribute_no][value_name];
      }
      return response;
    },

    anno_formatter: function(data) {
      // data: annotation data
      // this method creates a data for formatting.
      let annotation_formatted = {};
      let anno_labels = [];
      let anno_id_info = [];
      if (data.length > 0) {
        annotation_formatted["bbox"] = {};
        annotation_formatted["polygon"] = {};
        for (let anno_number = 0; anno_number < data.length; anno_number++) {
          let anno_data = data[anno_number];
          if (anno_data["bbox"]) {
            annotation_formatted["bbox"][anno_data["id"]] = {};
            annotation_formatted["bbox"][anno_data["id"]]["label"] =
              anno_data["label"];
            annotation_formatted["bbox"][anno_data["id"]]["coordinates"] = {
              xmin: anno_data["bbox"]["xmin"],
              ymin: anno_data["bbox"]["ymin"],
              xmax: anno_data["bbox"]["xmax"],
              ymax: anno_data["bbox"]["ymax"],
            };
            annotation_formatted["bbox"][anno_data["id"]][
              "parameters"
            ] = this.attribute_formatter(
              anno_data["bbox"]["parameters"],
              "nam",
              "val"
            );
            anno_labels.push(anno_data["label"]);
            anno_id_info.push(anno_data["id"]);
          } else if (anno_data["polygon"]) {
            annotation_formatted["polygon"][anno_data["id"]] = {};
            annotation_formatted["polygon"][anno_data["id"]]["label"] =
              anno_data["label"];
            annotation_formatted["polygon"][anno_data["id"]][
              "parameters"
            ] = this.attribute_formatter(
              anno_data["polygon"]["parameters"],
              "nam",
              "val"
            );
            annotation_formatted["polygon"][anno_data["id"]][
              "coordinates"
            ] = this.attribute_formatter(
              anno_data["polygon"]["points"],
              "id",
              "x"
            );
            anno_labels.push(anno_data["label"]);
            anno_id_info.push(anno_data["id"]);
          }
        }
      }
      return [annotation_formatted, anno_labels, anno_id_info];
    },

    method_comparator_attributes: function(old_values, new_values) {
      for (var key in old_values) {
        if (new_values[key] != old_values[key]) {
          return 1;
        }
      }
      return 0;
    },

    method_comparison_handler: function(
      old_anno,
      new_anno,
      class_operations_info
    ) {
      let editlabel_operation = null,
        editcoord_operation = null,
        editparam_operation = null,
        delete_operation = null;
      for (var key in old_anno) {
        if (key.includes("M-", 0)) {
          editlabel_operation = "editlabel_m";
          editcoord_operation = "editcoord_m";
          editparam_operation = "editparam_m";
          delete_operation = "deleted_m";
        } else {
          editlabel_operation = "editlabel_a";
          editcoord_operation = "editcoord_a";
          editparam_operation = "editparam_a";
          delete_operation = "deleted_a";
        }
        if (new_anno[key]) {
          class_operations_info[old_anno[key]["label"]][editlabel_operation] =
            this.method_comparator_label(
              old_anno[key]["label"],
              new_anno[key]["label"]
            ) +
            class_operations_info[old_anno[key]["label"]][editlabel_operation];
          class_operations_info[old_anno[key]["label"]][editcoord_operation] =
            this.method_comparator_attributes(
              old_anno[key]["coordinates"],
              new_anno[key]["coordinates"]
            ) +
            class_operations_info[old_anno[key]["label"]][editcoord_operation];
          class_operations_info[old_anno[key]["label"]][editparam_operation] =
            this.method_comparator_attributes(
              old_anno[key]["parameters"],
              new_anno[key]["parameters"]
            ) +
            class_operations_info[old_anno[key]["label"]][editparam_operation];
        } else {
          class_operations_info[old_anno[key]["label"]][delete_operation] =
            1 + class_operations_info[old_anno[key]["label"]][delete_operation];
        }
      }
      let operation_type = null;
      for (var key in new_anno) {
        if (!old_anno[key]) {
          if (key.includes("M-", 0)) {
            operation_type = "added_m";
          } else {
            operation_type = "added_a";
          }
          class_operations_info[new_anno[key]["label"]][operation_type] =
            1 + class_operations_info[new_anno[key]["label"]][operation_type];
        }
      }
      return class_operations_info;
    },

    anno_curator: function(previous_annotations, new_annotations) {
      /*
                four cases
                1. previous no, new no
                2. previous no, new yes: create dict with classes as key and value as {added:0}
                //handle te 3rd point in fourth one.
                3. previous yes, new no: create dict with classes as key and value as {deleted:0}
                4. previous yes, new yes: create dict with classes as key and value as {edit:0, added:0, deleted:0}
            */

      if (previous_annotations.length === 0 && new_annotations.length === 0) {
        return null;
      } else {
        let data_formatted_previous = this.anno_formatter(previous_annotations);
        const previous_annotations_formatted = data_formatted_previous[0],
          previous_anno_labels = data_formatted_previous[1],
          prev_anno_ids = data_formatted_previous[2];
        let data_formatted_new = this.anno_formatter(new_annotations);
        const new_annotations_formatted = data_formatted_new[0],
          new_anno_labels = data_formatted_new[1],
          new_anno_ids = data_formatted_new[2];
        let unique_classes = [
          ...new Set([...previous_anno_labels, ...new_anno_labels]),
        ];
        if (previous_annotations.length > 0 && new_annotations.length === 0) {
          let deleted_count = this.method_counter(
            previous_anno_labels,
            prev_anno_ids,
            unique_classes,
            "deleted"
          );
          return deleted_count;
        } else if (
          previous_annotations.length === 0 &&
          new_annotations.length > 0
        ) {
          let added_count = this.method_counter(
            new_anno_labels,
            new_anno_ids,
            unique_classes,
            "added"
          );
          return added_count;
        } else if (
          JSON.stringify(previous_annotations_formatted) ===
          JSON.stringify(new_annotations_formatted)
        ) {
          return null;
        } else {
          let class_operations_info = this.method_classes_formatter(
            unique_classes
          );
          for (var key in previous_annotations_formatted) {
            let old_annotation = previous_annotations_formatted[key];
            let new_annotation = new_annotations_formatted[key];
            if (
              JSON.stringify(old_annotation) != JSON.stringify(new_annotation)
            ) {
              class_operations_info = this.method_comparison_handler(
                old_annotation,
                new_annotation,
                class_operations_info
              );
            }
          }
          return class_operations_info;
        }
      }
    },
    first_image: function() {
      this.imageId = 0;
      try {
        this.annotationJson = [];
        this.storeColorProp = [];
        borderColorProp = [];
        this.opacity = 0.25;
        this.color = "";
        this.fillBorder = "false";
        this.propInFrame = [];
        this.objList = [];
        activeAnnoMode = null;
        this.removeActiveToolEffect("annotation-tool");
        // this.objList[0] = "NA";
        const userid = SettingService.getSelectedUserId();
        this.fillColor = "NA";
        if (this.firstImageFlag == 0) {
          this.$apollo
            .mutate({
              mutation: NEXT_OBJ_VIDEO_IMG_QUERY,
              variables: {
                videoid: this.videoId,
                imageid: this.imageId,
                project: this.project,
                video_type: this.video_type,
                videoname: this.videoName,
                file: "",
                base64Image: "",
                annotations: null,
                copy_mode: this.copyMode,
                configure_flag: 2,
                project_id: this.projectId,
                userid: userid,
              },
            })
            .then((data) => {
              try {
                if (data.data.nextObjVideoImage != null) {
                  this.isQueryError = false;
                  this.image = data.data.nextObjVideoImage;
                  this.annotationJson = JSON.parse(
                    data.data.nextObjVideoImage.annos_json
                  );
                  this.imageIDSubtring = this.image.id
                    .substring(this.image.id.lastIndexOf("_"))
                    .substring(
                      1,
                      this.image.id.substring(this.image.id.lastIndexOf("_"))
                        .length
                    );
                  this.isBlurModeActive =
                    data.data.nextObjVideoImage.is_blur_mode_active;
                  this.videopath = atob(data.data.nextObjVideoImage.videopath);
                  this.imgsrc = atob(data.data.nextObjVideoImage.src);
                  this.imageId = data.data.nextObjVideoImage.imageId;
                  if (
                    this.image.orientation != 1 &&
                    this.image.orientation != null
                  ) {
                    this.showRotateMsg = true;
                  }
                  this.labels = data.data.nextObjVideoImage.labels;
                  this.firstImageCount = data.data.nextObjVideoImage.imageId;
                  this.tolatImageCount = data.data.nextObjVideoImage.imagecount;
                  this.lastImageCount =
                    this.firstImageCount + this.tolatImageCount;
                  this.videoName = data.data.nextObjVideoImage.videoname;
                  this.video_type = data.data.nextObjVideoImage.video_type;
                  this.width = data.data.nextObjVideoImage.width;
                  this.height = data.data.nextObjVideoImage.height;
                  this.isBlurModeActive =
                    data.data.nextObjVideoImage.is_blur_mode_active;
                  this.loadAllAnnotations();
                  this.scrollView();
                  this.getAnnotationList(this.imageId);
                  if (this.annotationJson.length > 0) {
                    this.getFrameProp();
                    jsonArray = JSON.parse(
                      data.data.nextObjVideoImage.annos_json
                    );
                  }
                  this.setLockUnlockAllValue();
                  this.isBlurActive = false;
                  if (this.isBlurModeActive) {
                    setTimeout(() => {
                      this.createImage();
                    }, 200);
                  }
                }
              } catch (error) {
                console.log("Error:", error);
              }
            })
            .catch((error) => {
              this.isQueryError = true;
              this.queryErrorResult = /:(.+)/.exec(error.message)[1];
            });
        }
        this.allLabelList = [];
        this.isTagOpen = false;
        this.isRectangleToolOpen = false;
        if (this.canvasHeight > 0 && this.canvasWidth > 0) {
          this.resetZoom();
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },
    scrollView: function() {
      try {
        $(function() {
          $("#scrollDiv").draggable();
        });
        var elementOuter = document.getElementById("scrollDiv");
        var elementInner = document.getElementById("scrollDivInner");
        var vertical_position;
        var horizontal_position;
        if (
          this.canvasWidth >= this.screenWidth ||
          this.canvasHeight >= this.screenHeight
        ) {
          this.insatViewDisplay = true;
          if (elementOuter === null || elementInner === null) {
            return;
          }
          elementOuter.style.display = "block";
          if (
            this.screenWidth === RESOLUTION_WIDTH &&
            this.screenHeight === RESOLUTION_HEIGHT
          ) {
            if (this.canvasHeight === this.screenHeight) {
              $("#scrollDivInner").css("margin-top", 0);
              $("#scrollDivInner").css("margin-left", 0);
            } else {
              vertical_position = window.pageYOffset / 24;
              $("#scrollDivInner").css("margin-top", vertical_position);
              horizontal_position =
                (window.pageXOffset * 80) / this.screenWidth;
              $("#scrollDivInner").css("margin-left", horizontal_position);
            }
          } else {
            if (this.canvasHeight === this.screenHeight) {
              $("#scrollDivInner").css("margin-top", 0);
              $("#scrollDivInner").css("margin-left", 0);
            } else {
              vertical_position = (window.pageYOffset * 22) / this.screenHeight;
              $("#scrollDivInner").css("margin-top", vertical_position);
              horizontal_position =
                (window.pageXOffset * 50) / this.screenWidth;
              $("#scrollDivInner").css("margin-left", horizontal_position);
            }
          }
        } else {
          this.insatViewDisplay = false;
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },

    openAnnottaor() {
      this.isAnnotationOpen = true;
    },
    openColorWindow() {
      if (this.duplicateObj == false) {
        this.isColorListOpen = !this.isColorListOpen;
        this.isZoomToolOpen = false;
        this.isShowPropToolOpen = false;
        this.isShowHideToolOpen = false;
        this.isFillToolOpen = false;
        this.isRectangleToolOpen = false;
        this.isFreeTextOpen = false;
        this.freeTextMode = false;
      } else {
        this.showDuplicateDialog = true;
      }

      if (this.isColorListOpen == true) {
        this.addActiveToolEffect("color-palette-btn");
      } else {
        this.removeActiveToolEffect("dialog-toggler", "color-palette-btn");
      }
    },
    openImageWindow() {
      if (this.duplicateObj == false) {
        this.isImageToolOpen = !this.isImageToolOpen;
        this.isZoomToolOpen = false;
        this.isShowPropToolOpen = false;
        this.isShowHideToolOpen = false;
        this.isFillToolOpen = false;
        this.isRectangleToolOpen = false;
        this.isFreeTextOpen = false;
        this.freeTextMode = false;
      } else {
        this.showDuplicateDialog = true;
      }

      if (this.isImageToolOpen == true) {
        this.addActiveToolEffect("image-tool-btn");
      } else {
        this.removeActiveToolEffect("dialog-toggler", "image-tool-btn");
      }
    },
    openRectangleTools() {
      if (this.duplicateObj == false) {
        $(function() {
          $("#scrollDiv").draggable();
        });
        this.isRectangleToolOpen = !this.isRectangleToolOpen;
        this.isZoomToolOpen = false;
        this.isShowPropToolOpen = false;
        this.isShowHideToolOpen = false;
        this.isFillToolOpen = false;
        this.isFreeTextOpen = false;
        this.freeTextMode = false;
      } else {
        this.showDuplicateDialog = true;
      }
    },
    openZoomTools() {
      if (this.duplicateObj == false) {
        this.isZoomToolOpen = !this.isZoomToolOpen;
        this.isRectangleToolOpen = false;
        this.isShowPropToolOpen = false;
        this.isShowHideToolOpen = false;
        this.isFillToolOpen = false;
        this.isFreeTextOpen = false;
        this.freeTextMode = false;
      } else {
        this.showDuplicateDialog = true;
      }
    },
    openShowHideTools() {
      if (this.duplicateObj == false) {
        this.isShowPropToolOpen = false;
        this.isDeleteToolOpen = false;
        this.isShowHideToolOpen = !this.isShowHideToolOpen;
        this.isZoomToolOpen = false;
        this.isRectangleToolOpen = false;
        this.isFillToolOpen = false;
        this.isFreeTextOpen = false;
        this.freeTextMode = false;
      } else {
        this.showDuplicateDialog = true;
      }
    },
    openShowObjectTools() {
      if (this.duplicateObj == false) {
        if (this.isAnychange == false) {
          this.isShowPropToolOpen = !this.isShowPropToolOpen;
          this.isDeleteToolOpen = false;
          this.isShowHideToolOpen = false;
          this.isZoomToolOpen = false;
          this.isRectangleToolOpen = false;
          this.isFillToolOpen = false;
          this.isFreeTextOpen = false;
          this.freeTextMode = false;
        } else {
          this.showDialog = true;
        }
      } else {
        this.showDuplicateDialog = true;
      }
    },
    openDeleteTools() {
      if (this.duplicateObj == false) {
        this.isDeleteToolOpen = !this.isDeleteToolOpen;
        this.isShowHideToolOpen = false;
        this.isZoomToolOpen = false;
        this.isShowPropToolOpen = false;
        this.isRectangleToolOpen = false;
        this.isFillToolOpen = false;
        this.isFreeTextOpen = false;
        this.freeTextMode = false;
      } else {
        this.showDuplicateDialog = true;
      }
    },
    openFillTools() {
      this.isFillToolOpen = !this.isFillToolOpen;
      this.isShowHideToolOpen = false;
      this.isZoomToolOpen = false;
      this.isShowPropToolOpen = false;
      this.isRectangleToolOpen = false;
      this.isFreeTextOpen = false;
      this.freeTextMode = false;
    },

    openFrameList() {
      this.isImageListOpen = !this.isImageListOpen;
      if (this.isImageListOpen == true) {
        this.addActiveToolEffect("image-list-btn");
      } else {
        this.removeActiveToolEffect("dialog-toggler", "image-list-btn");
      }
    },
    openLabelList() {
      this.isAnnotationListOpen = !this.isAnnotationListOpen;
      if (this.isAnnotationListOpen == true) {
        this.addActiveToolEffect("label-list-btn");
      } else {
        this.removeActiveToolEffect("dialog-toggler", "label-list-btn");
      }
    },
    openRightPanel() {
      this.isRightPanelOpen = !this.isRightPanelOpen;
      if (this.isRightPanelOpen == true) {
        this.addActiveToolEffect("right-panel-btn");
      } else {
        this.removeActiveToolEffect("dialog-toggler", "right-panel-btn");
      }
    },

    // open inbox page

    callInbox(link) {
      if (this.duplicateObj == false) {
        if (this.isAnychange == false) {
          if (this.isafterSave == true) {
            this.afterSave();
          }
          this.firstImageFlag = 0;
          this.$router.push({ path: link });
        } else {
          this.showDialog = true;
        }
      } else {
        this.showDuplicateDialog = true;
      }
    },
    //open mask annotation page
    callMask(link) {
      this.$router.push({
        path: link,
        query: {
          videoid: this.videoId,
          videoname: this.videoName,
          video_type: this.video_type,
        },
      });
    },
    //open dashboard page
    callDashbord(link) {
      if (this.duplicateObj == false) {
        if (this.isAnychange == false) {
          if (this.isafterSave == true) {
            this.afterSave();
          }
          this.firstImageFlag = 0;
          this.$router.push({ path: link });
        } else {
          this.showDialog = true;
        }
      } else {
        this.showDuplicateDialog = true;
      }
    },
    //open setting page
    callSetting: function(link) {
      if (this.duplicateObj == false) {
        if (this.isAnychange == false) {
          if (this.isafterSave == true) {
            this.afterSave();
          }
          this.firstImageFlag = 0;
          this.$router.push({ path: link });
        } else {
          this.showDialog = true;
        }
      } else {
        this.showDuplicateDialog = true;
      }
    },
    callUser: function(link) {
      if (this.isAnychange == false) {
        if (this.isafterSave == true) {
          this.afterSave();
        }
        this.firstImageFlag = 0;
        this.$router.push({ path: link });
      } else {
        this.showDialog = true;
      }
    },

    removeTip: function(id) {
      try {
        if (id !== undefined && id !== null) {
          var tipIndex = this.annotationJson
            .map(function(o) {
              return o.id;
            })
            .indexOf(id);
          var getElem = document.getElementById(id);
          var getip = document.getElementById(tipIndex);
          if (getElem !== null) {
            getElem.remove();
          }
          if (getip !== null) {
            getip.remove();
          }
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },

    keydownfn: function(e) {
      try {
        let moveKeys = ["up", "down", "right", "left"];
        let code = e.keyCode;
        let keyObj = keys.KEY_MAP[code];
        let self = this;
        let obj = canvas.getActiveObject();
        let changeBy = 1;
        let MinWidthHeight = 2;
        let key = keyObj === null || keyObj === undefined ? null : keyObj.key;
        if (this.duplicateObj == false && this.isFreeTextOpen == false) {
          if (
            (e.keyCode == 27 && this.isTagOpen) ||
            (e.keyCode == 27 && this.isAnnotationListOpen) ||
            (e.keyCode == 27 && this.isImageListOpen) ||
            (e.keyCode == 27 && this.isImageToolOpen) ||
            (e.keyCode == 27 && this.isColorListOpen) ||
            (e.keyCode == 27 && this.isShowHideToolOpen) ||
            (e.keyCode == 27 && this.isZoomToolOpen) ||
            (e.keyCode == 27 && this.isRectangleToolOpen) ||
            (e.keyCode == 27 && this.isShowPropToolOpen)
          ) {
            this.isTagOpen = false;
            this.isShowHideToolOpen = false;
            this.isZoomToolOpen = false;
            this.isShowPropToolOpen = false;
            this.isRectangleToolOpen = false;
            if (this.polygonMode == true) {
              this.exitPolygonMode();
              this.polygonMode = true;
            } else if (this.isDotMode == true) {
              this.exitDotMode();
              canvas.defaultCursor = "default";
              canvas.hoverCursor = "move";
              canvas.discardActiveObject();
              canvas.renderAll();
              this.isDotMode = true;
            } else if (this.lineMode == true) {
              this.exitLineMode();
              this.lineMode = true;
            } else if (this.extremeClickMode) {
              canvas.remove(drawExtremeClick);
              this.resetExtremeClicks();
              this.extremeClickMode = true;
            } else if (this.freehandMode) {
              this.exitFreeDrawMode();
              this.freehandMode = true;
            } else if (this.isFloodFillmode) {
              this.exitFloodFillMode();
              this.isFloodFillmode = true;
            } else if (
              !this.polygonMode &&
              !this.isDotMode &&
              !this.isDotModeLabel &&
              !this.lineMode &&
              !this.extremeClickMode &&
              !this.freehandMode &&
              !this.isFloodFillmode
            ) {
              canvas.remove(drawRect);
              this.drawMode = true;
              this.makeCrossHair(e);
            } else {
              return;
            }
          }
          // Shrink box
          else if (e.keyCode == 37 && e.shiftKey && e.altKey) {
            if (obj && obj.width > changeBy + MinWidthHeight) {
              obj.set({
                hoverCursor: "move",
                cornerColor: "transparent",
                cornerStyle: false,
                transparentCorners: true,
                selectable: true,
              });
              obj.set({ width: (obj.width -= changeBy) });
              if (obj.labelType == BOX_LABEL) {
                this.removeTip(obj.annoId);
                this.isAnychange = true;
                obj.sWidth -= changeBy;
              }
            }
          } else if (e.keyCode == 39 && e.shiftKey && e.altKey) {
            if (obj && obj.width > changeBy + MinWidthHeight) {
              obj.set({
                hoverCursor: "move",
                cornerColr: "transparent",
                cornerStyle: false,
                transparentCorners: true,
                selectable: true,
              });
              obj.set({ width: (obj.width -= changeBy) });
              obj.set({ left: (obj.left += changeBy) });

              if (obj.labelType == BOX_LABEL) {
                this.removeTip(obj.annoId);
                this.isAnychange = true;
                obj.sWidth -= changeBy;
              }
            }
          } else if (e.keyCode == 38 && e.shiftKey && e.altKey) {
            if (obj && obj.height > changeBy + MinWidthHeight) {
              obj.set({
                hoverCursor: "move",
                cornerColor: "transparent",
                cornerStyle: false,
                transparentCorners: true,
                selectable: true,
              });
              obj.set({ height: (obj.height -= changeBy) });
              if (obj.labelType == BOX_LABEL) {
                this.removeTip(obj.annoId);
                this.isAnychange = true;
                obj.sHeight -= changeBy;
              }
            }
          } else if (e.keyCode == 40 && e.shiftKey && e.altKey) {
            if (obj && obj.height > changeBy + MinWidthHeight) {
              obj.set({
                hoverCursor: "move",
                cornerColor: "transparent",
                cornerStyle: false,
                transparentCorners: true,
                selectable: true,
              });
              obj.set({ height: (obj.height -= changeBy) });
              obj.set({ top: (obj.top += changeBy) });
              if (obj.labelType == BOX_LABEL) {
                this.removeTip(obj.annoId);
                this.isAnychange = true;
                obj.sHeight -= changeBy;
              }
            }
            // Stretch box
          } else if (obj && e.keyCode == 37 && e.shiftKey && obj.left >= 0) {
            obj.set({
              hoverCursor: "move",
              cornerColor: "transparent",
              cornerStyle: false,
              transparentCorners: true,
              selectable: true,
            });
            obj.set({ width: (obj.width += changeBy) });
            obj.set({ left: (obj.left -= changeBy) });
            if (obj.labelType == BOX_LABEL) {
              this.removeTip(obj.annoId);
              this.isAnychange = true;
              obj.sWidth += changeBy;
            }
          } else if (
            obj &&
            e.keyCode == 39 &&
            e.shiftKey &&
            obj.left + obj.width < canvas.width
          ) {
            obj.set({
              hoverCursor: "move",
              cornerColor: "transparent",
              cornerStyle: false,
              transparentCorners: true,
              selectable: true,
            });
            obj.set({ width: (obj.width += changeBy) });
            if (obj.labelType == BOX_LABEL) {
              this.removeTip(obj.annoId);
              this.isAnychange = true;
              obj.sWidth += changeBy;
            }
          } else if (obj && e.keyCode == 38 && e.shiftKey && obj.top >= 0) {
            obj.set({
              hoverCursor: "move",
              cornerColor: "transparent",
              cornerStyle: false,
              transparentCorners: true,
              selectable: true,
            });
            obj.set({ height: (obj.height += changeBy) });
            obj.set({ top: (obj.top -= changeBy) });
            if (obj.labelType == BOX_LABEL) {
              this.removeTip(obj.annoId);
              this.isAnychange = true;
              obj.sHeight += changeBy;
            }
          } else if (
            obj &&
            e.keyCode == 40 &&
            e.shiftKey &&
            obj.top + obj.height < canvas.height
          ) {
            obj.set({
              hoverCursor: "move",
              cornerColor: "transparent",
              cornerStyle: false,
              transparentCorners: true,
              selectable: true,
            });
            obj.set({ height: (obj.height += changeBy) });
            if (obj.labelType == BOX_LABEL) {
              this.removeTip(obj.annoId);
              this.isAnychange = true;
              obj.sHeight += changeBy;
            }

            // Move Box
          } else if (obj && e.keyCode == 37 && e.ctrlKey && obj.left >= 0) {
            obj.set({
              hoverCursor: "move",
              cornerColor: "transparent",
              cornerStyle: false,
              transparentCorners: true,
              selectable: true,
            });
            this.removeTip(obj.annoId);
            this.isAnychange = true;
            obj.set({ left: (obj.left -= changeBy) });
          } else if (
            obj &&
            e.keyCode == 39 &&
            e.ctrlKey &&
            obj.left + obj.width < canvas.width
          ) {
            obj.set({
              hoverCursor: "move",
              cornerColor: "transparent",
              cornerStyle: false,
              transparentCorners: true,
              selectable: true,
            });
            this.removeTip(obj.annoId);
            this.isAnychange = true;
            obj.set({ left: (obj.left += changeBy) });
          } else if (obj && e.keyCode == 38 && e.ctrlKey && obj.top >= 0) {
            obj.set({
              hoverCursor: "move",
              cornerColor: "transparent",
              cornerStyle: false,
              transparentCorners: true,
              selectable: true,
            });
            this.removeTip(obj.annoId);
            this.isAnychange = true;
            obj.set({ top: (obj.top -= changeBy) });
          } else if (
            obj &&
            e.keyCode == 40 &&
            e.ctrlKey &&
            obj.top + obj.height < canvas.height
          ) {
            obj.set({
              hoverCursor: "move",
              cornerColor: "transparent",
              cornerStyle: false,
              transparentCorners: true,
              selectable: true,
            });
            this.removeTip(obj.annoId);
            this.isAnychange = true;
            obj.set({ top: (obj.top += changeBy) });
          } else if (e.key === "s") {
            if (this.checkFlag) {
              this.showCheck = true;
            }
            this.save();
            e.preventDefault();
            e.stopImmediatePropagation();
          } else if (e.key === "z" && e.ctrlKey) {
            this.clearAllAnnotations();
            e.preventDefault();
            e.stopImmediatePropagation();
          } else if (e.key === "+") {
            self.setZoomMode(0, 0);
            e.preventDefault();
            e.stopImmediatePropagation();
          } else if (e.key === "-") {
            self.zoomOut(0, 0);
            e.preventDefault();
            e.stopImmediatePropagation();
          } else if (e.key === "y" && e.ctrlKey) {
            self.setDotMode();
            e.preventDefault();
            e.stopImmediatePropagation();
          } else if (e.key === "f" && e.ctrlKey) {
            self.freeHand();
            e.preventDefault();
            e.stopImmediatePropagation();
          } else if (e.key === "b" && e.ctrlKey) {
            self.setDrawMode();
            e.preventDefault();
            e.stopImmediatePropagation();
          } else if (e.key === "h" && e.ctrlKey) {
            self.setDrawRatioMode();
            e.preventDefault();
            e.stopImmediatePropagation();
          } else if (e.key === "q" && e.ctrlKey) {
            self.setExtremeClickMode();
            e.preventDefault();
            e.stopImmediatePropagation();
          } else if (e.key === "p" && e.ctrlKey) {
            self.setPolygonMode();
            e.preventDefault();
            e.stopImmediatePropagation();
          } else if (e.key === "l" && e.ctrlKey) {
            self.setLineMode();
            e.preventDefault();
            e.stopImmediatePropagation();
          } else if (e.key === "i" && e.ctrlKey) {
            self.freeText();
            e.preventDefault();
            e.stopImmediatePropagation();
          } else if (e.key === "h" && e.ctrlKey) {
            self.toggleUnselectedVisibility(true);
            e.preventDefault();
            e.stopImmediatePropagation();
          } else if (e.keyCode == 9 && e.shiftKey) {
            self.highlightSelected(obj);
            self.navigateNextBox("left");
          } else if (e.keyCode == 9) {
            self.highlightSelected(obj);
            self.navigateNextBox("right");
          } else if (key === "esc") {
            self.deselectObject();
          } else if (key === "delete") {
            self.deleteObject1();
          } else if (
            (e.key === "n" || e.key === "d") &&
            this.imageId <= this.tolatImageCount - 2
          ) {
            if (this.video_type == 0) {
              self.nextImage();
            } else {
              self.selectImage();
            }
          } else if ((e.key === "p" || e.key === "a") && this.imageId > 0) {
            self.prevImage();
          } else if (
            e.keyCode == 190 &&
            e.shiftKey &&
            this.imageId <= this.tolatImageCount - 2
          ) {
            let autoAnnolist = [];
            if (this.video_type == 0) {
              if (this.copyMode == "manual" || this.copyMode == "automatic") {
                if (this.copyDirection == "Forward") {
                  autoAnnolist = this.copyAnnotationList;
                } else {
                  autoAnnolist = null;
                }
              }

              self.requestImage(this.imageId + 1, autoAnnolist, 0);
            } else {
              self.selectImage();
            }
          } else if (e.keyCode == 188 && e.shiftKey && this.imageId > 0) {
            let autoAnnolist = [];
            if (this.video_type == 0) {
              if (this.copyMode == "manual" || this.copyMode == "automatic") {
                if (this.copyDirection == "Backward") {
                  autoAnnolist = this.copyAnnotationList;
                } else {
                  autoAnnolist = null;
                }
              }

              self.requestImage(this.imageId - 1, autoAnnolist, 1);
            } else {
              self.selectImage();
            }
          } else if (e.keyCode == 13) {
            this.showDialog = false;
          } else {
            return;
          }
        } else {
          this.showDuplicateDialog = true;
        }
        canvas.renderAll();
      } catch (error) {
        console.log("Error:", error);
      }
    },

    keyupfn: function(e) {
      try {
        let self = this;
        let code = e.keyCode;
        let keyObj = keys.KEY_MAP[code];
        let key = !self.exists(keyObj) ? null : keyObj.key;
        if (this.duplicateObj == false) {
          if (key === "esc") {
            if (prevSelected !== null && prevSelected !== undefined) {
              // document.getElementById(prevSelected).style.borderColor = "white";
            }
            this.removePolyBullet();
            self.deselectObject();
            this.exitDotMode();
            this.exitLineMode();
            this.resetExtremeClicks();
            this.exitFreeDrawMode();
            this.exitFloodFillMode();
            this.exitDrawMode();
            this.exitZoomMode();
            this.exitPolygonMode();
            this.exitDrawRatioMode();
            this.isFreeTextOpen = false;
            this.freeTextMode = false;
            this.isZoomToolOpen = false;
            this.isShowPropToolOpen = false;
            this.isShowHideToolOpen = false;
            this.isFillToolOpen = false;
            this.isRectangleToolOpen = false;
            this.incomplete_anno = false;
            canvas.remove(drawRect);
            canvas.remove(drawRatioRectLine);
            canvas.defaultCursor = "default";
            canvas.hoverCursor = "move";
            canvas.remove(this.crossHairVLine);
            canvas.remove(this.crossHairHLine);
            canvas.remove(this.boxsize);
            canvas.renderAll();
          }
        } else {
          this.showDuplicateDialog = true;
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },
    selectImage: function() {
      try {
        document.getElementById("file").click();
      } catch (error) {
        console.log("Error:", error);
      }
    },
    getImageBase64: function(file, onLoadCallback) {
      try {
        return new Promise(function(resolve, reject) {
          var reader = new FileReader();
          reader.onload = function() {
            resolve(reader.result);
          };
          reader.onerror = reject;
          reader.readAsDataURL(file);
        });
      } catch (error) {
        console.log("Error:", error);
      }
    },
    fetchImage: async function() {
      var promise = this.getImageBase64(this.file);
      this.base64Image = await promise;
    },
    toogleImage: function(flag, QUERY) {
      //I will recieve some flag of prev/next from main function call
      let step;
      let autoAnnolist;
      //Prev
      if (flag == 0) {
        step = -1;
      } else {
        //Next
        step = 1;
      }
      this.resetZoom();
      this.firstImageFlag = 1;
      try {
        //Check for Duplicate Object
        if (this.duplicateObj == false) {
          this.propInFrame = [];
          this.objList = [];
          if (this.isAnychange == false) {
            this.annotationJson = [];
            if (this.video_type == 0) {
              this.fileName = null;
              this.base64Image = null;
              this.initializeCanvas(this.imageId + step);
            }
            if (this.isafterSave == true) {
              this.afterSave();
            }
            if (this.video_type == 0) {
              this.fileName = "";
              this.base64Image = "";
            } else {
              this.fileName = this.$refs.file.files[0].name;
              this.file = this.$refs.file.files[0];
              //Await only in next Image
              if (flag == 1) {
                this.fetchImage();
              }
              var div = document.createElement("div");
              var img = document.createElement("img");
              img.src = "static/loading.gif";
              img.style.cssText = "margin-top:20%;width:5%;height:10%;";
              div.style.cssText =
                "width: 100%;height: 100%;top: 0px;left: 0px;position: fixed;display: block;opacity: 0.7;background-color: #fff;z-index: 99;text-align: center";
              div.appendChild(img);
              document.body.appendChild(div);
            }
            if (this.copyMode == "automatic" || this.copyMode == "manual") {
              if (flag == 1) {
                if (this.copyDirection == "Forward") {
                  autoAnnolist = this.copyAnnotationList;
                  //this.lockUnlockFlag = "false";
                } else {
                  autoAnnolist = null;
                  //this.lockUnlockFlag = "false";
                }
              }
              if (flag == 0) {
                if (this.copyDirection == "Backward") {
                  autoAnnolist = this.copyAnnotationList;
                  //this.lockUnlockFlag = "false";
                } else {
                  autoAnnolist = null;
                  //this.lockUnlockFlag = "false";
                }
              }
            }
            const userid = SettingService.getSelectedUserId();
            this.$apollo
              .mutate({
                mutation: QUERY,
                variables: {
                  videoid: this.videoId,
                  imageid: this.imageId + step,
                  project: this.project,
                  video_type: this.video_type,
                  videoname: this.videoName,
                  file: this.fileName,
                  base64Image: this.base64Image,
                  auto_annotations: autoAnnolist,
                  copy_mode: this.copyMode,
                  configure_flag: 2,
                  project_id: this.projectId,
                  userid: userid,
                },
              })
              .then((data) => {
                try {
                  if (typeof div != "undefined" && div != null) {
                    div.style.display = "none";
                  }
                  let ObjImageData;
                  if (flag == 0) {
                    ObjImageData = data.data.prevObjVideoImage;
                    this.isBlurModeActive =
                      data.data.prevObjVideoImage.is_blur_mode_active;
                  } else {
                    ObjImageData = data.data.nextObjVideoImage;
                    this.isBlurModeActive =
                      data.data.nextObjVideoImage.is_blur_mode_active;
                  }

                  if (ObjImageData != null) {
                    this.isQueryError = false;
                    this.image = ObjImageData;
                    this.annotationJson = JSON.parse(ObjImageData.annos_json);
                    this.imageIDSubtring = this.image.id
                      .substring(this.image.id.lastIndexOf("_"))
                      .substring(
                        1,
                        this.image.id.substring(this.image.id.lastIndexOf("_"))
                          .length
                      );
                    this.tolatImageCount = this.image.imagecount;
                    this.videopath = atob(ObjImageData.videopath);
                    this.imgsrc = atob(ObjImageData.src);
                    this.labels = ObjImageData.labels;
                    this.width = ObjImageData.width;
                    this.height = ObjImageData.height;
                    this.imageId = this.imageId + step;
                  }
                  this.isBlurActive = false;
                  //Image Orientation
                  if (
                    this.image.orientation != 1 &&
                    this.image.orientation != null
                  ) {
                    this.showRotateMsg = true;
                  }
                  this.loadAllAnnotations();
                  this.resetInsatView();
                  this.getAnnotationList(this.imageId);
                  //Taking Json data based on Prev/Next Flag
                  if (this.annotationJson.length > 0) {
                    this.getFrameProp();
                    jsonArray = JSON.parse(ObjImageData.annos_json);
                  }
                  this.setLockUnlockAllValue();

                  if (this.isBlurModeActive) {
                    setTimeout(() => {
                      this.createImage();
                    }, 200);
                  }
                } catch (error) {
                  if (typeof div != "undefined" && div != null) {
                    div.style.display = "none";
                  }
                  console.log("Error:", error);
                }
              })
              .catch((error) => {
                if (typeof div != "undefined" && div != null) {
                  div.style.display = "none";
                }
                this.isQueryError = true;
                this.queryErrorResult = /:(.+)/.exec(error.message)[1];
              });
            this.allLabelList = [];
            this.isTagOpen = false;
            this.isRectangleToolOpen = false;
            this.isFreeTextOpen = false;
            this.freeTextMode = false;
          } else {
            if (this.checkFlag === true) {
              this.showCheck = true;
            }
          }
        } else {
          this.showDuplicateDialog = true;
        }
      } catch (error) {
        if (typeof div != "undefined" && div != null) {
          div.style.display = "none";
        }
        console.log("Error:", error);
      }
    },
    nextImage: async function() {
      this.toogleImage(1, NEXT_OBJ_VIDEO_IMG_QUERY);
    },
    prevImage: function() {
      this.toogleImage(0, PREV_OBJ_VIDEO_IMG_QUERY);
    },
    requestImage: function(index, list_annotations, riFlag) {
      if (this.isAnychange == true) {
        this.showDialog = true;
        return;
      }
      this.resetZoom();
      this.getFrameList();
      this.afterSave();

      if (this.video_type == 0) {
        if (index == 1 && this.imageId == 0) {
          this.ImageId = this.imageId + 1;
          activeAnnoMode = null;
          this.removeActiveToolEffect("annotation-tool");
          this.initializeCanvas(index);
        } else if (index == -1) {
          this.ImageId = this.imageId;
          this.initializeCanvas(this.ImageId);
        } else {
          this.ImageId = index;
          activeAnnoMode = null;
          this.removeActiveToolEffect("annotation-tool");
          this.initializeCanvas(index);
        }
      } else {
        if (index == 1 && this.imageId == 0) {
          this.ImageId = this.imageId + 1;
        } else if (index == -1) {
          this.ImageId = this.imageId;
        } else {
          this.ImageId = index;
        }
      }

      this.firstImageFlag = 1;
      try {
        this.propInFrame = [];
        this.objList = [];

        if (this.isAnychange == false) {
          this.annotationJson = [];
          if (
            this.isafterSave == true &&
            this.isImageListOpen == true &&
            index != -1
          ) {
            this.afterSave();
          }
          const userid = SettingService.getSelectedUserId();
          this.$apollo
            .mutate({
              mutation: NEXT_OBJ_VIDEO_IMG_QUERY,
              variables: {
                videoid: this.videoId,
                imageid: this.ImageId,
                project: this.project,
                video_type: this.video_type,
                videoname: this.videoName,
                file: "",
                base64Image: "",
                auto_annotations: list_annotations,
                copy_mode: this.copyMode,
                configure_flag: riFlag,
                project_id: this.projectId,
                userid: userid,
              },
            })
            .then((data) => {
              try {
                if (data.data.nextObjVideoImage != null) {
                  this.isQueryError = false;
                  this.image = data.data.nextObjVideoImage;
                  this.annotationJson = JSON.parse(
                    data.data.nextObjVideoImage.annos_json
                  );
                  this.imageIDSubtring = this.image.id
                    .substring(this.image.id.lastIndexOf("_"))
                    .substring(
                      1,
                      this.image.id.substring(this.image.id.lastIndexOf("_"))
                        .length
                    );
                  this.isBlurModeActive =
                    data.data.nextObjVideoImage.is_blur_mode_active;

                  this.videopath = atob(data.data.nextObjVideoImage.videopath);
                  this.imgsrc = atob(data.data.nextObjVideoImage.src);
                  this.labels = data.data.nextObjVideoImage.labels;
                  this.imageId = data.data.nextObjVideoImage.imageId;
                  this.width = data.data.nextObjVideoImage.width;
                  this.height = data.data.nextObjVideoImage.height;
                  this.tolatImageCount = data.data.nextObjVideoImage.imagecount;
                  if (
                    this.image.orientation != 1 &&
                    this.image.orientation != null
                  ) {
                    this.showRotateMsg = true;
                  }
                  this.loadAllAnnotations();

                  this.getAnnotationList(this.imageId);
                  if (this.annotationJson.length > 0) {
                    this.getFrameProp();
                    jsonArray = JSON.parse(
                      data.data.nextObjVideoImage.annos_json
                    );
                  }
                  this.setLockUnlockAllValue();
                  this.isBlurActive = false;
                  if (this.isBlurModeActive) {
                    setTimeout(() => {
                      this.createImage();
                    }, 200);
                  }
                }
              } catch (error) {
                console.log("Error:", error);
              }
            })
            .catch((error) => {
              this.isQueryError = true;
              this.queryErrorResult = /:(.+)/.exec(error.message)[1];
            });
          this.allLabelList = [];
          this.isFreeTextOpen = false;
          this.freeTextMode = false;
        } else {
          this.showDialog = true;
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },
    changeOrientation: function() {
      try {
        this.$apollo
          .mutate({
            mutation: CHANGE_ORIENTATION,
            variables: {
              videoname: this.videoName,
              filename: this.image.id,
              orientation: this.image.orientation,
            },
          })
          .then((data) => {
            try {
              this.isQueryError = false;
              this.requestImage(-1, null, 2);
            } catch (error) {
              console.log("Error:", error);
            }
          })
          .catch((error) => {
            this.isQueryError = true;
            this.queryErrorResult = /:(.+)/.exec(error.message)[1];
          });
      } catch (error) {
        console.log("Error:", error);
      }
    },
    resetInsatView: function() {
      $("#scrollDiv").css({
        top: this.canvasHeight / 10,
        left: this.canvasWidth / 35 + (this.screenWidth - 500),
      });
    },
    discardChanges: function() {
      try {
        this.copyAnnotationList = []; // to avoid unlock/lock issue
        this.isAnychange = false;
        this.unsavechange = false;
        this.showDuplicateDialog = false;
        this.duplicateObj = false;
        this.lockUnlockFlag = false;
        this.requestImage(-1, null, 2);
      } catch (error) {
        console.log("Error:", error);
      }
    },
    afterSave: function() {
      try {
        this.$apollo
          .mutate({
            mutation: AFTER_SAVE_FRAME,
            variables: {
              videoid: this.videoId,
              videoname: this.videoName,
            },
          })
          .then((data) => {
            try {
              this.isQueryError = false;
            } catch (error) {
              console.log("Error:", error);
            }
          })
          .catch((error) => {
            this.isQueryError = true;
            this.queryErrorResult = /:(.+)/.exec(error.message)[1];
          });
        this.isafterSave = false;
      } catch (error) {
        console.log("Error:", error);
      }
    },
    save: function() {
      try {
        if (this.incomplete_anno == true) {
          return;
        }
        if (this.video_type == 1) {
          this.showDownloadMsg = true;
        } else {
          this.saveData();
          if (this.isBlurModeActive) {
            setTimeout(() => {
              this.createImage();
            }, 500);
          }
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },
    // #############################################################################
    checkSave: function(flagType) {
      try {
        if (this.incomplete_anno == true) {
          return;
        }
        if (this.video_type == 1) {
          this.showDownloadMsg = true;
        } else {
          if (flagType == "forward") {
            this.saveCheckDataForward();
          } else if (flagType == "backward") {
            this.saveCheckDataBackward();
          } else if (flagType == "all") {
            this.saveCheckData();
          }
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },
    saveCheckDataHelper: function(action) {
      try {
        let annos = this.extractAnnotations();
        this.isAnychange = false;
        this.unsavechange = false;
        this.isafterSave = true;
        selectedProp = null;
        this.resetZoom();
        var self = this;
        setTimeout(function() {
          self.showNotification = true;
        }, 200);
        this.$apollo
          .mutate({
            mutation: action,
            variables: {
              id: this.image.id,
              project: this.project,
              annotations: annos,
              videopath: this.videopath,
              videoid: this.videoId,
            },
          })
          .then((data) => {
            try {
              this.isQueryError = false;
              this.requestImage(-1, null, 2);
            } catch (error) {
              console.log("Error:", error);
            }
          })
          .catch((error) => {
            this.isQueryError = true;
            this.queryErrorResult = /:(.+)/.exec(error.message)[1];
          });
        setTimeout(function() {
          self.showNotification = false;
        }, 1000);
        editPolygon = [];
      } catch (error) {
        console.log("Error:", error);
      }
    },
    saveCheckDataForward: function() {
      this.saveCheckDataHelper(CHECK_SAVE_OBJ_DETECT_IMAGE_FORWARD);
    },
    saveCheckDataBackward: function() {
      this.saveCheckDataHelper(CHECK_SAVE_OBJ_DETECT_IMAGE_BACKWARD);
    },
    saveCheckData: function() {
      this.saveCheckDataHelper(CHECK_SAVE_OBJ_DETECT_IMAGE);
    },
    // ############################################################
    savDelDataHelper: function(annos) {
      try {
        let anno_info;
        const userid = SettingService.getSelectedUserId();
        if (annos) {
          anno_info = this.anno_curator(this.annotationJson, annos);
        } else {
          anno_info = this.anno_curator(this.annotationJson, []);
        }
        if (anno_info) {
          this.consolidate_annotations(anno_info);
        }
        this.isAnychange = false;
        this.unsavechange = false;
        this.isafterSave = true;
        selectedProp = null;
        this.resetZoom();
        var self = this;
        setTimeout(function() {
          if (annos) {
            self.showNotification = true;
          } else {
            self.showDelNotification = true;
          }
        }, 200);
        this.$apollo
          .mutate({
            mutation: SAVE_OBJ_DETECT_IMAGE,
            variables: {
              id: this.image.id,
              project: this.project,
              annotations: annos,
              classwise_data: JSON.stringify(
                this.consolidated_annotation_change_info
              ),
              videopath: this.videopath,
              videoid: this.videoId,
              width: this.width,
              height: this.height,
              //Only for save
              userid: userid,
              projectid: this.projectId,
              is_blur_mode_active: this.isBlurModeActive,
            },
          })
          .then((data) => {
            try {
              this.isQueryError = false;
              this.requestImage(-1, null, 2);
            } catch (error) {
              console.log("Error:", error);
            }
          })
          .catch((error) => {
            this.isQueryError = true;
            this.queryErrorResult = /:(.+)/.exec(error.message)[1];
          });
        setTimeout(function() {
          if (annos) {
            self.showNotification = false;
          } else {
            self.showDelNotification = false;
          }
        }, 1000);
        editPolygon = [];
      } catch (error) {
        console.log("Error:", error);
      }
    },
    saveData: function() {
      let annos = this.extractAnnotations();
      this.savDelDataHelper(annos);
    },
    deleteData: function() {
      this.savDelDataHelper(null);
    },
    clearAllAnnotations: function() {
      try {
        if (this.isTagOpen == true) {
          this.showObjectClassMenu = true;
        } else {
          if (this.video_type == 1) {
            this.showDownloadMsg = true;
          } else {
            this.deleteData();
          }
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },
    downloadData: function() {
      try {
        jsonResult = [];
        this.$apollo
          .mutate({
            mutation: FILE_DOWNLOAD_MUTATION,
            variables: {
              imageid: this.imageId,
              videoid: this.videoId,
              imagename: this.image.id,
              serverpath: imgsrc,
            },
          })
          .then((data) => {
            try {
              this.isQueryError = false;
              if (data.data.fileDownloadCloud != null) {
                jsonResult = data.data.fileDownloadCloud.annos_json;
                this.saveJson(jsonResult);
              }
            } catch (error) {
              console.log("Error:", error);
            }
          })
          .catch((error) => {
            this.isQueryError = true;
            this.queryErrorResult = /:(.+)/.exec(error.message)[1];
          });
      } catch (error) {
        console.log("Error:", error);
      }
    },
    saveJson: function(jsonData) {
      try {
        var arr = [];
        var imgname = this.image.id;
        var name = imgname
          .split(".")
          .slice(0, -1)
          .join(".");
        var jsonName = name + "_label.json";
        const parseJson = JSON.parse(jsonData);
        const data = JSON.stringify(parseJson, undefined, 4);
        const blob = new Blob([data], { type: "text/plain" });
        const e = document.createEvent("MouseEvents");
        const a = document.createElement("a");
        a.download = jsonName;
        a.href = window.URL.createObjectURL(blob);
        a.dataset.downloadurl = ["text/json", a.download, a.href].join(":");
        e.initEvent(
          "click",
          true,
          false,
          window,
          0,
          0,
          0,
          0,
          0,
          false,
          false,
          false,
          false,
          0,
          null
        );
        a.dispatchEvent(e);
      } catch (error) {
        console.log("Error:", error);
      }
    },
    conJson: function(jsonData) {
      try {
        const nodes = jsonData.nodes.reduce((a, node) => {
          a[node.index] = { ...node, index: undefined };
          return a;
        }, []);

        // organize the links by their source
        const links = input.links.reduce((a, link) => {
          return a.set((a.get(link.source) || []).concat(nodes[link.target]));
        }, new Map());

        // Apply side effect of updating node children
        nodes.forEach((node) =>
          Object.assign(node, {
            children: links.get(node.index),
          })
        );
      } catch (error) {
        console.log("Error:", error);
      }
    },
    setAnnoError: function(annoItem) {
      try {
        let objs = canvas.getObjects();
        if (this.role == "VALIDATOR") {
          for (var i = 0; i < objs.length; i++) {
            if (annoItem.polygon && annoItem.polygon.annoId == objs[i].annoId) {
              this.polyid = annoItem.polygon.annoId;
              if (annoItem.polygon.score == 0.0) {
                annoItem.polygon.score = 1.0;
                objs[i].score = 1.0;
              } else {
                annoItem.polygon.score = 0.0;
                objs[i].score = 0.0;
              }
            } else if (
              annoItem.bbox &&
              annoItem.bbox.annoId == objs[i].annoId
            ) {
              this.muid = annoItem.bbox.annoId;
              if (annoItem.bbox.score == 0.0) {
                annoItem.bbox.score = 1.0;
                objs[i].score = 1.0;
              } else {
                annoItem.bbox.score = 0.0;
                objs[i].score = 0.0;
              }
            }
          }
          this.isAnychange = true;
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },
    mytoggle: function(i) {
      try {
        if (this.showDetails[i] == true) {
          this.$set(this.showDetails, i, false);
        } else {
          this.$set(this.showDetails, i, true); // open the corresponding box
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },
    showAnnoDetail: function(index) {
      try {
        if (this.isDetailVisible[index] == true) {
          this.$set(this.isDetailVisible, index, false);
        } else {
          this.$set(this.isDetailVisible, index, true);
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },
    clearCanvas: function() {
      try {
        canvas.clear();
        document.getElementById("c").style.backgroundImage =
          "url(" + this.imageSource + ")";
        this.loadAllAnnotations();
      } catch (error) {
        console.log("Error:", error);
      }
    },
    changeColorPropTooltip: function() {
      try {
        if (this.color !== "") {
          if (this.tipcolor == "true") {
            this.tipTextcolor = this.color;
          } else {
            this.tipTextcolor = "white";
          }
          this.clearCanvas();
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },
    changeColorProp: function() {
      try {
        if (
          this.fillColor !== "" &&
          this.color !== "" &&
          this.fillColor !== "NA"
        ) {
          if (this.fillBorder == "true") {
            if (borderColorProp.length == 0) {
              borderColorProp.push({
                name: this.fillColor,
                color: this.color,
              });
            } else {
              let bordercolorindex = borderColorProp
                .map(function(o) {
                  return o.name;
                })
                .indexOf(this.fillColor);
              if (bordercolorindex >= 0) {
                borderColorProp[bordercolorindex].color = this.color;
              } else {
                borderColorProp.push({
                  name: this.fillColor,
                  color: this.color,
                });
              }
            }
          } else {
            if (this.storeColorProp.length == 0) {
              this.storeColorProp.push({
                name: this.fillColor,
                color: this.color,
              });
            } else {
              var colorindex = this.storeColorProp
                .map(function(o) {
                  return o.name;
                })
                .indexOf(this.fillColor);
              if (colorindex >= 0) {
                this.storeColorProp[colorindex].color = this.color;
              } else {
                this.storeColorProp.push({
                  name: this.fillColor,
                  color: this.color,
                });
              }
            }
            this.stroke = "white";
            this.clearCanvas();
          }
        } else {
          this.stroke = "white";
          this.tipTextcolor = "white";
          this.storeColorProp = [];
          borderColorProp = [];
          this.clearCanvas();
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },
    reset: function() {
      this.fillColor = "NA";
      this.opacity = 0.25;
      this.fillColor = false;
      this.fillBorder = false;
      this.tipcolor = false;
      this.color = "";
    },
    makeColors: function(labels) {
      try {
        let colorMap = {};
        for (let opt of labels) {
          colorMap[opt.value] = opt.color;
        }
        return colorMap;
      } catch (error) {
        console.log("Error:", error);
      }
    },
    /**
     * initialize canvas
     */
    initializeCanvas: function(imageId) {
      try {
        document.getElementById("c").style.backgroundImage = "none";
        var videoname = this.$route.query.videoname;
        let self = this;
        if (canvas == null) {
          canvas = new fabric.Canvas("c");
        } else {
          canvas.dispose();
          canvas = new fabric.Canvas("c");
        }
        var img = new Image();
        img.onload = function() {
          self.configureCanvas(this.width, this.height);
          self.width = this.width;
          self.height = this.height;
        };
        this.imageSource =
          this.$hostname + "/img_path/noesis_data/" + videoname + "/" + imageId;

        img.src = this.imageSource;
      } catch (error) {
        console.log("Error:", error);
      }
    },

    configureCanvas: function(width, height) {
      try {
        canvas.selection = false;
        canvas.setDimensions({
          height: height,
          width: width,
        });
        document.getElementsByClassName("upper-canvas")[0].style.top = "0px";
        document.getElementsByClassName("upper-canvas")[0].style.left = "28px";
        canvas.setBackgroundImage(
          this.imageSource,
          canvas.renderAll.bind(canvas)
        );
        this.canvasHeight = canvas.height;
        this.canvasWidth = canvas.width;
        this.setCornerSize(this.cornerSize);
        canvas.on({
          "mouse:dblclick": this.mouseDblClickHandler,
          //"mouse:over": this.mouseOverHandler,
          "mouse:down": this.mouseDownHandler,
          "mouse:up": this.mouseUpHandler,
          "mouse:move": this.mouseMoveHandler,
          "object:moving": function(e) {
            var obj = e.target;
            let pointer = canvas.getPointer(e.e);
            if (obj.top < 0 && obj.left < 0) {
              obj.top = 0;
              obj.left = 0;
            } else if (obj.left < 0 && obj.top + obj.sHeight > height) {
              obj.left = 0;
              obj.top = height - obj.sHeight;
            } else if (obj.top < 0 && obj.left + obj.sWidth > width) {
              obj.top = 0;
              obj.left = width - obj.sWidth;
            } else if (
              obj.left + obj.sWidth > width &&
              obj.top + obj.sHeight > height
            ) {
              obj.left = width - obj.sWidth;
              obj.top = height - obj.sHeight;
            } else if (obj.left + obj.sWidth > width) {
              obj.left = width - obj.sWidth;
            } else if (obj.top + obj.sHeight > height) {
              obj.top = height - obj.sHeight;
            } else if (obj.left < 0) {
              obj.left = 0;
            } else if (obj.top < 0) {
              obj.top = 0;
            } else {
              this.objectMovingHandler;
            }
          },
          //"mouse:out": this.mouseOutHandler,
          "mouse:wheel": this.mouseWheelHandler,
          "object:modified": this.objectModifiedHandler,
        });
        this.setMode();
        canvas.renderAll();
      } catch (error) {
        console.log("Error:", error);
      }
    },

    objectOverHandler: function(e) {
      if (this.extremeClickMode) {
        canvas.defaultCursor = "default";
      }
      return;
    },

    objectMovingHandler: function(e) {
      try {
        if (this.extremeClickMode) {
          return;
        } else if (this.polygonMode) {
          this.adjustPolygonClick(e);
        } else if (this.lineMode) {
        } else if (this.drawMode) {
          this.handleDrawMove(e);
        } else {
          return;
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },

    objectModifiedHandler: function(e) {
      try {
        let obj = canvas.getActiveObject();
        let _strokeWidth = 2;
        if (obj && obj.labelType == BOX_LABEL) {
          this.removeTip(obj.annoId);
          this.isAnychange = true;
          obj.isModified = true;
          obj.sWidth = obj.getScaledWidth();
          obj.sHeight = obj.getScaledHeight();
          obj.strokeWidth = _strokeWidth / Math.max(obj.scaleX, obj.scaleY);
          if (obj.ratio > 0) {
            this.loadratioLine(obj);
          }
        }
        canvas.renderAll();
      } catch (error) {
        console.log("Error:", error);
      }
    },

    mouseOverOutHandler: function(e, flag) {
      try {
        if (this.extremeClickMode) {
          if (flag === "over") {
            canvas.hoverCursor = "pointer";
          } else {
            return;
          }
        } else if (this.polygonMode) {
          this.handlePolygonMouseOver(e);
        } else if (this.lineMode) {
          this.handleLineMouseOver(e);
        } else if (this.drawMode) {
          return;
        } else if (e.target != null) {
          if (flag === "over") {
            e.target.set({ selectable: true }).setCoords();
            if (e.target.opacity !== 0) {
              e.target.set({ opacity: 0.5 }).setCoords();
            }
            this.stroke = e.target.stroke;
            e.target.set({ stroke: "#FF0000" }).setCoords();
          } else {
            if (e.target.opacity !== 0) {
              e.target.set({ opacity: this.opacity }).setCoords();
              if (e.target.labelType == "RationLine") {
                e.target.set({ opacity: 1 }).setCoords();
              }
            }
            e.target.set({ stroke: this.stroke }).setCoords();
          }
          canvas.renderAll();
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },
    mouseOverHandler: function(e) {
      this.mouseOverOutHandler(e, "over");
    },

    mouseOutHandler: function(e) {
      this.mouseOverOutHandler(e, "out");
    },

    OnButtonDown: function() {
      var selectID = document.getElementById("fill-box-select");
      if (selectID.options.length == 1) {
        selectID.size = "1";
      } else if (selectID.options.length == 2) {
        selectID.size = "2";
      } else {
        selectID.size = "3";
      }
    },

    mouseDownHandler: function(e) {
      try {
        if (e.target != null && e.target.labelType == "box") {
          if (this.drawMode) {
            this.makeRectangle(e);
            this.showBoxSize = true;
          } else if (this.extremeClickMode) {
            this.makeCrossHair(e);
            this.saveExtremeClick(e);
          } else if (this.polygonMode) {
            this.handlePolygonClick(e);
          } else if (this.lineMode) {
            this.handleLineClick(e);
          } else if (this.isDotMode) {
            this.saveDotClick(e);
          } else {
            if (e.target.ratio > 0) {
              let ratiolineObj = this.getObjectById(e.target.annoId);
              if (
                ratiolineObj !== null &&
                ratiolineObj !== undefined &&
                (ratiolineObj.labelType == "RationLine" ||
                  ratiolineObj.labelType == "Triangle")
              ) {
                canvas.remove(ratiolineObj);
              }
            }
            editRatioLineMode = false;
            this.highlightBbClick(e.target);
            editPolygon = null;
            this.removePolyBullet();
            this.highlightSelectedByAnno(e.target, 0);
          }
        } else if (e.target != null && e.target.look == "polygon") {
          if (this.polygonMode) {
            this.handlePolygonClick(e);
          } else if (this.drawMode) {
            this.makeRectangle(e);
            this.showBoxSize = true;
          } else if (this.extremeClickMode) {
            this.makeCrossHair(e);
            this.saveExtremeClick(e);
          } else if (this.lineMode) {
            this.handleLineClick(e);
          } else if (this.isDotMode) {
            this.saveDotClick(e);
          } else {
            this.removePolyBullet();
            editPolygon = e.target;
            this.highlightPolygonClick(e, 0);
            this.highlightSelectedByAnno(e.target, 0);
          }
        } else if (
          e.target != null &&
          (e.target.look == "freehand" ||
            e.target.look == "point" ||
            e.target.look == "floodFill" ||
            e.target.look == "line")
        ) {
          if (this.lineMode) {
            this.handleLineClick(e);
          } else if (this.drawMode) {
            this.makeRectangle(e);
            this.showBoxSize = true;
          } else if (this.extremeClickMode) {
            this.makeCrossHair(e);
            this.saveExtremeClick(e);
          } else if (this.polygonMode) {
            this.handlePolygonClick(e);
          } else {
            this.removePolyBullet();
            editPolygon = e.target;
            this.highlightPolygonClick(e, 0);
            this.highlightSelectedByAnno(e.target, 0);
          }
        } else if (this.extremeClickMode) {
          this.makeCrossHair(e);
          this.saveExtremeClick(e);
          this.showBoxSize = true;
        } else if (this.freeTextMode) {
        } else if (this.polygonMode) {
          this.handlePolygonClick(e);
        } else if (this.lineMode) {
          this.handleLineClick(e);
        } else if (this.drawMode) {
          this.makeRectangle(e);
          this.showBoxSize = true;
        } else if (this.drawRatioMode) {
          this.makeRectangle(e);
          this.showBoxSize = true;
        } else if (this.drawRatioLineMode) {
          this.isTagOpen = true;
          this.popupPosition(e);
          this.drawRatioLineMode = false;
        } else if (this.isDotMode) {
          this.saveDotClick(e);
        } else if (this.zoomMode) {
          this.zoomToClick(e);
        } else if (this.isFloodFillmode) {
          this.doFloodFill(e);
        } else if (this.isFreeHandmodeMouseDown) {
          canvas.defaultCursor = this.selectedCursor;
          this.isFreeHandmode = true;
          let pointer = canvas.getPointer(e.e);
          origX = pointer.x;
          origY = pointer.y;
          this.firstorigX = origX;
          this.firstorigY = origY;
        } else if (e.target != null && e.target.labelType == "RationLine") {
          editRatioLineMode = true;
          e.target.lockMovementX = true;
          e.target.lockMovementY = true;
          e.target.lockScalingX = true;
          e.target.lockScalingY = true;
        } else if (e.target === null) {
          this.setGrabMode();
          this.removePolyBullet();
          this.highlightanno = "";
          editRatioLineMode = false;
        }
        this.isRectangleToolOpen = false;
        this.isZoomToolOpen = false;
        this.isShowPropToolOpen = false;
        this.isShowHideToolOpen = false;
      } catch (error) {
        console.log("Error:", error);
      }
    },

    mouseUpHandler: function(e) {
      try {
        var obj = e.target;
        if (this.grabMode) {
          this.exitGrabMode();
        } else if (this.polygonMode) {
          //this.handlePolygonClick(e);
        } else if (this.lineMode) {
          //this.handleLineClick(e);
        } else if (this.isFreeHandmodeMouseDown) {
          canvas.defaultCursor = this.selectedCursor;
          this.freehandMode = true;
          this.isTagOpen = true;
          this.popupPosition(e);
          this.isFreeHandmode = false;
          this.isFreeHandmodeMouseDown = false;
        } else if (this.drawMode) {
          if (
            drawRect.sHeight >= this.minheight &&
            drawRect.sWidth >= this.minwidth
          ) {
            this.isTagOpen = true;
            this.popupPosition(e);
            this.exitDrawMode();
          } else {
            canvas.remove(drawRect);
            canvas.remove(this.boxsize);
            this.showBoxSize = false;
          }
        } else if (this.drawRatioMode) {
          this.enterRatioLineMode(e);
        } else if (this.isFloodFillmode) {
          this.isTagOpen = true;
          this.popupPosition(e);
        } else if (this.freeTextMode) {
          this.imageText = "";
          this.imageTextSelect = [];
          this.isFreeTextOpen = true;
          let pointer = canvas.getPointer(e.e);
          origX = pointer.x;
          origY = pointer.y;
          var popupBox = document.getElementById("boxset");
          popupBox.style.marginTop = e.e.offsetY + 50 + "px";
          popupBox.style.marginLeft = e.e.offsetX + 15 + "px";
        } else if (this.isDotMode) {
          this.isTagOpen = true;
          this.handlePopUp(e);
          this.isDotMode = false;
          canvas.renderAll();
        } else if (
          obj != null &&
          obj.look == "point" &&
          obj.points.length == 1
        ) {
          // For point update
          obj.points[0].x = obj.left;
          obj.points[0].y = obj.top;
          this.isAnychange = true;
        } else if (
          obj != null &&
          (obj.labelType == POLY_CLICK_LABEL ||
            obj.labelType == POLY_LINE_LABEL)
        ) {
          for (var i = 0; i < editPolygon.points.length; i++) {
            if (editPolygon.points[i].id == obj.id) {
              editPolygon.points[i].x = obj.left;
              editPolygon.points[i].y = obj.top;
            }
          }
          if (editPolygon.look == "polygon") {
            this.removeTip(editPolygon.annoId);
          }
          this.isAnychange = true;
          obj.set({ selectable: false }).setCoords();
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },

    popupPosition: function(e) {
      try {
        var popup = document.getElementById("set");
        if (e.e.offsetY < 50) {
          popup.style.marginTop = e.e.offsetY + 50 + "px";
          popup.style.marginLeft = e.e.offsetX + 30 + "px";
        } else if (
          this.canvasWidth - e.e.offsetX < 50 &&
          this.canvasHeight - e.e.offsetY < 50
        ) {
          popup.style.marginTop = e.e.offsetY - 140 + "px";
          popup.style.marginLeft = e.e.offsetX - 100 + "px";
        } else if (this.canvasHeight - e.e.offsetY < 50) {
          popup.style.marginTop = e.e.offsetY - 50 + "px";
          popup.style.marginLeft = e.e.offsetX + 30 + "px";
        } else if (this.canvasWidth - e.e.offsetX < 50) {
          popup.style.marginTop = e.e.offsetY + 40 + "px";
          popup.style.marginLeft = e.e.offsetX - 80 + "px";
        } else if (e.e.offsetX < 20) {
          popup.style.marginTop = e.e.offsetY + 40 + "px";
          popup.style.marginLeft = e.e.offsetX + 35 + "px";
        } else {
          popup.style.marginLeft = e.e.offsetX + "px";
          popup.style.marginTop = e.e.offsetY + "px";
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },

    mouseMoveHandler: function(e) {
      try {
        if (this.grabMode) {
          let currZoom = canvas.getZoom();
          if (currZoom != 1) {
            this.handleGrabMove(e);
          }
        } else if (this.extremeClickMode) {
          this.makeCrossHair(e);
          this.handleDrawMove(e);
        } else if (this.drawMode) {
          this.makeCrossHair(e);
          this.handleDrawMove(e);
        } else if (this.drawRatioMode) {
          this.makeCrossHair(e);
          this.handleDrawMove(e);
        } else if (editRatioLineMode == true && e.target != null) {
          let allRatioLineObjs = canvas.getObjects();
          for (let i = 0; i < allRatioLineObjs.length; i++) {
            if (
              allRatioLineObjs[i] !== undefined &&
              allRatioLineObjs[i] !== null &&
              allRatioLineObjs[i].id === e.target.id &&
              allRatioLineObjs[i].labelType == "Triangle"
            ) {
              console.log("Triangle:", allRatioLineObjs[i]);
              canvas.remove(allRatioLineObjs[i]);
            }
          }
          this.handleDrawRatioMove(e);
        } else if (this.drawRatioLineMode) {
          this.handleDrawRatioMove(e);
        } else if (this.polygonMode) {
          // this.makeCrossHair(e);
          // this.handleDrawMove(e);
        } else if (this.isFreeHandmode) {
          this.doFreeDraw(e);
        } else if (
          e.target != null &&
          (e.target.look == "polygon" ||
            e.target.look == "line" ||
            e.target.look == "freehand")
        ) {
          e.target.lockMovementX = true;
          e.target.lockMovementY = true;
        } else {
          return;
        }
        canvas.renderAll();
      } catch (error) {
        console.log("Error:", error);
      }
    },

    mouseWheelHandler: function(e) {
      try {
        let self = this;
        if (e.e.ctrlKey) {
          if (e.e.wheelDelta > 0) {
            this.setZoomMode(0, 0);
          } else {
            this.zoomOut(0, 0);
          }

          e.e.preventDefault();
          e.e.stopImmediatePropagation();
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },

    mouseDblClickHandler: function(e) {
      try {
        let self = this;
        if (this.extremeClickMode && e.target !== null) {
          this.resetExtremeClicks();
          this.setMode();
          this.deselectObject();
        } else if (this.lineMode) {
          this.line_end = 1;
          this.handleLineClick(e);
        } else if (this.drawMode) {
          return;
        } else if (e.target != null && e.target.labelType == "polygonClick") {
          this.deselectObject();
          canvas.forEachObject(function(o) {
            if (self.isLabelObject(o)) {
              o.set({ selectable: true }).setCoords();
            }
          });
        } else if (e.target != null) {
          this.removePolyBullet();
          this.exitDrawMode();
          this.highlightSelectedByAnno(e.target, 1);
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },

    isNumberKey: function(event) {
      try {
        let code = event.keyCode;
        if (code != 46 && code > 31 && (code < 48 || code > 57)) {
          return event.preventDefault();
        } else {
          return true;
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },

    removePolyBullet: function() {
      if (circleArray.length > 0) {
        for (var i = 0; i < circleArray.length; i++) {
          canvas.remove(circleArray[i]);
        }
        circleArray = [];
      }
    },
    highlightBbClick: function(val) {
      val.set({
        hoverCursor: "move",
        cornerColor: "blue",
        cornerStyle: "circle",
        transparentCorners: false,
        selectable: true,
      });
      canvas.setActiveObject(val);
      canvas.bringToFront(val);
      canvas.renderAll();
    },
    highlightPolygonClick: function(val, index) {
      try {
        this.removePolyBullet();
        if (index) {
          editPolygon = val;
        }
        let self = this;
        let newradius;
        if (this.zoomFactor > 1) {
          newradius = this.polyClickRadius / this.zoomFactor;
        } else {
          newradius = this.polyClickRadius;
        }
        for (var i = 0; i < editPolygon.points.length; i++) {
          polyCircle = new fabric.Circle({
            id: editPolygon.points[i].id,
            ...Polygon,
            radius: newradius,
            left: editPolygon.points[i].x - newradius,
            top: editPolygon.points[i].y - newradius,
            fill: "blue",
            labelType: POLY_CLICK_LABEL,
          });
          circleArray.push(polyCircle);
          canvas.add(polyCircle);
          canvas.setActiveObject(polyCircle);
          canvas.bringToFront(polyCircle);
        }
        canvas.renderAll();
        canvas.forEachObject(function(o) {
          if (self.isLabelObject(o)) {
            o.set({ selectable: false }).setCoords();
          }
        });
      } catch (error) {
        console.log("Error:", error);
      }
    },

    giveLabel: function(settingItem, index) {
      try {
        this.isAnychange = true;
        var label = this.getCurLabel();
        if (prevSelected !== null && prevSelected !== undefined) {
          // document.getElementById(prevSelected).style.borderColor = "white";
        }
        for (let j = 0; j < this.classObj[index].param.length; j++) {
          if (
            !this.parameterLabel[[index, j]] &&
            this.classObj[index].param[j].name !== "Id"
          ) {
            // document.getElementById(settingItem.name + j).style.borderColor = "red";
            $("#" + settingItem.name + j)
              .parent()
              .addClass("input-error");
            prevSelected = settingItem.name + j;
            this.radioSelect = false;
            this.isTagOpen = true;
            this.exitDrawMode();
            return;
          } else {
            this.isTagOpen = false;
            $("#" + settingItem.name + j)
              .parent()
              .removeClass("input-error");
            // document.getElementById(settingItem.name + j).style.borderColor = "white";
          }
        }
        if (this.isTagOpen == false) {
          var cnt = 0;
          var arr = [];
          polyParam = [];
          rectParam = [];

          if (this.polygonMode) {
            if (this.polygon_end == true) this.polygon_end = false;
            this.makePolygon();
          }
          if (this.lineMode) {
            if (this.line_end == 1) this.line_end = 0;
            this.makeLine();
          }
          if (this.freehandMode) {
            this.saveFreeDraw();
          }
          for (let j = 0; j < this.classObj[index].param.length; j++) {
            var parameterList = this.classObj[index].param[j];
            if (parameterList) {
              if (this.extremeClickMode) {
                if (parameterList.name == "Id") {
                  parameterVal.push(drawExtremeClick.annoId);
                } else {
                  parameterVal.push(this.parameterLabel[[index, j]]);
                }
                drawExtremeClick.set(parameterList.name, parameterVal[cnt]);
                rectParam.push({
                  val: parameterVal[cnt],
                  nam: parameterList.name,
                });
                arr.push(parameterVal[cnt]);
                cnt = cnt + 1;
              } else if (this.polygonMode) {
                if (parameterList.name == "Id") {
                  parameterVal.push(drawPolygon.annoId);
                } else {
                  parameterVal.push(this.parameterLabel[[index, j]]);
                }
                drawPolygon.set(parameterList.name, parameterVal[cnt]);
                polyParam.push({
                  val: parameterVal[cnt],
                  nam: parameterList.name,
                });
                arr.push(parameterVal[cnt]);
                cnt = cnt + 1;
              } else if (this.lineMode) {
                if (parameterList.name == "Id") {
                  parameterVal.push(drawLine.annoId);
                } else {
                  parameterVal.push(this.parameterLabel[[index, j]]);
                }
                drawLine.set(parameterList.name, parameterVal[cnt]);
                polyParam.push({
                  val: parameterVal[cnt],
                  nam: parameterList.name,
                });
                arr.push(parameterVal[cnt]);
                cnt = cnt + 1;
              } else if (this.isDotModeLabel) {
                if (drawCircle != null) {
                  if (parameterList.name == "Id") {
                    parameterVal.push(drawCircle.annoId);
                  } else {
                    parameterVal.push(this.parameterLabel[[index, j]]);
                  }
                  drawCircle.set(parameterList.name, parameterVal[cnt]);
                  polyParam.push({
                    val: parameterVal[cnt],
                    nam: parameterList.name,
                  });
                  arr.push(parameterVal[cnt]);
                  cnt = cnt + 1;
                } else if (drawCircle == null) {
                  this.dotWarning = true;
                  this.setDotMode();
                }
              } else if (this.freehandMode) {
                if (parameterList.name == "Id") {
                  parameterVal.push(drawFreeDraw.annoId);
                } else {
                  parameterVal.push(this.parameterLabel[[index, j]]);
                }
                drawFreeDraw.set(parameterList.name, parameterVal[cnt]);
                polyParam.push({
                  val: parameterVal[cnt],
                  nam: parameterList.name,
                });
                arr.push(parameterVal[cnt]);
                cnt = cnt + 1;
              } else if (this.isFloodFillmode) {
                if (parameterList.name == "Id") {
                  parameterVal.push(drawfloodfill.annoId);
                } else {
                  parameterVal.push(this.parameterLabel[[index, j]]);
                }
                drawfloodfill.set(parameterList.name, parameterVal[cnt]);
                polyParam.push({
                  val: parameterVal[cnt],
                  nam: parameterList.name,
                });
                arr.push(parameterVal[cnt]);
                cnt = cnt + 1;
              } else {
                if (parameterList.name == "Id") {
                  parameterVal.push(drawRect.annoId);
                } else {
                  parameterVal.push(this.parameterLabel[[index, j]]);
                }
                drawRect.set(parameterList.name, parameterVal[cnt]);
                rectParam.push({
                  val: parameterVal[cnt],
                  nam: parameterList.name,
                });
                arr.push(parameterVal[cnt]);
                cnt = cnt + 1;
              }
            }
          }
          if (this.extremeClickMode) {
            canvas.add(
              new fabric.IText(label, {
                left: origX,
                top: origY - 20,
                evented: false,
                fontFamily: "20px Helvetica",
                fill: "white",
                id: drawExtremeClick.annoId,
              })
            );
            this.sortedLabelList.push({
              label: label,
              id: drawExtremeClick.annoId,
              bbox: {
                parameters: rectParam,
                score: 0,
              },
            });
            this.allLabelFlag.push({
              value: false,
              id: drawExtremeClick.annoId,
            });
            var i = this.sortedLabelList.length;
            i = i - 1;
            this.parameterLabel1[i] = arr;
            this.saveExtremeClickMode();
          } else if (this.polygonMode) {
            canvas.add(
              new fabric.IText(label, {
                left: this.getX / this.zoomFactor - 20,
                top: this.getY / this.zoomFactor - 20,
                fontFamily: "20px Helvetica",
                fill: "white",
                id: drawPolygon.annoId,
              })
            );
            this.sortedLabelList.push({
              label: label,
              id: drawPolygon.annoId,
              polygon: {
                parameters: polyParam,
                score: 0,
              },
            });
            this.allLabelFlag.push({
              value: false,
              id: drawPolygon.annoId,
            });
            var i = this.sortedLabelList.length;
            i = i - 1;
            this.parameterLabel1[i] = arr;
            this.savePolygon();
          } else if (this.lineMode) {
            canvas.add(
              new fabric.IText(label, {
                left: this.getX / this.zoomFactor - 20,
                top: this.getY / this.zoomFactor - 20,
                fontFamily: "20px Helvetica",
                evented: false,
                fill: "white",
                id: drawLine.annoId,
              })
            );
            this.sortedLabelList.push({
              label: label,
              id: drawLine.annoId,
              polygon: {
                parameters: polyParam,
                score: 0,
              },
            });
            this.allLabelFlag.push({
              value: false,
              id: drawLine.annoId,
            });
            var i = this.sortedLabelList.length;
            i = i - 1;
            this.parameterLabel1[i] = arr;
            this.saveLine();
          } else if (this.isDotModeLabel) {
            if (drawCircle != null) {
              canvas.add(
                new fabric.IText(label, {
                  left: this.getX / this.zoomFactor - 20,
                  top: this.getY / this.zoomFactor - 20,
                  fontFamily: "20px Helvetica",
                  evented: false,
                  fill: "blue",
                  id: drawCircle.annoId,
                })
              );
              this.isDotModeLabel = false;
              this.isDotMode = true;
              this.sortedLabelList.push({
                label: label,
                id: drawCircle.annoId,
                polygon: {
                  parameters: polyParam,
                  score: 0,
                },
              });
              this.allLabelFlag.push({
                value: false,
                id: drawCircle.annoId,
              });
              var i = this.sortedLabelList.length;
              i = i - 1;
              this.parameterLabel1[i] = arr;
              this.saveDot();
            }
          } else if (this.freehandMode) {
            canvas.add(
              new fabric.IText(label, {
                left: this.firstorigX,
                top: this.firstorigY,
                evented: false,
                fontFamily: "20px Helvetica",
                fill: "white",
                id: drawFreeDraw.annoId,
              })
            );
            this.sortedLabelList.push({
              label: label,
              id: drawFreeDraw.annoId,
              polygon: {
                parameters: polyParam,
                score: 0,
              },
            });
            this.allLabelFlag.push({
              value: false,
              id: drawFreeDraw.annoId,
            });
            var i = this.sortedLabelList.length;
            i = i - 1;
            this.parameterLabel1[i] = arr;
            this.finalSaveFreeDraw();
          } else if (this.isFloodFillmode) {
            canvas.add(
              new fabric.IText(label, {
                left: this.getX / this.zoomFactor - 20,
                top: this.getY / this.zoomFactor - 20,
                fontFamily: "20px Helvetica",
                fill: "blue",
                evented: false,
                id: drawfloodfill.annoId,
              })
            );
            this.sortedLabelList.push({
              label: label,
              id: drawfloodfill.annoId,
              polygon: {
                parameters: polyParam,
                score: 0,
              },
            });
            this.allLabelFlag.push({
              value: false,
              id: drawfloodfill.annoId,
            });
            var i = this.sortedLabelList.length;
            i = i - 1;
            this.parameterLabel1[i] = arr;
            this.saveFloodFill();
          } else {
            canvas.add(
              new fabric.IText(label, {
                left: origX,
                top: origY - 20,
                selectable: false,
                fontFamily: "20px Helvetica",
                fill: "white",
                evented: false,
                id: drawRect.annoId,
              })
            );
            this.sortedLabelList.push({
              label: label,
              id: drawRect.annoId,
              bbox: {
                parameters: rectParam,
                score: 0,
              },
            });
            this.allLabelFlag.push({
              value: false,
              id: drawRect.annoId,
            });
            var i = this.sortedLabelList.length;
            i = i - 1;
            this.parameterLabel1[i] = arr;
            this.saveRectangle();
          }
        }
        parameterVal = [];
        this.radioSelect = "";
        this.parameterLabel = [];
        this.incomplete_anno = false;
      } catch (error) {
        console.log("Error:", error);
      }
    },

    freeText: function() {
      try {
        if (this.isTagOpen === true) {
          this.showObjectClassMenu = true;
        } else {
          if (this.duplicateObj == false) {
            this.freeTextMode = true;
            this.isZoomToolOpen = false;
            this.isShowPropToolOpen = false;
            this.isShowHideToolOpen = false;
            this.isFillToolOpen = false;
            this.isRectangleToolOpen = false;
            this.drawRatioMode = false;
            this.removeActiveToolEffect("annotation-tool");
            this.addActiveToolEffect("free-text-tool");
            activeAnnoMode = "free-text-tool";
          } else {
            this.showDuplicateDialog = true;
          }
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },

    saveImageText: function() {
      try {
        if (
          this.isFreeTextOpen == true &&
          (this.imageText !== "" || this.imageTextSelect.length > 0)
        ) {
          var tagName;
          if (this.imageText !== "") {
            tagName = "";
            tagName = this.imageText;
            this.imageTextSelect = [];
          }
          if (this.imageTextSelect.length > 0) {
            tagName = "";
            var str;
            for (var i = 0; i < this.imageTextSelect.length; i++) {
              str = this.imageTextSelect[i];
              tagName += str;
            }
            this.imageText = "";
          }
          let text = new fabric.Text(tagName, {
            id: this.getRandId(),
            annoId: this.getRandId(),
            left: origX,
            top: origY - 20,
            fontFamily: "20px Helvetica",
            fill: "white",
          });
          text.setCoords();
          text.selectable = false;
          text.set("label", tagName);
          text.set("labelType", "Image_Tag");
          text.set("opacity", 0.5);
          canvas.add(text);
          canvas.renderAll();
          this.allLabelFlag.push({
            value: false,
            id: text.annoId,
          });
          this.isFreeTextOpen = false;
          this.isAnychange = true;
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },
    /**
     * Draw reactangle
     */
    makeRectangle: function(e) {
      try {
        this.incomplete_anno = true;
        var pointer = canvas.getPointer(e.e);
        origX = pointer.x;
        origY = pointer.y;
        let rect = new LabeledRect({
          id: this.getRandId(),
          annoId: this.getRandId(),
          track: false,
          left: origX,
          top: origY,
          width: pointer.x - origX,
          height: pointer.y - origY,
          ...Rectangle,
          fill: "transparent",
          //opacity: 0.5,
          cornerSize: this.cornerSize,
          sWidth: pointer.x - origX,
          sHeight: pointer.y - origY,
          ratio: 0,
          labelType: BOX_LABEL,
          hasRotatingPoint: false,
        });
        canvas.add(rect);
        drawRect = rect;
        canvas.renderAll();
      } catch (error) {
        console.log("Error:", error);
      }
    },
    enterRatioLineMode: function(e) {
      try {
        // this.deselectObject();
        this.drawRatioMode = false;
        this.boxsize = null;
        this.showBoxSize = false;
        this.makeRatioLine(e);
      } catch (error) {
        console.log("Error:", error);
      }
    },
    makeRatioLine: function(e) {
      try {
        let pointer = canvas.getPointer(e.e);
        let ratioLineCoords = [
          origX + (pointer.x - origX) / 2,
          origY,
          origX + (pointer.x - origX) / 2,
          pointer.y + 10,
        ];
        let ratioLine = new fabric.Line(ratioLineCoords, {
          opacity: 1,
          fill: "yellow",
          stroke: "yellow",
          strokeWidth: 3,
          hoverCursor: "move",
          cornerColor: "red",
          cornerStyle: "square",
          hasRotatingPoint: false,
          cornerSize: 5,
          transparentCorners: false,
          selectable: true,
        });
        drawRatioRectLine = ratioLine;
        canvas.add(ratioLine);
        canvas.setActiveObject(ratioLine);
        canvas.bringToFront(ratioLine);
        canvas.renderAll();
        this.drawRatioLineMode = true;
      } catch (error) {
        console.log("Error:", error);
      }
    },

    getObjectById: function(id) {
      try {
        let objs = canvas.getObjects();
        for (let i = 0; i < objs.length; i++) {
          if (objs[i] !== undefined && objs[i] !== null && objs[i].id === id) {
            return objs[i];
          }
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },

    /**
     * Remove canvas object's by id
     */
    removeObjectById: function(id) {
      try {
        canvas.forEachObject(function(o) {
          if (o !== undefined && o !== null && o.id === id) {
            canvas.remove(o);
            canvas.renderAll();
            return;
          }
        });
      } catch (error) {
        console.log("Error:", error);
      }
    },

    /**
     * Save Reactangle
     */
    saveRectangle: function(e) {
      try {
        drawRect.set({
          score: 0,
        });
        drawRect.setCoords();
        drawRect.selectable = false;
        var text = this.getCurLabel();
        var objColor = this.getCurColor(text);
        drawRect.set("label", text);
        drawRect.set("fill", objColor);
        drawRect.set("opacity", 0.3);
        let copy = fabric.util.object.clone(drawRect);
        this.drawMode = true;
        if (drawRatioRectLine) {
          drawRatioRectLine.set("stroke", objColor);
          drawRatioRectLine.set("opacity", 1);
          drawRatioRectLine.set("strokeWidth", 2);
          canvas.remove(drawRatioRectLine);
          canvas.add(drawRatioRectLine);
          drawRatioRectLine = null;
          this.drawMode = false;
          this.drawRatioMode = true;
        }
        canvas.remove(drawRect);
        canvas.add(drawRect);
        drawRect = null;
        canvas.renderAll();
      } catch (error) {
        console.log("Error:", error);
      }
    },

    saveExtremeClick: function(e) {
      try {
        let pointer = canvas.getPointer(e.e);
        let circle = new fabric.Circle({
          id: this.getRandId(),
          radius: this.extremeClickRadius,
          fill: "blue",
          left: this.getXCoordFromClick(pointer, this.extremeClickRadius),
          top: this.getYCoordFromClick(pointer, this.extremeClickRadius),
          visible: true,
          score: 0,
          labelType: EC_LABEL,
        });
        canvas.add(circle);
        this.extremeClicks.push(circle.id);
        if (this.extremeClicks.length === 2) {
          this.isTagOpen = true;
          var popup = document.getElementById("set");
          this.getX = e.e.offsetX;
          this.getY = e.e.offsetY;
          popup.style.marginLeft = e.e.offsetX + 15 + "px";
          popup.style.marginTop = e.e.offsetY + 15 + "px";
          this.createBoxFromExtremeClicks();
        }
        canvas.renderAll();
      } catch (error) {
        console.log("Error:", error);
      }
    },

    savePolygonClick: function(e) {
      try {
        let pointer = canvas.getPointer(e.e);
        let newradius;
        if (this.zoomFactor > 1) {
          newradius = this.polyClickRadius / this.zoomFactor;
        } else {
          newradius = this.polyClickRadius;
        }
        let circle = new fabric.Circle({
          id: this.getRandId(),
          ...Polygon,
          radius: newradius,
          left: this.getXCoordFromClick(pointer, newradius),
          top: this.getYCoordFromClick(pointer, newradius),
          labelType: POLY_CLICK_LABEL,
        });

        if (this.polygonClicks.length === 0) {
          circle.selectable = true;
          circle.lineIn = null;
          circle.set({
            radius: circle.radius * 1.5,
            left: this.getXCoordFromClick(pointer, circle.radius * 1.5),
            top: this.getYCoordFromClick(pointer, circle.radius * 1.5),
            fill: "blue",
            padding: 5,
          });
          canvas.add(circle);
          this.polygonClicks.push(circle.id);
        } else {
          let startCircle = this.getObjectById(
            this.polygonClicks[this.polygonClicks.length - 1]
          );
          let line = this.makePolygonLine(startCircle, circle);
          circle.lineIn = line;
          startCircle.lineOut = line;
          line.selectable = false;
          canvas.add(line);
          canvas.add(circle);
          this.polygonClicks.push(circle.id);
        }
        canvas.setActiveObject(circle);
        canvas.bringToFront(circle);
        canvas.renderAll();
      } catch (error) {
        console.log("Error:", error);
      }
    },

    saveLineClick: function(e) {
      try {
        let pointer = canvas.getPointer(e.e);
        let newradius;
        if (this.zoomFactor > 1) {
          newradius = this.polyClickRadius / this.zoomFactor;
        } else {
          newradius = this.polyClickRadius;
        }
        let circle = new fabric.Circle({
          id: this.getRandId(),
          radius: newradius,
          ...Polygon,
          left: this.getXCoordFromClick(pointer, newradius),
          top: this.getYCoordFromClick(pointer, newradius),
          labelType: POLY_LINE_LABEL,
        });

        if (this.lineClicks.length === 0) {
          circle.selectable = true;
          circle.lineIn = null;
          circle.set({
            radius: circle.radius * 1.5,
            left: this.getXCoordFromClick(pointer, circle.radius * 1.5),
            top: this.getYCoordFromClick(pointer, circle.radius * 1.5),
            fill: "white",
            padding: 5,
          });
          canvas.add(circle);
          this.lineClicks.push(circle.id);
        } else {
          let startCircle = this.getObjectById(
            this.lineClicks[this.lineClicks.length - 1]
          );
          let line = this.makePolygonLine(startCircle, circle);
          circle.lineIn = line;
          startCircle.lineOut = line;
          line.selectable = false;
          canvas.add(line);
          canvas.add(circle);
          this.lineClicks.push(circle.id);
        }
        canvas.setActiveObject(circle);
        canvas.bringToFront(circle);
        canvas.renderAll();
      } catch (error) {
        console.log("Error:", error);
      }
    },

    saveDotClick: function(e) {
      try {
        let pointer = canvas.getPointer(e.e);
        let newradius;
        if (this.zoomFactor > 1) {
          newradius = this.polyClickRadius / this.zoomFactor;
        } else {
          newradius = this.polyClickRadius;
        }
        let circle = new fabric.Circle({
          id: this.getRandId(),
          annoId: this.getRandId(),
          ...Polygon,
          radius: newradius,
          left: this.getXCoordFromClick(pointer, newradius),
          top: this.getYCoordFromClick(pointer, newradius),
          fill: "blue",
          originX: "center",
          originY: "center",
          look: "point",
          labelType: POINT_CLICK_LABEL,
        });
        canvas.add(circle);
        this.DotClicks = circle.id;
        drawCircle = circle;
        this.dotLeft = circle.left;
        this.dotTop = circle.top;
        canvas.setActiveObject(circle);
        canvas.bringToFront(circle);
        canvas.renderAll();
      } catch (error) {
        console.log("Error:", error);
      }
    },

    makePointsFromCoords: function(coords) {
      try {
        let self = this;
        coords.map(function(o) {
          o.id = self.getRandId();
        });
        return coords;
      } catch (error) {
        console.log("Error:", error);
      }
    },

    makePolygon: function() {
      try {
        let coords = [];
        let click;
        for (let id of this.polygonClicks) {
          click = this.getObjectById(id);
          coords.push({
            x: click.left + click.radius,
            y: click.top + click.radius,
          });
        }
        var text = this.getCurLabel();
        var objColor = this.getCurColor(text);
        let polygon = new fabric.Polygon(coords, {
          id: this.getRandId(),
          annoId: this.getRandId(),
          track: false,
          label: text,
          fill: objColor,
          opacity: 0.5,
          stroke: "black",
          ...defaultPolygonPty,
          borderColor: "black",
          look: "polygon",
          points: this.makePointsFromCoords(coords),
          coord: coords,
        });
        canvas.add(polygon);
        drawPolygon = polygon;
        canvas.renderAll();
        return polygon;
      } catch (error) {
        console.log("Error:", error);
      }
    },

    makeLine: function() {
      try {
        let coords = [];
        let click;
        for (let id of this.lineClicks) {
          click = this.getObjectById(id);
          coords.push({
            x: click.left + click.radius,
            y: click.top + click.radius,
          });
        }
        let line = new fabric.Polyline(coords, {
          id: this.getRandId(),
          annoId: this.getRandId(),
          track: false,
          label: this.getCurLabel(),
          ...Line,
          opacity: 0.5,
          look: "line",
          points: this.makePointsFromCoords(coords),
        });
        //line.selectable = false;
        canvas.add(line);
        drawLine = line;
        canvas.renderAll();
        return line;
      } catch (error) {
        console.log("Error:", error);
      }
    },

    savePolygon: function(e) {
      try {
        let polygon = drawPolygon;
        polygon.selectable = false;
        let copy = fabric.util.object.clone(polygon);
        canvas.remove(polygon);
        canvas.add(polygon);
        polygon = null;
        // Update labels.json
        this.exitPolygonMode();
        this.setPolygonMode();
        canvas.setActiveObject(polygon);
        canvas.renderAll();
      } catch (error) {
        console.log("Error:", error);
      }
    },
    saveLine: function(e) {
      try {
        let line = drawLine;
        line.selectable = false;
        let copy = fabric.util.object.clone(line);
        canvas.remove(line);
        canvas.add(line);
        //Update labels.json
        this.exitLineMode();
        this.setLineMode();
        canvas.setActiveObject(line);
        canvas.renderAll();
      } catch (error) {
        console.log("Error:", error);
      }
    },
    saveExtremeClickMode: function(e) {
      try {
        drawExtremeClick.set({
          score: 0,
        });
        drawExtremeClick.setCoords();
        drawExtremeClick.selectable = false;
        var text = this.getCurLabel();
        var objColor = this.getCurColor(text);
        drawExtremeClick.set("label", text);
        drawExtremeClick.set("fill", objColor);
        drawExtremeClick.set("opacity", 0.3);
        drawExtremeClick.set("ratio", 0);
        let copy = fabric.util.object.clone(drawExtremeClick);
        canvas.remove(drawExtremeClick);
        canvas.add(drawExtremeClick);
        canvas.setActiveObject(drawExtremeClick);
        drawExtremeClick = null;
        this.setExtremeClickMode();
        canvas.renderAll();
      } catch (error) {
        console.log("Error:", error);
      }
    },
    saveDot: function(e) {
      try {
        drawCircle.set({
          score: 0,
        });
        drawCircle.set({
          points: [
            {
              id: this.getRandId(),
              x: this.dotLeft,
              y: this.dotTop,
            },
          ],
        });
        drawCircle.selectable = false;
        var text = this.getCurLabel();
        var objColor = this.getCurColor(text);
        drawCircle.set("label", text);
        drawCircle.set("fill", objColor);
        drawCircle.set("opacity", 0.5);
        let copy = fabric.util.object.clone(drawCircle);
        canvas.remove(drawCircle);
        canvas.add(drawCircle);
        drawCircle = null;
        this.setDotMode();
        canvas.renderAll();
      } catch (error) {
        console.log("Error:", error);
      }
    },

    adjustPolygonClick: function(e) {
      try {
        let activeObj = canvas.getActiveObject();
        let idx = this.polygonClicks.indexOf(activeObj.id);
        if (activeObj.lineIn !== undefined && activeObj.lineIn !== null) {
          activeObj.lineIn.set({
            x2: activeObj.left + activeObj.radius,
            y2: activeObj.top + activeObj.radius,
          });
        }
        if (activeObj.lineOut !== undefined && activeObj.lineOut !== null) {
          activeObj.lineOut.set({
            x1: activeObj.left + activeObj.radius,
            y1: activeObj.top + activeObj.radius,
          });
        }
        if (this.exists(this.polygon)) {
          this.polygon.points[idx] = {
            x: activeObj.left + activeObj.radius,
            y: activeObj.top + activeObj.radius,
          };
        }
        //canvas.renderAll();
      } catch (error) {
        console.log("Error:", error);
      }
    },
    handlePopUp: function(e) {
      var popup = document.getElementById("set");

      if (this.isTagOpen == false || this.isTagOpen == true) {
        this.getX = e.e.offsetX;
        this.getY = e.e.offsetY;
      }

      this.isTagOpen = true;

      if (this.getY < 50) {
        popup.style.marginTop = this.getY + 50 + "px";
        popup.style.marginLeft = this.getX + 15 + "px";
      } else if (
        this.canvasWidth - this.getX < 50 &&
        this.canvasHeight - this.getY < 50
      ) {
        popup.style.marginTop = this.getY - 140 + "px";
        popup.style.marginLeft = this.getX - 100 + "px";
      } else if (this.canvasHeight - this.getY < 50) {
        popup.style.marginTop = this.getY - 50 + "px";
        popup.style.marginLeft = this.getX + 15 + "px";
      } else if (this.canvasWidth - this.getX < 50) {
        popup.style.marginTop = this.getY + 15 + "px";
        popup.style.marginLeft = this.getX - 80 + "px";
      } else if (this.getX < 20) {
        popup.style.marginTop = this.getY + 15 + "px";
        popup.style.marginLeft = this.getX + 35 + "px";
      } else {
        popup.style.marginLeft = this.getX + 15 + "px";
        popup.style.marginTop = this.getY + 15 + "px";
      }
    },
    handlePolygonClick: function(e) {
      try {
        let activeObj = canvas.getActiveObject();
        if (this.exists(this.polygon)) {
          return;
        } else if (this.polygonClicks.length === 0) {
          this.savePolygonClick(e);
        } else if (
          (activeObj === undefined || activeObj === null) &&
          this.polygon_end == false
        ) {
          this.savePolygonClick(e);
        } else if (this.polygonClicks.length <= 2) {
          this.polygonError = true;
        } else if (
          activeObj != null &&
          this.polygonClicks[0] === activeObj.id &&
          !this.exists(this.polygon) &&
          this.polygonClicks.length > 2
        ) {
          this.polygonError = false;
          this.isTagOpen = true;
          this.polygon_end = true;
          this.handlePopUp(e);
        } else if (
          activeObj != null &&
          this.polygonClicks.includes(activeObj.id)
        ) {
          this.adjustPolygonClick(e);
        } else {
          return;
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },
    handleLineClick: function(e) {
      try {
        let activeObj = canvas.getActiveObject();
        if (this.exists(this.line)) {
          return;
        } else if (this.lineClicks.length === 0) {
          this.saveLineClick(e);
        } else if (
          (activeObj === undefined || activeObj === null) &&
          this.line_end == 0
        ) {
          this.saveLineClick(e);
        } else if (this.line_end === 1 && this.lineClicks.length == 1) {
          this.lineError = true;
        } else if (this.line_end === 1 && this.lineClicks.length > 1) {
          this.lineError = false;
          this.handlePopUp(e);
        } else if (this.lineClicks.includes(activeObj.id)) {
          this.adjustPolygonClick(e);
        } else {
          return;
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },
    handlePolygonMouseOver: function(e) {
      try {
        let obj = e.target;
        if (
          obj !== undefined &&
          obj !== null &&
          this.polygonClicks.length > 0
        ) {
          if (obj === this.polygonClicks[0]) {
            obj.set({
              stroke: "green",
              fill: "green",
            });
          } else if (obj.selectable === true) {
            canvas.hoverCursor = "move";
          }
        }
        canvas.renderAll();
      } catch (error) {
        console.log("Error:", error);
      }
    },
    handleLineMouseOver: function(e) {
      try {
        let obj = e.target;
        if (obj !== undefined && obj !== null && this.lineClicks.length > 0) {
          if (obj === this.lineClicks[0]) {
            obj.set({
              stroke: "green",
              fill: "green",
            });
          } else if (obj.selectable === true) {
            canvas.hoverCursor = "move";
          }
        }
        canvas.renderAll();
      } catch (error) {
        console.log("Error:", error);
      }
    },
    handlePolygonMouseOut: function(e) {
      try {
        let obj = e.target;
        if (
          obj !== undefined &&
          obj !== null &&
          this.polygonClicks.length > 0 &&
          obj === this.polygonClicks[0]
        ) {
          obj.set({
            stroke: "blue",
            fill: "blue",
          });
          canvas.renderAll();
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },
    handleLineMouseOut: function(e) {
      try {
        let obj = e.target;
        if (
          obj !== undefined &&
          obj !== null &&
          this.lineClicks.length > 0 &&
          obj === this.lineClicks[0]
        ) {
          obj.set({
            stroke: "blue",
            fill: "blue",
          });
          canvas.renderAll();
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },
    makePolygonLine: function(startCircle, endCircle) {
      try {
        let coords = [
          startCircle.left + startCircle.radius,
          startCircle.top + startCircle.radius,
          endCircle.left + endCircle.radius,
          endCircle.top + endCircle.radius,
        ];
        return new fabric.Line(coords, {
          id: this.getRandId(),
          ...Line,
        });
      } catch (error) {
        console.log("Error:", error);
      }
    },

    getXCoordFromClick: function(pointer, radius) {
      return pointer.x - radius;
    },

    getYCoordFromClick: function(pointer, radius) {
      return pointer.y - radius;
    },

    makePoint: function(click) {
      return {
        id: this.getRandId(),
        x: (click.left += click.radius),
        y: (click.top += click.radius),
      };
    },

    createBoxFromExtremeClicks: function() {
      try {
        let r, click, xmin, ymin, xmax, ymax;
        let points = [];
        for (let i = 0; i < this.extremeClicks.length; i++) {
          click = this.getObjectById(this.extremeClicks[i]);
          if (xmin === undefined || click.left < xmin) {
            xmin = click.left + this.extremeClickRadius;
          }
          if (ymin === undefined || click.top < ymin) {
            ymin = click.top + this.extremeClickRadius;
          }
          if (xmax === undefined || click.left > xmax) {
            xmax = click.left + this.extremeClickRadius;
          }
          if (ymax === undefined || click.top > ymax) {
            ymax = click.top + this.extremeClickRadius;
          }
        }
        origX = xmin;
        origY = ymin;
        r = this.createRectFromCoords(xmin, ymin, xmax, ymax);
        r.points = points;
        this.removeExtremeClicks();
      } catch (error) {
        console.log("Error:", error);
      }
    },

    removeExtremeClicks: function() {
      try {
        while (this.extremeClicks.length > 0) {
          this.removeObjectById(this.extremeClicks[0]);
          this.extremeClicks.splice(0, 1);
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },

    resetExtremeClicks: function() {
      try {
        this.removeExtremeClicks();
        this.extremeClickMode = false;
        canvas.remove(this.crossHairVLine);
        canvas.remove(this.crossHairHLine);
      } catch (error) {
        console.log("Error:", error);
      }
    },

    exists: function(obj) {
      return obj !== undefined && obj !== null;
    },

    deletePolygonClick: function(click) {
      try {
        let idx = this.polygonClicks.indexOf(click.id);
        if (idx === this.polygonClicks.length - 1) {
          canvas.remove(click.lineIn);
        } else if (idx === 0 && this.exists(click.lineOut)) {
          canvas.remove(click.lineOut);
        } else if (this.exists(click.lineIn) && this.exists(click.lineOut)) {
          let priorClick = this.getObjectById(this.polygonClicks[idx - 1]);
          let nextClick = this.getObjectById(this.polygonClicks[idx + 1]);
          priorClick.lineOut.set({
            x2: click.lineOut.x2,
            y2: click.lineOut.y2,
          });
          nextClick.set({
            lineIn: priorClick.lineOut,
          });
          canvas.remove(click.lineOut);
        } else {
          canvas.remove(click.lineIn);
          canvas.remove(click.lineOut);
        }
        canvas.remove(click);
        if (idx > 0) {
          let obj = this.getObjectById(this.polygonClicks[idx - 1]);
          canvas.setActiveObject(obj);
          canvas.renderAll();
        }
        this.polygonClicks.splice(idx, 1);
        if (this.exists(this.polygon)) {
          canvas.remove(this.polygon);
          this.savePolygon();
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },
    deleteDotClick: function(click) {
      try {
        canvas.remove(click);
        canvas.renderAll();
      } catch (error) {
        console.log("Error:", error);
      }
    },
    deleteLineClick: function(click) {
      try {
        let idx = this.lineClicks.indexOf(click.id);
        if (idx === this.lineClicks.length - 1) {
          canvas.remove(click.lineIn);
        } else if (idx === 0 && this.exists(click.lineOut)) {
          canvas.remove(click.lineOut);
        } else if (this.exists(click.lineIn) && this.exists(click.lineOut)) {
          let priorClick = this.getObjectById(this.lineClicks[idx - 1]);
          let nextClick = this.getObjectById(this.lineClicks[idx + 1]);
          priorClick.lineOut.set({
            x2: click.lineOut.x2,
            y2: click.lineOut.y2,
          });
          nextClick.set({
            lineIn: priorClick.lineOut,
          });
          canvas.remove(click.lineOut);
        } else {
          canvas.remove(click.lineIn);
          canvas.remove(click.lineOut);
        }
        canvas.remove(click);
        if (idx > 0) {
          let obj = this.getObjectById(this.lineClicks[idx - 1]);
          canvas.setActiveObject(obj);
          canvas.renderAll();
        }
        this.lineClicks.splice(idx, 1);
        if (this.exists(this.line)) {
          canvas.remove(this.line);
          this.saveLine();
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },
    exitPolygonMode: function() {
      try {
        while (this.polygonClicks.length > 0) {
          let idx = this.polygonClicks.length - 1;
          let click = this.getObjectById(this.polygonClicks[idx]);
          if (click == undefined) {
            this.polygon_end = false;
            break;
          }
          this.deletePolygonClick(click);
        }
        this.polygonMode = false;
        this.polygon = null;
      } catch (error) {
        console.log("Error:", error);
      }
    },
    exitLineMode: function() {
      while (this.lineClicks.length > 0) {
        let idx = this.lineClicks.length - 1;
        let click = this.getObjectById(this.lineClicks[idx]);
        if (click == undefined) {
          this.line_end = 0;
          break;
        }
        this.deleteLineClick(click);
      }
      this.lineMode = false;
      this.line = null;
    },
    exitDotMode: function() {
      try {
        this.isTagOpen = false;
        let click = this.getObjectById(this.DotClicks);
        this.deleteDotClick(click);
        this.isDotMode = false;
        this.isDotModeLabel = false;
        this.polygon = null;
      } catch (error) {
        console.log("Error:", error);
      }
    },
    createRectFromCoords: function(xmin, ymin, xmax, ymax) {
      try {
        let rect = new LabeledRect({
          id: this.getRandId(),
          annoId: this.getRandId(),
          left: xmin,
          top: ymin,
          originX: "left",
          originY: "top",
          width: xmax - xmin,
          height: ymax - ymin,
          angle: 0,
          fill: "transparent",
          stroke: "black",
          selectable: true,
          label: this.getCurLabel(),
          opacity: 0.5,
          visible: true,
          transparentCorners: true,
          cornerSize: this.cornerSize,
          score: 0,
          labelType: EC_LABEL,
          isModified: false,
          sWidth: xmax - xmin,
          sHeight: ymax - ymin,
        });
        rect.selectable = false;
        canvas.add(rect);
        canvas.setActiveObject(rect);
        drawExtremeClick = rect;
        canvas.renderAll();
        return rect;
      } catch (error) {
        console.log("Error:", error);
      }
    },

    handleGrabMove: function(e) {
      try {
        var delta = new fabric.Point(e.e.movementX, e.e.movementY);
        canvas.relativePan(delta);
      } catch (error) {
        console.log("Error:", error);
      }
    },
    makeCrossHair: function(e) {
      try {
        let pointer = canvas.getPointer(e.e);
        var width = canvas.width;
        var height = canvas.height;
        let vertiCoords = [
          pointer.x,
          0,
          pointer.x,
          height + height / this.zoomFactor,
        ];
        let horiCoords = [
          0,
          pointer.y,
          width + width / this.zoomFactor,
          pointer.y,
        ];
        if (this.crossHairVLine != null) {
          canvas.remove(this.crossHairVLine);
          canvas.renderAll();
        }
        if (this.crossHairHLine != null) {
          canvas.remove(this.crossHairHLine);
          canvas.renderAll();
        }
        this.crossHairVLine = new fabric.Line(vertiCoords, {
          ...Line,
          opacity: 1,
          fill: "red",
          stroke: "red",
        });
        this.crossHairHLine = new fabric.Line(horiCoords, {
          ...Line,
          opacity: 1,
          fill: "red",
          stroke: "red",
        });
        this.crossHairVLine.selectable = false;
        this.crossHairHLine.selectable = false;
        canvas.add(this.crossHairVLine);
        canvas.add(this.crossHairHLine);
        canvas.bringToFront(this.crossHairVLine);
        canvas.bringToFront(this.crossHairHLine);
        canvas.renderAll();
      } catch (error) {
        console.log("Error:", error);
      }
    },
    findRatioLineBox: function(id) {
      let annosList = canvas.getObjects();
      let getBbox, activeRatioLineBbox;
      if (id) {
        getBbox = this.getBoxById(annosList, id);
      }
      if (id == getBbox.annoId) {
        activeRatioLineBbox = getBbox;
        return activeRatioLineBbox;
      }
    },

    handleDrawRatioMove: function(e) {
      let obj = canvas.getActiveObject();
      let pointer = canvas.getPointer(e.e);
      let faceToSideRatio = 0;
      if (editRatioLineMode == true) {
        drawRect = this.findRatioLineBox(obj.id);
      }
      if (
        pointer.x > drawRect.left &&
        pointer.x < drawRect.left + drawRect.width &&
        pointer.y > drawRect.top &&
        pointer.y < drawRect.top + drawRect.height
      ) {
        if (
          obj.left != pointer.x &&
          obj.left > drawRect.left &&
          obj.left < drawRect.left + drawRect.width
        ) {
          obj.set({
            left: Math.abs(pointer.x),
          });
        }
        if (obj.top != drawRect.top) {
          obj.set({
            top: Math.abs(drawRect.top),
          });
        }
        if (obj.height != drawRect.height) {
          obj.set({
            height: Math.abs(drawRect.height),
          });
        }
      }
      faceToSideRatio = (obj.left - drawRect.left) / drawRect.width;
      drawRect.set({
        ratio: faceToSideRatio.toFixed(2),
      });
    },
    handleDrawMove: function(e) {
      try {
        if (!this.exists(drawRect)) {
          return;
        }
        let pointer = canvas.getPointer(e.e);
        if (origX > pointer.x) {
          drawRect.set({
            left: Math.abs(pointer.x),
          });
        }
        if (origY > pointer.y) {
          drawRect.set({
            top: Math.abs(pointer.y),
          });
        }
        drawRect.set({
          width: Math.abs(origX - pointer.x),
        });
        drawRect.set({
          height: Math.abs(origY - pointer.y),
        });
        drawRect.set({
          sWidth: Math.abs(origX - pointer.x),
        });
        drawRect.set({
          sHeight: Math.abs(origY - pointer.y),
        });
        if (this.showBoxSize) {
          let text =
            Math.abs(Math.round(pointer.x) - Math.round(origX)) +
            "x" +
            Math.abs(Math.round(pointer.y) - Math.round(origY));
          if (this.boxsize != null) {
            canvas.remove(this.boxsize);
            canvas.renderAll();
          }
          this.boxsize = new fabric.IText(text, {
            left: pointer.x + 5,
            top: pointer.y - 17,
            fontSize: 15,
            fontFamily: "Helvetica",
            fill: "white",
          });
          canvas.add(this.boxsize);
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },

    loadratioLine: function(bbox) {
      let ratioLineCoords, triangleLeft, triangleTop;
      if (bbox.xmax) {
        let boxWidth = bbox.xmax - bbox.xmin;
        ratioLineCoords = [
          bbox.xmin + bbox.ratio * boxWidth,
          bbox.ymin,
          bbox.xmin + bbox.ratio * boxWidth,
          bbox.ymax + 15,
        ];
        triangleLeft = bbox.xmin + 1 + bbox.ratio * boxWidth;
        triangleTop = bbox.ymax + 10;
      } else {
        let boxYmax = parseInt(bbox.sHeight) + parseInt(bbox.top);
        ratioLineCoords = [
          parseInt(bbox.left) + bbox.ratio * parseInt(bbox.sWidth),
          parseInt(bbox.top),
          parseInt(bbox.left) + bbox.ratio * parseInt(bbox.sWidth),
          boxYmax + 15,
        ];
        triangleLeft =
          parseInt(bbox.left) + 1 + bbox.ratio * parseInt(bbox.sWidth);
        triangleTop = boxYmax + 10;
      }
      let ratioLine = new fabric.Line(ratioLineCoords, {
        id: bbox.annoId,
        opacity: 1,
        fill: bbox.fill,
        stroke: bbox.fill,
        strokeWidth: 3,
        hoverCursor: "move",
        cornerColor: "red",
        cornerStyle: "square",
        hasRotatingPoint: false,
        cornerSize: 5,
        transparentCorners: false,
        selectable: true,
        labelType: "RationLine",
      });
      let trianglePointer = new fabric.Triangle({
        id: bbox.annoId,
        left: triangleLeft,
        top: triangleTop,
        strokeWidth: 1,
        width: 7,
        height: 7,
        stroke: bbox.fill,
        angle: 360,
        fill: bbox.fill,
        originX: "center",
        labelType: "Triangle",
        selectable: false,
        evented: false,
      });
      canvas.add(ratioLine);
      canvas.add(trianglePointer);
    },

    loadBB: function(bbox) {
      try {
        let rect = new fabric.Rect({
          id: bbox.id,
          annoId: bbox.annoId,
          track: bbox.track,
          left: bbox.xmin,
          top: bbox.ymin,
          originX: "left",
          originY: "top",
          width: bbox.xmax - bbox.xmin,
          height: bbox.ymax - bbox.ymin,
          angle: 0,
          fill: bbox.fill,
          transparentCorners: false,
          borderColor: "transparent",
          cornerColor: "transparent",
          visible: true,
          label: bbox.label,
          stroke: this.stroke,
          opacity: bbox.opacity,
          score: bbox.score,
          transparentCorners: true,
          cornerSize: this.cornerSize,
          labelType: BOX_LABEL,
          points: bbox.points,
          sWidth: bbox.xmax - bbox.xmin,
          sHeight: bbox.ymax - bbox.ymin,
          ratio: bbox.ratio,
          parameters: this.makeParameter(bbox.parameters),
          hasRotatingPoint: false,
        });
        if (bbox.ratio) {
          this.loadratioLine(bbox);
        }
        let colorindex = this.storeColorProp
          .map(function(o) {
            return o.name;
          })
          .indexOf(rect.label);
        let borderColorindex = borderColorProp
          .map(function(o) {
            return o.name;
          })
          .indexOf(rect.label);
        if (colorindex >= 0) {
          rect.set("fill", this.storeColorProp[colorindex].color);
        }
        if (borderColorindex >= 0) {
          rect.set("stroke", borderColorProp[borderColorindex].color);
        }
        if (rect.opacity !== 0) {
          rect.set("opacity", this.opacity);
        }
        canvas.add(rect);
      } catch (error) {
        console.log("Error:", error);
      }
    },

    loadImageTag: function(tag) {
      try {
        let text = new fabric.Text(tag.label, {
          id: tag.id,
          annoId: tag.annoId,
          left: tag.x,
          top: tag.y,
          originX: "left",
          originY: "top",
          width: 300,
          height: 200,
          fill: tag.fill,
          selectable: false,
          visible: true,
          label: tag.label,
          opacity: tag.opacity,
          labelType: TAG_LABEL,
          sWidth: 300,
          sHeight: 200,
        });
        if (text.opacity !== 0) {
          text.set("opacity", this.opacity);
        }
        canvas.add(text);
      } catch (error) {
        console.log("Error:", error);
      }
    },
    loadPolygon: function(poly) {
      try {
        let coords = [];
        let point = [];
        let click, x, y, id;
        let n = poly.points.length;
        let polygonPty = {
          selectable: false,
          objectCaching: false,
          opacity: poly.opacity,
          hasControls: false,
          hasBorders: true,
          borderColor: "transparent",
          cornerStyle: "circle",
          cornerColor: "white",
          cornerSize: 3,
          labelType: POLYGON_LABEL,
        };
        for (let t = 0; t < n; t++) {
          coords.push({
            x: poly.points[t].x,
            y: poly.points[t].y,
          });
          point.push({
            id: poly.points[t].id,
            x: poly.points[t].x,
            y: poly.points[t].y,
          });
        }
        if (poly.look == "polygon") {
          let polygon = new fabric.Polygon(coords, {
            id: this.getRandId(),
            annoId: poly.annoId,
            track: poly.track,
            label: poly.label,
            fill: poly.fill,
            opacity: poly.opacity,
            stroke: this.stroke,
            score: poly.score,
            ...polygonPty,
            look: "polygon",
            points: point,
            parameters: this.makeParameter(poly.parameters),
          });
          var colorindex = this.storeColorProp
            .map(function(o) {
              return o.name;
            })
            .indexOf(polygon.label);
          let borderColorindex = borderColorProp
            .map(function(o) {
              return o.name;
            })
            .indexOf(polygon.label);
          if (colorindex >= 0) {
            polygon.set("fill", this.storeColorProp[colorindex].color);
          }
          if (borderColorindex >= 0) {
            polygon.set("stroke", borderColorProp[borderColorindex].color);
          }
          if (polygon.opacity !== 0) {
            polygon.set("opacity", this.opacity);
          }
          canvas.add(polygon);
        } else {
          let polygon = new fabric.Polygon(coords, {
            id: this.getRandId(),
            annoId: poly.annoId,
            label: poly.label,
            fill: poly.fill,
            opacity: poly.opacity,
            stroke: this.stroke,
            score: poly.score,
            ...polygonPty,
            look: "freehand",
            points: point,
            parameters: this.makeParameter(poly.parameters),
          });
          var colorindex = this.storeColorProp
            .map(function(o) {
              return o.name;
            })
            .indexOf(polygon.label);
          let borderColorindex = borderColorProp
            .map(function(o) {
              return o.name;
            })
            .indexOf(polygon.label);
          if (colorindex >= 0) {
            polygon.set("fill", this.storeColorProp[colorindex].color);
          }
          if (borderColorindex >= 0) {
            polygon.set("stroke", borderColorProp[borderColorindex].color);
          }
          if (polygon.opacity !== 0) {
            polygon.set("opacity", this.opacity);
          }
          canvas.add(polygon);
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },

    loadLine: function(poly) {
      try {
        let coords = [];
        let point = [];
        let newcoords = [];
        let x, y;
        let n = poly.points.length;
        for (let id = 0; id < n; id++) {
          coords.push({
            x: poly.points[id].x,
            y: poly.points[id].y,
          });
          point.push({
            id: poly.points[id].id,
            x: poly.points[id].x,
            y: poly.points[id].y,
          });
        }
        for (let id = 0; id < n - 1; id++) {
          newcoords = [
            coords[id].x,
            coords[id].y,
            coords[id + 1].x,
            coords[id + 1].y,
          ];
        }
        //####//
        let line = new fabric.Polyline(newcoords, {
          id: poly.id,
          annoId: poly.annoId,
          track: poly.track,
          label: poly.label,
          ...Line,
          fill: "transparent", //"#fff",
          opacity: poly.opacity,
          stroke: "white",
          strokeWidth: 4,
          score: poly.score,
          look: "line",
          points: point,
          parameters: this.makeParameter(poly.parameters),
        });
        if (line.opacity !== 0) {
          line.set("opacity", 1);
        }
        canvas.add(line);
      } catch (error) {
        console.log("Error:", error);
      }
    },

    loadPoint: function(dot) {
      try {
        let point = [];
        let click, x, y, id;
        let n = dot.points.length;
        let pointPty = {
          selectable: false,
          objectCaching: false,
          opacity: dot.opacity,
          hasControls: false,
          hasBorders: true,
          labelType: POINT_CLICK_LABEL,
        };
        point.push({
          id: dot.points[0].id,
          x: dot.points[0].x,
          y: dot.points[0].y,
        });
        let circle = new fabric.Circle({
          id: this.getRandId(),
          annoId: dot.annoId,
          label: dot.label,
          fill: dot.fill,
          opacity: dot.opacity,
          stroke: this.stroke,
          score: dot.score,
          ...pointPty,
          radius: this.polyClickRadius,
          left: dot.points[0].x,
          top: dot.points[0].y,
          originX: "center",
          originY: "center",
          look: "point",
          points: point,
          parameters: this.makeParameter(dot.parameters),
        });
        var colorindex = this.storeColorProp
          .map(function(o) {
            return o.name;
          })
          .indexOf(circle.label);
        let borderColorindex = borderColorProp
          .map(function(o) {
            return o.name;
          })
          .indexOf(circle.label);
        if (colorindex >= 0) {
          circle.set("fill", this.storeColorProp[colorindex].color);
        }
        if (borderColorindex >= 0) {
          circle.set("stroke", borderColorProp[borderColorindex].color);
        }
        if (circle.opacity !== 0) {
          circle.set("opacity", this.opacity);
        }
        canvas.add(circle);
      } catch (error) {
        console.log("Error:", error);
      }
    },

    removeAllObj: function() {
      try {
        this.isShowHideToolOpen = false;
        this.radioSelect1 = false;
        this.radioSelect = false;
        for (var i = 0; i < this.isDetailVisible.length; i++) {
          this.$set(this.isDetailVisible, i, false);
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },

    showAllObj: function() {
      try {
        this.isShowHideToolOpen = false;
        let annos = this.annotationJson;
        for (var i = 0; i < annos.length; i++) {
          if (annos[i].label == selectedProp || selectedProp == null) {
            this.$set(this.isDetailVisible, i, true);
          }
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },

    requestIndex: function(imageName) {
      try {
        let index = this.allImagesList.indexOf(imageName);
        this.requestImage(index, null, 2);
      } catch (error) {
        console.log("Error:", error);
      }
    },
    clearSearch: function() {
      this.search = "";
    },
    getFrameProp: function() {
      try {
        this.propInFrame = [];
        for (var i = 0; i < this.classObj.length; i++) {
          let obj = this.annotationJson.find(
            (o) => o.label === this.classObj[i].name
          );
          if (obj != null) {
            this.propInFrame[0] = {
              name: "Show All",
            };
            this.propInFrame[1] = {
              name: "Hide All",
            };
            this.propInFrame.push({
              name: obj.label,
            });
            this.radioSelectObj = "Show All";
            this.objList.push(obj.label);
          }
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },

    updateAnnowithCpy: function() {
      try {
        var cnt = 0;
        if (this.copyAnnotationList.length) {
          this.isAnychange = true;
          for (let anno of this.copyAnnotationList) {
            if (anno !== undefined) {
              let obj = this.annotationJson.find((o) => o.id === anno.id);
              this.annotationJson.push(anno);
              for (let annos of this.annotationJson) {
                if (obj !== null && obj !== undefined) {
                  if (anno.id == annos.id) {
                    if (annos.bbox !== null) {
                      annos.bbox.fill = "#FF0000";
                    } else if (annos.polygon !== null) {
                      annos.polygon.fill = "#FF0000";
                    }
                    this.duplicateObj = true;
                  }
                  canvas.renderAll();
                } else {
                  if (annos.id == anno.id) {
                    this.allLabelFlag.splice(cnt, 1, {
                      value: true,
                      id: annos.id,
                    });
                  } else if (
                    this.allLabelFlag[cnt] &&
                    annos.id.includes(this.allLabelFlag[cnt].id)
                  ) {
                    this.allLabelFlag;
                  } else {
                    this.allLabelFlag.splice(cnt, 1, {
                      value: false,
                      id: annos.id,
                    });
                  }
                  cnt = cnt + 1;
                }
              }

              cnt = 0;
            }
          }
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },
    loadAllAnnotations: function() {
      try {
        let annos = this.annotationJson;
        allAnnos = [];
        this.showtogglebbox = [];
        this.showtogglepolygon = [];
        for (let i = 0; i < annos.length; i++) {
          this.isDetailVisible.push(false);
          if (this.exists(annos[i].bbox)) {
            if (this.classObjNames.includes(annos[i].bbox.label)) {
              //this.showtogglebbox[i] = true;
              this.loadBB(annos[i].bbox);
            } else {
              allAnnos.push(annos[i]);
            }
          }
          if (this.exists(annos[i].imageTag)) {
            this.loadImageTag(annos[i].imageTag);
          }
          if (this.exists(annos[i].polygon)) {
            if (this.classObjNames.includes(annos[i].polygon.label)) {
              //this.showtogglepolygon[i] = true;
              if (annos[i].polygon.look === "polygon") {
                this.showPolyLabel = true;
                this.loadPolygon(annos[i].polygon);
              } else if (annos[i].polygon.look === "freehand") {
                this.showPolyLabel = true;
                this.loadPolygon(annos[i].polygon);
              } else if (annos[i].polygon.look === "line") {
                this.showPolyLabel = true;
                this.loadLine(annos[i].polygon);
              } else if (annos[i].polygon.look === "point") {
                this.loadPoint(annos[i].polygon);
              }
            } else {
              allAnnos.push(annos[i]);
            }
          }
        }
        canvas.renderAll();
      } catch (error) {
        console.log("Error:", error);
      }
    },

    loadAnnotations: function(name) {
      try {
        selectedProp = name;
        let detail;
        let annos = this.annotationJson;
        for (var i = 0; i < annos.length; i++) {
          if (name == null) {
            // this.requestImage(-1);
            if (this.exists(annos[i].bbox)) {
              annos[i].bbox.opacity = 0.5;
            }
            this.clearCanvas();
          } else {
            if (this.exists(annos[i].bbox)) {
              if (name == annos[i].bbox.label) {
                annos[i].bbox.opacity = 0.5;
              } else {
                annos[i].bbox.opacity = 0;
              }
            }
            if (this.exists(annos[i].polygon)) {
              if (name === annos[i].polygon.label) {
                annos[i].polygon.opacity = 0.5;
              } else {
                annos[i].polygon.opacity = 0;
              }
            }
            canvas.renderAll();
            this.clearCanvas();
          }
        }
        // to add anno details inside bbox
        for (var i = 0; i < annos.length; i++) {
          var text;
          if (this.exists(annos[i].bbox)) {
            if (name == annos[i].bbox.label) {
              text = annos[i].bbox.label + "\n";
              for (var j = 0; j < annos[i].bbox.parameters.length; j++) {
                text = text + annos[i].bbox.parameters[j].val + "\n";
              }
              detail = new fabric.IText(text, {
                selectable: false,
                left: annos[i].bbox.xmin + 5,
                top: annos[i].bbox.ymin + 5,
                fontSize: 12,
                fontFamily: "Helvetica",
                fill: "white",
                evented: false,
                opacity: 0.8,
              });
              canvas.add(detail);
              canvas.sendToBack(detail);
              canvas.renderAll();
            }
          }
        }
        activeAnnoMode = null;
      } catch (error) {
        console.log("Error:", error);
      }
    },
    // Trigger Annotation Load
    triggerLoadAnnotation: function() {
      if (this.radioSelectObj == "Show All") {
        this.loadAnnotations(null);
      } else if (this.radioSelectObj == "Hide all") {
        this.setMode();
        return;
      } else {
        this.loadAnnotations(this.radioSelectObj);
        this.setMode();
        this.removeActiveToolEffect("annotation-tool");
      }
    },

    getCurLabel: function() {
      if (this.radioSelect) return this.radioSelect;
    },

    getCurColor: function(name) {
      var objColor = "transparent";
      for (var i = 0; i < this.classObj.length; i++) {
        if (name == this.classObj[i].name) {
          objColor = this.classObj[i].color;
        }
      }
      return objColor;
    },

    getRandId: function() {
      let random_id_generated = Math.random()
        .toString(36)
        .substr(2, 4);
      //editormodel script
      let manual_anno_id = "M-" + random_id_generated;
      return manual_anno_id;
    },

    deleteObject1: function() {
      try {
        this.removeActiveToolEffect("annotation-tool");
        activeAnnoMode = null;
        let obj = canvas.getActiveObject();
        if (obj !== undefined && obj !== null) {
          if (editPolygon == null || editPolygon.length == 0) {
            this.deleteLabelListObj(obj.annoId);
            if (this.unsavechange == false) {
              this.removeTip(obj.annoId);
              if (obj.look == "line" || obj.labelType == "polygonLine") {
                this.deleteLineClick(obj);
              } else {
                let label = this.getObjectById(obj.annoId);
                let ratiolineObj = this.getObjectById(obj.annoId);
                canvas.remove(obj);
                canvas.remove(label);
                canvas.remove(ratiolineObj);
              }
            } else {
              this.showDialog = true;
            }
          } else {
            this.deleteLabelListObj(editPolygon.annoId);
            if (this.unsavechange == false) {
              this.removeTip(editPolygon.annoId);
              if (editPolygon != null) {
                canvas.remove(editPolygon);
                let label = this.getObjectById(editPolygon.annoId);
                canvas.remove(label);
                this.removePolyBullet();
                this.removeTip(editPolygon.annoId);
              }
            } else {
              this.showDialog = true;
            }
          }
          this.isAnychange = true;
        } else {
          this.isAnychange = false;
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },

    deleteLabelListObj: function(id) {
      try {
        this.unsavechange = false;
        if (this.sortedLabelList.length > jsonArray.length) {
          var newlabelindex = this.sortedLabelList
            .map(function(o) {
              return o.id;
            })
            .indexOf(id);
          var objLength = Object.keys(this.sortedLabelList[newlabelindex])
            .length;
          if (newlabelindex >= 0) {
            if (objLength > 3) {
              this.unsavechange = true;
            } else {
              this.unsavechange = false;
              this.parameterLabel1.splice(newlabelindex, 1);
              this.sortedLabelList.splice(newlabelindex, 1);
            }
          }
        } else {
          this.sortedLabelList = [];
          var labelindex = jsonArray
            .map(function(o) {
              return o.id;
            })
            .indexOf(id);
          if (labelindex >= 0) {
            this.parameterLabel1.splice(labelindex, 1);
            jsonArray.splice(labelindex, 1);
          }
          this.sortedLabelList = jsonArray;
        }

        for (let i = 0; i < this.copyAnnotationList.length; i++) {
          if (this.copyAnnotationList[i].id == newlabelindex) {
            this.copyAnnotationList.pop(i);
          }
        }
        for (let i = 0; i < this.allLabelFlag.length; i++) {
          if (this.allLabelFlag[i].id == newlabelindex) {
            this.allLabelFlag.pop(i);
          }
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },

    deselectObject: function() {
      this.line_end = 0;
      this.polygon_end = false;
      activeAnnoMode = null;
      canvas.remove(this.boxsize);
      canvas.discardActiveObject();
      canvas.remove(this.crossHairVLine);
      canvas.remove(this.crossHairHLine);
      canvas.renderAll();
      this.removeActiveToolEffect("annotation-tool");
    },

    // showObject: function(name, i) {
    //   try {
    //     if (name !== null) {
    //       let annos = this.annotationJson;
    //       allAnnos = [];
    //       this.showtogglebbox = [];
    //       this.showtogglepolygon = [];
    //       for (let i = 0; i < annos.length; i++) {
    //         this.isDetailVisible.push(false);
    //         if (this.exists(annos[i].bbox)) {
    //           if (annos[i].bbox.label == name) {
    //             this.showtogglebbox[i] = true;
    //             this.loadBB(annos[i].bbox);
    //           } //else {
    //           //     allAnnos.push(annos[i]);
    //           // }
    //         }
    //         if (this.exists(annos[i].polygon)) {
    //           if (annos[i].polygon.label == name) {
    //             this.showtogglepolygon[i] = true;
    //             if (annos[i].polygon.look === "polygon") {
    //               this.showPolyLabel = true;
    //               this.loadPolygon(annos[i].polygon);
    //             } else if (annos[i].polygon.look === "freehand") {
    //               this.showPolyLabel = true;
    //               this.loadPolygon(annos[i].polygon);
    //             } else if (annos[i].polygon.look === "line") {
    //               this.showPolyLabel = true;
    //               this.loadLine(annos[i].polygon);
    //             } else if (annos[i].polygon.look === "point") {
    //               this.loadPoint(annos[i].polygon);
    //             }
    //           } //else {
    //           //     allAnnos.push(annos[i]);
    //           // }
    //         }
    //       }
    //       canvas.renderAll();
    //     }
    //   } catch (error) {
    //     console.log("Error:", error);
    //   }
    // },

    extractBB: function(rect) {
      //Update to make sure coord is less than width/height of picture
      try {
        let bb = {};
        let coords = rect.get("aCoords");
        bb.id = rect.get("id");
        bb.annoId = rect.get("annoId");
        bb.track = false;
        bb.label = rect.get("label");
        var objColor = this.getCurColor(bb.label);
        bb.parameters = rect.get("parameters");
        let parametersN = [];
        for (let i = 0; i < this.sortedLabelList.length; i++) {
          if (this.sortedLabelList[i].bbox != undefined) {
            if (
              this.sortedLabelList[i].bbox.track != undefined &&
              bb.annoId == this.sortedLabelList[i].bbox.annoId
            ) {
              bb.track = this.sortedLabelList[i].bbox.track;
            }
          }
        }
        if (rect.get("parameters")) {
          bb.parameters = rect.get("parameters");
        } else {
          for (let i = 0; i < this.sortedLabelList.length; i++) {
            if (this.sortedLabelList[i].bbox != undefined) {
              for (
                let j = 0;
                j < this.sortedLabelList[i].bbox.parameters.length;
                j++
              ) {
                if (bb.annoId == this.sortedLabelList[i].id) {
                  var name = this.sortedLabelList[i].bbox.parameters[j].nam;
                  var val = this.sortedLabelList[i].bbox.parameters[j].val;
                  parametersN.push({
                    nam: name,
                    val: val,
                  });
                  bb.parameters = parametersN;
                }
              }
            }
          }
        }
        if (rect.ratio != 0) {
          bb.ratio = rect.ratio;
        } else {
          bb.ratio = 0;
        }
        bb.score = rect.get("score");
        bb.fill = objColor;
        bb.xmin = Math.min(Math.max(rect.left, 0));
        (bb.ymin = Math.min(Math.max(rect.top, 0))),
          (bb.xmax = bb.xmin + rect.sWidth);
        bb.ymax = bb.ymin + rect.sHeight;
        //
        //                if ( bb.xmax > this.width){
        //                bb.xmax = this.width;
        //                alert(this.width)
        //                }
        //                if ( bb.ymax > this.height ){
        //                bb.ymax = this.height;
        //                alert(this.width)
        //
        //                }
        bb.points = rect.get("points");
        bb.opacity = 0.5;
        return bb;
      } catch (error) {
        console.log("Error:", error);
      }
    },

    extractTag: function(obj) {
      //Update to make sure coord is less than width/height of picture
      try {
        let tag = {};
        //  let coords = tag.get("aCoords");
        tag.id = obj.get("id");
        tag.annoId = obj.get("annoId");
        tag.label = obj.get("label");
        tag.score = obj.get("score");
        tag.fill = obj.get("fill");
        tag.x = obj.get("left");
        tag.y = obj.get("top");
        tag.points = obj.get("points");
        tag.parameters = obj.get("parameters");
        tag.opacity = 0.5;
        return tag;
      } catch (error) {
        console.log("Error:", error);
      }
    },
    extractPolygon: function(obj) {
      try {
        let poly = {};
        poly.id = obj.get("id");
        poly.annoId = obj.get("annoId");
        poly.track = false;
        poly.label = obj.get("label");
        var objColor = this.getCurColor(poly.label);
        poly.score = obj.get("score");
        poly.fill = objColor;
        poly.opacity = 0.5;
        poly.look = obj.get("look");
        poly.points = obj.get("points");
        poly.parameters = obj.get("parameters");
        let parametersN = [];
        for (let i = 0; i < this.sortedLabelList.length; i++) {
          if (this.sortedLabelList[i].polygon != undefined) {
            if (
              this.sortedLabelList[i].polygon.track != undefined &&
              poly.annoId == this.sortedLabelList[i].polygon.annoId
            ) {
              poly.track = this.sortedLabelList[i].polygon.track;
            }
          }
        }

        if (obj.get("parameters")) {
          poly.parameters = obj.get("parameters");
        } else {
          for (let i = 0; i < this.sortedLabelList.length; i++) {
            if (this.sortedLabelList[i].polygon != undefined) {
              for (
                let j = 0;
                j < this.sortedLabelList[i].polygon.parameters.length;
                j++
              ) {
                if (poly.annoId == this.sortedLabelList[i].id) {
                  var name = this.sortedLabelList[i].polygon.parameters[j].nam;
                  var val = this.sortedLabelList[i].polygon.parameters[j].val;
                  parametersN.push({
                    nam: name,
                    val: val,
                  });
                  poly.parameters = parametersN;
                }
              }
            }
          }
        }
        return poly;
      } catch (error) {
        console.log("Error:", error);
      }
    },

    getUniqueAnnotationIds: function() {
      try {
        let annoIds = new Set();
        let self = this;
        canvas.forEachObject(function(o) {
          if (self.isLabelObject(o) && o.annoId) {
            annoIds.add(o.annoId);
          }
        });
        return annoIds;
      } catch (error) {
        console.log("Error:", error);
      }
    },

    extractAnnotations: function() {
      try {
        let annos = [];
        let self = this;
        let annoIdsSet = this.getUniqueAnnotationIds();
        annoIdsSet.forEach(function(id) {
          let anno = self.extractAnnotation(id);
          if (anno) {
            annos.push(anno);
          }
        });
        allAnnos.forEach(function(anno_obj) {
          let anno = self.makeAnnotationFromObject(anno_obj);
          if (anno) {
            annos.push(anno);
          }
        });
        annos.forEach(function(anno) {
          if (anno.bbox !== null) {
            if (anno.bbox.ratio === undefined) {
              anno.bbox.ratio = 0;
            }
          }
        });
        return annos;
      } catch (error) {
        console.log("Error:", error);
      }
    },

    copyAnnotations: function(i, flag) {
      try {
        let existAnno = this.annotationJson; //this.extractAnnotations();
        if (flag) {
          if (existAnno[i].imageTag !== null && i !== existAnno.length - 1) {
            var k = i + 1;
            this.copyAnnotationList.push(existAnno[k]);
          } else {
            this.copyAnnotationList.push(existAnno[i]);
          }
        } else {
          if (existAnno[i].imageTag) {
            var k = i + 1;
            this.copyAnnotationList.pop(existAnno[k]);
          } else {
            this.copyAnnotationList.pop(existAnno[i]);
          }
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },

    getObjectsByAnnoId: function(annoId) {
      try {
        let objs = [];
        let self = this;
        canvas.forEachObject(function(o) {
          if (self.isLabelObject(o) && o.annoId === annoId) {
            objs.push(o);
          }
        });
        return objs;
      } catch (error) {
        console.log("Error:", error);
      }
    },

    extractAnnotation: function(id) {
      try {
        let objs = this.getObjectsByAnnoId(id);
        let anno = {
          id: id,
          label: objs[0].label,
        };
        for (let o of objs) {
          if (o.labelType === BOX_LABEL || o.labelType === EC_LABEL) {
            let bb = this.extractBB(o);
            let width = bb.xmax - bb.xmin;
            let height = bb.ymax - bb.ymin;
            if (width >= this.minwidth && height >= this.minheight) {
              anno["polygon"] = null;
              anno["imageTag"] = null;
              anno["bbox"] = bb;
              return anno;
            }
          } else if (o.labelType === "Image_Tag") {
            let tag = this.extractTag(o);
            anno["polygon"] = null;
            anno["bbox"] = null;
            anno["imageTag"] = tag;
            return anno;
          } else {
            let poly = this.extractPolygon(o);
            anno["polygon"] = poly;
            anno["bbox"] = null;
            anno["imageTag"] = null;
            return anno;
          }
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },

    makeAnnotationFromObject: function(obj) {
      try {
        let anno = {
          id: obj.id,
          label: obj.label,
        };
        if (obj.bbox) {
          anno["bbox"] = {
            annoId: obj["bbox"]["annoId"],
            id: obj["bbox"]["id"],
            track: obj["bbox"]["track"],
            label: obj["bbox"]["label"],
            score: obj["bbox"]["score"],
            fill: obj["bbox"]["fill"],
            opacity: obj["bbox"]["opacity"],
            xmax: obj["bbox"]["xmax"],
            xmin: obj["bbox"]["xmin"],
            ymax: obj["bbox"]["ymax"],
            ymin: obj["bbox"]["ymin"],
            parameters: [],
            points: [],
          };
          if (obj.bbox.parameters.length > 0) {
            obj.bbox.parameters.forEach(function(paramObj) {
              anno["bbox"]["parameters"].push({
                nam: paramObj.nam,
                val: paramObj.val,
              });
            });
          } else {
            anno["bbox"]["parameters"] = null;
          }
          obj.bbox.points.forEach(function(pointObj) {
            anno["bbox"]["points"].push({
              nam: pointObj.nam,
              val: pointObj.val,
            });
          });

          anno["polygon"] = null;
          anno["imageTag"] = null;
        }
        if (obj.imageTag) {
          anno["imageTag"] = {
            annoId: obj["imageTag"]["annoId"],
            id: obj["imageTag"]["id"],
            track: obj["imageTag"]["track"],
            label: obj["imageTag"]["label"],
            score: obj["imageTag"]["score"],
            fill: obj["imageTag"]["fill"],
            opacity: obj["imageTag"]["opacity"],
            x: obj["imageTag"]["x"],
            y: obj["imageTag"]["y"],
            parameters: [],
            points: [],
          };
          anno["bbox"] = null;
          anno["polygon"] = null;
        }

        if (obj.polygon) {
          anno["polygon"] = {
            annoId: obj["polygon"]["annoId"],
            id: obj["polygon"]["id"],
            track: obj["polygon"]["track"],
            label: obj["polygon"]["label"],
            score: obj["polygon"]["score"],
            fill: obj["polygon"]["fill"],
            opacity: obj["polygon"]["opacity"],
            look: obj["polygon"]["look"],
            parameters: [],
            points: [],
          };
          obj.polygon.points.forEach(function(pointObj) {
            anno["polygon"]["points"].push({
              id: pointObj.id,
              x: pointObj.x,
              y: pointObj.y,
            });
          });
          if (obj.polygon.parameters.length > 0) {
            obj.polygon.parameters.forEach(function(paramObj) {
              anno["polygon"]["parameters"].push({
                nam: paramObj.nam,
                val: paramObj.val,
              });
            });
          } else {
            anno["polygon"]["parameters"] = null;
          }

          anno["bbox"] = null;
          anno["imageTag"] = null;
        }
        return anno;
      } catch (error) {
        console.log("Error:", error);
      }
    },
    getBoxScore: function(id) {
      let box = null;
    },
    adjustThreshold: function() {
      try {
        // let self = this;
        // const val = this.sliderValue / 100;
        // let visible;
        // if (canvas !== undefined) {
        //     canvas.forEachObject(function (o) {
        //         if (self.isLabelObject(o)) {
        //             o.visible = true;;
        //         }
        //     });
        //     canvas.renderAll();
        // }
      } catch (error) {
        console.log("Error:", error);
      }
    },

    isLabelObject: function(obj) {
      try {
        return (
          obj.labelType !== undefined &&
          LABEL_TYPES.indexOf(obj.labelType) !== -1
        );
      } catch (error) {
        console.log("Error:", error);
      }
    },

    navigateNextBox: function(direction) {
      try {
        let self = this;
        let curBox = canvas.getActiveObject();
        canvas.discardActiveObject();
        let boxes = [];
        canvas.forEachObject(function(o) {
          if (self.isLabelObject(o)) {
            boxes.push(o);
          }
        });
        this.sortBoxesByProp(boxes, "left");
        let box;
        for (let i = 0; i < boxes.length; i++) {
          box = boxes[i];
          if (box.id === curBox.id) {
            if (direction === "right") {
              if (i + 1 < boxes.length) {
                self.setCurrentObject(boxes[i + 1]);
              } else {
                self.setCurrentObject(boxes[0]);
              }
            } else {
              if (i === 0) {
                self.setCurrentObject(boxes[boxes.length - 1]);
              } else {
                self.setCurrentObject(boxes[i - 1]);
              }
            }
          }
        }
        self.toggleUnselectedVisibility(false);
        canvas.renderAll();
      } catch (error) {
        console.log("Error:", error);
      }
    },

    setCurrentObject: function(box) {
      try {
        box.visible = true;
        box.selectable = true;
        canvas.setActiveObject(box);
        canvas.renderAll();
      } catch (error) {
        console.log("Error:", error);
      }
    },

    // deleteObject: function() {
    //   try {
    //     this.isZoomToolOpen = false;
    //     this.isShowPropToolOpen = false;
    //     this.isShowHideToolOpen = false;
    //     this.isFillToolOpen = false;
    //     this.isRectangleToolOpen = false;
    //     let obj = canvas.getActiveObject();
    //     this.extractDelAnnosId.push(obj.annoId);
    //     this.removeActiveToolEffect("annotation-tool");
    //     if (obj !== undefined && obj !== null) {
    //       if (obj._objects instanceof Array) {
    //         if (this.polygonMode) {
    //           this.exitPolygonMode();
    //           this.setPolygonMode();
    //         }
    //         if (this.lineMode) {
    //           this.exitLineMode();
    //           this.setLineMode();
    //         }
    //         if (this.isDotMode) {
    //           this.exitDotMode();
    //           this.setDotMode();
    //         }
    //         if (obj._objects.length > 0) {
    //           for (let i in obj._objects) {
    //             canvas.remove(obj._objects[i]);
    //           }
    //         }
    //       } else if (this.polygonMode) {
    //         this.deletePolygonClick(obj);
    //         return;
    //       } else if (this.isDotMode) {
    //         this.deleteDotClick(obj);
    //         return;
    //       } else if (this.lineMode) {
    //         this.deleteLineClick(obj);
    //         return;
    //       } else {
    //         canvas.remove(obj);
    //       }
    //       canvas.renderAll();
    //       this.setMode();
    //     }
    //   } catch (error) {
    //     console.log("Error:", error);
    //   }
    // },

    setDefaultObject: function() {
      try {
        let box;
        if (canvas !== undefined) {
          let boxes = canvas.getObjects();
          this.sortBoxesByProp(boxes, "left");
          for (let i in boxes) {
            if (this.isLabelObject(boxes[i])) {
              canvas.setActiveObject(boxes[i]);
              canvas.renderAll();
              return boxes[i];
            }
          }
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },

    sortBoxesByProp: function(boxes, prop) {
      try {
        boxes.sort(function(a, b) {
          return a[prop] - b[prop];
        });
      } catch (error) {
        console.log("Error:", error);
      }
    },

    getBoxById: function(boxes, id) {
      try {
        for (let box of boxes) {
          if (box.annoId === id) {
            return box;
          }
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },

    setCornerSize: function(size) {
      try {
        let self = this;
        canvas.forEachObject(function(o) {
          if (self.isLabelObject(o)) {
            o.set({ cornerSize: parseFloat(size) });
          }
        });
        canvas.renderAll();
      } catch (error) {
        console.log("Error:", error);
      }
    },

    setCursors: function() {
      try {
        if (this.extremeClickMode || this.polygonMode || this.drawMode) {
          canvas.defaultCursor = "pointer";
          canvas.hoverCursor = "pointer";
        } else if (this.zoomMode) {
          canvas.defaultCursor = "zoom-in";
          canvas.hoverCursor = "zoom-in";
        } else {
          canvas.defaultCursor = "default";
          canvas.hoverCursor = "move";
        }
        canvas.renderAll();
      } catch (error) {
        console.log("Error:", error);
      }
    },
    setTogglePos: function(newZoom) {
      this.zoomFactor = newZoom;
    },
    setZoomMode: function(x, y) {
      try {
        this.insatViewDisplay = false;
        //this.removePolyBullet();
        //if (x !=0, y!=0){
        //let annos = this.annotationJson;
        //for (var i=0; i<annos.length; i++) {
        //document.getElementById(i).style.visibility = "hidden";
        //}
        //}
        var canvasCenter = new fabric.Point(x, y);
        let self = this;
        this.showDialogOnZoom = true;
        try {
          document.getElementById("scrollDiv").style.visibility = "hidden";
        } catch (error) {}
        let currZoom = canvas.getZoom();
        var newZoom = getNextZoomInFactor(currZoom);
        this.latestZoomValue = Math.round(newZoom * 100);
        setTimeout(() => {
          this.showDialogOnZoom = false;
        }, 1000);

        let cWidth = Math.floor(this.canvasWidth * newZoom);
        let cHeight = Math.floor(this.canvasHeight * newZoom);
        canvas.setDimensions({
          height: cHeight,
          width: cWidth,
        });
        self.width = cWidth;
        self.height = cHeight;
        this.setTogglePos(newZoom);
        canvas.zoomToPoint(canvasCenter, newZoom);
      } catch (error) {
        console.log("Error:", error);
      }
    },

    exitZoomMode: function() {
      try {
        this.zoomMode = false;
        this.setCursors();
        this.exitGrabMode();
      } catch (error) {
        console.log("Error:", error);
      }
    },

    scalePoints: function(delta) {
      try {
        this.clickRadius = Math.min(Math.max(this.clickRadius * delta, 1), 10);
        this.cornerSize = Math.min(Math.max(this.cornerSize * delta, 1), 10);
        this.extremeClickRadius = Math.min(
          Math.max(this.extremeClickRadius * delta, 1),
          10
        );
        this.polyClickRadius = Math.min(
          Math.max(this.polyClickRadius * delta, 1),
          10
        );
        let self = this;
        canvas.forEachObject(function(o) {
          if (self.isLabelObject(o)) {
            if (o.labelType === POLY_CLICK_LABEL) {
              o.radius = self.polyClickRadius;
            } else if (o.labelType === EC_LABEL) {
              o.radius = self.extremeClickRadius;
            }
          }
        });
        canvas.renderAll();
      } catch (error) {
        console.log("Error:", error);
      }
    },
    zoomOut: function(x, y) {
      try {
        var canvasCenter = new fabric.Point(x, y);
        let self = this;
        this.showDialogOnZoom = true;
        try {
          document.getElementById("scrollDiv").style.visibility = "hidden";
        } catch (error) {}
        let currZoom = canvas.getZoom();
        let newZoom = getNextZoomOutFactor(currZoom);
        this.latestZoomValue = Math.round(newZoom * 100);
        setTimeout(() => {
          this.showDialogOnZoom = false;
        }, 1000);
        let cWidth = Math.floor(this.canvasWidth * newZoom);
        let cHeight = Math.floor(this.canvasHeight * newZoom);
        canvas.setDimensions({
          height: cHeight,
          width: cWidth,
        });
        self.width = cWidth;
        self.height = cHeight;
        this.setTogglePos(newZoom);
        canvas.zoomToPoint(canvasCenter, newZoom);
        canvas.renderAll();
      } catch (error) {
        console.log("Error:", error);
      }
    },
    uiresetZoom: function() {
      // added this for reset zoom
      document.getElementById("scrollDiv").style.visibility = "visible";
      this.resetInsatView();
      this.initializeCanvas(this.imageId);
      this.loadAllAnnotations();
    },
    resetZoom: function() {
      try {
        this.latestZoomValue = 100;
        this.isZoomToolOpen = false;
        this.zoomFactor = 1;
        var scrolldiv = document.getElementById("scrollDiv");
        if (scrolldiv) {
          scrolldiv.style.display = "block";
        }
        var canvasCenter = new fabric.Point(0, 0);
        let self = this;
        canvas.setDimensions({
          height: this.canvasHeight,
          width: this.canvasWidth,
        });
        self.width = canvas.getWidth();
        self.height = canvas.getHeight();
        this.setTogglePos(1);
        canvas.zoomToPoint(canvasCenter, 1);
        //this.initializeCanvas(this.imageId);
        // this.loadAllAnnotations();
        canvas.renderAll();
      } catch (error) {
        console.log("Error:", error);
      }
    },
    zoomToClick: function(e) {
      try {
        let pointer = canvas.getPointer(e.e);
        let cursor, delta;
        if (e.e.shiftKey) {
          cursor = "zoom-out";
          delta = 0.95;
        } else {
          cursor = "zoom-in";
          delta = 1.1;
        }
        this.zoomFactor *= delta;
        canvas.zoomToPoint(
          new fabric.Point(e.e.offsetX, e.e.offsetY),
          this.zoomFactor
        );
      } catch (error) {
        console.log("Error:", error);
      }
    },

    zoomToPoint: function(e) {
      try {
        let pointer = canvas.getPointer(e.e);
        let zoomIn = e.e.wheelDelta < 0;
        let curZoom = this.zoomFactor;
        let cursor, delta;
        if (zoomIn) {
          cursor = "zoom-in";
          delta = 1.1;
          this.scalePoints(0.95);
        } else {
          cursor = "zoom-out";
          delta = 0.95;
          this.scalePoints(1.1);
        }
        this.zoomFactor *= delta;
        canvas.defaultCursor = cursor;
        canvas.hoverCursor = cursor;
        canvas.zoomToPoint(
          new fabric.Point(e.e.offsetX, e.e.offsetY),
          this.zoomFactor
        );
        this.resetCursors();
        let obj = e.target;
        if (
          obj !== undefined &&
          obj !== null &&
          this.polygonClicks.length > 0 &&
          obj === this.polygonClicks[0]
        ) {
          obj.set({
            stroke: "green",
            fill: "green",
          });
          canvas.renderAll();
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },

    setDrawMode: function() {
      try {
        if (this.isTagOpen === true) {
          this.showObjectClassMenu = true;
        } else {
          this.incomplete_anno = true;
          this.isRectangleToolOpen = false;
          this.deselectObject();
          this.drawMode = true;
          let self = this;
          this.exitGrabMode();
          this.exitZoomMode();
          this.resetExtremeClicks();
          this.exitPolygonMode();
          this.exitLineMode();
          this.exitDotMode();
          this.exitFreeDrawMode();
          this.exitFreeTextMode();
          this.exitFloodFillMode();
          this.removeActiveToolEffect("annotation-tool");
          this.addActiveToolEffect("rectangle-tool");
          activeAnnoMode = "rectangle-tool";
          canvas.forEachObject(function(o) {
            if (self.isLabelObject(o)) {
              o.selectable = false;
            }
          }).selection = false;
          canvas.renderAll();
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },

    setDrawRatioMode: function() {
      try {
        if (this.isTagOpen === true) {
          this.showObjectClassMenu = true;
        } else {
          drawRect = null;
          this.isRectangleToolOpen = false;
          this.deselectObject();
          this.drawRatioMode = true;
          let self = this;
          this.drawMode = false;
          this.exitDrawMode();
          this.exitGrabMode();
          this.exitZoomMode();
          this.resetExtremeClicks();
          this.exitPolygonMode();
          this.exitLineMode();
          this.exitDotMode();
          this.exitFreeTextMode();
          this.exitFreeDrawMode();
          this.exitFloodFillMode();
          this.removeActiveToolEffect("annotation-tool");
          this.addActiveToolEffect("cube-tool");
          activeAnnoMode = "cube-tool";
          canvas.forEachObject(function(o) {
            if (self.isLabelObject(o)) {
              o.selectable = false;
            }
          }).selection = false;
          canvas.renderAll();
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },

    exitDrawMode: function() {
      try {
        // this.deselectObject();
        this.drawMode = false;
        // this.boxsize = null;
        this.showBoxSize = false;
        canvas.remove(this.crossHairVLine);
        canvas.remove(this.crossHairHLine);
        canvas.remove(this.boxsize);
      } catch (error) {
        console.log("Error:", error);
      }
    },

    exitFreeTextMode: function() {
      try {
        this.freeTextMode = false;
      } catch (error) {
        console.log("Error:", error);
      }
    },

    exitDrawRatioMode: function(e) {
      try {
        // this.deselectObject();
        this.drawRatioMode = false;
        this.drawRatioLineMode = false;
        // this.boxsize = null;
        this.showBoxSize = false;
      } catch (error) {
        console.log("Error:", error);
      }
    },

    setMode: function() {
      try {
        switch (activeAnnoMode) {
          case "click-box-tool":
            this.setExtremeClickMode();
            break;
          case "rectangle-tool":
            this.setDrawMode();
            break;
          case "cube-tool":
            this.setDrawRatioMode();
            break;
          case "polygon-tool":
            this.setPolygonMode();
            break;
          case "polyline-tool":
            this.setLineMode();
            break;
          case "point-tool":
            this.setDotMode();
            break;
          case "free-hand-tool":
            this.freeHand();
            break;
          case "flood-fill-tool":
            this.floodFill();
            break;
          case "free-text-tool":
            this.freeText();
            break;
          default:
            this.exitZoomMode();
            this.exitDrawMode();
            this.resetExtremeClicks();
            this.exitPolygonMode();
            this.exitLineMode();
            this.exitFreeTextMode();
            this.exitDotMode();
            this.exitFreeDrawMode();
            this.exitFloodFillMode();
            this.exitDrawRatioMode();
        }
        let self = this;
        this.isZoomToolOpen = false;
        this.isShowPropToolOpen = false;
        this.isShowHideToolOpen = false;
        this.isFillToolOpen = false;
        this.isRectangleToolOpen = false;
        canvas.forEachObject(function(o) {
          if (self.isLabelObject(o)) {
            o.set({ selectable: true }).setCoords();
          }
        });
        let obj = canvas.getActiveObject();
        if (obj === undefined || obj === null) {
          this.setDefaultObject();
        }
        canvas.defaultCursor = "default";
        canvas.hoverCursor = "move";
        canvas.renderAll();
      } catch (error) {
        console.log("Error:", error);
      }
    },

    setExtremeClickMode: function() {
      try {
        if (this.isTagOpen === true) {
          this.showObjectClassMenu = true;
        } else {
          this.incomplete_anno = true;
          this.isRectangleToolOpen = false;
          this.deselectObject();
          this.extremeClickMode = true;
          this.extremeClicks = [];
          let self = this;
          this.drawMode = false;
          this.exitZoomMode();
          this.exitFreeTextMode();
          this.exitGrabMode();
          this.exitDrawMode();
          this.exitDrawRatioMode();
          this.exitPolygonMode();
          this.exitLineMode();
          this.exitDotMode();
          this.exitFreeDrawMode();
          this.exitFloodFillMode();
          this.removeActiveToolEffect("annotation-tool");
          this.addActiveToolEffect("click-box-tool");
          activeAnnoMode = "click-box-tool";
          canvas.forEachObject(function(o) {
            if (self.isLabelObject(o)) {
              o.selectable = false;
            }
          }).selection = false;
          canvas.defaultCursor = "pointer";
          canvas.hoverCursor = "pointer";
          canvas.renderAll();
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },

    setPolygonMode: function() {
      try {
        if (this.isTagOpen === true) {
          this.showObjectClassMenu = true;
        } else {
          this.incomplete_anno = true;
          this.isRectangleToolOpen = false;
          this.deselectObject();
          this.polygonMode = true;
          this.polygonClicks = [];
          let self = this;
          this.exitZoomMode();
          this.exitFreeTextMode();
          this.exitGrabMode();
          this.exitDrawMode();
          this.exitDrawRatioMode();
          this.exitDotMode();
          this.exitLineMode();
          this.exitFreeDrawMode();
          this.resetExtremeClicks();
          this.exitFloodFillMode();
          this.removeActiveToolEffect("annotation-tool");
          this.addActiveToolEffect("polygon-tool");
          activeAnnoMode = "polygon-tool";
          canvas.forEachObject(function(o) {
            if (self.isLabelObject(o)) {
              o.selectable = false;
            }
          }).selection = false;
          canvas.renderAll();
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },
    setLineMode: function() {
      try {
        if (this.isTagOpen === true) {
          this.showObjectClassMenu = true;
        } else {
          this.incomplete_anno = true;
          this.isRectangleToolOpen = false;
          this.deselectObject();
          this.lineMode = true;
          this.lineClicks = [];
          let self = this;
          this.exitZoomMode();
          this.exitGrabMode();
          this.exitDrawMode();
          this.exitDrawRatioMode();
          this.exitPolygonMode();
          this.exitFreeTextMode();
          this.exitDotMode();
          this.exitFreeDrawMode();
          this.resetExtremeClicks();
          this.exitFloodFillMode();
          this.removeActiveToolEffect("annotation-tool");
          this.addActiveToolEffect("polyline-tool");
          activeAnnoMode = "polyline-tool";
          canvas.forEachObject(function(o) {
            if (self.isLabelObject(o)) {
              o.selectable = false;
            }
          }).selection = false;
          canvas.renderAll();
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },
    setDotMode: function() {
      try {
        if (this.isTagOpen === true) {
          this.showObjectClassMenu = true;
        } else {
          this.incomplete_anno = true;
          this.isRectangleToolOpen = false;
          this.deselectObject();
          this.isDotMode = true;
          this.isDotModeLabel = true;
          let self = this;
          this.DotClicks = "";
          this.exitZoomMode();
          this.exitGrabMode();
          this.exitDrawMode();
          this.exitDrawRatioMode();
          this.exitPolygonMode();
          this.exitLineMode();
          this.exitFreeDrawMode();
          this.resetExtremeClicks();
          this.exitFreeTextMode();
          this.exitFloodFillMode();
          this.removeActiveToolEffect("annotation-tool");
          this.addActiveToolEffect("point-tool");
          activeAnnoMode = "point-tool";
          canvas.forEachObject(function(o) {
            if (self.isLabelObject(o)) {
              o.selectable = false;
            }
          }).selection = false;
          canvas.renderAll();
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },
    setGrabMode: function(e) {
      try {
        this.grabMode = true;
        canvas.defaultCursor = "move";
        canvas.renderAll();
      } catch (error) {
        console.log("Error:", error);
      }
    },

    exitGrabMode: function() {
      try {
        this.grabMode = false;
        this.setCursors();
      } catch (error) {
        console.log("Error:", error);
      }
    },

    toggleUnselectedVisibility: function(updateToggle) {
      try {
        if (updateToggle !== undefined && updateToggle) {
          this.hideUnselected = !this.hideUnselected;
        }
        let curBox = canvas.getActiveObject();
        if (!this.exists(curBox)) {
          curBox = this.setDefaultObject();
        }
        let allBoxes = canvas.getObjects();
        for (let box of allBoxes) {
          if (box.id !== curBox.id) {
            box.visible = !this.hideUnselected;
          }
        }
        canvas.renderAll();
      } catch (error) {
        console.log("Error:", error);
      }
    },
    getFrameList: function() {
      try {
        if (this.duplicateObj == false) {
          this.isShowPropToolOpen = false;
          this.isRectangleToolOpen = false;
          this.$apollo
            .mutate({
              mutation: ALL_IMAGE_DETAIL_MUTATION,
              variables: {
                videoid: this.videoName,
              },
            })
            .then((data) => {
              this.isQueryError = false;
              this.allImages = data.data.allImageDetail;
              this.allImagesList = [];
              let allJsonsList = [];
              this.allJsons = {};
              let i = 0;
              let index = 0;
              for (let opt of this.allImages.jsons) {
                allJsonsList.push(opt);
              }
              for (let opt of this.allImages.images) {
                this.allImagesList[i] = opt;
                i++;
                this.allJsons[opt] = allJsonsList.includes(
                  opt.replace(".jpg", "").replace(".png", "")
                );
              }
            })
            .catch((error) => {
              this.isQueryError = true;
              this.queryErrorResult = /:(.+)/.exec(error.message)[1];
            });
        } else {
          this.showDuplicateDialog = true;
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },
    getAnnotationList: function(imageId) {
      try {
        this.isZoomToolOpen = false;
        this.isShowPropToolOpen = false;
        this.isShowHideToolOpen = false;
        this.isFillToolOpen = false;
        this.isRectangleToolOpen = false;
        this.sortedLabelList = [];

        for (var i = 0; i < this.annotationJson.length; i++) {
          if (
            this.annotationJson[i].bbox != null ||
            this.annotationJson[i].polygon != null
          ) {
            if (this.classObjNames.includes(this.annotationJson[i].label)) {
              this.sortedLabelList.push(this.annotationJson[i]);
            }
            if (this.annotationJson[i].imageTag !== null) {
              this.sortedLabelList.push(this.annotationJson[i]);
            }
          }
        }
        if (this.id_img != imageId) {
          for (var i = 0; i < this.sortedLabelList.length; i++) {
            for (var j = 0; j < this.classObj.length; j++) {
              if (
                this.sortedLabelList[i].bbox &&
                this.sortedLabelList[i].bbox.parameters.length !=
                  this.classObj[j].param.length &&
                this.sortedLabelList[i].label == this.classObj[j].name
              ) {
                this.settingError = true;
              } else if (
                this.sortedLabelList[i].polygon &&
                this.sortedLabelList[i].polygon.parameters.length !=
                  this.classObj[j].param.length &&
                this.sortedLabelList[i].label == this.classObj[j].name
              ) {
                this.settingError = true;
              }
            }
          }
        }

        this.id_img = imageId;
        let arr = [];
        //this.setAllLabelFlag(this.sortedLabelList, this.id_img)
        for (let i = 0; i < this.sortedLabelList.length; i++) {
          this.parameterLabel1[i] = [0];
          if (this.sortedLabelList) {
            var classValue = this.classObj
              .map(function(o) {
                return o.name.toLowerCase();
              })
              .indexOf(this.sortedLabelList[i].label.toLowerCase());
            if (
              this.sortedLabelList[i].bbox != null &&
              this.sortedLabelList[i].bbox.parameters
            ) {
              if (classValue !== -1) {
                for (let prm of this.classObj[classValue].param) {
                  var paramValue = this.sortedLabelList[i].bbox.parameters
                    .map(function(o) {
                      return o.nam.toLowerCase();
                    })
                    .indexOf(prm.name.toLowerCase());
                  if (paramValue !== -1) {
                    arr.push(
                      this.sortedLabelList[i].bbox.parameters[paramValue].val
                    );
                  } else {
                    arr.push(null);
                  }
                }
              }
              this.parameterLabel1[i] = arr;
              arr = [];
            }
            if (
              this.sortedLabelList[i].polygon != null &&
              this.sortedLabelList[i].polygon.parameters
            ) {
              if (classValue !== -1) {
                for (let prm of this.classObj[classValue].param) {
                  var paramValue = this.sortedLabelList[i].polygon.parameters
                    .map(function(o) {
                      return o.nam.toLowerCase();
                    })
                    .indexOf(prm.name.toLowerCase());
                  if (paramValue !== -1) {
                    arr.push(
                      this.sortedLabelList[i].polygon.parameters[paramValue].val
                    );
                  } else {
                    arr.push(null);
                  }
                }
              }
              this.parameterLabel1[i] = arr;
              arr = [];
            }
          }
          /*        if (this.allLabelFlag.length < this.sortedLabelList.length) {
                        if (this.sortedLabelList[i].bbox) {
                            this.allLabelFlag.push({
                                "value": false,
                                "id": this.sortedLabelList[i].bbox.annoId,
                            });
                            this.isEditableLable[i] = 0;
                        }
                        if (this.sortedLabelList[i].polygon) {
                            this.allLabelFlag.push({
                                "value": false,
                                "id": this.sortedLabelList[i].polygon.annoId,
                            });
                            this.isEditableLable[i] = 0;
                        }
                        if (this.sortedLabelList[i].imageTag) {
                            this.allLabelFlag.push({
                                "value": false,
                                "id": this.sortedLabelList[i].imageTag.annoId,
                            });
                        }
                    }
                    else if (this.allLabelFlag[i].value == true) {
                        if (this.sortedLabelList[i].bbox) {
                            this.allLabelFlag[i].value = true;
                            this.allLabelFlag[i].id = this.sortedLabelList[i].bbox.annoId;
                            this.isEditableLable[i] = 1;
                        }
                        if (this.sortedLabelList[i].polygon) {
                            this.allLabelFlag[i].value = true;
                            this.allLabelFlag[i].id = this.sortedLabelList[i].polygon.annoId;
                            this.isEditableLable[i] = 1;
                        }
                    } else {
                        if (this.sortedLabelList[i].bbox) {
                            //this.allLabelFlag[i].value = false;
                            //this.allLabelFlag[i].id = this.sortedLabelList[i].bbox.annoId;
                            //this.isEditableLable[i] = 0;
                        }
                        if (this.sortedLabelList[i].polygon) {
                            //this.allLabelFlag[i].value = false;
                            //this.allLabelFlag[i].id = this.sortedLabelList[i].polygon.annoId;
                            //this.isEditableLable[i] = 0;
                        }
                    }*/
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },
    setAllLabelFlag: function(sortedLabelList, id_img) {
      this.allLabelFlag_local = [];
      if (id_img != 0) {
        for (let i = 0; i < this.allLabelFlag.length; i++) {
          if (this.allLabelFlag[i].value == true) {
            this.allLabelFlag_local.push({
              value: this.allLabelFlag[i].value,
              id: this.allLabelFlag[i].id,
            });
          }
        }
        this.allLabelFlag = [];
        for (let i = 0; i < this.allLabelFlag_local.length; i++) {
          this.allLabelFlag.push({
            value: this.allLabelFlag_local[i].value,
            id: this.allLabelFlag_local[i].id,
          });
        }
      }
    },
    makeParameter: function(parameters) {
      try {
        let param = [];
        for (let prm of parameters) {
          if (parameters.length) {
            param.push({
              nam: prm.nam,
              val: prm.val,
            });
          }
        }
        return param;
      } catch (error) {
        console.log("Error:", error);
      }
    },
    editablelable: function(i) {
      this.isEditableLable.splice(i, 1, !this.isEditableLable[i]);
    },
    fetchLable: function(i, label, id) {
      try {
        let allBoxes = canvas.getObjects();
        let box = this.getBoxById(allBoxes, id);
        box.label = label;
        canvas.renderAll();
      } catch (error) {
        console.log("Error:", error);
      }
    },
    fetchParam: function(i, label, track, name, parameter, id, index) {
      try {
        let allBoxes = canvas.getObjects();
        let box = this.getBoxById(allBoxes, id);
        let parametersN = box.parameters;
        let getIndex = parametersN
          .map(function(o) {
            return o.nam.toLowerCase();
          })
          .indexOf(name.toLowerCase());
        if (getIndex !== -1) {
          if (parameter != parametersN[getIndex].val) {
            if (this.parameterLabel1[i][index] == parameter && track) {
              this.checkFlag = true;
            }
            if (parametersN[getIndex] && parametersN[getIndex].nam == name) {
              parametersN[getIndex].val = parameter;
            }
            this.isAnychange = true;
            box.parameters = parametersN;
            parametersN = [];
            canvas.renderAll();
          }
        } else {
          let parametersAdd = [];
          let k = 0;
          let classIndex = this.classObj
            .map(function(o) {
              return o.name.toLowerCase();
            })
            .indexOf(label.toLowerCase());
          for (var j = 0; j < this.classObj[classIndex].param.length; j++) {
            if (this.classObj[classIndex].param[j].name !== name) {
              let paramIndex = parametersN
                .map(function(o) {
                  return o.nam.toLowerCase();
                })
                .indexOf(this.classObj[classIndex].param[j].name.toLowerCase());
              if (paramIndex == -1) {
                parametersAdd.push({
                  nam: this.classObj[classIndex].param[j].name,
                  val: null,
                });
              } else {
                parametersAdd.push({
                  nam: parametersN[k].nam,
                  val: parametersN[k].val,
                });
                k = k + 1;
              }
            }
            if (this.classObj[classIndex].param[j].name == name) {
              parametersAdd.push({
                nam: name,
                val: parameter,
              });
            }
          }
          this.isAnychange = true;
          box.parameters = parametersAdd;
          parametersN = [];
          parametersAdd = [];
          canvas.renderAll();
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },
    annoToggle(i, track, annoId) {
      try {
        for (var j = 0; j < this.sortedLabelList.length; j++) {
          if (this.sortedLabelList[j].bbox != null) {
            if (this.sortedLabelList[j].bbox.annoId == annoId) {
              this.sortedLabelList[j].bbox.track = track;
            }
          }
          if (this.sortedLabelList[j].polygon != null) {
            if (this.sortedLabelList[j].polygon.annoId == annoId) {
              this.sortedLabelList[j].polygon.track = track;
            }
          }
        }
        for (var j = 0; j < this.sortedLabelList.length; j++) {
          if (this.sortedLabelList[j].bbox != null) {
            if (this.sortedLabelList[j].bbox.annoId == annoId) {
              this.copyAnnotations(j, this.sortedLabelList[j].bbox.track);
            }
          } else if (this.sortedLabelList[j].polygon != null) {
            if (this.sortedLabelList[j].polygon.annoId == annoId) {
              this.copyAnnotations(j, this.sortedLabelList[j].polygon.track);
            }
          }
        }
        this.setLockUnlockAllValue();
        this.isAnychange = true;
      } catch (error) {
        console.log("Error:", error);
      }
    },

    resetCopyAnno: function() {
      try {
        this.copyAnnotationList = [];
        for (let i in this.allLabelFlag) {
          this.allLabelFlag.splice(i, 1, {
            value: false,
            id: this.allLabelFlag[i].id,
          });
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },

    setLockUnlockAllValue: function() {
      try {
        if (this.sortedLabelList !== null) {
          var totalLength = this.sortedLabelList.filter(function(e) {
            return (
              (e.bbox && e.bbox.track === true) ||
              (e.polygon && e.polygon.track === true)
            );
          }).length;
          if (
            this.sortedLabelList.length == totalLength &&
            this.sortedLabelList.length !== 0
          ) {
            this.lockUnlockFlag = true;
          } else {
            this.lockUnlockFlag = false;
          }
        } else {
          this.lockUnlockFlag = false;
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },

    selectObjects: function() {
      try {
        if (this.isAnychange == false) {
          if (this.lockUnlockFlag == "true" || this.lockUnlockFlag == true) {
            for (var j = 0; j < this.sortedLabelList.length; j++) {
              if (this.sortedLabelList[j].bbox !== null) {
                this.sortedLabelList[j].bbox.track = true;
              }
              if (this.sortedLabelList[j].polygon !== null) {
                this.sortedLabelList[j].polygon.track = true;
              }
              this.copyAnnotationList.push(this.sortedLabelList[j]);
            }
            this.isAnychange = true;
          } else {
            for (var j = 0; j < this.sortedLabelList.length; j++) {
              if (this.sortedLabelList[j].bbox !== null) {
                this.sortedLabelList[j].bbox.track = false;
              }
              if (this.sortedLabelList[j].polygon !== null) {
                this.sortedLabelList[j].polygon.track = false;
              }
            }
            this.copyAnnotationList = [];
            this.isAnychange = true;
          }
        } else {
          this.lockUnlockFlag = false;
          this.showDialog = true;
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },

    highlightSelected: function(item, index) {
      try {
        let allBoxes = canvas.getObjects();
        let box;
        for (let resetbox of allBoxes) {
          resetbox.set({ opacity: this.opacity }).setCoords();
          resetbox.set({ stroke: this.stroke }).setCoords();
        }
        box = this.getBoxById(allBoxes, item.annoId);
        box.set({ opacity: 0.8 }).setCoords();
        box.set({ stroke: "#FF0000" }).setCoords();
        canvas.renderAll();
      } catch (error) {
        console.log("Error:", error);
      }
    },

    highlightSelectedByList: function(item, index) {
      try {
        let allBoxes = canvas.getObjects();
        let box;
        this.allLabelList = this.annotationJson;
        this.highlightanno = item.id;
        if (item.bbox) {
          box = this.getBoxById(allBoxes, item.bbox.annoId);
          window.scrollTo(
            item.bbox.xmin - (window.innerHeight >> 1),
            item.bbox.ymin - (window.innerHeight >> 1)
          );
          this.highlightBbClick(box);
        } else if (item.polygon) {
          box = this.getBoxById(allBoxes, item.polygon.annoId);
          window.scrollTo(
            item.polygon.points[0].x - (window.innerHeight >> 1),
            item.polygon.points[0].y - (window.innerHeight >> 1)
          );
          this.highlightPolygonClick(item.polygon, 1);
        }
        box.set({ opacity: 0.5 }).setCoords();
        box.set({ stroke: "#FF0000" }).setCoords();
        canvas.renderAll();
      } catch (error) {
        console.log("Error:", error);
      }
    },
    highlightSelectedByAnno: function(value, call) {
      let annos = this.annotationJson;
      for (var i = 0; i < annos.length; i++) {
        if (value.type == "rect") {
          if (annos[i].bbox != null) {
            if (
              (annos[i].bbox.xmin == value.left &&
                annos[i].bbox.ymin == value.top) ||
              annos[i].bbox.annoId == value.annoId
            ) {
              this.highlightanno = annos[i].bbox.annoId;
              if (call) {
                this.setAnnoError(annos[i]);
              }
            }
          }
        }
        if (value.type == "polygon" || value.type == "polyline") {
          if (annos[i].polygon != null) {
            if (
              annos[i].polygon.points[0].x == value.points[0].x &&
              annos[i].polygon.points[0].y == value.points[0].y
            ) {
              this.highlightanno = annos[i].polygon.annoId;
              if (call) {
                this.setAnnoError(annos[i]);
              }
            }
          }
        }
      }
    },
    floodFill: function() {
      if (this.isTagOpen === true) {
        this.showObjectClassMenu = true;
      } else {
        if (this.duplicateObj == false) {
          this.isFloodFillmode = true;
          this.drawMode = false;
          this.lineMode = false;
          this.polygonMode = false;
          this.isDotMode = false;
          this.extremeClickMode = false;
          this.freehandMode = false;
          this.isFillToolOpen = false;
          this.isZoomToolOpen = false;
          this.isShowPropToolOpen = false;
          this.isShowHideToolOpen = false;
          this.isFillToolOpen = false;
          this.isRectangleToolOpen = false;
          this.exitDrawMode();
          this.exitDrawRatioMode();
        } else {
          this.showDuplicateDialog = true;
        }
        this.removeActiveToolEffect("annotation-tool");
        this.addActiveToolEffect("flood-fill-tool");
        activeAnnoMode = "flood-fill-tool";
      }
    },

    freeHand: function() {
      try {
        if (this.isTagOpen === true) {
          this.showObjectClassMenu = true;
        } else {
          this.deselectObject();
          this.isFreeHandmodeMouseDown = true;
          this.drawMode = false;
          this.lineMode = false;
          this.polygonMode = false;
          this.isDotMode = false;
          this.extremeClickMode = false;
          this.isRectangleToolOpen = false;
          this.isFloodFillmode = false;
          this.removeActiveToolEffect("annotation-tool");
          this.addActiveToolEffect("free-hand-tool");
          activeAnnoMode = "free-hand-tool";
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },
    doFreeDraw: function(e) {
      try {
        let coords = [];
        let pointer = canvas.getPointer(e.e);
        let clickPointX = pointer.x;
        let clickPointY = pointer.y;
        let coordinates = [origX, origY, clickPointX, clickPointY];
        let linecoords = [
          this.firstorigX,
          this.firstorigY,
          clickPointX,
          clickPointY,
        ];
        this.freeHandClicks.push({
          x: clickPointX,
          y: clickPointY,
        });
        this.freeDrawLine = new fabric.Line(coordinates, {
          opacity: 1,
          fill: "black",
          stroke: "black",
          ...defaultPolygonPty,
          points: coordinates,
        });
        if (this.freeDrawLineConnect != null) {
          canvas.remove(this.freeDrawLineConnect);
        }
        this.freeDrawLineConnect = new fabric.Line(linecoords, {
          ...Line,
          opacity: 1,
          fill: "black",
          stroke: "black",
          points: linecoords,
        });
        this.saveFreeHandClicks.push(this.freeDrawLine);
        origX = clickPointX;
        origY = clickPointY;
        this.freeDrawLine.selectable = false;
        this.freehandMode = false;
        canvas.add(this.freeDrawLine);
        canvas.add(this.freeDrawLineConnect);
      } catch (error) {
        console.log("Error:", error);
      }
    },
    setFreeHandMode: function() {
      try {
        this.deselectObject();
        this.freehandMode = true;
        let self = this;
        this.exitZoomMode();
        this.exitGrabMode();
        this.exitDrawMode();
        this.exitDrawRatioMode();
        this.exitPolygonMode();
        this.exitDotMode();
        this.exitLineMode();
        this.resetExtremeClicks();
        this.exitFloodFillMode();
        canvas.forEachObject(function(o) {
          if (self.isLabelObject(o)) {
            o.selectable = false;
          }
        }).selection = false;
        canvas.renderAll();
      } catch (error) {
        console.log("Error:", error);
      }
    },
    exitFreeDrawMode: function() {
      try {
        this.isTagOpen = false;
        for (var i = 0; i < this.saveFreeHandClicks.length; i++) {
          canvas.remove(this.saveFreeHandClicks[i]);
        }
        this.freehandMode = false;
        this.isFreeHandmodeMouseDown = false;
        canvas.remove(this.freeDrawLineConnect);
        this.freeHandClicks = [];
      } catch (error) {
        console.log("Error:", error);
      }
    },
    saveFreeDraw: function() {
      try {
        var text = this.getCurLabel();
        var objColor = this.getCurColor(text);
        let freeDraw = new fabric.Polygon(this.freeHandClicks, {
          id: this.getRandId(),
          annoId: this.getRandId(),
          label: text,
          selectable: false,
          fill: objColor,
          stroke: "black",
          opacity: 0.5,
          ...defaultPolygonPty,
          borderColor: "black",
          look: "freehand",
          points: this.makePointsFromCoords(this.freeHandClicks),
          coord: this.freeHandClicks,
        });
        freeDraw.selectable = false;
        this.freehandMode = false;
        this.setFreeHandMode();
        canvas.add(freeDraw);
        drawFreeDraw = freeDraw;
        canvas.renderAll();
        this.freeHandClicks = [];
      } catch (error) {
        console.log("Error:", error);
      }
    },
    finalSaveFreeDraw: function() {
      try {
        let saveFreeDraw = drawFreeDraw;
        saveFreeDraw.selectable = false;
        this.freehandMode = false;
        canvas.add(saveFreeDraw);
        canvas.setActiveObject(saveFreeDraw);
        canvas.renderAll();
        this.freeHand();
      } catch (error) {
        console.log("Error:", error);
      }
    },
    doFloodFill: function(e, tolerance) {
      let pointer = canvas.getPointer(e.e);
      let point = [];
      let coords = [];
      let n = 0;
      try {
        this.$apollo
          .mutate({
            mutation: IMG_PROC_PARAMETER_SEND,
            variables: {
              videoid: this.videoId,
              imageid: this.imageId,
              videoname: this.videoName,
              clickPointX: pointer.x,
              clickPointY: pointer.y,
              tolerance: this.tolerance,
            },
          })
          .then((data) => {
            try {
              this.isQueryError = false;
              var text = this.getCurLabel();
              var objColor = this.getCurColor(text);
              point = data.data.doFloodFill.points;
              n = point.length;
              for (let t = 0; t < n; t++) {
                coords.push({
                  x: point[t].x,
                  y: point[t].y,
                });
              }
              let polygon = new fabric.Polygon(coords, {
                id: this.getRandId(),
                annoId: this.getRandId(),
                label: text,
                fill: objColor,
                opacity: 0.5,
                stroke: "black",
                ...defaultPolygonPty,
                borderColor: "black",
                look: "floodFill",
                points: this.makePointsFromCoords(coords),
                coord: coords,
              });
              drawfloodfill = polygon;
              canvas.add(polygon);
              canvas.renderAll();
              return polygon;
            } catch (error) {
              console.log("Error:", error);
            }
            let polygon = new fabric.Polygon(coords, {
              id: this.getRandId(),
              annoId: this.getRandId(),
              label: text,
              fill: objColor,
              opacity: 0.5,
              stroke: "black",
              ...defaultPolygonPty,
              borderColor: "black",
              look: "polygon",
              points: this.makePointsFromCoords(coords),
              coord: coords,
            });
            drawfloodfill = polygon;
            canvas.add(polygon);
            canvas.renderAll();
            return polygon;
          })
          .catch((error) => {
            this.isQueryError = true;
            this.queryErrorResult = /:(.+)/.exec(error.message)[1];
          });
      } catch (error) {
        console.log("Error:", error);
      }
    },
    saveFloodFill: function() {
      try {
        drawfloodfill.set({
          score: 0,
        });
        drawfloodfill.selectable = false;
        var text = this.getCurLabel();
        drawfloodfill.set("label", text);
        canvas.add(drawfloodfill);
        drawfloodfill = null;
        canvas.renderAll();
      } catch (error) {
        console.log("Error:", error);
      }
    },
    exitFloodFillMode: function() {
      try {
        this.isTagOpen = false;
        this.isFloodFillmode = false;
        canvas.remove(drawfloodfill);
      } catch (error) {
        console.log("Error:", error);
      }
    },
    removeActiveToolEffect: function(toolType, selectTool) {
      let selectedToolType = document.getElementsByClassName(toolType);
      let selectedTool = document.getElementById(selectTool);

      if (toolType == "annotation-tool") {
        for (var i = 0; i < selectedToolType.length; i++) {
          selectedToolType[i].classList.remove("active-tool");
        }
      } else if (selectTool != "") {
        selectedTool.classList.remove("active-tool");
      }
    },
    addActiveToolEffect: function(selectTool) {
      let selectedTool = document.getElementById(selectTool);
      selectedTool.classList.add("active-tool");
    },
    loadCanvas: function() {
      try {
        this.fwdUserId = SettingService.getSelectedUserId();
        this.username = SettingService.getSelectedUserName();
        this.role = SettingService.getSelectedUserRole();
        this.projectId = SettingService.getSelectedProject();
        this.videoId = this.$route.query.videoid;
        this.videoName = this.$route.query.videoname;
        this.video_type = this.$route.query.video_type;
        this.isAnnotationListOpen = true;
        // this.radioSelectObj = null;
        this.imageId = this.$route.query.imageid;
        if (this.imageId == 0) this.initializeCanvas(0);
        else this.initializeCanvas(this.imageId);
      } catch (error) {
        console.log("Error:", error);
      }
    },
    getThemeMode: function() {
      this.isDarkMode = SettingService.getDarkMode();
    },

    blurSelection: function(left, top, width, height, blurredCanvas) {
      const image = fabric.Image.fromURL(blurredCanvas.toDataURL(), function(
        img
      ) {
        img.top = top;
        img.left = left;
        img.cropX = left;
        img.cropY = top;
        img.width = width; // Default
        img.height = height; // Default
        img.objectCaching = false;
        canvas.add(img);
        img.bringToFront();
        img.on("moving", function(options) {
          const newLeft = options.target.left;
          const newTop = options.target.top;
          const img = options.target;
          img.cropX = newLeft;
          img.cropY = newTop;
          img.width *= img.scaleX;
          img.height *= img.scaleY;
          img.scaleX = 1;
          img.scaleY = 1;
        });
        img.on("scaling", function(options) {
          const newLeft = options.target.left;
          const newTop = options.target.top;
          const img = options.target;
          img.cropX = newLeft;
          img.cropY = newTop;
          img.width *= img.scaleX;
          img.height *= img.scaleY;
          img.scaleX = 1;
          img.scaleY = 1;
        });
      });
      canvas.renderAll();
    },
    createImage: function() {
      this.isBlurActive = !this.isBlurActive;
      if (this.isBlurActive === true) {
        this.addActiveToolEffect("blur-tool");
        this.isBlurModeActive = true;
        let allObjects = canvas.getObjects();
        let dimensionsAll = [];
        let dimensions = {};

        let copiedCanvas = [];
        let blurredCanvas = [];
        let blurredImage = [];
        let n = allObjects.length;
        const filter = new fabric.Image.filters.Blur({
          blur: 0.2,
        });
        for (let i = 0; i < n; i++) {
          // let obj = this.getObjectById(allObjects[i].id);
          // canvas.remove(obj);
          copiedCanvas[i] = canvas.toCanvasElement();
          dimensions.left = allObjects[i].left;
          dimensions.top = allObjects[i].top;
          dimensions.width = allObjects[i].width;
          dimensions.height = allObjects[i].height;
          dimensionsAll.push([
            dimensions.left,
            dimensions.top,
            dimensions.width,
            dimensions.height,
          ]);

          blurredImage[i] = new fabric.Image(copiedCanvas[i]);

          blurredImage[i].filters.push(filter);
          blurredImage[i].applyFilters();

          blurredCanvas[i] = new fabric.Canvas(copiedCanvas[i]);

          blurredCanvas[i].add(blurredImage[i]);
          blurredCanvas[i].renderAll();

          this.blurSelection(
            dimensionsAll[i][0],
            dimensionsAll[i][1],
            dimensionsAll[i][2],
            dimensionsAll[i][3],
            blurredCanvas[i]
          );

          canvas.renderAll.bind(canvas);
        }

        canvas.renderAll();
        console.log("All Objects", allObjects[0].id);
      } else {
        this.isBlurModeActive = false;
        this.removeActiveToolEffect("annotation-tool", "blur-tool");
      }
    },
  },

  mounted: function() {
    this.disableBack();
    this.loadCanvas();
  },
  beforeMount() {
    this.getThemeMode();
  },
};
