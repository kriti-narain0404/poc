import { SAVE_SETTING_OBJ_DATA } from "../../../constants/graphql";
import { GET_SETTING_OBJ_DATA } from "../../../constants/graphql";
import { validationMixin } from "vuelidate";
import { required, maxLength, email } from "vuelidate/lib/validators";
import Appfooter from "../../../shared/Appfooter.vue";
import HomeHeader from "../../../shared/HomeHeader.vue";
import SettingService from "../../../services/SettingService.js";
import SettingsModel from "../../../model/SettingsModel.js";

var fromFile = 0;

export default {
  name: "Setting",
  components: {
    "home-header": HomeHeader,
    "app-footer": Appfooter,
  },
  props: ["project"],
  mixins: [validationMixin],
  validations: {
    folderPath: { required },
    height: { required },
    width: { required },
    annotationTip: { required },
    modelSelection: { required },
    radioValue: { required },
  },
  data() {
    return SettingsModel;
  },

  apollo: {
    getSettingObject: {
      query: GET_SETTING_OBJ_DATA,
      variables() {
        const userid = SettingService.getSelectedUserId();
        const projectId = SettingService.getSelectedProject();
        const video_id = -1;
        return {
          userid,
          projectId,
          fromFile,
          video_id,
        };
      },
      result({ data, loader, networkStatus }) {
        let settingData = [];
        if (data.getSettingObject != null) {
          settingData = JSON.parse(data.getSettingObject.settingObject);
        }
        if (settingData != null) {
          this.settingObj = [];
          this.allKeys = [];

          
          for (let obj of settingData) {
            if (settingData.length) {
              this.settingObj.push({
                id: obj.id,
                name: obj.name,
                selected: obj.selected,
                type: obj.type,
                color: obj.color,
                length: obj.length,
                parameters: obj.parameters,
              });
              this.category.push(obj.type); // show object category in the dropdown
            }
          }
        }
        this.radioValue = data.getSettingObject.predType;
        this.modelSelection = data.getSettingObject.modelType;
        this.folderPath = data.getSettingObject.folderPath;
        this.height = data.getSettingObject.minHeight;
        this.width = data.getSettingObject.minWidth;
        this.annotationTip = data.getSettingObject.annoTip;
        this.outputFormat = data.getSettingObject.outputFormat;
        this.FramesToInterpolate = data.getSettingObject.interpolate_data;
        this.setSettingData();
        this.initSelectAll();
      },
    },
  },
  computed: {
    pathErrors() {
      const errors = [];
      if (!this.$v.folderPath.$dirty) return errors;
      !this.$v.folderPath.required && errors.push("Path is required.");
      return errors;
    },
    heightErrors() {
      const errors = [];
      if (!this.$v.height.$dirty) return errors;
      !this.$v.height.required && errors.push("Height is required.");
      if (String(this.height).match(/^[0-9]+$/) == null) {
        this.errorFlag = true;
        return "Invalid height";
      } else {
        this.errorFlag = false;
      }
      return errors;
    },
    widthErrors() {
      const errors = [];
      if (!this.$v.width.$dirty) return errors;
      !this.$v.width.required && errors.push("Width is required.");
      if (String(this.width).match(/^[0-9]+$/) == null) {
        this.errorFlag = true;
        return "Invalid width";
      } else {
        this.errorFlag = false;
      }
      return errors;
    },
    annotationTipErrors() {
      const errors = [];
      if (!this.$v.annotationTip.$dirty) return errors;
      !this.$v.annotationTip.required &&
        errors.push("Annotation Tip is required");
      return errors;
    },
    modelSelectionErrors() {
      const errors = [];
      if (!this.$v.modelSelection.$dirty) return errors;
      !this.$v.modelSelection.required &&
        errors.push("Model Selection is required");
      return errors;
    },
    radioValueErrors() {
      const errors = [];
      if (!this.$v.radioValue.$dirty) return errors;
      !this.$v.radioValue.required && errors.push("Load Type is required");
      return errors;
    },
    classNameErrors() {
      const errors = [];
      if (!this.$v.className.$dirty) return errors;
      !this.$v.className.required && errors.push("Object Class is required");
      return errors;
    },
    objectTypeErrors() {
      const errors = [];
      if (!this.$v.objectType.$dirty) return errors;
      !this.$v.objectType.required &&
        errors.push("Object Category is required");
      return errors;
    },
  },

  watch: {
    objectType: function(val) {
      if (val == "Parameters" || val == "parameters") {
        this.showobjectLength = true;
      } else {
        this.showobjectLength = false;
      }
    },
  },

  methods: {
    getUserId() {
      this.userId = SettingService.getSelectedUserId();
      this.username = SettingService.getSelectedUserName();
      this.role = SettingService.getSelectedUserRole();
      this.projectId = SettingService.getSelectedProject();
    },
    disableBack: function() {
      history.pushState(null, null, location.href);
      window.onpopstate = function() {
        history.go(1);
      };
    },
    callInbox(link) {
      this.$router.push({ path: link });
    },
    callDashbord(link) {
      this.$router.push({ path: link });
    },
    callSetting(link) {
      this.$router.push({ path: link });
    },
    callUser(link) {
      this.$router.push({ path: link });
    },
    callEditor(link) {
      this.$router.push({ path: link });
    },
    setSettingData: function() {
      var self = this;
      try {
        self.finalSettingObj = {};

        this.settingObj.forEach(function(item) {
          if (!(item.type in self.finalSettingObj)) {
            self.finalSettingObj[item.type] = [];
          }
          self.finalSettingObj[item.type].push(item);
        });
        this.allKeys = Object.keys(self.finalSettingObj);
        console.log(this.allKeys);
      } catch (error) {
        console.log("Error:", error);
      }
    },
    getSubclassSelected() {
      var temp = 0;
      for (var i = 0; i < this.showParamList.length; i++) {
        if (this.showParamList[i].selected) {
          temp = temp + 1;
        }
      }
      if (temp === 0) {
        this.subclassSelectedFlag = true;
      } else {
        this.subclassSelectedFlag = false;
      }
    },
    saveSettingObj: function() {
      this.$v.$touch();
      try {
        if (this.errorFlag == false) {
          var div = document.createElement("div");
          var img = document.createElement("img");
          img.src = "static/loading.gif";
          img.style.cssText = "margin-top:20%;width:5%;height:10%;";
          div.style.cssText =
            "width: 100%;height: 100%;top: 0px;left: 0px;position: fixed;display: block;opacity: 0.7;background-color: #fff;z-index: 99;text-align: center";
          div.appendChild(img);
          document.body.appendChild(div);
          this.$apollo
            .mutate({
              mutation: SAVE_SETTING_OBJ_DATA,
              variables: {
                userid: this.userId,
                projectId: this.projectId,
                predType: this.radioValue,
                modelType: this.modelSelection,
                outputFormat: this.outputFormat,
                folderPath: this.folderPath,
                minHeight: this.height,
                minWidth: this.width,
                annoTip: this.annotationTip,
                settingObject: this.settingObj,
                class_added: this.class_added_dict_array,
                frames_to_interpolate: this.FramesToInterpolate,
              },
            })
            .then((data) => {
              div.style.display = "none";
              this.isQueryError = false;
              location.reload();
            })
            .catch((error) => {
              div.style.display = "none";
              this.isQueryError = true;
              this.queryErrorResult = /:(.+)/.exec(error.message)[1];
            });
        } else {
          this.errorMessageSubmit = true;
        }
      } catch (error) {
        div.style.display = "none";
        console.log("Error:", error);
      }
    },

    selectObjects(event) {
      let count = 0;
      for (let i in this.settingObj) {
        if (event.target.checked) {
          this.settingObj[i].selected = true;
          count++;
        } else {
          this.settingObj[i].selected = false;
          count--;
        }
      }
      this.selectedObjectCount = count;
    },

    selectParameters(event) {
      let count = 0;
      for (let i in this.settingObj) {
        for (let j in this.settingObj[i].parameters) {
          if (event.target.checked) {
            this.settingObj[i].parameters[j].selected = true;
            count++;
          } else {
            this.settingObj[i].parameters[j].selected = false;
            count--;
          }
        }
      }
      this.selectedParametersCount = count;
    },

    selectSettingClassData(e) {
      try {
        // e.selected = !e.selected;
        if (e.selected) {
          this.selectedObjectCount += 1;
        } else if (!e.selected) {
          this.selectedObjectCount -= 1;
        }
        this.selectUnselectObjectsAll();
      } catch (error) {
        console.log("Error:", error);
      }
    },

    selectSettingParamData(e) {
      try {
        // e.selected = !e.selected;
        if (e.selected) {
          this.selectedParametersCount += 1;
        } else if (!e.selected) {
          this.selectedParametersCount -= 1;
          this.openList = false;
        }
        this.selectUnselectParametersAll();
      } catch (error) {
        console.log("Error:", error);
      }
    },

    openSubParamList: function(data, name, classname) {
      try {
        this.openList = true;
        this.showParamList = data;
        this.currentParam = name;
        this.currentClass = classname;
      } catch (error) {
        console.log("Error:", error);
      }
    },

    addSubclass: function(data) {
      try {
        var subclass = {};
        this.isSubclassExist = false;

        var givenClassindex = this.settingObj
          .map(function(o) {
            return o.name.toLowerCase();
          })
          .indexOf(this.currentClass.toLowerCase());
        var givenParamindex = this.settingObj[givenClassindex].parameters
          .map(function(o) {
            return o.name.toLowerCase();
          })
          .indexOf(this.currentParam.toLowerCase());
        if (data !== "" && this.subclassNameError == false) {
          if (
            this.settingObj[givenClassindex].parameters[givenParamindex]
              .subClass == null ||
            this.settingObj[givenClassindex].parameters[givenParamindex]
              .subClass.length == 0
          ) {
            this.settingObj[givenClassindex].parameters[
              givenParamindex
            ].subClass = [];
            subclass = {
              id: 1,
              name: data,
              selected: true,
              type: "Subtype",
              length: 0,
              color: "#000000".replace(/0/g, function() {
                return (~~(Math.random() * 16)).toString(16);
              }),
            };
            this.settingObj[givenClassindex].parameters[
              givenParamindex
            ].subClass.push(subclass);
            this.showParamList = this.settingObj[givenClassindex].parameters[
              givenParamindex
            ].subClass;
          } else {
            var givenSubclassindex = this.settingObj[
              givenClassindex
            ].parameters[givenParamindex].subClass
              .map(function(o) {
                return o.name.toLowerCase();
              })
              .indexOf(data.toLowerCase());
            if (givenSubclassindex >= 0) {
              this.isSubclassExist = true;
              this.subclassExistMessage =
                "Sub class" + " " + data + " " + "already exist.";
              return;
            } else {
              var lastElement = this.showParamList.slice(-1)[0];
              var id = lastElement.id + 1;
              subclass = {
                id: id,
                name: data,
                selected: false,
                type: "Subtype",
                length: 0,
                color: "#000000".replace(/0/g, function() {
                  return (~~(Math.random() * 16)).toString(16);
                }),
              };
              this.settingObj[givenClassindex].parameters[
                givenParamindex
              ].subClass.push(subclass);
            }
          }
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },

    validateSubclass(subclassName) {
      let trimmedSubClassName = subclassName.replace(/\s+/g, " ").trim();
      this.subclassNameError = false;
      if (!trimmedSubClassName.replace(/\s/g, "").length) {
        this.subclassNameError = true;
      } else {
        this.addSubclass(trimmedSubClassName);
      }
    },

    checkExistingObject(className, objectType, objectParam) {
      try {
        this.isObjectExist = false;
        this.isParameterExist = false;
        this.required = false;
        this.requiredCheckbox = false;
        if (className !== "" && objectType !== "") {
          if (this.settingObj.length == 0) {
            this.class_added_dict_array.push({ name: className });
            if (objectParam == "") {
              this.settingObj.push({
                id: 1,
                name: className,
                selected: true,
                type: objectType,
                parameters: [
                  {
                    id: 1,
                    name: "Id",
                    selected: true,
                    type: "Parameters",
                    length: 1,
                    subClass: null,
                    color: "#000000".replace(/0/g, function() {
                      return (~~(Math.random() * 16)).toString(16);
                    }),
                  },
                ],
                length: 0,
                color: "#000000".replace(/0/g, function() {
                  return (~~(Math.random() * 16)).toString(16);
                }),
              });
            } else {
              if (objectParam.toLowerCase() !== "id") {
                this.settingObj.push({
                  id: 1,
                  name: className,
                  selected: true,
                  type: objectType,
                  parameters: [
                    {
                      id: 1,
                      name: "Id",
                      selected: true,
                      type: "Parameters",
                      length: 1,
                      subClass: null,
                      color: "#000000".replace(/0/g, function() {
                        return (~~(Math.random() * 16)).toString(16);
                      }),
                    },
                    {
                      id: 2,
                      name: objectParam,
                      selected: true,
                      type: "Parameters",
                      length: 0,
                      subClass: null,
                      color: "#000000".replace(/0/g, function() {
                        return (~~(Math.random() * 16)).toString(16);
                      }),
                    },
                  ],
                  length: 0,
                  color: "#000000".replace(/0/g, function() {
                    return (~~(Math.random() * 16)).toString(16);
                  }),
                });
              } else {
                this.isParameterExist = true;
                return;
              }
            }
            // part to show the added class in real time
            this.finalSettingObj[objectType] = [];
            this.finalSettingObj[objectType].push(this.settingObj[0]);
            this.allKeys.push(objectType);
          } else {
            if (objectParam !== "" && className !== "") {
              var givenClassindex = this.settingObj
                .map(function(o) {
                  if (o.type == objectType) return o.name.toLowerCase();
                })
                .indexOf(className.toLowerCase());
              if (givenClassindex >= 0) {
                var givenParamindex = this.settingObj[
                  givenClassindex
                ].parameters
                  .map(function(o) {
                    return o.name.toLowerCase();
                  })
                  .indexOf(objectParam.toLowerCase());
                if (givenParamindex >= 0) {
                  this.paramExistMessage =
                    "Parameter" + " " + objectParam + " " + "already exist.";
                  this.isParameterExist = true;
                  return;
                } else {
                  this.addObject(className, objectType, objectParam);
                }
              } else {
                if (objectParam.toLowerCase() !== "id") {
                  this.addObject(className, objectType, objectParam);
                } else {
                  this.isParameterExist = true;
                  return;
                }
              }
            } else if (className !== "") {
              var givenClassindex = this.settingObj
                .map(function(o) {
                  if (o.type == objectType) return o.name.toLowerCase();
                })
                .indexOf(className.toLowerCase());
              if (givenClassindex >= 0) {
                this.objectExistMessage =
                  "Object class" + " " + className + " " + "already exist.";
                this.isObjectExist = true;
              } else {
                this.addObject(className, objectType, objectParam);
              }
            }
          }
        } else {
          this.required = true;
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },

    addObject(className, type, objectParam) {
      try {
        this.required = false;
        this.requiredCheckbox = false;
        let parameter = {};
        if (className !== "" && type !== "") {
          this.valid = false;
          var lastElement = this.settingObj.slice(-1)[0];
          var id = lastElement.id + 1;
          if (this.isObjectExist == false && objectParam !== "") {
            if (this.isParameterExist == false) {
              var classindex = this.settingObj
                .map(function(o) {
                  if (o.type == type) return o.name;
                })
                .indexOf(className);
              if (classindex >= 0) {
                if (
                  this.settingObj[classindex].parameters !== null &&
                  this.settingObj[classindex].parameters.length > 0
                ) {
                  var lastElement = this.settingObj[
                    classindex
                  ].parameters.slice(-1)[0];
                  var id = lastElement.id + 1;
                  parameter = {
                    id: id,
                    name: objectParam,
                    selected: true,
                    type: "Parameters",
                    length: 0,
                    subClass: null,
                    color: "#000000".replace(/0/g, function() {
                      return (~~(Math.random() * 16)).toString(16);
                    }),
                  };
                  this.settingObj[classindex].parameters.push(parameter);
                }
              } else if (classindex < 0) {
                this.class_added_dict_array.push({ name: className });
                var lastElement = this.settingObj.slice(-1)[0];
                var id = lastElement.id + 1;
                this.settingObj.push({
                  id: id,
                  name: className,
                  selected: true,
                  type: type,
                  length: 0,
                  parameters: [
                    {
                      id: 1,
                      name: "Id",
                      selected: true,
                      type: "Parameters",
                      length: 1,
                      subClass: null,
                      color: "#000000".replace(/0/g, function() {
                        return (~~(Math.random() * 16)).toString(16);
                      }),
                    },
                    {
                      id: 2,
                      name: objectParam,
                      selected: true,
                      type: "Parameters",
                      length: 0,
                      subClass: null,
                      color: "#000000".replace(/0/g, function() {
                        return (~~(Math.random() * 16)).toString(16);
                      }),
                    },
                  ],
                  color: "#000000".replace(/0/g, function() {
                    return (~~(Math.random() * 16)).toString(16);
                  }),
                });
                if (this.allKeys.includes(type)) {
                  // part to show the added class in real time
                  this.finalSettingObj[type].push(
                    this.settingObj[lastElement.id]
                  );
                } else {
                  // Part when the added category was not already present
                  this.finalSettingObj[type] = [];
                  this.finalSettingObj[type].push(
                    this.settingObj[lastElement.id]
                  );
                  this.allKeys.push(type);
                }
              }
            }
          } else if (this.isObjectExist == false && objectParam == "") {
            var lastElement = this.settingObj.slice(-1)[0];
            var id = lastElement.id + 1;
            this.class_added_dict_array.push({ name: className });
            this.settingObj.push({
              id: id,
              name: className,
              selected: true,
              type: type,
              parameters: [
                {
                  id: 1,
                  name: "Id",
                  selected: true,
                  type: "Parameters",
                  length: 1,
                  subClass: null,
                  color: "#000000".replace(/0/g, function() {
                    return (~~(Math.random() * 16)).toString(16);
                  }),
                },
              ],
              length: 0,
              color: "#000000".replace(/0/g, function() {
                return (~~(Math.random() * 16)).toString(16);
              }),
            });
            if (this.allKeys.includes(type)) {
              // part to show the added class in real time
              this.finalSettingObj[type].push(this.settingObj[lastElement.id]);
            } else {
              // Part when the added category was not already present
              this.finalSettingObj[type] = [];
              this.finalSettingObj[type].push(this.settingObj[lastElement.id]);
              this.allKeys.push(type);
            }
          }
        } else {
          this.required = true;
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },

    deleteSettingObject() {
      // delete setting objects on the basis of fields value
      this.required = false;
      this.isObjectExist = false;
      this.isParameterExist = false;
      try {
        for (let i in this.settingObj) {
          if (
            this.objectType !== "" &&
            this.className !== "" &&
            this.objectParam !== ""
          ) {
            // delete class's parameter
            if (
              this.objectType == this.settingObj[i].type &&
              this.className == this.settingObj[i].name
            ) {
              let paramIndex = this.settingObj[i].parameters
                .map(function(o) {
                  return o.name.toLowerCase();
                })
                .indexOf(this.objectParam.toLowerCase());
              if (paramIndex >= 0)
                this.settingObj[i].parameters.splice(paramIndex, 1);
              return;
            }
          } else if (
            this.objectType !== "" &&
            this.className !== "" &&
            this.objectParam == ""
          ) {
            // delete category's class
            if (
              this.objectType == this.settingObj[i].type &&
              this.className == this.settingObj[i].name
            ) {
              let classIndex = this.finalSettingObj[this.objectType]
                .map(function(o) {
                  return o.name.toLowerCase();
                })
                .indexOf(this.className.toLowerCase());
              let classAddedindex = this.class_added_dict_array
                .map(function(o) {
                  return o.name.toLowerCase();
                })
                .indexOf(this.className.toLowerCase());
              if (classIndex >= 0)
                this.finalSettingObj[this.objectType].splice(classIndex, 1);
              if (classAddedindex >= 0)
                this.class_added_dict_array.splice(classAddedindex, 1);
              this.settingObj.splice(i, 1);
              return;
            }
          } else if (this.objectType !== "") {
            // delete category
            if (this.objectType == this.settingObj[i].type) {
              let categoryIndex = this.allKeys
                .map(function(o) {
                  return o.toLowerCase();
                })
                .indexOf(this.objectType.toLowerCase());
              let categoryTotalClass = this.finalSettingObj[this.objectType]
                .length;
              this.settingObj.splice(i, categoryTotalClass);
              delete this.finalSettingObj[this.objectType];
              this.allKeys.splice(categoryIndex, 1);
              return;
            }
          } else {
            this.required = true;
            return;
          }
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },

    deleteSubclass(data) {
      var isObjSelected = false;
      this.required = false;
      this.isObjectExist = false;
      this.isParameterExist = false;
      var givenClassindex = this.settingObj
        .map(function(o) {
          return o.name.toLowerCase();
        })
        .indexOf(this.currentClass.toLowerCase());
      var givenParamindex = this.settingObj[givenClassindex].parameters
        .map(function(o) {
          return o.name.toLowerCase();
        })
        .indexOf(this.currentParam.toLowerCase());
      try {
        for (
          var i =
            this.settingObj[givenClassindex].parameters[givenParamindex]
              .subClass.length - 1;
          i >= 0;
          --i
        ) {
          if (
            this.settingObj[givenClassindex].parameters[givenParamindex]
              .subClass !== null &&
            data !== null
          ) {
            if (
              this.settingObj[givenClassindex].parameters[givenParamindex]
                .subClass[i].selected == true
            ) {
              this.requiredCheckbox = false;
              isObjSelected = true;
              this.settingObj[givenClassindex].parameters[
                givenParamindex
              ].subClass.splice(i, 1);
            }
          }
        }
        if (isObjSelected == true) {
          console.log("array ");
        } else {
          this.requiredCheckbox = true;
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },

    closeAddObjDialog: function() {
      // reset add new object dialog fields
      this.AddObjectDialog = false;
      this.isParameterExist = false;
      this.isObjectExist = false;
      this.required = false;
      this.objectType = "";
      this.className = "";
      this.objectParam = "";
    },

    editObjectCategory: function() {
      try {
        if (this.editCategory == true) {
          this.editCategory = false;
        } else {
          this.editCategory = true;
          this.objectType = "";
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },

    editObjectClass: function() {
      try {
        if (this.editClass == true) {
          this.editClass = false;
        } else {
          this.editClass = true;
          this.className = "";
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },

    editObjectParam: function() {
      try {
        if (this.editParam == true) {
          this.editParam = false;
        } else {
          this.editParam = true;
          this.objectParam = "";
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },

    changeObjectClass: function() {
      // show object class on the basis of object category in the dropdown
      try {
        this.className = "";
        this.objectClass = [];
        if (this.editCategory == false) {
          this.editClass = false;
          this.editParam = false;
        }
        for (let index in this.settingObj) {
          if (this.objectType == this.settingObj[index].type) {
            this.objectClass.push(this.settingObj[index].name);
          }
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },

    changeObjectParam: function() {
      // show parameters on the basis of object class in the dropdown
      try {
        this.objectParam = "";
        this.parameterClass = [];
        let index = this.settingObj
          .map(function(o) {
            return o.name;
          })
          .indexOf(this.className);
        if (this.editCategory == false) {
          this.editClass = false;
          this.editParam = false;
        }
        if (index >= 0) {
          for (let paramIndex in this.settingObj[index].parameters) {
            if (this.settingObj[index].parameters[paramIndex].name !== "Id") {
              this.parameterClass.push(
                this.settingObj[index].parameters[paramIndex].name
              );
            }
          }
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },

    selectUnselectParametersAll: function() {
      try {
        if (this.selectedParametersCount == this.totalParametersCount) {
          this.checkedParameter = true;
        } else {
          this.checkedParameter = false;
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },

    selectUnselectObjectsAll: function() {
      try {
        if (this.selectedObjectCount === this.totalObjectCount) {
          this.checkObjectAll = true;
        } else {
          this.checkObjectAll = false;
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },

    initSelectAll(event) {
      try {
        let count = 0,
          tot = 0,
          countParam = 0,
          totparam = 0;
        for (let i in this.settingObj) {
          if (this.settingObj[i].selected) {
            count++;
          }
          tot++;
          if (this.settingObj[i].parameters !== null) {
            for (let j in this.settingObj[i].parameters) {
              if (this.settingObj[i].parameters[j].selected) {
                countParam++;
              }
              totparam++;
            }
          }
        }
        this.selectedObjectCount = count;
        this.totalObjectCount = tot;
        this.selectUnselectObjectsAll();
        this.selectedParametersCount = countParam;
        this.totalParametersCount = totparam;
        this.selectUnselectParametersAll();
      } catch (error) {
        console.log("Error:", error);
      }
    },
    getThemeMode: function() {
      this.isDarkMode = SettingService.getDarkMode();
    },
  },
  beforeMount() {
    this.getThemeMode();
    this.getUserId();
    this.disableBack();
  },
};
