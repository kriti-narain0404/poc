//import { fabric } from "fabric";
//import editorScript from "./editorScript.js"
  export function getNextZoomInFactor(zoomfctr)
  {
    let currZoom = zoomfctr;//editorScript.canvas.getZoom();
    let nextZoom = 1.0;
    if(currZoom >=4.9)
    {
      nextZoom = 5.0;
    }
    else if(currZoom >=4.8)
    {
      nextZoom = 4.9;
    }
    else if(currZoom >=4.7)
    {
      nextZoom = 4.8;
    }
    else if(currZoom >=4.6)
    {
      nextZoom = 4.7;
    }
    else if(currZoom >=4.5)
    {
      nextZoom = 4.6;
    }
    else if(currZoom >=4.4)
    {
      nextZoom = 4.5;
    }
    else if(currZoom >=4.3)
    {
      nextZoom = 4.4;
    }
    else if(currZoom >=4.2)
    {
      nextZoom = 4.3;
    }
    else if(currZoom >=4.1)
    {
      nextZoom = 4.2;
    }
    else if(currZoom >=4)
    {
      nextZoom = 4.1;
    }
    else if(currZoom >=3.9)
    {
      nextZoom = 4;
    }
    else if(currZoom >=3.8)
    {
      nextZoom = 3.9;
    }
    else if(currZoom >=3.7)
    {
      nextZoom = 3.8;
    }
    else if(currZoom >=3.6)
    {
      nextZoom = 3.7;
    }
    else if(currZoom >=3.5)
    {
      nextZoom = 3.6;
    }
    else if(currZoom >=3.4)
    {
      nextZoom = 3.5;
    }
    else if(currZoom >=3.3)
    {
      nextZoom = 3.4;
    }
    else if(currZoom >=3.2)
    {
      nextZoom = 3.3;
    }
    else if(currZoom >=3.1)
    {
      nextZoom = 3.2;
    }
    else if(currZoom >=3)
    {
      nextZoom = 3.1;
    }
    else if(currZoom >=2.9)
    {
      nextZoom = 3;
    }
    else if(currZoom >=2.8)
    {
      nextZoom = 2.9;
    }
    else if(currZoom >=2.7)
    {
      nextZoom = 2.8;
    }
    else if(currZoom >=2.6)
    {
      nextZoom = 2.7;
    }
    else if(currZoom >=2.5)
    {
      nextZoom = 2.6;
    }
    else if(currZoom >=2.4)
    {
      nextZoom = 2.5;
    }
    else if(currZoom >=2.3)
    {
      nextZoom = 2.4;
    }
    else if(currZoom >=2.2)
    {
      nextZoom = 2.3;
    }
    else if(currZoom >=2.1)
    {
      nextZoom = 2.2;
    }
    else if(currZoom >=2)
    {
      nextZoom = 2.1;
    }
    else if(currZoom >=1.9)
    {
      nextZoom = 2.0;
    }
    else if(currZoom >=1.8)
    {
      nextZoom = 1.9;
    }
    else if(currZoom >=1.7)
    {
      nextZoom = 1.8;
    }
    else if(currZoom >=1.6)
    {
      nextZoom = 1.7;
    }
    else if(currZoom >=1.5)
    {
      nextZoom = 1.6;
    }
    else if(currZoom >=1.4)
    {
      nextZoom = 1.5;
    }
    else if(currZoom >=1.3)
    {
      nextZoom = 1.4;
    }
    else if(currZoom >=1.2)
    {
      nextZoom = 1.3;
    }
    else if(currZoom >=1.1)
    {
      nextZoom = 1.2;
    }
    else if(currZoom >=1.0)
    {
      nextZoom = 1.1;
    }
    else if(currZoom >=0.9)
    {
      nextZoom = 1.0;
    }
    else if(currZoom >=0.8)
    {
      nextZoom = 0.9;
    }
    else if(currZoom >=0.7)
    {
      nextZoom = 0.8;
    }
    else if(currZoom >=0.6)
    {
      nextZoom = 0.7;
    }
    else if(currZoom >=0.5)
    {
      nextZoom = 0.6;
    }
    else if(currZoom >=0.4)
    {
      nextZoom = 0.5;
    }
    else if(currZoom >=0.3)
    {
      nextZoom = 0.4;
    }
    else if(currZoom >=0.2)
    {
      nextZoom = 0.3;
    }
    else if(currZoom >=0.1)
    {
      nextZoom = 0.2;
    }
    else if(currZoom >=0)
    {
      nextZoom = 0.1;
    }
    else
    {
      nextZoom = 0;
    }

    return nextZoom;
  }

  export function getNextZoomOutFactor(zoomfctr)
  {
    let currZoom = zoomfctr;//editorScript.canvas.getZoom();
    let nextZoom = 1.0;

    if(currZoom > 4.9)
    {
      nextZoom = 4.9;
    }
    else if(currZoom > 4.8)
    {
      nextZoom = 4.8;
    }
    else if(currZoom > 4.7)
    {
      nextZoom = 4.7;
    }
    else if(currZoom > 4.6)
    {
      nextZoom = 4.6;
    }
    else if(currZoom > 4.5)
    {
      nextZoom = 4.5;
    }
    else if(currZoom > 4.4)
    {
      nextZoom = 4.4;
    }
    else if(currZoom > 4.3)
    {
      nextZoom = 4.3;
    }
    else if(currZoom > 4.2)
    {
      nextZoom = 4.2;
    }
    else if(currZoom > 4.1)
    {
      nextZoom = 4.1;
    }
    else if(currZoom > 4.0)
    {
      nextZoom = 4.0;
    }
    else if(currZoom > 3.9)
    {
      nextZoom = 3.9;
    }
    else if(currZoom > 3.8)
    {
      nextZoom = 3.8;
    }
    else if(currZoom > 3.7)
    {
      nextZoom = 3.7;
    }
    else if(currZoom > 3.6)
    {
      nextZoom = 3.6;
    }
    else if(currZoom > 3.5)
    {
      nextZoom = 3.5;
    }
    else if(currZoom > 3.4)
    {
      nextZoom = 3.4;
    }
    else if(currZoom > 3.3)
    {
      nextZoom = 3.3;
    }
    else if(currZoom > 3.2)
    {
      nextZoom = 3.2;
    }
    else if(currZoom > 3.1)
    {
      nextZoom = 3.1;
    }
    else if(currZoom > 3.0)
    {
      nextZoom = 3.0;
    }
    else if(currZoom > 2.9)
    {
      nextZoom = 2.9;
    }
    else if(currZoom > 2.8)
    {
      nextZoom = 2.8;
    }
    else if(currZoom > 2.7)
    {
      nextZoom = 2.7;
    }
    else if(currZoom > 2.6)
    {
      nextZoom = 2.6;
    }
    else if(currZoom > 2.5)
    {
      nextZoom = 2.5;
    }
    else if(currZoom > 2.4)
    {
      nextZoom = 2.4;
    }
    else if(currZoom > 2.3)
    {
      nextZoom = 2.3;
    }
    else if(currZoom > 2.2)
    {
      nextZoom = 2.2;
    }
    else if(currZoom > 2.1)
    {
      nextZoom = 2.1;
    }
    else if(currZoom > 2.0)
    {
      nextZoom = 2.0;
    }
    else if(currZoom > 1.9)
    {
      nextZoom = 1.9;
    }
    else if(currZoom > 1.8)
    {
      nextZoom = 1.8;
    }
    else if(currZoom > 1.7)
    {
      nextZoom = 1.7;
    }
    else if(currZoom > 1.6)
    {
      nextZoom = 1.6;
    }
    else if(currZoom > 1.5)
    {
      nextZoom = 1.5;
    }
    else if(currZoom > 1.4)
    {
      nextZoom = 1.4;
    }
    else if(currZoom > 1.3)
    {
      nextZoom = 1.3;
    }
    else if(currZoom > 1.2)
    {
      nextZoom = 1.2;
    }
    else if(currZoom > 1.1)
    {
      nextZoom = 1.1;
    }
    else if(currZoom > 1.0)
    {
      nextZoom = 1.0;
    }
    else if(currZoom > 0.9)
    {
      nextZoom = 0.9;
    }
    else if(currZoom > 0.8)
    {
      nextZoom = 0.8;
    }
    else if(currZoom > 0.7)
    {
      nextZoom = 0.7;
    }
    else if(currZoom > 0.6)
    {
      nextZoom = 0.6;
    }
    else if(currZoom > 0.5)
    {
      nextZoom = 0.5;
    }
    else if(currZoom > 0.4)
    {
      nextZoom = 0.4;
    }
    else if(currZoom > 0.3)
    {
      nextZoom = 0.3;
    }
    else
    {
      nextZoom = 0.2;
    }

    return nextZoom;
  }

