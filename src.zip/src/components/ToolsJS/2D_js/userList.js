
import Appfooter from "../../../shared/Appfooter.vue";
import HomeHeader from "../../../shared/HomeHeader.vue";
import UserModel from "../../../model/UserModel.js";
import Loading from 'vue-loading-overlay';
import { SAVE_OBJ_USER_MUTATION } from "../../../constants/graphql";
import { GET_OBJ_USER_MUTATION } from "../../../constants/graphql";
import { INIT_PROJECT } from "../../../constants/graphql";
import { INIT_PROJECT_REPORT, VIDEO_TO_FRAMES } from "../../../constants/graphql";
import { GET_PROJECT_CONFIG_MUTATION } from "../../../constants/graphql";
import { ACKNOWLEDGMENT_DATA_PIPELINE } from "../../../constants/graphql";
import SettingService from "../../../services/SettingService.js";
import axios from "axios";

var projectListId = [];
export default {
  name: "userList",
  components: {
    "home-header": HomeHeader,
    "app-footer": Appfooter,
    Loading,

  },
  props: ["project"],

  data() {
    return UserModel; // Moved to model UserModel
  },

  computed: {
    getUserId() {
      this.userId = SettingService.getSelectedUserId();
      this.username = SettingService.getSelectedUserName();
      this.role = SettingService.getSelectedUserRole();
      this.mainProjectId = SettingService.getSelectedProject();
      this.projectList = SettingService.getProjectList();
      this.required = false;
      this.isUserExist = false;
    },
    getCounts(){
      try {
          if(this.userList.length > 0){
             for (var i=0; i<this.userList.length; i++){
               if(this.projectType == this.userList[i].project){
                 let validatorCount = this.userList[i].validators.length;
                 let annotatorCount=0;
                 let totalannotatorCount=0;
                 for (var j=0; j<this.userList[i].validators.length; j++){
                   annotatorCount = this.userList[i].validators[j].annotators.length;
                   totalannotatorCount=annotatorCount + totalannotatorCount;
                 }
                 this.availannotator=totalannotatorCount;
                 this.availvalidator=validatorCount;
               }
             }
           }
      } catch (error) {
        console.log("Error:", error);
      }
    },
    disableBack: function () {
      history.pushState(null, null, location.href);
      window.onpopstate = function () {
          history.go(1);
      };
    }
  },
  apollo: {
    getUserListObj: {
      query: GET_OBJ_USER_MUTATION,
      variables() {
        const userid = this.userId;
        const proId = this.mainProjectId;
        return {
          userid,
          proId
        };
      },
      result({ data, loader, networkStatus }) {
        this.userList = [];
        this.flag = [];
        let userData = data.getUserListObj.userList;
        let scriptData = data.getUserListObj.workDiv;      
        if (userData != null) {
          let adminCount = userData.length;
          this.projectList[0] = "No Selection";
          for (var i = 0; i < adminCount; i++) {
            this.currentProjectName = userData[i].project;
            this.projectName = this.currentProjectName;
            this.adminName = userData[i].username;
            let validatorCount = userData[i].validators.length;            
            this.projectList.push(userData[i].project);
            projectListId.push({
              type: userData[i].project,
              id: userData[i].project_id
            });
            this.userList.push({
              project: userData[i].project,
              project_id: userData[i].project_id,
              changed: userData[i].changed,
              projectEditmode: userData[i].projectEditmode,
              username: userData[i].username,
              editmode: userData[i].editmode,
              validators: [],
              role: userData[i].role
            });
            let validatorList = [];
            this.valList = [];
            for (var j = 0; j < validatorCount; j++) {
              let annotatorCount = userData[i].validators[j].annotators.length;
              validatorList.push({
                username: userData[i].validators[j].username,
                editmode: userData[i].validators[j].editmode,
                status24hr: userData[i].validators[j].status_1,
                status8hr: userData[i].validators[j].status_2,
                role: userData[i].validators[j].role,
                annotators: []
              });
              this.valList.push(userData[i].validators[j].username); // add validator's name to show in add project drop down
              this.userList[i].validators = validatorList;              
              let annotatorList = [];
              for (var k = 0; k < annotatorCount; k++) {
                
                  annotatorList.push({
                    username: userData[i].validators[j].annotators[k].username,
                    editmode: userData[i].validators[j].annotators[k].editmode,
                    status24hr: userData[i].validators[j].annotators[k].status_1,
                    status8hr: userData[i].validators[j].annotators[k].status_2,
                    role: userData[i].validators[j].annotators[k].role
                  });
                  this.userList[i].validators[j].annotators = annotatorList;

               
              }
            }
          }
        }
        this.scripts=[];
        this.conversionScripts=[];
        if(scriptData != null){
          this.projectType=scriptData.projectType;
          this.folderpath=scriptData.folderpath;
          this.divisionType=scriptData.divisionType;
          this.availdays=scriptData.availdays;
          this.requiredays=scriptData.requiredays;
          this.productivity=scriptData.productivity;
          this.avgFrame=scriptData.avgFrame;
          this.totalFrame=scriptData.totalFrame;
          this.availannotator=scriptData.availannotator;
          this.requireannotator=scriptData.requireannotator;
          this.annoratio=scriptData.annoratio;
          this.availvalidator=scriptData.availvalidator;
          let listscript=scriptData.scriptList;
          var conversionScriptsArray=scriptData.conversionScripts;
          this.conversionScripts[0] = "No Selection";
          for (var i = 0; i < conversionScriptsArray.length; i++) {            
            this.conversionScripts.push(conversionScriptsArray[i]);
          }          
          this.conversionScriptType=scriptData.conversionScript;
          for (var i = 0; i < listscript.length; i++) {
            this.scripts.push({
              scriptname: listscript[i].scriptname,
              flag: listscript[i].flag
            });
            this.flag.push(listscript[i].flag);
          }
        }
        var self = this;
        if(self.showNotification == true){
          setTimeout(function () { self.showNotification = false; }, 500);
        }

      }

    }
  },

  methods: {
    slide: function (direction){
    try{
      if(direction == 'right'){
        document.getElementById('validator-group-container').scrollLeft += 500;
      } else if (direction == 'left') {
        document.getElementById('validator-group-container').scrollLeft -= 500;
      }
      } catch (error) {
        console.log("Error:", error);
      }
    },
    scrollDiv: function () {
    try{
      console.log("scrolled");
      var annotatorContainer = document.getElementById("annotator-group-container");
      var validatorContainer = document.getElementById("validator-group-container");
      annotatorContainer.scrollLeft = validatorContainer.scrollLeft;
      validatorContainer.scrollRight = validatorContainer.scrollRight;
      
    } catch (error) {
      console.log("Error:", error);
    }
  },
  saveUserListObj: function () {
          try {
            var div = document.createElement('div');
            var img = document.createElement('img');
            img.src = 'static/loading.gif';
            img.style.cssText = 'margin-top:20%;width:5%;height:10%;';
            div.style.cssText = 'width: 100%;height: 100%;top: 0px;left: 0px;position: fixed;display: block;opacity: 0.7;background-color: #fff;z-index: 99;text-align: center';
            div.appendChild(img);
            document.body.appendChild(div);
            var self = this;
            this.$apollo
              .mutate({
                mutation: SAVE_OBJ_USER_MUTATION,
                variables: {
                  userList: this.userList
                }
              })
              .then(data => {
                this.userList = [];
                div.style.display = "none";
                self.showNotification = true;
                this.isQueryError = false;
                if(self.showNotification == true){                                 
                  this.$apollo.queries.getUserListObj.refetch();  
                }
              }).catch(error => {
                div.style.display = "none";
                this.isQueryError = true;
                this.queryErrorResult = /:(.+)/.exec(error.message)[1];
            });
          } catch (error) {
            div.style.display = "none";
            console.log("Error:", error);
          }
        },        
        getParameters: function () {
          try{
            if(this.totalFrame > 0 && this.avgFrame > 0 && this.productivity > 0){
              this.requiredays= Math.ceil(((this.totalFrame * this.avgFrame)/this.productivity)/this.availannotator);
              if(this.availdays > 0){
                this.requireannotator= Math.ceil((this.totalFrame * this.avgFrame)/(this.availdays * this.productivity));
              }
            }
          } catch (error) {
            console.log("Error:", error);
          }
        },
        editUser: function(i, item) {
          try{
            if(this.userList[i].projectEditmode == false && this.userList[i].project == item){
              this.userList[i].projectEditmode = true;
              this.projectName=this.userList[i].project
            }
            else if(this.userList[i].editmode == false && this.userList[i].username == item){
              this.userList[i].editmode = true;
              this.adminName=this.userList[i].username
            }
            else{
              this.userList[i].projectEditmode = false;
              this.userList[i].editmode = false;
            }
          } catch (error) {
            console.log("Error:", error);
          }
        },
        editValidator: function(i, j) {
          try{
            if(this.userList[i].validators[j].editmode == true){
              this.userList[i].validators[j].editmode = false;
            }
            else{
              for (var m=0; m<this.userList[i].validators.length; m++){
                if(m==j){
                  this.userList[i].changed = true;              
                  this.userList[i].validators[m].editmode = true;
                  this.valName=this.userList[i].validators[j].username;
                }
                else{              
                  this.userList[i].validators[m].editmode = false;
                }
              }
            }
          } catch (error) {
            console.log("Error:", error);
          }
        },
        editAnnotator: function(i, j, k) {
          try{
            if(this.userList[i].validators[j].annotators[k].editmode == true){
              this.userList[i].validators[j].annotators[k].editmode = false;
            }
            else{
              for (var m=0; m<this.userList[i].validators[j].annotators.length; m++){
                if(m==k){
                  this.userList[i].validators[j].annotators[m].editmode = true;
                  this.annoName=this.userList[i].validators[j].annotators[k].username;
                }
                else{this.userList[i].validators[j].annotators[m].editmode = false;}
                
              }
              
            }
          } catch (error) {
            console.log("Error:", error);
          }
        },
        saveUser: function(i, name) {
          try{
            if(this.userList[i].projectEditmode == true){
              if(name !== this.userList[i].project){
                this.userList[i].changed = true;
              }
              this.userList[i].projectEditmode = false;
              if(this.projectName!=''){
              this.userList[i].project=this.projectName;
              }
              this.projectName="";
            }
            else if(this.userList[i].editmode == true){
              if(name !== this.userList[i].username){
                this.userList[i].changed = true;
              }
              this.userList[i].editmode = false;
              if(this.this.adminName!=''){
              this.userList[i].username=this.adminName;
              }
              this.adminName="";
            }
            else{
              this.userList[i].projectEditmode = false;
              this.userList[i].editmode = false;
            }
          } catch (error) {
            console.log("Error:", error);
          }
        },
        saveValidator: function(i, j, name) {
          try{
            if(name !== this.userList[i].validators[j].username){
              this.userList[i].changed = true;
            }
            this.userList[i].validators[j].editmode = false;
            if(this.valName!=''){
            this.userList[i].validators[j].username=this.valName;
            }            
            this.valName="";
          } catch (error) {
            console.log("Error:", error);
          }
        },
        saveAnnotator: function(i, j, k, name) {
          try{
            if(name !== this.userList[i].validators[j].annotators[k].username){
              this.userList[i].changed = true;
            }
            this.userList[i].validators[j].annotators[k].editmode = false;
            if(this.annoName!=''){
            this.userList[i].validators[j].annotators[k].username=this.annoName;
            }
            this.annoName="";
          } catch (error) {
            console.log("Error:", error);
          }
        },
        addValidUser: function (projectname, adminname, valname, annoname) {
          try{
            this.sameNameVerify = false;
            this.required = false;
            this.isExistAdmin = false;
            this.isExistValidator = false;
            this.isExistAnnotator = false;
            var id = 1;
            if(projectname && adminname && valname && annoname){
              if ((adminname != valname) && (valname != annoname) && (adminname != annoname)){
                if(this.userList.length == 0){
                  this.userList.push({
                    project: projectname,
                    project_id: id,
                    changed: true,
                    projectEditmode: false,
                    username: adminname,
                    editmode: false,
                    validators: [{
                      username: valname,
                      editmode: false,
                      role: "VALIDATOR",
                      annotators: [{
                        editmode: false,
                        username: annoname,
                        role: "ANNOTATOR"
                      }],
                    }],
                    role: "ADMIN"
                  });
                  this.annoName='';
                }
                else{
                  for(var i=0; i<this.userList.length; i++){
                    for(var j=0; j<this.userList[i].validators.length; j++){
                      for(var k=0; k<this.userList[i].validators[j].annotators.length; k++){
                        if(this.userList[i].project == projectname){
                          if (this.userList[i].username === adminname || this.userList[i].validators[j].username === adminname
                            || this.userList[i].validators[j].annotators[k].username === adminname) {
                              this.isExistAdmin = true;
                          }
                          if (this.userList[i].username === valname || this.userList[i].validators[j].username === valname
                            || this.userList[i].validators[j].annotators[k].username === valname) {
                              this.isExistValidator = true;
                          }
                          if (this.userList[i].username === annoname || this.userList[i].validators[j].username === annoname
                            || this.userList[i].validators[j].annotators[k].username === annoname) {
                              this.isExistAnnotator = true;
                          }
                        }
                      }
                    }
                  }
                    this.addUser(projectname, adminname, valname, annoname);
                }
            }else{
              this.sameNameVerify = true;
            }
            }
            else{
              this.required = true;
            }
          }catch (error) {
            console.log("Error:", error);
          }
        },
        addUser: function (projectname, adminname, valname, annoname) {
          try{
            this.isUserExist = false;
            let validator={};
            let annotator={};
              if(this.userList.length > 0){
                var valindex;
                var projectindex = this.userList.map(function(o) { return o.project; }).indexOf(projectname);
                var adminindex = this.userList.map(function(o) { return o.username; }).indexOf(adminname);
                for(var i=0; i<this.userList.length; i++){
                  if(this.userList[i].project == projectname){
                    var indexvalue= this.userList[i].validators.map(function(o) { return o.username; }).indexOf(valname);
                    if(indexvalue >=0){
                      valindex = indexvalue;
                      break;
                    }
                    else{
                      valindex = indexvalue;
                    }
                  }
                }
                if(projectindex >=0 && adminindex >=0 && valindex ==-1 && this.isExistValidator == false && this.isExistAnnotator == false){
                  validator={
                    username: valname,
                    role: "VALIDATOR",
                    editmode: false,
                    annotators: [
                      {
                        editmode: false,
                        username: annoname,
                        role: "ANNOTATOR"
                      }]
                  };
                  this.userList[projectindex].changed = true;
                  this.userList[projectindex].validators.push(validator);
                  this.valList.push(valname); // add validator's name to show in add project drop down
                }
                else if(projectindex >=0 && adminindex >=0 && valindex >=0 && this.isExistAnnotator == false){
                    annotator={
                    editmode: false,
                    username: annoname,
                    role: "ANNOTATOR"
                  };
                  this.userList[projectindex].changed = true;
                  this.userList[projectindex].validators[valindex].annotators.push(annotator);
                }
                else if(this.isExistAdmin == false){
                  var oldId = this.userList.length;
                  var newId = oldId + 1;
                  this.userList.push({
                    project: projectname,
                    project_id: newId,
                    changed: true,
                    projectEditmode: false,
                    username: adminname,
                    editmode: false,
                    validators: [{
                      editmode: false,
                      username: valname,
                      role: "VALIDATOR",
                      annotators: [{
                        editmode: false,
                        username: annoname,
                        role: "ANNOTATOR"
                      }],
                    }],
                    role: "ADMIN"
                  });
                }
                else{
                  if(adminindex >=0 && valindex ==-1 && this.isExistValidator == true) {
                    this.isUserExist = true;
                    this.adminExistMessage='Name' + ' ' + valname + ' ' +'already exist.';
                  }
                  else if(adminindex >=0 && valindex ==-1 && this.isExistAnnotator == true){
                    this.isUserExist = true;
                    this.adminExistMessage='Name' + ' ' + annoname + ' ' +'already exist.';
                  }
                  else if(valindex >=0 && this.isExistAnnotator == true){
                    this.isUserExist = true;
                    this.adminExistMessage='Name' + ' ' + annoname + ' ' +'already exist.';
                  }
                  else{
                    this.isUserExist = true;
                    this.adminExistMessage='Name' + ' ' + adminname + ' ' +'already exist.';
                  }
                }
                this.annoName = '';
              }
          } catch (error) {
            console.log("Error:", error);
          }
        },
    deleteUser: function (projectname, adminname, valname, annoname) {
      try {
        for (var i = this.userList.length - 1; i >= 0; --i) {
          if(this.userList[i].validators && valname && this.userList[i].project == projectname 
            && this.userList[i].username == adminname){
            this.userList[i].changed = true;
            for (var j = this.userList[i].validators.length - 1; j >= 0; --j) {
              if (this.userList[i].validators[j].username == valname && !annoname) {
                this.userList[i].validators.splice(j, 1);
                this.valName = "";
              }
              else if(this.userList[i].validators[j].annotators){
                for (var k = this.userList[i].validators[j].annotators.length - 1; k >= 0; --k) {
                  if (this.userList[i].validators[j].annotators[k].username == annoname) {
                    this.userList[i].validators[j].annotators.splice(k, 1);
                    this.annoName = "";
                  }
                }
              }
            }
          }
          else if (this.userList[i].project == projectname || this.userList[i].username == adminname) {
            this.userList.splice(i, 1);
            this.projectName = "";
            this.adminName = "";
          }
        }
        // this.saveUserListObj();
        this.deleteDialog = false;
      } catch (error) {
        console.log("Error:", error);
      }
    },
    saveAllUser: function () {
      var self = this;
      try {
        if (this.userList.length > 0) {          
          this.saveUserListObj();                   
        }
        else {
          this.addUserNotification = true;
          setTimeout(function () { self.addUserNotification = false; }, 1000);
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },
    saveScript: function (name, value) {
      try{
        for(let i=0; i<this.scripts.length; i++){
          if(name == this.scripts[i].scriptname){
            this.scripts[i].flag=value;
          }
        }

      }catch (error) {
        console.log("Error:", error);
      }
    },
    videoToFrames: function () {
      try{
        this.scripts=[];
        var div = document.createElement('div');
        var img = document.createElement('img');
        img.src = 'static/loading.gif';
        img.style.cssText = 'margin-top:20%;width:5%;height:10%;';
        div.style.cssText = 'width: 100%;height: 100%;top: 0px;left: 0px;position: fixed;display: block;opacity: 0.7;background-color: #fff;z-index: 99;text-align: center';
        div.appendChild(img);
        document.body.appendChild(div);
          this.$apollo
            .mutate({
                mutation: VIDEO_TO_FRAMES,
                variables: {
                  folderpath: this.folderpath,
                }
            })
            .then(data => {
              div.style.display = "none";
              this.isQueryError = false;
              this.folderpath= data.data.videoToFrames.path;
              this.totalFrame = data.data.videoToFrames.frames_count;
              let scriptList= data.data.videoToFrames.scripts_list;
              for(let i=0; i < scriptList.length; i++){
                this.scripts.push({
                  scriptname: scriptList[i],
                  flag: false
                });
              }
            }).catch(error => {
              div.style.display = "none";
              this.isQueryError = true;
              this.queryErrorResult = /:(.+)/.exec(error.message)[1];
          });
      }catch (error) {
        console.log("Error:", error);
      }
    },
    initProject: function () {
      try{
        if(this.availdays==0 || this.requiredays==0 || this.productivity==0
           || this.avgFrame==0 || this.totalFrame==0 || this.availannotator==0
            || this.requireannotator==0 || this.annoratio==0 || this.availvalidator==0){
              this.requiredParam = true;
        }
        else{
          this.isLoading=true;
          this.$apollo
            .mutate({
                mutation: INIT_PROJECT,
                variables: {
                  userid: this.userId,
                  projectType: this.projectType,
                  folderpath: this.folderpath,
                  divisionType: this.divisionType,
                  availdays: this.availdays,
                  requiredays: this.requiredays,
                  productivity: this.productivity,
                  avgFrame: this.avgFrame,
                  totalFrame: this.totalFrame,
                  availannotator: this.availannotator,
                  requireannotator: this.requireannotator,
                  annoratio: this.annoratio,
                  availvalidator: this.availvalidator,
                  scriptList: this.scripts,
                  conversionScripts: this.conversionScripts,
                  conversionScript: this.conversionScriptType,

                }
            })
            .then(data => {
              this.isLoading=false;
              this.isQueryError = false;
            }).catch(error => {
              this.isQueryError = true;
              this.queryErrorResult = /:(.+)/.exec(error.message)[1];
          });
          this.requiredParam = false;
        }
      }catch (error) {
        console.log("Error:", error);
      }
    },
    initProjectReport: function () {
      this.notifyReport = false;
      try{
        this.$apollo
          .mutate({
              mutation: INIT_PROJECT_REPORT,
              variables: {
                userid: this.userId,
              }
          })
          .then(data => {
            this.isQueryError = false;
            this.reportDetails= JSON.stringify(data.data.initProjectReport.text);
            this.notifyReport = true;
          }).catch(error => {
            this.isQueryError = true;
            this.queryErrorResult = /:(.+)/.exec(error.message)[1];

        });
      }catch (error) {
        console.log("Error:", error);
      }
    },
    getThemeMode: function() {
      this.isDarkMode = SettingService.getDarkMode();
    },
    getProjectConfig: function (value) {      
      try{         
        this.scripts=[];
        this.conversionScripts=[];       
        if(value != "No Selection"){
          var div = document.createElement('div');
          var img = document.createElement('img');
          img.src = 'static/loading.gif';
          img.style.cssText = 'margin-top:20%;width:5%;height:10%;';
          div.style.cssText = 'width: 100%;height: 100%;top: 0px;left: 0px;position: fixed;display: block;opacity: 0.7;background-color: #fff;z-index: 99;text-align: center';
          div.appendChild(img);
          document.body.appendChild(div);
          var projectId = 0;        
          for(var i=0; i<projectListId.length; i++){
              if(value == projectListId[i].type){
                  projectId = projectListId[i].id;
              }
          }
          this.$apollo
            .mutate({
                mutation: GET_PROJECT_CONFIG_MUTATION,
                variables: {
                  projectid: projectId,
                }
            })
            .then(data => {   
              div.style.display = "none";                
              this.isQueryError = false;
              if(data.data.getProjectConfig == null){
                this.folderpath="";
                this.divisionType="";
                this.availdays=0;
                this.requiredays=0;
                this.productivity=0;
                this.avgFrame=0;
                this.totalFrame=0;
                this.availannotator=0;
                this.requireannotator=0;
                this.annoratio=0;
                this.availvalidator=0;
                this.conversionScriptType="";
                this.conversionScripts=[];
                this.scripts = [];
                this.flag = [];
              }
              else{                 
                this.folderpath=data.data.getProjectConfig.folderpath;
                this.divisionType=data.data.getProjectConfig.divisionType;
                this.availdays=data.data.getProjectConfig.availdays;
                this.requiredays=data.data.getProjectConfig.requiredays;
                this.productivity=data.data.getProjectConfig.productivity;
                this.avgFrame=data.data.getProjectConfig.avgFrame;
                this.totalFrame=data.data.getProjectConfig.totalFrame;
                this.availannotator=data.data.getProjectConfig.availannotator;
                this.requireannotator=data.data.getProjectConfig.requireannotator;
                this.annoratio=data.data.getProjectConfig.annoratio;
                this.availvalidator=data.data.getProjectConfig.availvalidator;
                this.conversionScriptType=data.data.getProjectConfig.conversionScript;
                var conversionScriptsArray=data.data.getProjectConfig.conversionScripts;
                this.conversionScripts[0] = "No Selection";
                for (var i = 0; i < conversionScriptsArray.length; i++) {            
                  this.conversionScripts.push(conversionScriptsArray[i]);
                } 
                var valscript = data.data.getProjectConfig.scriptList;
                for (var i = 0; i < valscript.length; i++) {
                  this.scripts.push({
                    scriptname: valscript[i].scriptname,
                    flag: valscript[i].flag
                  });
                  this.flag.push(valscript[i].flag);
                }
              }            
            }).catch(error => {
              div.style.display = "none";
              this.isQueryError = true;
              this.queryErrorResult = /:(.+)/.exec(error.message)[1];

          });
        }
        else{
          this.folderpath="";
          this.divisionType="";
          this.availdays=0;
          this.requiredays=0;
          this.productivity=0;
          this.avgFrame=0;
          this.totalFrame=0;
          this.availannotator=0;
          this.requireannotator=0;
          this.annoratio=0;
          this.availvalidator=0;
          this.conversionScriptType="";
          this.conversionScripts=[];
          this.scripts = [];
          this.flag = [];
        }
      }catch (error) {
        div.style.display = "none";
        console.log("Error:", error);
      }
    },
    editValCategory: function () { // toggle drop-down to textbox on double click
      try {
        if (this.isValCategoryEdit == true) {
          this.isValCategoryEdit = false;
        }
        else {
          this.isValCategoryEdit = true;
          this.valName = "";
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },

    editAnnoCategory: function () { // toggle drop-down to textbox on double click
      try {
        if (this.isAnnoCategoryEdit == true) {
          this.isAnnoCategoryEdit = false;
        }
        else {
          this.isAnnoCategoryEdit = true;
          this.annoName = "";
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },

    changeAnnoClass: function () {    // show annotators on the basis of validator selected in the dropdown
      try {
        this.annoName = "";
        this.annoList = [];
        let index = this.userList[0].validators.map(function(o) { return o.username; }).indexOf(this.valName);
        if (this.isValCategoryEdit == false) {
          this.isAnnoCategoryEdit = false;
        }
        if(index >=0){  
          for(let annoIndex in this.userList[0].validators[index].annotators){         
            this.annoList.push(this.userList[0].validators[index].annotators[annoIndex].username); // add validator's name to show in add project drop down
          }
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },

    closeAddObjDialog: function(){  // reset add new project dialog fields
      this.AddProjectDialog = false;
      this.required = false;
      this.isUserExist = false;
      this.valName = "";
      this.annoName = "";
    },
    addComponentField(){       
      this.componentLists.push(null);
      setTimeout(function() {       
      let selectPipelineDiv = document.getElementById("pipeline-fields-container");
      selectPipelineDiv.scrollTop = selectPipelineDiv.scrollHeight; }, 100);
    },
    updateComponentField(index,value){
      // let index = this.componentLists.length-1;
      this.componentLists[index]=value; 
    },
    searchComponents(){
      this.pipelineExecuteDialog = true ;      
    },
    // executePipeline(){
    //   let self = this
    //   console.log("Pipeline Executed");
    //   setTimeout(function() {    
    //     console.log("function Run")   
    //     self.pipelineExecuteDialog = true }, 2000);
    //   setTimeout(function() {    
    //     console.log("function Run")   
    //     self.pipelineExecuteDialog = false }, 6000);
    // },
    executePipeline: function(){
      // let apiData = {  
      //   projectId:this.mainProjectId,
      //   schedulerType:this.schedulerType,
      //   time:this.schedulerTime,
      //   frequency:this.schedulerFrequency,
      //   sourceBucket:this.sourceBucketName,
      //   sourcePath:this.sourcePath,
      //   destBucket:this.destBucketName,
      //   destPath:this.destPath,
      //   fileType:this.fileTypeSelected,
      //   projectName:this.selectProject,
      //   divisonType:this.divisionType,
      //   daysRequired:this.daysRequired,
      //   avgObjectPerFrame:this.avgObject,
      //   annotatorsAvailable:this.annoAvailable,
      //   ratio:this.ratioAVV,
      //   daysAvailable:this.daysAvailable,
      //   productivity:this.productivityField,
      //   frameCount:this.noOfFrames,
      //   annotatorRequired:this.annoRequired,
      //   validatorAvailable:this.valAvaialable,
      //   conversionScript:this.conversionScript,
      //   pipelineSequence:this.componentLists,
      // };
      let apiData = { 
        userId: this.userId, 
        projectId:this.mainProjectId,
        schedulerType: "HOURS",
        time: "10",
        frequency: "34",
        sourceBucket: "nat-data-source",
        sourcePath: "",
        destBucket: "nat-data-source1",
        destPath: "",
        fileType: ["MF4", "JPG", "mp4"],
        projectName: "",
        divisonType: "",
        daysRequired: 0,
        avgObjectPerFrame: 2,
        annotatorsAvailable: 0,
        ratio: 0,
        daysAvailable: 4,
        productivity: 4,
        frameCount: 8,
        annotatorRequired: 0,
        validatorAvailable: 0,
        conversionScript: "",
        pipelineSequence: ["extractor_initiate", "model_initiate", "attributes_initiate", "nat_json_initiate", "distributor_initiate"]
      };
//      axios.post(this.lauchPipelineURL,apiData,{headers: {
//        'Access-Control-Allow-Origin': '*',
//      }})
//      .then(response => this.updateProcessStatus(response.data.status))
//      .catch(error => {
//        // this.isQueryError = true;
//        // this.queryErrorResult = /:(.+)/.exec(error.message)[1];
//      });
      this.updateProcessStatus('success')
    },
    updateProcessStatus: function(status){
      if(status == "success"){
        this.getAcknowledgement();
        this.isDisableExecution = true;
      }
      else{
        this.isDisableExecution = false;
      }
    },
    getPipelineStatus: function () {
      if (this.isDisableExecution) {
          try{
            this.isDisableExecution = false;
            this.isExecutionSuccessful = true;
//            alert('Pipeline finished successfully')

            this.$apollo
              .mutate({
                mutation: ACKNOWLEDGMENT_DATA_PIPELINE,
                variables: {
                  projectid: this.mainProjectId
                }
              })
              .then(data => {
                let pipelineStatus = JSON.parse(data.data.acknowledgeDataPipeline.acknowledge);
                if(pipelineStatus.components_running_status == false){
                  axios.post(this.stopPipelineURL,{headers: {
                    'Access-Control-Allow-Origin': '*',
                  }})
                  .then(response => this.isDisableExecution = false)
                  .catch(error => {
                    // this.isQueryError = true;
                    // this.queryErrorResult = /:(.+)/.exec(error.message)[1];
                  });
                }
              }).catch(error => {
                  this.isQueryError = true;
                  this.queryErrorResult = /:(.+)/.exec(error.message)[1];
              });
          }catch (error) {
            console.log("Error:", error);
          }
      }
    },
    getAcknowledgement: function(){
      var self = this;
//      setInterval(function () { self.getPipelineStatus(); }, this.setPipelineInterval);
      setInterval(function () { self.getPipelineStatus(); }, 7000);
    },
  },
  beforeMount() {
    this.getThemeMode();
},
};

