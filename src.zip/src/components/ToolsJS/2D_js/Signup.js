import Appfooter from "../../../shared/Appfooter.vue";
import SignupModel from "../../../model/SignupModel.js";
import { SIGNUP } from "../../../constants/graphql";
import SettingService from "../../../services/SettingService.js";



export default {
  name: "Signup",
  props: [],
  components: {
    Appfooter
  },
  data() {
    return SignupModel; // Moved to model SignupModel
  },  
  methods: {
    callLogin: function () {
      this.$router.push({ name: 'login' });
    },
    changeSecurityQuestion (event) {
      this.selectedSecurityQuestion = event;
    },
    registerUser: function (firstname,lastname,username,password,contact,securityQuestion,securityAnswer) {
      try {     
        if (this.captcha != null){
          `This condition is for the situation when user press 
          submit button without entering any value in captcha input box.`
          this.matchCaptcha();
        }  
        
        if(this.isPasswordSame == false && this.firstname != "" 
          && this.username != "" && this.password != "" 
          && this.confirmpassword != "" && this.captcha != "" 
          // && this.authPIN != "" 
          && securityQuestion != "" && securityAnswer != "" && this.isCaptchaMatch == true && this.passwordWeak == false 
          && this.iscontactlength==true && this.contactint==true && this.lastnameerror ==true && this.firstnameerror ==true && this.passwordLength == false 
          && this.firstnameLength == false && this.lastnameLength == false && this.userLength == false && this.usernameType == false && this.passwordError == false 
          && this.answerError == false 
          // && this.authPinErrorMsg == false && this.isAuthPINSame == true 
          && this.sequentialVal == false ){
          this.showError = false;
          var div = document.createElement('div');
          var img = document.createElement('img');
          img.src = 'static/loading.gif';
          img.style.cssText = 'margin-top:20%;width:5%;height:10%;';
          div.style.cssText = 'width: 100%;height: 100%;top: 0px;left: 0px;position: fixed;display: block;opacity: 0.7;background-color: #fff;z-index: 99;text-align: center';
          div.appendChild(img);
          document.body.appendChild(div);
          this.$apollo
            .mutate({
              mutation: SIGNUP,
              variables: {
                username:username,
                password:password,
                first_name:firstname,
                last_name:lastname,
                mobile_number:contact,
                role:"ANNOTATOR",
                security_question: securityQuestion,
                security_answer: securityAnswer,
                // auth_pin: this.authPIN,//added captcha
                auto_captcha:this.captcha,
                user_captcha:this.captcha_code,
              }
            })
            .then(data => {     
              div.style.display = "none";        
              this.isUserRegistered = data.data.signup.newuser;
              if(this.isUserRegistered == false){
                this.isUserRegisteredconfirm = true;
                // var self = this;
                // setTimeout(function () { self.isUserRegisteredconfirm = false; }, 1200);
                // setTimeout(function () { self.callLogin(); }, 1300);
              }
              else{
                this.isUserRegisteredconfirm = false;
                var self = this;
                setTimeout(function () { self.callLogin(); }, 3000);
              }
              this.isQueryError = false;
              this.userSave = true;
            }).catch(error => {
              div.style.display = "none";
              this.isQueryError = true;
              this.queryErrorResult = /:(.+)/.exec(error.message)[1];
          }); 
          
        }
        else{
          this.showError = true;
        }
      } catch (error) {
        div.style.display = "none";
        console.log("Error:", error);
      }
    },
    validatePassword: function(){
      try{
        var specialch = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]+/;
        if(/\s/.test(this.password) || (this.password.match(/[0-9]/g) || []).length == 0 || (this.password.match(/[a-z]/g) || []).length == 0 || (this.password.match(/[A-Z]/g) || []).length == 0  || !specialch.test(this.password)){
          this.passwordError = true;
        }
        else{
          this.passwordError = false;
          this.checkPasswordStrength();
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },
    checkPasswordStrength: function () {
      try{
        if(this.password.length < 8){
          this.passwordWeak = true;
          this.passwordStrong = false;
          this.passwordMedium = false;
          this.passwordLength = false;

        }
        else if(this.password.length == 8){
          this.passwordWeak = false;
          this.passwordStrong = false;
          this.passwordMedium = true;
          this.passwordLength = false;

        }
        else if(this.password.length < 13){
          this.passwordWeak = false;
          this.passwordStrong = true;
          this.passwordMedium = false;
          this.passwordLength = false;

        }
        else{
          this.passwordWeak = false;
          this.passwordMedium = false;
          this.passwordStrong = false;
          this.passwordLength = true;
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },
    newCaptcha: function () {
      this.captcha = null;
      try{
        var Numb1, Numb2, Numb3, Numb4;     
        Numb1 = (Math.ceil(Math.random() * 10)-1).toString();
        Numb2 = (Math.ceil(Math.random() * 10)-1).toString();
        Numb3 = (Math.ceil(Math.random() * 10)-1).toString();
        Numb4 = (Math.ceil(Math.random() * 10)-1).toString();
        
        this.captcha_code = Numb1 + Numb2 + Numb3 + Numb4;
      } catch (error) {
        console.log("Error:", error);
      }
    },
    matchCaptcha: function () {
      try{
        if(this.captcha == this.captcha_code){
            this.isCaptchaMatch = true;
        }
        else{
          this.isCaptchaMatch = false;
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },
    comparePassword: function () {
      try{
        if(this.password == this.confirmpassword){
            this.isPasswordSame = false;
        }
        else{
          this.isPasswordSame = true;
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },
    usernameValidate: function () {
      var usernameVal = /[0-9!@#$%~`^&*()+\=\[\]{};':"\\|,<>\/?]+/;
      try{
        if(this.username.length < 6 || this.username.length > 20 ){
            this.userLength = true;
        }
        else{
          this.userLength = false;
        }
        if (/\s/.test(this.username) || ((this.username.split("_").length - 1) > 1) || ((this.username.split("-").length - 1) > 1) || ((this.username.split(".").length - 1) > 1) || usernameVal.test(this.username.toString())){
          this.usernameType = true;
        }else {
          this.usernameType = false;
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },
    firstnameError: function () {
      var specialch = /[0-9!@#$%~`^&*()_+\-=\[\]{};':"\\|,.<>\/?]+/;
      try{
        if(specialch.test(String(this.firstname)) || /\s/.test(this.firstname)){
            this.firstnameerror = false;
            this.firstnameLength = false;
        }
        else{
          this.firstnameerror = true;
          this.firstnameLength = false;
        }
        if(this.firstname.length < 1){
          this.firstnameerror = true;
          this.firstnameLength = true;
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },
    lastnameError: function () {
      var specialch = /[0-9!@#$ ~`%^&*()_+\-=\[\]{};':"\\|,.<>\/?]+/;
 
      try{
        if(specialch.test(String(this.lastname)) || /\s/.test(this.lastname)){
            this.lastnameerror = false;
            this.lastnameLength = false;
        }
        else{
          this.lastnameerror = true;
          this.lastnameLength = false;
        }
        if(this.lastname.length < 1){
          this.lastnameerror = true;
          this.lastnameLength = true;
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },
    // authPinError: function () {
    //   var specialch = /^\d{6}$/;
    //   try{
    //     if(specialch.test(this.authPIN)){
    //       this.authPinErrorMsg = false;
    //     }        
    //     else if(this.authPIN.length !== 6){
    //       this.authPinErrorMsg = true;
    //     }
    //     else{
    //       this.authPinErrorMsg = true;
    //     }

    //     //Sequential Validation
    //     let s = this.authPIN
    //     this.sequentialVal = true;
    //     for(var i = 0; i < s.length - 1; i++) {
    //       if ((s[i+1] - s[i]) != 1) {
    //         this.sequentialVal = false;
    //         break;
    //       }
    //     }

    //     //Repeating Validation
    //     for(var i in s) 
    //     if (+s[+i+1] == +s[i] && +s[+i+2] == +s[i]) {
    //           this.sequentialVal = true;
    //         }
    //   } catch (error) {
    //     console.log("Error:", error);
    //   }
    // },
    // compareAuthPIN: function() {
    //   try{
    //     if(this.authPIN == this.confirmAuthPIN){
    //         this.isAuthPINSame = true;
    //     }
    //     else{
    //       this.isAuthPINSame = false;
    //     }
    //   } catch (error) {
    //     console.log("Error:", error);
    //   }

    // },
    validateAnswer: function(){
      try{
        if(!this.securityAnswer.replace(/\s/g, '').length){
          this.answerError = true;
        } else{
          this.answerError = false;
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },
    contactlength: function () {
      var phoneno = /^\d{10}$/;
      try{
        if(this.contact.length ==10 && this.contact.match(phoneno)){
            this.iscontactlength = true;
            this.contactint=true
        }
        else{
          this.iscontactlength = false;
          this.contactint=false;
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },
    hideErrorMessage: function () {
      try{
        if(this.isPasswordSame == false && this.firstname != "" && this.lastname != "" 
          && this.username != "" && this.password != ""
          && this.confirmpassword != "" 
          // && this.authPIN != "" && this.isAuthPINSame != "" && this.sequentialVal!= "" 
          && this.securityQuestion != ""){
            this.showError = false;
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },
    getThemeMode: function() {
      this.isDarkMode = SettingService.getDarkMode();
    },
    clearFields: function () {
      try{
            this.firstname = "";
            this.lastname = "";
            this.username = "";
            this.password = "";
            this.contact = "";
            this.confirmpassword = "";
            this.captcha = "";
            this.passwordWeak = false;
            this.passwordMedium = false;
            this.passwordStrong = false;
            this.isPasswordSame = false;
            this.showError = false;
            this.isCaptchaMatch = true;
            this.securityQuestion = "";
            this.securityAnswer = "";
            this.usernameType = false;
            this.firstnameLength = false;
            this.isUserRegistered = false;
            this.passwordError = false;
            this.authPinErrorMsg = false;
            this.isAuthPINSame = true;
            this.sequentialVal = false;
            this.answerError = false;
      } catch (error) {
        console.log("Error:", error);
      }
    },
  },
  mounted: function () {
    this.clearFields();
    this.newCaptcha();
  }, 
  beforeMount() {
    this.getThemeMode();
  },
};
