import axios from "axios";
import accuracyObject from "@/components/accuracyObject";
import accuracyVideo from "@/components/accuracyVideo";
import changesVideo from "@/components/changesVideo";
import changesObject from "@/components/changesObject";
import HomeModel from "../../../model/HomeModel.js";
import { ALL_VIDEO_QUERY } from "../../../constants/graphql";
import { GET_METRICS_DATA_MUTATION } from "../../../constants/graphql";
import { GET_PRODUCTIVITY_METRICS_QUERY } from "../../../constants/graphql";
import { GET_PERFORMANCE_CHART } from "../../../constants/graphql";
import { ALL_IMAGE_DETAIL_MUTATION } from "../../../constants/graphql";
import { GET_OBJ_USER_MUTATION } from "../../../constants/graphql";
import Appfooter from "../../../shared/Appfooter.vue";
import HomeHeader from "../../../shared/HomeHeader.vue";
import * as d3 from "d3";
import SettingService from "../../../services/SettingService.js";
import { ticks } from "d3";

export default {
  name: "Dashboard",
  components: {
    accuracyObject,
    accuracyVideo,
    changesVideo,
    changesObject,
    "home-header": HomeHeader,
    "app-footer": Appfooter,
  },
  props: [],

  data() {
    var temp = null;
    if (HomeModel.role == "ADMIN") {
      temp = ["Productivity", "Accuracy", "Performance"];
    } else if (HomeModel.role == "VALIDATOR") {
      temp = ["Productivity", "Performance"];
    }
    return {
      activeTab: "Productivity",
      tabs: temp,
      allValidator: "All",
      allAccuracy: "All",
      validators: [{ text: this.allValidator }],
      annotators: [{ text: this.allValidator }],
      accuracyVideoList: [{ text: this.allAccuracy }],
      accuracyFramesList: [{ text: this.allAccuracy }],
      title:
        '<img src="../assets/icon/logo2.png" style="width:100px;margin-top: 12px;cursor:pointer;"/>',
      e1: { id: 0, text: "Select Video" },
      e2: null,
      e3: null,
      e4: null,
      e5: "All",
      selectedValidator: ["All"],
      selectedAnnotator: [],
      selectedAccuracy: null,
      menu: false,
      menu1: false,
      selectedVideo: null,

      videos: [{ id: 0, text: "Select Video" }],
      frames: [{ text: "Select Frame" }],
      Users: [
        { text: "Select User" },
        { text: "Annotator-1" },
        { text: "Annotator-2" },
        { text: "Annotator-3" },
      ],
      Type: [
        { text: "Select Metrics" },
        { text: "Productivity" },
        { text: "Accuracy" },
      ],
      userId: "",
      role: "ADMIN",
      username: "",
      projectId: 0,
      videoId: [],
      selectedVideo: null,
      homePath: "/home",
      dashbordPath: "/dashboard",
      settingPath: "/setting",
      userPath: "/userList",
      // endDate: new Date().toISOString().substr(0, 10),
      startDate: new Date(new Date().setDate(new Date().getDate() - 7))
        .toISOString()
        .substr(0, 10),
      // startDate: "2022-02-01",
      endDate: new Date().toISOString().substr(0, 10),
      currentDate: new Date().toISOString().substr(0, 10),
      // startDate: "2022-02-01",
      msg: null,
      msgAccuracy: null,
      msgBurnDown: null,
      isQueryError: false,
      queryErrorResult: "",
      isDarkMode: "",
      selectedTab: "productivity",
      validatorList: [],
      selectedValidator: ["All"],
      selectedValidatorList: [],
      selectedAnnotatorList: [],
      validator_name: [],
      accuracyModalDate: '',
      accuracyUsersData: "",
      accuracyUserDate_ModelKeys: [],
      accuracyModalClass: "",
      accuracyModalClassList: [],
      filteredClass: "",
      annoNameList: [],
      performanceChartData: [],
    };
  },
  computed: {
    disableBack: function() {
      try {
        history.pushState(null, null, location.href);
        window.onpopstate = function() {
          history.go(1);
        };
      } catch (error) {
        console.log("Error:", error);
      }
    },

    getUserId() {
      try {
        this.userId = SettingService.getSelectedUserId();
        this.username = SettingService.getSelectedUserName();
        this.role = SettingService.getSelectedUserRole();
        this.projectId = SettingService.getSelectedProject();
      } catch (error) {
        console.log("Error:", error);
      }
    },
  },
  apollo: {
    getUserListObj: {
      query: GET_OBJ_USER_MUTATION,
      variables() {
        const userid = SettingService.getSelectedUserId();
        const proId = SettingService.getSelectedProject();
        return {
          userid,
          proId,
        };
      },
      result({ data, loader, networkStatus }) {
        // get the users data for the project
        let userData = data.getUserListObj.userList;

        if (this.role == "VALIDATOR") {
          //Get Annotator List of Logged In Validator
          let validatorsList = userData[0].validators;
          let currentValData = validatorsList.filter(
            (selectValName) => selectValName.username === this.username
          );
          let currentValAnno = currentValData.map((item) => item.annotators);
          this.annoNameList = currentValAnno[0].map(
            (element) => element.username
          );
        }

        this.validatorsData = {};
        this.annotatorsData = {};
        this.dateData = {};
        if (userData != null) {
          // count of the total admins
          let adminCount = userData.length;
          for (var i = 0; i < adminCount; i++) {
            // count of the validators
            let validatorCount = userData[i].validators.length;
            // initialize the validators list
            this.validatorList = [];
            // initialize the annotators dict for validator annotator mapping
            this.annotatordict = {};
            for (var j = 0; j < validatorCount; j++) {
              // total annotators under the validator
              let annotatorCount = userData[i].validators[j].annotators.length;
              // validator name
              let valname = userData[i].validators[j].username;
              // to be shown in the graph can be initialized here saving the for loop
              this.validatorsData[valname] = {
                modify: 0,
                deleted: 0,
                added: 0,
                validator: valname,
              };
              // insert into the validator list the validator name
              this.validatorList.push(valname);
              // annotator dict key intialization with validator as key
              this.annotatordict[valname] = valname;
              this.annotatorsData[valname] = {};
              this.annotatorsData[valname][valname] = {
                modify: 0,
                deleted: 0,
                added: 0,
                annotator: valname,
              };
              this.dateData[valname] = {};
              for (var k = 0; k < annotatorCount; k++) {
                // insert into the annotator list corresponding to a validator
                let annotator_name =
                  userData[i].validators[j].annotators[k].username;
                this.annotatordict[annotator_name] = valname;
                this.dateData[annotator_name] = {};
                // to be shown in the graph can be initialized here saving the for loop
                this.annotatorsData[valname][annotator_name] = {
                  modify: 0,
                  deleted: 0,
                  added: 0,
                  annotator: annotator_name,
                };
              }
            }
          }
        }
      },
    },
  },

  methods: {
    refreshProductivity() {
      this.hideChartContainers("annotator-chart-container--admin");
      this.hideChartContainers("annotator-date-chart-container--admin");
      try {
        var div = document.createElement("div");
        var img = document.createElement("img");
        img.src = "static/loading.gif";
        img.style.cssText = "margin-top:20%;width:5%;height:10%;";
        div.style.cssText =
          "width: 100%;height: 100%;top: 0px;left: 0px;position: fixed;display: block;opacity: 0.7;background-color: #fff;z-index: 99;text-align: center";
        div.appendChild(img);
        document.body.appendChild(div);
        this.$apollo
          .mutate({
            mutation: GET_PRODUCTIVITY_METRICS_QUERY,
            variables: {
              userid: this.userId,
              username: this.username,
              userrole: this.role,
              from_date: this.startDate,
              to_date: this.endDate,
              pid: this.projectId,
              active_tab: this.activeTab,
            },
          })
          .then((data) => {
            let users_data = JSON.parse(
              data.data.getProductivityMetrics.productivity_data
            );
            div.style.display = "none";

            //Productivity Chart Call
            self = this;
            this.renderProductivityChart(users_data, null);

            //Performance Chart Call
            this.refreshPerformanceChart(users_data);
          })
          .catch((error) => {
            div.style.display = "none";
            this.isQueryError = true;
            this.queryErrorResult = /:(.+)/.exec(error.message)[1];
          });
      } catch (error) {
        div.style.display = "none";
        console.log("Error:", error);
      }
    },
    refreshAccuracy() {
      try {
        var div = document.createElement("div");
        var img = document.createElement("img");
        img.src = "static/loading.gif";
        img.style.cssText = "margin-top:20%;width:5%;height:10%;";
        div.style.cssText =
          "width: 100%;height: 100%;top: 0px;left: 0px;position: fixed;display: block;opacity: 0.7;background-color: #fff;z-index: 99;text-align: center";
        div.appendChild(img);
        document.body.appendChild(div);
        this.$apollo
          .mutate({
            mutation: GET_PRODUCTIVITY_METRICS_QUERY,
            variables: {
              userid: this.userId,
              username: this.username,
              userrole: this.role,
              from_date: this.startDate,
              to_date: this.endDate,
              pid: this.projectId,
              active_tab: 'Accuracy',
            },
          })
          .then((data) => {
            this.accuracyUsersData = [];
            self = this;
            // Get Accuracy Data
            let users_data = JSON.parse(
              data.data.getProductivityMetrics.productivity_data
            );
            this.accuracyUsersData = users_data;

            // Get Model Date Data
            var accuracyUserDate_Model = users_data.model_data;

            // Get Model Date Keys
            try {
              if(accuracyUserDate_Model){
                this.accuracyUserDate_ModelKeys = Object.keys(
                  accuracyUserDate_Model
                  );
              }
            } catch (error) {
              console.log("Error:", error);
            }
            this.accuracyModalDate = this.accuracyUserDate_ModelKeys[0];

            div.style.display = "none";

            this.renderDateAccuracyChart(this.accuracyUsersData),
            this.renderClassAccuracyChart(this.accuracyUsersData)
          })
          .catch((error) => {
            div.style.display = "none";
            this.isQueryError = true;
            this.queryErrorResult = /:(.+)/.exec(error.message)[1];
          });
      } catch (error) {
        div.style.display = "none";
        console.log("Error:", error);
      }
    },
    refreshPerformanceChart(users_data) {
      try {
        $("#project-health-chart").hide();
        d3.selectAll("#project-health-chart > *").remove();
    
        if(users_data == null){
          $("#project-health-chart_no-data-text-container").css('display','flex');
        }else{
          $("#project-health-chart").show();
          $("#project-health-chart_no-data-text-container").css('display','none');

        //Object Calculation

        //Function to convert userdata to Profermance Chart Data
        function convert(obj) {
          let temp = {};
          let arr = [];
          for (let i = 0; i < obj.length; i++) {
            let d = obj[i].date;
            if (!temp[d]) {
              temp[d] = obj[i];
            } else {
              let add = temp[d].added + obj[i].added;
              let del = temp[d].deleted + obj[i].deleted;
              let res = add - del;
              temp[d].added = res;
            }
          }
          // [{date:"25-05-2022", value:"0"}
          for (let [key, val] of Object.entries(temp)) {
            let d = val.date;
            let v = val.added;
            let newObj = { date: d, value: v };
            arr.push(newObj);
          }
          return arr;
        }

        this.performanceChartData = convert(users_data);
        this.renderPerformanceChart(this.performanceChartData);
      }
      } catch (error) {
        console.log("Error:", error);
      }
    },

    renderValidatorsChart(data, anno_data, dateData) {
      $("#validator-chart-container--admin").addClass("show");

      // data = [{"modify":10, "deleted":100, "added":90, "validator":"a"}, {"modify":10, "deleted":100, "added":90, "validator":"b"}]
      // d3.select("#chart").attr("height", "400");
      // set the dimensions and margins of the graph
      var margin = { top: 20, right: 30, bottom: 40, left: 60 },
        width = 600 - margin.left - margin.right,
        height = 200 - margin.top - margin.bottom;

      var chart = $("#validator-chart"),
        aspect = chart.width() / chart.height(),
        container = chart.parent();
      $(window)
        .on("resize", function() {
          var targetWidth = container.width();
          chart.attr("width", targetWidth);
          chart.attr("height", Math.round(targetWidth / aspect));
        })
        .trigger("resize");

      // create tooltip element
      const tooltip = d3
        .select("body")
        .append("div")
        .attr("class", "d3-tooltip")
        .style("position", "absolute")
        .style("z-index", "10")
        .style("display", "none")
        .style("padding", "5px")
        .style("background", "var(--dialog-box-background)")
        .style("border-radius", "5px")
        .style("color", "var(--dark-gray)");
      // .text("a simple tooltip");

      // append the svg object to the body of the page
      var svg = d3
        .select("#validator-chart")
        .append("svg")
        .attr("width", width + margin.left + margin.right)
        .attr("height", height + margin.top + margin.bottom)
        .append("g")
        .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

      var subgroups = ["deleted", "modify", "added"];
      var groups = data.map(function(el) {
        return el.validator;
      });

      var wrap = function() {
        var self = d3.select(this),
          textLength = self.node().getComputedTextLength(),
          text = self.text();
        while (textLength > 30 && text.length > 0) {
          text = text.slice(0, -1);
          self.text(text + "...");
          textLength = self.node().getComputedTextLength();
        }
      };

      // Add X axis
      var x = d3
        .scaleBand()
        .domain(groups)
        .range([0, width])
        .padding([0.2]);
      svg
        .append("g")
        .attr("transform", "translate(0," + height + ")")
        .attr("style", "font-size: 6px")
        .call(d3.axisBottom(x).tickSizeOuter(0))
        .selectAll("text")
        .attr("dx", "-1.5em")
        .attr("dy", "-0.5em")
        .attr("transform", "rotate(-65)")
        .style("text-anchor", "end")
        .style("cursor", "default")
        .on("mouseover", function(d, i) {
          tooltip.html(x.domain()[i]).style("display", "block");
          d3.select(this)
            .attr("opacity", "1")
            .on("mousemove", function() {
              tooltip
                .style("top", event.pageY - 10 + "px")
                .style("left", event.pageX + 10 + "px");
            })
            .on("mouseout", function() {
              tooltip.html(``).style("display", "none");
              d3.select(this).attr("opacity", "1");
            });
        })
        .each(wrap);

      //Find Y Axis Max Value
      let yAxisMaxVal = [];
      for (let i = 0; i < data.length; i++) {
        let sum = data[i].added + data[i].deleted + data[i].modify;
        yAxisMaxVal.push(sum);
      }

      // Add Y axis
      var y = d3
        .scaleLinear()
        .domain([
          0,
          200 +
            d3.max(yAxisMaxVal, function(d) {
              return d;
            }),
        ])
        // .domain( [0, 30000])
        .range([height, 0]);
      svg
        .append("g")
        .call(d3.axisLeft(y))
        .attr("style", "font-size: 6px")
        .selectAll("text")
        .style("cursor", "default");

      // color palette = one color per subgroup
      var color = d3
        .scaleOrdinal()
        .domain(subgroups)
        .range(["rgb(230,165,151)", "rgb(248,222,157)", "rgb(169,202,241)"]);

      //stack the data? --> stack per subgroup
      var stackedData = d3.stack().keys(subgroups)(data);

      self = this;
      svg
        .append("g")
        .selectAll("g")
        .data(stackedData)
        .enter()
        .append("g")
        .on("click", function() {
          renderAnnotatorChart(
            d3.event.path[0].__data__.data.validator,
            anno_data,
            dateData
          ),
            self.hideChartContainers("annotator-date-chart-container--admin");
        })
        .attr("fill", function(d) {
          return color(d.key);
        })
        .selectAll("rect")
        .data(function(d) {
          return d;
        })
        .enter()
        .append("rect")
        .attr("x", function(d) {
          return x(d.data.validator);
        })
        .attr("y", function(d) {
          return y(d[1]);
        })
        .attr("height", function(d) {
          return y(d[0]) - y(d[1]);
        })
        .attr("width", x.bandwidth())
        .on("mouseover", function(d, i) {
          tooltip.html(`${d[1] - d[0]}`).style("display", "block");
          d3.select(this).attr("opacity", "1");
        })
        .on("mousemove", function() {
          tooltip
            .style("top", event.pageY - 10 + "px")
            .style("left", event.pageX + 10 + "px");
        })
        .on("mouseout", function() {
          tooltip.html(``).style("display", "none");
          d3.select(this).attr("opacity", "1");
        });

      function renderAnnotatorChart(validator_name, anno_data, dateData) {
        $("#annotator-chart-container--admin").addClass("show");

        d3.selectAll("#annotator-chart > *").remove();
        let annotators_data = [];
        let groups = [];
        for (var key in anno_data[validator_name]) {
          annotators_data.push(anno_data[validator_name][key]);
          groups.push(key);
          $("#selected-validator-name").html(validator_name);
        }

        // set the dimensions and margins of the graph
        // set the dimensions and margins of the graph
        var margin = { top: 20, right: 30, bottom: 40, left: 60 },
          width = 600 - margin.left - margin.right,
          height = 200 - margin.top - margin.bottom;

        var chart2 = $("#annotator-chart"),
          aspect = chart2.width() / chart.height(),
          container = chart2.parent();
        $(window)
          .on("resize", function() {
            var targetWidth = container.width();
            chart.attr("width", targetWidth);
            chart.attr("height", Math.round(targetWidth / aspect));
          })
          .trigger("resize");

        // append the svg object to the body of the page
        var svg = d3
          .select("#annotator-chart")
          .append("svg")
          .attr("width", width + margin.left + margin.right)
          .attr("height", height + margin.top + margin.bottom)
          .append("g")
          .attr(
            "transform",
            "translate(" + margin.left + "," + margin.top + ")"
          );

        var subgroups = ["deleted", "modify", "added"];

        // Add X axis
        var x = d3
          .scaleBand()
          .domain(groups)
          .range([0, width])
          .padding([0.2]);
        svg
          .append("g")
          .attr("transform", "translate(0," + height + ")")
          .attr("style", "font-size: 6px")
          .call(d3.axisBottom(x).tickSizeOuter(0))
          .selectAll("text")
          .attr("dx", "-1.5em")
          .attr("dy", "-0.5em")
          .attr("transform", "rotate(-65)")
          .style("text-anchor", "end")
          .style("cursor", "default")
          .each(wrap)
          .on("mouseover", function(d, i) {
            tooltip.html(x.domain()[i]).style("display", "block");
            d3.select(this)
              .attr("opacity", "1")
              .on("mousemove", function() {
                tooltip
                  .style("top", event.pageY - 10 + "px")
                  .style("left", event.pageX + 10 + "px");
              })
              .on("mouseout", function() {
                tooltip.html(``).style("display", "none");
                d3.select(this).attr("opacity", "1");
              });
          });

        //Find Y Axis Max Value
        let yAxisMaxVal = [];
        for (let i = 0; i < annotators_data.length; i++) {
          let sum =
            annotators_data[i].added +
            annotators_data[i].deleted +
            annotators_data[i].modify;
          yAxisMaxVal.push(sum);
        }

        // Add Y axis
        var y = d3
          .scaleLinear()
          .domain([
            0,
            200 +
              d3.max(yAxisMaxVal, function(d) {
                return d;
              }),
          ])
          .range([height, 0]);
        svg
          .append("g")
          .call(d3.axisLeft(y))
          .attr("style", "font-size: 6px")
          .selectAll("text")
          .style("cursor", "default");

        // color palette = one color per subgroup
        var color = d3
          .scaleOrdinal()
          .domain(subgroups)
          .range(["rgb(230,165,151)", "rgb(248,222,157)", "rgb(169,202,241)"]);

        //stack the data? --> stack per subgroup
        var stackedData = d3.stack().keys(subgroups)(annotators_data);

        // Show the bars
        svg
          .append("g")
          .selectAll("g")
          // Enter in the stack data = loop key per key = group per group
          .data(stackedData)
          .enter()
          .append("g")
          .on("click", function() {
            date_chart(d3.event.path[0].__data__.data.annotator, dateData);
          })
          .attr("fill", function(d) {
            return color(d.key);
          })
          .selectAll("rect")
          // enter a second time = loop subgroup per subgroup to add all rectangles
          .data(function(d) {
            return d;
          })
          .enter()
          .append("rect")
          .attr("x", function(d) {
            return x(d.data.annotator);
          })
          .attr("y", function(d) {
            return y(d[1]);
          })
          .attr("height", function(d) {
            return y(d[0]) - y(d[1]);
          })
          .attr("width", x.bandwidth())
          .on("mouseover", function(d, i) {
            tooltip.html(`${d[1] - d[0]}`).style("display", "block");
            d3.select(this).attr("opacity", "1");
          })
          .on("mousemove", function() {
            tooltip
              .style("top", event.pageY - 10 + "px")
              .style("left", event.pageX + 10 + "px");
          })
          .on("mouseout", function() {
            tooltip.html(``).style("display", "none");
            d3.select(this).attr("opacity", "1");
          });

        function date_chart(anno_name, dateData) {
          $("#annotator-date-chart-container--admin").addClass("show");

          d3.selectAll("#annotator-date-chart > *").remove();
          try {
            let date_data = [];
            let groups = [];
            for (var key in dateData[anno_name]) {
              date_data.push(dateData[anno_name][key]);
              groups.push(key);
              $("#selected-annotator-name").html(anno_name);
            }
            // d3.select("#chart3").attr("height", "400");
            // set the dimensions and margins of the graph
            // set the dimensions and margins of the graph
            var margin = { top: 20, right: 30, bottom: 40, left: 60 },
              width = 600 - margin.left - margin.right,
              height = 200 - margin.top - margin.bottom;

            var chart3 = $("#annotator-date-chart"),
              aspect = chart3.width() / chart3.height(),
              container = chart.parent();
            $(window)
              .on("resize", function() {
                var targetWidth = container.width();
                chart3.attr("width", targetWidth);
                chart3.attr("height", Math.round(targetWidth / aspect));
              })
              .trigger("resize");

            // append the svg object to the body of the pageaccu
            var svg = d3
              .select("#annotator-date-chart")
              .append("svg")
              .attr("width", width + margin.left + margin.right)
              .attr("height", height + margin.top + margin.bottom)
              .append("g")
              .attr(
                "transform",
                "translate(" + margin.left + "," + margin.top + ")"
              );

            var subgroups = ["deleted", "modify", "added"];

            // Add X axis
            var x = d3
              .scaleBand()
              .domain(groups)
              .range([0, width])
              .padding([0.2]);

            svg
              .append("g")
              .attr("transform", "translate(0," + height + ")")
              .attr("style", "font-size: 6px")
              .call(d3.axisBottom(x).tickSizeOuter(0))
              .selectAll("text")
              .attr("dx", "-1.5em")
              .attr("dy", "-0.5em")
              .attr("transform", "rotate(-65)")
              .style("text-anchor", "end")
              .style("cursor", "default")
              .on("mouseover", function(d, i) {
                tooltip.html(x.domain()[i]).style("display", "block");
                d3.select(this)
                  .attr("opacity", "1")
                  .on("mousemove", function() {
                    tooltip
                      .style("top", event.pageY - 10 + "px")
                      .style("left", event.pageX + 10 + "px");
                  })
                  .on("mouseout", function() {
                    tooltip.html(``).style("display", "none");
                    d3.select(this).attr("opacity", "1");
                  });
              });

            //Find Y Axis Max Value
            let yAxisMaxVal = [];
            for (let i = 0; i < date_data.length; i++) {
              let sum =
                date_data[i].added + date_data[i].deleted + date_data[i].modify;
              yAxisMaxVal.push(sum);
            }

            // Add Y axis
            var y = d3
              .scaleLinear()
              .domain([
                0,
                200 +
                  d3.max(yAxisMaxVal, function(d) {
                    return d;
                  }),
              ])
              .range([height, 0]);

            svg
              .append("g")
              .call(d3.axisLeft(y))
              .attr("style", "font-size: 6px")
              .selectAll("text")
              .style("cursor", "default");

            // color palette = one color per subgroup
            var color = d3
              .scaleOrdinal()
              .domain(subgroups)
              .range([
                "rgb(230,165,151)",
                "rgb(248,222,157)",
                "rgb(169,202,241)",
              ]);

            //stack the data? --> stack per subgroup
            var stackedData = d3.stack().keys(subgroups)(date_data);

            // Show the bars
            svg
              .append("g")
              .selectAll("g")
              // Enter in the stack data = loop key per key = group per group
              .data(stackedData)
              .enter()
              .append("g")
              .attr("fill", function(d) {
                return color(d.key);
              })
              .selectAll("rect")
              // enter a second time = loop subgroup per subgroup to add all rectangles
              .data(function(d) {
                return d;
              })
              .enter()
              .append("rect")
              .attr("x", function(d) {
                return x(d.data.date);
              })
              .attr("y", function(d) {
                return y(d[1]);
              })
              .attr("height", function(d) {
                return y(d[0]) - y(d[1]);
              })
              .attr("width", x.bandwidth())
              .on("mouseover", function(d, i) {
                tooltip.html(`${d[1] - d[0]}`).style("display", "block");
                d3.select(this).attr("opacity", "1");
              })
              .on("mousemove", function() {
                tooltip
                  .style("top", event.pageY - 10 + "px")
                  .style("left", event.pageX + 10 + "px");
              })
              .on("mouseout", function() {
                tooltip.html(``).style("display", "none");
                d3.select(this).attr("opacity", "1");
              });
          } catch (error) {
            console.log("Error:", error);
          }
        }
      }
    },
    //Shown on Valideror Screen
    renderAnnotatorChart(validator_name, anno_data, dateData) {
      // Wrap Axis Text
      var wrap = function() {
        var self = d3.select(this),
          textLength = self.node().getComputedTextLength(),
          text = self.text();
        while (textLength > 30 && text.length > 0) {
          text = text.slice(0, -1);
          self.text(text + "...");
          textLength = self.node().getComputedTextLength();
        }
      };

      // create tooltip element
      const tooltip = d3
        .select("body")
        .append("div")
        .attr("class", "d3-tooltip")
        .style("position", "absolute")
        .style("z-index", "10")
        .style("display", "none")
        .style("padding", "5px")
        .style("background", "var(--dialog-box-background)")
        .style("border-radius", "5px")
        .style("color", "var(--dark-gray)");
      // .text("a simple tooltip");

      $("#annotator-chart-container--admin").addClass("show");
      // d3.selectAll("#chart2 > *").remove();
      let annotators_data = [];
      let groups = [];
      for (var key of this.selectedAnnotator) {
        annotators_data.push(anno_data[validator_name][key]);
        groups.push(key);
      }

      // set the dimensions and margins of the graph
      var margin = { top: 20, right: 30, bottom: 40, left: 60 },
        width = 600 - margin.left - margin.right,
        height = 200 - margin.top - margin.bottom;

      // append the svg object to the body of the page
      var svg = d3
        .select("#annotator-chart")
        .append("svg")
        .attr("width", width + margin.left + margin.right)
        .attr("height", height + margin.top + margin.bottom)
        .append("g")
        .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

      var subgroups = ["modify", "deleted", "added"];

      // Add X axis
      var x = d3
        .scaleBand()
        .domain(groups)
        .range([0, width])
        .padding([0.2]);
      svg
        .append("g")
        .attr("style", "font-size: 6px")
        .attr("transform", "translate(0," + height + ")")
        .call(d3.axisBottom(x).tickSizeOuter(0))
        .selectAll("text")
        .attr("dx", "-1.5em")
        .attr("dy", "-0.5em")
        .attr("transform", "rotate(-65)")
        .style("text-anchor", "end")
        .style("cursor", "default")
        .each(wrap)
        .on("mouseover", function(d, i) {
          tooltip.html(x.domain()[i]).style("display", "block");
          d3.select(this)
            .attr("opacity", "1")
            .on("mousemove", function() {
              tooltip
                .style("top", event.pageY - 10 + "px")
                .style("left", event.pageX + 10 + "px");
            })
            .on("mouseout", function() {
              tooltip.html(``).style("display", "none");
              d3.select(this).attr("opacity", "1");
            });
        });

      //Find Y Axis Max Value
      let yAxisMaxVal = [];
      for (let i = 0; i < annotators_data.length; i++) {
        let sum =
          annotators_data[i].added +
          annotators_data[i].deleted +
          annotators_data[i].modify;
        yAxisMaxVal.push(sum);
      }

      // Add Y axis
      // 2500 needs to be dynamic
      var y = d3
        .scaleLinear()
        .domain([
          0,
          200 +
            d3.max(yAxisMaxVal, function(d) {
              return d;
            }),
        ])
        .range([height, 0]);
      svg
        .append("g")
        .call(d3.axisLeft(y))
        .selectAll("text")
        .style("cursor", "default");

      // color palette = one color per subgroup
      var color = d3
        .scaleOrdinal()
        .domain(subgroups)
        .range(["rgb(230,165,151)", "rgb(248,222,157)", "rgb(169,202,241)"]);

      //stack the data? --> stack per subgroup
      var stackedData = d3.stack().keys(subgroups)(annotators_data);

      // Show the bars
      svg
        .append("g")
        .selectAll("g")
        // Enter in the stack data = loop key per key = group per group
        .data(stackedData)
        .enter()
        .append("g")
        .on("click", function() {
          date_chart(d3.event.path[0].__data__.data.annotator, dateData);
        })
        .attr("fill", function(d) {
          return color(d.key);
        })
        .selectAll("rect")
        // enter a second time = loop subgroup per subgroup to add all rectangles
        .data(function(d) {
          return d;
        })
        .enter()
        .append("rect")
        .attr("x", function(d) {
          return x(d.data.annotator);
        })
        .attr("y", function(d) {
          return y(d[1]);
        })
        .attr("height", function(d) {
          return y(d[0]) - y(d[1]);
        })
        .attr("width", x.bandwidth())
        .on("mouseover", function(d, i) {
          tooltip.html(`${d[1] - d[0]}`).style("display", "block");
          d3.select(this).attr("opacity", "1");
        })
        .on("mousemove", function() {
          tooltip
            .style("top", event.pageY - 10 + "px")
            .style("left", event.pageX + 10 + "px")
            .on("mouseout", function() {
              tooltip.html(``).style("display", "none");
              d3.select(this).attr("opacity", "1");
            });
        });

      function date_chart(anno_name, dateData) {
        $("#annotator-date-chart-container--admin").addClass("show");
        d3.selectAll("#annotator-date-chart > *").remove();
        try {
          let date_data = [];
          let groups = [];
          for (var key in dateData[anno_name]) {
            date_data.push(dateData[anno_name][key]);
            groups.push(key);
            $("#selected-annotator-name").html("anno_name");
          }
          d3.select("#annotator-date-chart").attr("height", "400");
          // set the dimensions and margins of the graph
          var margin = { top: 20, right: 30, bottom: 40, left: 60 },
            width = 600 - margin.left - margin.right,
            height = 200 - margin.top - margin.bottom;

          var chart = $("#annotator-date-chart"),
            aspect = chart.width() / chart.height(),
            container = chart.parent();
          $(window)
            .on("resize", function() {
              var targetWidth = container.width();
              chart.attr("width", targetWidth);
              chart.attr("height", Math.round(targetWidth / aspect));
            })
            .trigger("resize");

          // append the svg object to the body of the page
          var svg = d3
            .select("#annotator-date-chart")
            .append("svg")
            .attr("width", width + margin.left + margin.right)
            .attr("height", height + margin.top + margin.bottom)
            .append("g")
            .attr(
              "transform",
              "translate(" + margin.left + "," + margin.top + ")"
            );

          var subgroups = ["modify", "deleted", "added"];

          // Add X axis
          var x = d3
            .scaleBand()
            .domain(groups)
            .range([0, width])
            .padding([0.2]);

          svg
            .append("g")
            .attr("transform", "translate(0," + height + ")")
            .call(d3.axisBottom(x).tickSizeOuter(0))
            .selectAll("text")
            .attr("dx", "-1.5em")
            .attr("dy", "-0.5em")
            .attr("transform", "rotate(-65)")
            .style("text-anchor", "end")
            .style("cursor", "default")
            .on("mouseover", function(d, i) {
              tooltip.html(x.domain()[i]).style("display", "block");
              d3.select(this)
                .attr("opacity", "1")
                .on("mousemove", function() {
                  tooltip
                    .style("top", event.pageY - 10 + "px")
                    .style("left", event.pageX + 10 + "px");
                })
                .on("mouseout", function() {
                  tooltip.html(``).style("display", "none");
                  d3.select(this).attr("opacity", "1");
                });
            });

          //Find Y Axis Max Value
          let yAxisMaxVal = [];
          for (let i = 0; i < date_data.length; i++) {
            let sum =
              date_data[i].added + date_data[i].deleted + date_data[i].modify;
            yAxisMaxVal.push(sum);
          }

          // Add Y axis
          // 2500 needs to be dynamic
          var y = d3
            .scaleLinear()
            .domain([
              0,
              200 +
                d3.max(yAxisMaxVal, function(d) {
                  return d;
                }),
            ])
            .range([height, 0]);

          svg
            .append("g")
            .call(d3.axisLeft(y))
            .selectAll("text")
            .style("cursor", "default");

          // color palette = one color per subgroup
          var color = d3
            .scaleOrdinal()
            .domain(subgroups)
            .range([
              "rgb(230,165,151)",
              "rgb(248,222,157)",
              "rgb(169,202,241)",
            ]);

          //stack the data? --> stack per subgroup
          var stackedData = d3.stack().keys(subgroups)(date_data);

          // Show the bars
          svg
            .append("g")
            .selectAll("g")

            // Enter in the stack data = loop key per key = group per group
            .data(stackedData)
            .enter()
            .append("g")
            .attr("fill", function(d) {
              return color(d.key);
            })
            .selectAll("rect")
            // enter a second time = loop subgroup per subgroup to add all rectangles
            .data(function(d) {
              return d;
            })
            .enter()
            .append("rect")
            .attr("x", function(d) {
              return x(d.data.date);
            })
            .attr("y", function(d) {
              return y(d[1]);
            })
            .attr("height", function(d) {
              return y(d[0]) - y(d[1]);
            })
            .attr("width", x.bandwidth())
            .on("mouseover", function(d, i) {
              tooltip.html(`${d[1] - d[0]}`).style("display", "block");
              d3.select(this).attr("opacity", "1");
            })
            .on("mousemove", function() {
              tooltip
                .style("top", event.pageY - 10 + "px")
                .style("left", event.pageX + 10 + "px");
            })
            .on("mouseout", function() {
              tooltip.html(``).style("display", "none");
              d3.select(this).attr("opacity", "1");
            });
        } catch (error) {
          console.log("Error:", error);
        }
      }
    },
    renderProductivityChart(csv, input) {
      try {
        this.msg = "";
        d3.selectAll("#validator-chart > *").remove();
        d3.selectAll("#annotator-chart > *").remove();
        d3.selectAll("#annotator-date-chart > *").remove();
        // this.$apollo.queries.getUserListObj.refetch();


        for (var idx in csv) {
          this.validatorsData[this.annotatordict[csv[idx]["username"]]][
            "modify"
          ] =
            this.validatorsData[this.annotatordict[csv[idx]["username"]]][
              "modify"
            ] + csv[idx]["modify"];


          this.validatorsData[this.annotatordict[csv[idx]["username"]]][
            "deleted"
          ] =
            this.validatorsData[this.annotatordict[csv[idx]["username"]]][
              "deleted"
            ] + csv[idx]["deleted"];
          this.validatorsData[this.annotatordict[csv[idx]["username"]]][
            "added"
          ] =
            this.validatorsData[this.annotatordict[csv[idx]["username"]]][
              "added"
            ] + csv[idx]["added"];
          this.annotatorsData[this.annotatordict[csv[idx]["username"]]][
            csv[idx]["username"]
          ]["modify"] =
            this.annotatorsData[this.annotatordict[csv[idx]["username"]]][
              csv[idx]["username"]
            ]["modify"] + csv[idx]["modify"];
          this.annotatorsData[this.annotatordict[csv[idx]["username"]]][
            csv[idx]["username"]
          ]["deleted"] =
            this.annotatorsData[this.annotatordict[csv[idx]["username"]]][
              csv[idx]["username"]
            ]["deleted"] + csv[idx]["deleted"];
          this.annotatorsData[this.annotatordict[csv[idx]["username"]]][
            csv[idx]["username"]
          ]["added"] =
            this.annotatorsData[this.annotatordict[csv[idx]["username"]]][
              csv[idx]["username"]
            ]["added"] + csv[idx]["added"];
          this.dateData[csv[idx]["username"]][csv[idx]["date"]] = {
            modify: csv[idx]["modify"],
            deleted: csv[idx]["deleted"],
            added: csv[idx]["added"],
            date: csv[idx]["date"],
          };
        }
        let validatorData = [];
        if (this.role == "ADMIN") {
          //Selected Validator List for Frontend -- Admin
          this.selectedValidatorList = this.selectedValidator;

          if (this.selectedValidator.length > 0) {
            //Selected Validator Arrey
            var id = this.selectedValidator.indexOf("All"); // 2
            if (id != -1) {
              this.selectedValidatorList = this.selectedValidator.splice(id, 1);
            }
            for (var key of this.selectedValidator) {
              validatorData.push(this.validatorsData[key]);
            }
          } else {
            for (var key in this.validatorsData) {
              validatorData.push(this.validatorsData[key]);
            }
          }

          this.renderValidatorsChart(
            validatorData,
            this.annotatorsData,
            this.dateData
          );
        }

        //Selected Annotator List for Frontend -- Admin
        let annotatorsData = [];
        if (this.role == "VALIDATOR") {
          this.selectedAnnotatorList = this.selectedAnnotator.toString();
          if( this.selectedAnnotator.length < 1){
            this.selectedAnnotator = this.annoNameList;
          }
            //Selected Validator Arrey
            for (var key of this.selectedAnnotator) {
            annotatorsData.push(this.annotatorsData[key]);
            }
          this.renderAnnotatorChart(
            this.username,
            this.annotatorsData,
            this.dateData
          );
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },

    renderDateAccuracyChart(users_data) {
      $("#accuracy-chart--date").hide();
      d3.selectAll("#accuracy-chart--date > *").remove();
  
      try {
      if(users_data.model_data == undefined){
        $("#accuracy-chart--date_no-data-text-container").css('display','flex');
      }else{
        $("#accuracy-chart--date").show();
        $("#accuracy-chart--date_no-data-text-container").css('display','none');

        // this.accuracyModalDate = this.accuracyUserDate_ModelKeys[0];

        // Clear SVG
        this.clearSVG();

        // Get Data of Selected Date
        var accuracyUserDate_Model = users_data.model_data;

        // d3.select("#chart5").attr("height", "800")
        let width = 400;
        let height = 400;
        let margin = 0;

        // The radius of the pieplot is half the width or half the height (smallest one). I subtract a bit of margin.
        var radius = Math.min(width, height) / 2 - margin;

      // create tooltip element
      const tooltip = d3
      .select("body")
      .append("div")
      .attr("class", "d3-tooltip")
      .style("position", "absolute")
      .style("z-index", "10")
      .style("display", "none")
      .style("padding", "5px")
      .style("background", "var(--dialog-box-background)")
      .style("border-radius", "5px")
      .style("color", "var(--dark-gray)");

        // append the svg object to the div called 'my_dataviz'
        var svg = d3
          .select("#accuracy-chart--date")
          // .append("svg")
          //   .attr("width", width)
          //   .attr("height", height)

          .append("g")
          .attr("transform", "translate(" + width / 2 + "," + height / 2 + ")");

        var chart = $("#accuracy-chart--date"),
          aspect = chart.width() / chart.height(),
          container = chart.parent();
        $(window)
          .on("resize", function() {
            var targetWidth = container.width();
            chart.attr("width", targetWidth);
            chart.attr("height", Math.round(targetWidth / aspect));
          })
          .trigger("resize");

        //Chart Data
        var data = accuracyUserDate_Model[this.accuracyModalDate];

        // set the color scale
        var color = d3
          .scaleOrdinal()
          .domain([
            "wrong_classifications",
            "wrong_coordinates",
            "total_detections",
          ])
          .range([
            "rgba(248,222,157,1)",
            "rgba(204, 74, 46,1)",
            "rgba(82, 148, 226, 1)",
          ]);

        // Compute the position of each group on the pie:
        var pie = d3
          .pie()
          .sort(null) // Do not sort group by size
          .value(function(d) {
            return d.value;
          });
        var data_ready = pie(d3.entries(data));

        // The arc generator
        var arc = d3
          .arc()
          .innerRadius(radius * 0.5) // This is the size of the donut hole
          .outerRadius(radius * 0.8);

        // Another arc that won't be drawn. Just for labels positioning
        var outerArc = d3
          .arc()
          .innerRadius(radius * 0.9)
          .outerRadius(radius * 0.9);

        // Build the pie chart: Basically, each part of the pie is a path that we build using the arc function.
        svg
          .selectAll("allSlices")
          .data(data_ready)
          .enter()
          .append("path")
          .attr("d", arc)
          .attr("fill", function(d) {
            return color(d.data.key);
          })
          .attr("stroke", "white")
          .style("stroke-width", "2px")
          .style("opacity", 1)
          .on("mouseover", function(d, i) {
            tooltip.html(`${d.value}`).style("display", "block");
            d3.select(this).attr("opacity", "1");
          })
          .on("mousemove", function() {
            tooltip
              .style("top", event.pageY - 10 + "px")
              .style("left", event.pageX + 10 + "px");
          })
          .on("mouseout", function() {
            tooltip.html(``).style("display", "none");
            d3.select(this).attr("opacity", "1");
          });

        // svg.append("svg:text")
        // .attr("dy", ".35em")
        // .attr("text-anchor", "middle")
        // .attr("font-size","40")
        // .attr("fill","#fff")
        // .text("60%");
      }
      } catch (error) {
        console.log("Error:", error);
      }
    },
    renderClassAccuracyChart(users_data) {
    try {
        $("#accuracy-chart--class").hide();
        d3.selectAll("#accuracy-chart--class > *").remove();
    
        if(users_data.class_data == undefined){
          $("#accuracy-chart--class_no-data-text-container").css('display','flex');
        }else{
          $("#accuracy-chart--class").show();
          $("#accuracy-chart--class_no-data-text-container").css('display','none');

        // Get Model Class Data
        var accuracyUserDate_Class = users_data.class_data;

        // Filtering Class Data Based On Selected Date
        var filteredClass = accuracyUserDate_Class.filter(
          (selectedDate) => selectedDate.date === this.accuracyModalDate
        );

        // Get Class List from Filtered Class Data
        this.accuracyModalClassList = filteredClass.map(function(
          filteredClass
        ) {
          return filteredClass.class_name;
        });

        //Index of Selected Class
        if(this.accuracyModalClass == undefined){
          var selectedClassIndex = 0;
        }else{
          var selectedClassIndex = this.accuracyModalClassList.indexOf(this.accuracyModalClass);
        }

        this.accuracyModalClass = this.accuracyModalClassList[selectedClassIndex];

        // Filtering Data Based On Selected Class for Perticular Date
        var filteredClassData = filteredClass.filter(
          (selectedClass) =>
            selectedClass.class_name === this.accuracyModalClass
        );

        // Clear SVG
        d3.selectAll("#accuracy-chart--class > *").remove();

        // Get Data of Selected Date
        var accuracyUserClass_Model = users_data.class_data;

        let width = 400;
        let height = 400;
        let margin = 0;

        // The radius of the pieplot is half the width or half the height (smallest one). I subtract a bit of margin.
        var radius = Math.min(width, height) / 2 - margin;

      // create tooltip element
      const tooltip = d3
      .select("body")
      .append("div")
      .attr("class", "d3-tooltip")
      .style("position", "absolute")
      .style("z-index", "10")
      .style("display", "none")
      .style("padding", "5px")
      .style("background", "var(--dialog-box-background)")
      .style("border-radius", "5px")
      .style("color", "var(--dark-gray)");

        // append the svg object to the div called 'my_dataviz'
        var svg = d3
          .select("#accuracy-chart--class")
          // .append("svg")
          //   .attr("width", width)
          //   .attr("height", height)
          .append("g")
          .attr("transform", "translate(" + width / 2 + "," + height / 2 + ")")

        var chart = $("#accuracy-chart--class"),
          aspect = chart.width() / chart.height(),
          container = chart.parent();
        $(window)
          .on("resize", function() {
            var targetWidth = container.width();
            chart.attr("width", targetWidth);
            chart.attr("height", Math.round(targetWidth / aspect));
          })
          .trigger("resize");

        //Chart Data
        var data = filteredClassData[0];

        // set the color scale
        var color = d3
          .scaleOrdinal()
          .domain([
            "wrong_classifications",
            "wrong_coordinates",
            "total_detections",
          ])
          .range([
            "rgba(248,222,157,1)",
            "rgba(204, 74, 46,1)",
            "rgba(82, 148, 226, 1)",
          ]);
          
        // Compute the position of each group on the pie:
        var pie = d3
          .pie()
          .sort(null) // Do not sort group by size
          .value(function(d) {
            return d.value;
          });
        var data_ready = pie(d3.entries(data));

        // The arc generator
        var arc = d3
          .arc()
          .innerRadius(radius * 0.5) // This is the size of the donut hole
          .outerRadius(radius * 0.8);

        // Another arc that won't be drawn. Just for labels positioning
        var outerArc = d3
          .arc()
          .innerRadius(radius * 0.9)
          .outerRadius(radius * 0.9);

        // Build the pie chart: Basically, each part of the pie is a path that we build using the arc function.
        svg
          .selectAll("allSlices")
          .data(data_ready)
          .enter()
          .append("path")
          .attr("d", arc)
          .attr("fill", function(d) {
            return color(d.data.key);
          })
          .attr("stroke", "white")
          .style("stroke-width", "2px")
          .style("opacity", 1)
          .on("mouseover", function(d, i) {
            tooltip.html(`${d.value}`).style("display", "block");
            d3.select(this).attr("opacity", "1");
          })
          .on("mousemove", function() {
            tooltip
              .style("top", event.pageY - 10 + "px")
              .style("left", event.pageX + 10 + "px");
          })
          .on("mouseout", function() {
            tooltip.html(``).style("display", "none");
            d3.select(this).attr("opacity", "1");
          });
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },

    getThemeMode: function() {
      this.isDarkMode = SettingService.getDarkMode();
    },
    //Function to find max value of y-axis of Performance Chart
    yAxisMaxVal(obj) {
      let temp = {};
      let arr = [];
      for (let i = 0; i < obj.length; i++) {
        let sum = obj[i].added + obj[i].deleted + obj[i].modify;
        arr.push(sum);
      }
      return arr;
    },

    renderPerformanceChart(performanceChartData) {
      try {
        // set the dimensions and margins of the graph
        const margin = { top: 10, right: 30, bottom: 30, left: 60 },
          width = 600 - margin.left - margin.right,
          height = 200 - margin.top - margin.bottom;

        // append the svg object to the body of the page
        var svg = d3
          .select("#project-health-chart")
          .append("svg")
          .attr("width", width + margin.left + margin.right)
          .attr("height", height + margin.top + margin.bottom)
          .append("g")
          .attr("transform", `translate(${margin.left},${margin.top})`);

        var chart = $("#project-health-chart"),
          aspect = chart.width() / chart.height(),
          container = chart.parent();
        $(window)
          .on("resize", function() {
            var targetWidth = container.width();
            chart.attr("width", targetWidth);
            chart.attr("height", Math.round(targetWidth / aspect));
          })
          .trigger("resize");

        // Now I can use this dataset:
        // let custData = [{date:"25-05-2022", value:"100"},{date:"26-05-2022", value:"450"},{date:"27-05-2022", value:"550"},{date:"28-05-2022", value:"650"},{date:"29-05-2022", value:"350"},]
        let xAxisData = performanceChartData.map((item) => item.date);

        // Add X axis --> it is a date format
        var x = d3
          .scaleBand()
          .domain(xAxisData)
          .range([0, width])
          .padding([1]);

        svg
          .append("g")
          .attr("transform", "translate(0," + height + ")")
          .call(d3.axisBottom(x));

        // Add Y axis
        const y = d3
          .scaleLinear()
          .domain([
            0,
            200 +
              d3.max(performanceChartData, function(d) {
                return d.value;
              }),
          ])
          .range([height, 0]);

        svg.append("g").call(d3.axisLeft(y));

        svg
          .append("line")
          .datum(performanceChartData)
          .style("stroke", "#cc4a2e")
          .style("stroke-width", 1.5)
          .attr("x1", 0)
          .attr("y1", 20)
          .attr("x2", width)
          .attr("y2", 20);

        // Add the line
        svg
          .append("path")
          .datum(performanceChartData)
          .attr("fill", "none")
          .attr("stroke", "rgba(82, 148, 226, 1)")
          .attr("stroke-width", 1.5)
          .attr(
            "d",
            d3
              .line()
              .x((d) => x(d.date))
              .y((d) => y(d.value))
          );

        // Add the points
        svg
          .append("g")
          .selectAll("dot")
          .data(performanceChartData)
          .join("circle")
          .attr("cx", (d) => x(d.date))
          .attr("cy", (d) => y(d.value))
          .attr("r", 3)
          .attr("fill", "rgba(82, 148, 226, 1)");
      } catch (error) {
        console.log("Error:", error);
      }
    },

    changeVal(e) {
      try {
        d3.csv("static/productivity1.csv")
          .then(d => this.renderProductivityChart(d, e))
      } catch (error) {
        console.log("Error:", error);
      }
    },
    //-----------------------------------------------
    changeVideo(e) {
      try {
        if (e == "All") {
          d3.csv("static/accuracy.csv").then((d) =>
            this.renderDateAccuracyChart(d)
          );
        } else {
          this.selectedVideo = e;
          d3.csv("static/accuracy.csv").then((d) =>
            this.renderDateAccuracyChart(d, e)
          );
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },
    changeFrame(e) {
      try {
        if (e == "All") {
          d3.csv("static/accuracy.csv").then((d) =>
            this.renderDateAccuracyChart(d, this.selectedVideo)
          );
        } else {
          d3.csv("static/accuracy.csv").then((d) =>
            this.renderDateAccuracyChart(d, this.selectedVideo, e)
          );
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },
    clearSVG() {
      d3.selectAll("#validator-chart > *").remove();
    },
    selectProductivity() {
      this.accuracyModalClass = "";
      this.accuracyModalDate = "";
      this.refreshProductivity();
    },
    selectAccuracy() {
      this.clearSVG();
      this.refreshAccuracy();
      this.refreshProductivity();
    },
    hideChartContainers(selectdBoxId) {
      $("#" + selectdBoxId).addClass("hide");
      $("#" + selectdBoxId).removeClass("show");
    },
    selectAllValToggle() {
      if (
        this.selectedValidator.includes("All") &&
        this.selectedValidator.length !== this.validatorList.length
      ) {
        this.selectedValidator = this.validatorList;
      } else if (this.selectedValidator.length == this.validatorList.length) {
      } else if (
        this.selectedValidator.length > 0 &&
        this.selectedValidator.length !== this.validatorList.length
      ) {
        // this.selectedValidator = ["All"]
        // this.selectedValidator = [];
      }
    },
  },
  // apollo: {
  //   getMetricsDetails: {
  //     query: GET_METRICS_DATA_MUTATION,
  //     variables() {
  //       const videoid = 0;
  //       return {
  //         videoid
  //       };
  //     },
  //     result({ data }) {
  //       d3.csv("static/accuracy.csv")
  //         .then(d => this.renderDateAccuracyChart(d))
  //     }
  //   },
  // },
  beforeMount() {
    this.getThemeMode();
  },

  mounted: function() {
    this.refreshProductivity();
  },
};
