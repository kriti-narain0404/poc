import { OBJ_LOGIN_USER } from "../../../constants/graphql";
import Appfooter from "../../../shared/Appfooter.vue";
import LoginModel from "../../../model/LoginModel.js";
import SettingService from "../../../services/SettingService.js";

export default {
  name: "Login",
  props: [],
  components: {
    Appfooter
  },
  data() {
    return LoginModel; // Moved to model LoginModel
  },
  methods: {
    callSignup: function () {
        this.$router.push({ name: 'signup' })
    },
    callForget: function () {
      this.$router.push({ name: 'forget' })
    },
    saveUserData: function (username, password, link) {
      this.userData = [];
      this.noProjectAssigned = false;
      this.required = false;
      this.$apollo
        .mutate({
          mutation: OBJ_LOGIN_USER,
          variables: {
            username: username,
            password: password,
          }
        })
        .then(data => {
          this.isQueryError = false;
          this.userData = data.data.loginUser;
          this.isUsersignedUp = false;
          if (this.userData != null) {
            this.isUsersignedUp = data.data.loginUser.userid > 0;
            if (this.userData['last_project']==null){
              this.noProjectAssigned = true;
            }
            else{
            if(this.isUsersignedUp) {
                // this.userData['plan'] = this.userData['userid'];
                this.userId = this.userData['userid'];
                this.username = this.userData['username'];
                this.role = this.userData['role'];
                this.projectId = this.userData['last_project'];
                this.accessToken = this.userData['access_token'];
                let authUserPin = this.userData['auth_pin'];
                sessionStorage.setItem('accessToken', this.accessToken);
                sessionStorage.setItem('login', this.username);
                sessionStorage.setItem('authUserPin', authUserPin);
                SettingService.setSelectedUserId(this.userId);
                SettingService.setSelectedProject(this.projectId);  
                SettingService.setSelectedUserName(this.username);
                SettingService.setSelectedUserRole(this.role);  
                if(this.userData['auth_pin'] == "Locked"){
                  this.isAccountLocked = true;
                }else{
                  this.$router.push({ path: "authPin" });
                }
            }
            else{ 
              this.required = false;
            }
            } 
          }
          else {
            this.required = true;
          }
        }).catch(error => {
          this.isQueryError = true;
          this.queryErrorResult = /:(.+)/.exec(error.message)[1];
        });
    },

    login: function (username, password, link) {
      try {
        if (this.username != "" && this.password != "") {
          this.saveUserData(username, password, link);
        } else {
          return;
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },


    logout: function () {
      this.isLoggedIn = false;
    },
    annotator: function (link) {
      this.userData = {
        plan: 3,
        username: "Annotator",
        role: "ANNOTATOR"
      };
      try {
        this.$router.push({ path: link, query: { ...this.userData } });
        location.reload();
      } catch (error) {
        console.log("Error:", error);
      }
    },

    validator: function (link) {
      this.userData = {
        plan: 2,
        username: "Validator",
        role: "VALIDATOR"
      };
      try {
        this.$router.push({ path: link, query: { ...this.userData } });
        location.reload();
      } catch (error) {
        console.log("Error:", error);
      }
    },
    admin: function (link) {
      this.userData = {
        plan: 1,
        username: "Admin",
        role: "ADMIN"
      };
      try {
        this.$router.push({ path: link, query: { ...this.userData } });
        location.reload();
      } catch (error) {
        console.log("Error:", error);
      }
    },
    clearFields: function () {
      try{
            this.password = "";
            this.username = "";
            this.isUsersignedUp = true;
            this.required = false;
            this.isAccountLocked = false;
      } catch (error) {
        console.log("Error:", error);
      }
    },
    themeModeToggle: function(){
      this.isDarkMode =!this.isDarkMode;
      SettingService.setDarkMode(this.isDarkMode);
      console.log(this.isDarkMode);
    },
    getThemeMode: function() {
      this.isDarkMode = SettingService.getDarkMode();
    },
  },
  mounted: function () {
    this.clearFields();
  }, 
  beforeMount() {
    this.getThemeMode();
  },
};
