import { ALL_VIDEO_VALIDATOR_MUTATION } from "../../../constants/graphql";
import { GET_VIDEO_DATA_MUTATION } from "../../../constants/graphql";
import { VIDEO_ASSIGNE_MUTATION } from "../../../constants/graphql";
import { VIDEO_ASSIGNE_VALIDATOR_MUTATION } from "../../../constants/graphql";
import { VIDEO_PUSH_MUTATION } from "../../../constants/graphql";
import { USERS_ASSIGNATION_LIST } from "../../../constants/graphql";
import { DELETE_VIDEO_MUTATION } from "../../../constants/graphql";
import { ACCEPT_REJECT_VIDEO_MUTATION } from "../../../constants/graphql";
import { REOPEN_VIDEO } from "../../../constants/graphql";
import { UPDATE_SETTINGS } from "../../../constants/graphql";
import HomeHeader from "../../../shared/HomeHeader.vue";
import Appfooter from "../../../shared/Appfooter.vue";
import SettingService from "../../../services/SettingService.js";
import HomeModel from "../../../model/HomeModel.js";
import { ALL_VIDEO_MUTATION } from "../../../constants/graphql";
import { GET_PREVIEW_VIDEO_DATA_MUTATION } from "../../../constants/graphql";
import { SAVE_PREVIEW_VIDEO_DATA_MUTATION } from "../../../constants/graphql";
import { ALL_PROJECT_MUTATION } from "../../../constants/graphql";

var slideshow, frameCount, activeEvent, taskName, targ, offsetX, canvas;
var coordX,
  ratioPxBySeconds,
  changedIndex,
  changedSecIndex,
  drag = false;
var timeStart = 0;
var timeEnd = 0;
var timeStamp = [];
var pos = [];

export default {
  name: "home",
  components: {},
  props: ["project"],
  components: {
    "home-header": HomeHeader,
    "app-footer": Appfooter,
  },
  data() {
    this.finalselectedList = [];
    return HomeModel; // Moved to model HomeModel
  },
  computed: {
    pages() {
      return this.pagination.rowsPerPage
        ? Math.ceil(this.mainItems.length / this.pagination.rowsPerPage)
        : 0;
    },
  },

  methods: {
    stopPreview(event) {
      this.Videosopen = false;
      this.PreviewImgOpen = false;
      this.videoPlay = "Play";
      this.searchImageId = 0;
      clearInterval(slideshow);
    },

    goToEditor: function() {
      this.toolView(
        this.selectedId,
        this.selectedName,
        this.selectedVideoType,
        this.searchImageId
      );
    },

    callInbox: function() {
      this.mainItems = [];
      this.Videosopen = false;
      this.videoPlay = "Play";
      if (this.PreviewImgOpen == false) {
        clearInterval(slideshow);
      }
      history.pushState(null, null, location.href);
      window.onpopstate = function() {
        history.go(1);
      };
      this.userId = SettingService.getSelectedUserId();
      this.username = SettingService.getSelectedUserName();
      this.role = SettingService.getSelectedUserRole();
      if (performance.navigation.type == performance.navigation.TYPE_RELOAD) {
        this.projectId = -1;
      } else {
        this.projectId = SettingService.getSelectedProject();
      }
      this.getUserProject();
    },

    toolView: function(event, name, type, imageid) {
      try {
        var path;
        this.videoid = event;
        this.videoname = name;
        this.video_type = type;
        this.imageid = imageid;
        if (this.video_type == 0) {
          path = "/project/noesis_data";
        }
        if (this.video_type == 1) {
          path = "/editor_3d";
        }
        if (this.video_type == 2) {
          path = "/mask";
        }
        if (this.video_type == 3) {
          path = "/textEditor";
        }
        this.$router.push({
          path: path,
          query: {
            videoid: this.videoid,
            videoname: this.videoname,
            imageid: this.imageid,
            imagecount: this.imagecount,
            video_type: this.video_type,
          },
        });
        location.reload();
      } catch (error) {
        console.log("Error:", error);
      }
    },
    selectedVideo: function(event, id) {
      try {
        if (!event.target.checked) {
          this.count--;
          var finalindex = this.finalselectedList.indexOf(id);
          this.finalselectedList.splice(finalindex, 1);
        } else {
          this.count++;
          this.finalselectedList.push(id);
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },
    submitVideoList: function() {
      try {
        this.partialselectedList = [];
        for (var i = 0; i < this.mainItems.length; i++) {
          this.partialselectedList.push(this.mainItems[i].videoid);
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },

    getAnnoVideo: function() {
      try {
        this.mainItems = [];
        this.updatedMainitems = [];
        this.mainItems = SettingService.getAllVideo();
        for (var i = 0; i < this.mainItems.length; i++) {
          if (this.mainItems[i].video_type == 0) {
            this.updatedMainitems.push(this.mainItems[i]);
          }
        }
        this.submitVideoList();
      } catch (error) {
        console.log("Error:", error);
      }
    },
    finalSubmit: function() {
      try {
        var div = document.createElement("div");
        var img = document.createElement("img");
        img.src = "static/loading.gif";
        img.style.cssText = "margin-top:20%;width:5%;height:10%;";
        div.style.cssText =
          "width: 100%;height: 100%;top: 0px;left: 0px;position: fixed;display: block;opacity: 0.7;background-color: #fff;z-index: 99;text-align: center";
        div.appendChild(img);
        document.body.appendChild(div);
        this.$apollo
          .mutate({
            mutation: VIDEO_PUSH_MUTATION,
            variables: {
              userid: this.userId,
              username: this.username,
              interim_ids: this.partialselectedList,
              final_ids: this.finalselectedList,
            },
          })
          .then((data) => {
            div.style.display = "none";
            var self = this;
            this.isQueryError = false;
            if (data.data.pushVideo.count == 0) {
              this.noFilesSubmitted = true;
              setTimeout(function() {
                self.noFilesSubmitted = false;
                location.reload();
              }, 1000);
            } else {
              this.isSubmitSuccessful = true;
              this.totalModifiedFile = data.data.pushVideo.count;
              setTimeout(function() {
                self.isSubmitSuccessful = false;
              }, 1000);
              setTimeout(function() {
                location.reload();
              }, 1050);
            }
          })
          .catch((error) => {
            div.style.display = "none";
            this.isQueryError = true;
            this.queryErrorResult = /:(.+)/.exec(error.message)[1];
          });
      } catch (error) {
        console.log("Error:", error);
      }
    },
    deleteVideo: function(event) {
      try {
        this.videoId = event;
        var div = document.createElement("div");
        var img = document.createElement("img");
        img.src = "static/loading.gif";
        img.style.cssText = "margin-top:20%;width:5%;height:10%;";
        div.style.cssText =
          "width: 100%;height: 100%;top: 0px;left: 0px;position: fixed;display: block;opacity: 0.7;background-color: #fff;z-index: 99;text-align: center";
        div.appendChild(img);
        document.body.appendChild(div);
        this.$apollo
          .mutate({
            mutation: DELETE_VIDEO_MUTATION,
            variables: {
              videoid: this.newArray,
            },
          })
          .then((data) => {
            div.style.display = "none";
            this.isQueryError = false;
            location.reload();
          })
          .catch((error) => {
            div.style.display = "none";
            this.isQueryError = true;
            this.queryErrorResult = /:(.+)/.exec(error.message)[1];
          });
        this.deleteDialog = false;
        this.newArray = [];
      } catch (error) {
        div.style.display = "none";
        console.log("Error:", error);
      }
    },

    updateSettings: function() {
      try {
        this.$apollo
          .mutate({
            mutation: UPDATE_SETTINGS,
            variables: {
              userid: this.userId,
            },
          })
          .then((data) => {
            this.isQueryError = false;
          })
          .catch((error) => {
            this.isQueryError = true;
            this.queryErrorResult = /:(.+)/.exec(error.message)[1];
          });
        this.isSettingsUpdated = false;
      } catch (error) {
        console.log("Error:", error);
      }
    },
    videoAssign: function(event, id) {
      try {
        this.videoid = id;
        if (event.target.checked) {
          this.count++;
          this.newArray.push(id);
        } else {
          this.count--;
          var index = this.newArray.indexOf(id);
          this.newArray.splice(index, 1);
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },
    assignUserList: function() {
      try {
        this.$apollo
          .mutate({
            mutation: USERS_ASSIGNATION_LIST,
            variables: {
              userid: this.userId,
              role: this.role,
              projectId: this.projectId,
            },
          })
          .then((data) => {
            this.isQueryError = false;
            this.items = data.data.usersAssignationList.users;
          })
          .catch((error) => {
            this.isQueryError = true;
            this.queryErrorResult = /:(.+)/.exec(error.message)[1];
          });
      } catch (error) {
        console.log("Error:", error);
      }
    },
    assignVideo: function() {
      try {
        if (this.role == "ADMIN") {
          this.assignVideoValidator();
        } else if (this.role == "VALIDATOR") {
          this.assignVideoAnnotator();
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },
    assignVideoValidator: function() {
      try {
        var div = document.createElement("div");
        var img = document.createElement("img");
        img.src = "static/loading.gif";
        img.style.cssText = "margin-top:20%;width:5%;height:10%;";
        div.style.cssText =
          "width: 100%;height: 100%;top: 0px;left: 0px;position: fixed;display: block;opacity: 0.7;background-color: #fff;z-index: 99;text-align: center";
        div.appendChild(img);
        document.body.appendChild(div);
        this.modelvalue = this.AssignValue;
        if (this.modelvalue == null) {
          var self = this;
          self.userNotAssigned = true;
          div.style.display = "none";
          setTimeout(function() {
            self.userNotAssigned = false;
          }, 4000);
          return;
        } else {
          this.modelvalue = this.AssignValue;
          this.modelvalueText = this.AssignValue.text;
          this.modelvalueId = this.AssignValue.vId;
          this.assignUserId = this.AssignValue.userid;
          this.$apollo
            .mutate({
              mutation: VIDEO_ASSIGNE_VALIDATOR_MUTATION,
              variables: {
                videoid: this.newArray,
                assignuserid: this.assignUserId,
                userid: this.userId,
              },
            })
            .then((data) => {
              div.style.display = "none";
              this.isQueryError = false;
              location.reload();
            })
            .catch((error) => {
              div.style.display = "none";
              this.isQueryError = true;
              this.queryErrorResult = /:(.+)/.exec(error.message)[1];
            });
          this.assignD = false;
          this.newArray = [];
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },
    assignVideoAnnotator: function() {
      try {
        var div = document.createElement("div");
        var img = document.createElement("img");
        img.src = "static/loading.gif";
        img.style.cssText = "margin-top:20%;width:5%;height:10%;";
        div.style.cssText =
          "width: 100%;height: 100%;top: 0px;left: 0px;position: fixed;display: block;opacity: 0.7;background-color: #fff;z-index: 99;text-align: center";
        div.appendChild(img);
        document.body.appendChild(div);
        this.modelvalue = this.AssignValue;
        if (this.modelvalue == null) {
          var self = this;
          self.userNotAssigned = true;
          div.style.display = "none";
          setTimeout(function() {
            self.userNotAssigned = false;
          }, 4000);
          return;
        } else {
          this.modelvalue = this.AssignValue;
          this.modelvalueText = this.AssignValue.text;
          this.modelvalueId = this.AssignValue.vId;
          this.assignUserId = this.AssignValue.userid;
          this.$apollo
            .mutate({
              mutation: VIDEO_ASSIGNE_MUTATION,
              variables: {
                videoid: this.newArray,
                assignuserid: this.assignUserId,
                userid: this.userId,
              },
            })
            .then((data) => {
              div.style.display = "none";
              this.isQueryError = false;
              location.reload();
            })
            .catch((error) => {
              div.style.display = "none";
              this.isQueryError = true;
              this.queryErrorResult = /:(.+)/.exec(error.message)[1];
            });
          this.assignD = false;
          this.newArray = [];
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },
    vedioOpen: function(event, name) {
      try {
        this.isnextClicked = false;
        this.videoid = event;
        taskName = name;
        this.imageid = -1;
        var preImgId = document.getElementById("imgpre");
        this.previewmode = false;
        if (this.PreviewImgOpen == true) {
          this.$apollo
            .mutate({
              mutation: GET_VIDEO_DATA_MUTATION,
              variables: {
                videoid: this.videoid,
                taskName: taskName,
                imageid: this.imageid,
              },
            })
            .then((data) => {
              this.isQueryError = false;
              this.imageurl = data.data.getVideoData.videourl;
              frameCount = data.data.getVideoData.imagecount;
              this.imagecount = data.data.getVideoData.imagecount;
              if (typeof preImgId != "undefined" && preImgId != null) {
                preImgId.src = this.imageurl;
              }
            })
            .catch((error) => {
              this.isQueryError = true;
              this.queryErrorResult = /:(.+)/.exec(error.message)[1];
            });
          var self = this;
          let duration = this.selectPreviewDuration * 1000;
          slideshow = setInterval(function() {
            self.nextImgOpen();
          }, duration);
        } else {
          return;
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },
    pauseSlideshow: function() {
      try {
        if (this.isPause == true) {
          clearInterval(slideshow);
        }
        if (this.isPause == false) {
          this.isnextClicked = false;
          var self = this;
          let duration = this.selectPreviewDuration * 1000;
          slideshow = setInterval(function() {
            self.nextImgOpen();
          }, duration);
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },
    openPreImage: function() {
      try {
        if (this.openFullSize == true) {
          // let minWidth = 1366;
          // let minHeight = 695;
          // let fixedHeight = 620;
          // let heightPercent = (fixedHeight/parseFloat(minHeight))
          // let calculatedImgWidth = parseInt((parseFloat(minWidth)*parseFloat(heightPercent)));
          $("#imgpre").css("width", "100vw");
          $("#imgpre").css("height", "88vh");
        } else {
          $("#imgpre").css("width", "50%");
          $("#imgpre").css("height", "350");
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },
    nextImgOpen: function() {
      try {
        var preImgId = document.getElementById("imgpre");
        if (this.PreviewImgOpen == true) {
          this.imageid = this.imageid + 1;
          if (this.isnextClicked) {
            this.isPause = true;
            clearInterval(slideshow);
            if (this.imageid == frameCount) {
              this.imageid = 0;
            }
          }
          if (this.imageid < frameCount) {
            this.$apollo
              .mutate({
                mutation: GET_VIDEO_DATA_MUTATION,
                variables: {
                  videoid: this.videoid,
                  imageid: this.imageid,
                },
              })
              .then((data) => {
                this.isQueryError = false;
                this.imageurl = data.data.getVideoData.videourl;
                if (typeof preImgId != "undefined" && preImgId != null) {
                  preImgId.src = this.imageurl;
                }
              })
              .catch((error) => {
                this.isQueryError = true;
                this.queryErrorResult = /:(.+)/.exec(error.message)[1];
              });
          } else if (this.isnextClicked == false) {
            this.imageid = -1;
          }
          this.searchImageId = this.imageid;
        } else {
          return;
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },
    prevImgOpen: function() {
      try {
        var preImgId = document.getElementById("imgpre");
        if (this.PreviewImgOpen == true) {
          this.isPause = true;
          clearInterval(slideshow);
          if (this.imageid > 0) {
            this.imageid = this.imageid - 1;
            this.$apollo
              .mutate({
                mutation: GET_VIDEO_DATA_MUTATION,
                variables: {
                  videoid: this.videoid,
                  imageid: this.imageid,
                },
              })
              .then((data) => {
                this.isQueryError = false;
                this.imageurl = data.data.getVideoData.videourl;
                if (typeof preImgId != "undefined" && preImgId != null) {
                  preImgId.src = this.imageurl;
                }
              })
              .catch((error) => {
                this.isQueryError = true;
                this.queryErrorResult = /:(.+)/.exec(error.message)[1];
              });
          }
          this.searchImageId = this.imageid;
        } else {
          return;
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },
    SelectPreMode: function() {
      try {
        this.openFullSize = false;
        if (this.modeType == "Image") {
          this.PreviewImgOpen = true;
          this.vedioOpen(this.selectedId, this.selectedName);
        }
        if (this.modeType == "Video") {
          this.Videosopen = true;
          this.startvideo(this.selectedId, this.selectedName);
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },
    startvideo: function(event, name) {
      try {
        this.videoPlaybackSpeed = 1;
        this.videoPlay = "Play";
        this.isPause = false;
        this.showTextbox = false;
        this.previewVidid = event;
        taskName = name;
        timeStamp = [];
        pos = [];
        var self = this;
        if (this.Videosopen == true) {
          this.previewmode = false;
          this.$apollo
            .mutate({
              mutation: GET_PREVIEW_VIDEO_DATA_MUTATION,
              variables: {
                videoid: this.previewVidid,
                taskName: taskName,
              },
            })
            .then((data) => {
              this.isQueryError = false;
              if (data.data.getPreviewVideoData != null) {
                var vid = document.getElementById("my_video");
                this.videourl = data.data.getPreviewVideoData.videourl;
                this.previewVidid = data.data.getPreviewVideoData.videoid;
                this.preVideoname = data.data.getPreviewVideoData.videoname;
                this.totalDuration =
                  data.data.getPreviewVideoData.total_duration;
                let timeStampData = [];
                timeStampData = data.data.getPreviewVideoData.timestamp;
                if (timeStampData != null) {
                  for (let obj of timeStampData) {
                    timeStamp.push({
                      eventtype: obj.eventtype,
                      endtime: {
                        hh: obj.endtime.hh,
                        mm: obj.endtime.mm,
                        ss: obj.endtime.ss,
                      },
                      starttime: {
                        hh: obj.starttime.hh,
                        mm: obj.starttime.mm,
                        ss: obj.starttime.ss,
                      },
                    });
                  }
                  if (typeof vid != "undefined" && vid != null) {
                    vid.src = this.videourl;
                  }
                }
              } else {
                this.showNoVid = true;
                setTimeout(function() {
                  self.showNoVid = false;
                  self.Videosopen = false;
                }, 1000);
              }
            })
            .catch((error) => {
              this.isQueryError = true;
              this.Videosopen = false;
              this.queryErrorResult = /:(.+)/.exec(error.message)[1];
            });
        } else {
          return;
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },
    jumpToFrame: function(selectedImageId) {
      try {
        var preImgId = document.getElementById("imgpre");
        if (this.PreviewImgOpen == true) {
          this.previewImageError = false;
          clearInterval(slideshow);
          this.isPause = true;
          if (this.imageid >= 0 && selectedImageId < this.imagecount) {
            this.imageid = parseInt(selectedImageId);
            this.$apollo
              .mutate({
                mutation: GET_VIDEO_DATA_MUTATION,
                variables: {
                  videoid: this.videoid,
                  imageid: this.imageid,
                },
              })
              .then((data) => {
                this.isQueryError = false;
                this.imageurl = data.data.getVideoData.videourl;
                if (typeof preImgId != "undefined" && preImgId != null) {
                  preImgId.src = this.imageurl;
                }
              })
              .catch((error) => {
                this.isQueryError = true;
                this.queryErrorResult = /:(.+)/.exec(error.message)[1];
              });
          } else {
            this.previewImageError = true;
          }
        } else {
          return;
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },
    playPause: function() {
      try {
        this.showTextbox = false;
        var vid = document.getElementById("my_video");
        if (vid.paused) {
          vid.play();
          this.videoPlay = "Play";
        } else {
          vid.pause();
          this.videoPlay = "Pause";
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },
    changePlaybackSpeed() {
      var vid = document.getElementById("my_video");
      vid.playbackRate = this.videoPlaybackSpeed;
    },
    seekForward() {
      var vid = document.getElementById("my_video");
      vid.currentTime = vid.currentTime + 2;
    },
    seekBackward() {
      var vid = document.getElementById("my_video");
      vid.currentTime = vid.currentTime - 2;
    },
    videoSeek: function(e) {
      try {
        this.showTextbox = false;
        var vid = document.getElementById("my_video");
        var seekslider = document.getElementById("seekslider");
        let percent = e.offsetX / seekslider.offsetWidth;
        vid.currentTime = percent * vid.duration;
        e.target.value = Math.floor(percent / 100);
      } catch (error) {
        console.log("Error:", error);
      }
    },
    seektimeupdate: function() {
      try {
        var vid = document.getElementById("my_video");
        var seekslider = document.getElementById("seekslider");
        var curtimetext = document.getElementById("curtimetext");
        var durtimetext = document.getElementById("durtimetext");
        if (typeof vid != "undefined" && vid != null) {
          var nt = (100 / vid.duration) * vid.currentTime;
          seekslider.value = nt;
          // var curhrs = Math.floor(vid.currentTime / 60);
          var curmins = Math.floor(vid.currentTime / 60);
          var cursecs = Math.floor(vid.currentTime - curmins * 60);
          //  var durhrs = Math.floor(vid.duration / 60);
          var durmins = Math.floor(vid.duration / 60);
          var dursecs = Math.floor(vid.duration - durmins * 60);
          if (cursecs < 10) {
            cursecs = "0" + cursecs;
          }
          if (dursecs < 10) {
            dursecs = "0" + dursecs;
          }
          if (curmins < 10) {
            curmins = "0" + curmins;
          }
          if (durmins < 10) {
            durmins = "0" + durmins;
          }
          // if(curhrs < 10){ curhrs = "0"+curhrs; }
          // if(durhrs < 10){ durhrs = "0"+durhrs; }
          curtimetext.innerHTML = curmins + ":" + cursecs;
          durtimetext.innerHTML = durmins + ":" + dursecs;
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },
    calculateTime: function(num) {
      num = Number(num);
      var h = Math.floor(num / 3600);
      var m = Math.floor((num % 3600) / 60);
      var s = Math.floor((num % 3600) % 60);
      var calHr = h > 0 ? h : 0;
      var calMin = m > 0 ? m : 0;
      var calSec = s > 0 ? s : 0;
      return {
        calHr,
        calMin,
        calSec,
      };
    },
    startDrag: function(e) {
      var self = this;
      if (!e) {
        var e = window.event;
      }
      if (e.preventDefault) e.preventDefault();
      targ = e.target ? e.target : e.srcElement;
      offsetX = e.clientX;
      if (!targ.style.marginLeft) {
        targ.style.marginLeft = "0px";
      }
      coordX = parseInt(targ.style.marginLeft);
      changedIndex = targ.id;
      drag = true;
      changedIndex = targ.id;

      document.onmousemove = function() {
        self.dragDiv();
      };

      return false;
    },
    dragDiv: function(e) {
      timeStart = 0;
      if (!drag) {
        return;
      }
      if (!e) {
        var e = window.event;
      }
      var marker = timeStamp[changedIndex];
      var finalStartTime =
        marker.starttime.hh * 3600 +
        marker.starttime.mm * 60 +
        marker.starttime.ss;
      var finalEndTime =
        marker.endtime.hh * 3600 + marker.endtime.mm * 60 + marker.endtime.ss;
      targ.style.marginLeft = coordX + e.clientX - offsetX + "px";
      var id = "endimg" + changedIndex;
      let markerWidth = (finalEndTime - finalStartTime) * ratioPxBySeconds;
      document.getElementById(id).style.marginLeft =
        coordX + e.clientX - offsetX + markerWidth + "px";
      var maleft = coordX + e.clientX - offsetX;
      var time = 0;
      time = maleft;
      timeStart = Math.round(time / ratioPxBySeconds);
      var actualTimeStart = this.calculateTime(timeStart);
      timeEnd = Math.round((time + markerWidth) / ratioPxBySeconds);
      var actualTimeEnd = this.calculateTime(timeEnd);
      marker.starttime.hh = actualTimeStart.calHr;
      marker.starttime.mm = actualTimeStart.calMin;
      marker.starttime.ss = actualTimeStart.calSec;
      marker.endtime.hh = actualTimeEnd.calHr;
      marker.endtime.mm = actualTimeEnd.calMin;
      marker.endtime.ss = actualTimeEnd.calSec;
      return false;
    },
    startSecondDrag: function(e) {
      var self = this;
      if (!e) {
        var e = window.event;
      }
      if (e.preventDefault) e.preventDefault();
      targ = e.target ? e.target : e.srcElement;
      offsetX = e.clientX;
      changedSecIndex = targ.id;
      if (!targ.style.marginLeft) {
        targ.style.marginLeft = "0px";
      }
      coordX = parseInt(targ.style.marginLeft);
      drag = true;
      document.onmousemove = function() {
        self.dragSecondDiv();
      };
      return false;
    },
    dragSecondDiv: function(e) {
      timeEnd = 0;
      var newIndex = changedSecIndex.split("endimg");
      var index = newIndex[1];
      var marker = timeStamp[index];
      if (!drag) {
        return;
      }
      if (!e) {
        var e = window.event;
      }
      targ.style.marginLeft = coordX + e.clientX - offsetX + "px";
      var maleft = coordX + e.clientX - offsetX;
      var time = 0;
      time = maleft;
      timeEnd = Math.round(time / ratioPxBySeconds);
      var actualTimeEnd = this.calculateTime(timeEnd);
      marker.endtime.hh = actualTimeEnd.calHr;
      marker.endtime.mm = actualTimeEnd.calMin;
      marker.endtime.ss = actualTimeEnd.calSec;
      return false;
    },
    stopDrag: function() {
      drag = false;
    },
    setMarkers: function(ctx, ratioPxSec, height) {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      try {
        $("#info img").remove();
        var self = this;
        for (var i = 0; i < timeStamp.length; i++) {
          var img = document.createElement("img");
          var endImg = document.createElement("img");
          var imgId = i;
          var endImgId = "endimg" + i;
          img.id = imgId;
          endImg.id = endImgId;
          var marker = timeStamp[i];
          var finalStartTime =
            marker.starttime.hh * 3600 +
            marker.starttime.mm * 60 +
            marker.starttime.ss;
          var finalEndTime =
            marker.endtime.hh * 3600 +
            marker.endtime.mm * 60 +
            marker.endtime.ss;
          let x = finalStartTime * ratioPxSec;
          let y = 0;
          let w = (finalEndTime - finalStartTime) * ratioPxSec;
          let h = parseFloat(height);
          ctx.fillStyle = "rgb(127, 51, 2, 0.9)";
          ctx.fillRect(x, y, w, h);
          img.src = "static/start_icon.svg";
          document.getElementById("info").appendChild(img);
          document.getElementById(imgId).style.marginLeft =
            Math.floor(x) + "px";
          document.getElementById(imgId).style.position = "absolute";
          document.getElementById(imgId).title = marker.eventtype;
          endImg.src = "static/end_icon.svg";
          document.getElementById("info").appendChild(endImg);
          document.getElementById(endImgId).style.marginLeft =
            Math.floor(x) + Math.floor(w) + "px";
          document.getElementById(endImgId).style.position = "absolute";
          document.getElementById(endImgId).title = marker.eventtype;
          img.ondblclick = function() {
            self.showText(this.id);
          };
          img.draggable = true;
          img.onmousedown = function() {
            self.startDrag();
          };
          img.onmouseup = function() {
            self.stopDrag();
          };
          endImg.draggable = true;
          endImg.onmousedown = function() {
            self.startSecondDrag();
          };
          endImg.onmouseup = function() {
            self.stopDrag();
          };
          pos.push(Math.floor(x));
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },
    newStartDrag: function(e) {
      var self = this;
      if (!e) {
        var e = window.event;
      }
      if (e.preventDefault) e.preventDefault();
      targ = e.target ? e.target : e.srcElement;
      offsetX = e.clientX;
      if (!targ.style.marginLeft) {
        targ.style.marginLeft = "0px";
      }
      coordX = parseInt(targ.style.marginLeft);
      changedIndex = targ.id;
      drag = true;
      changedIndex = targ.id;

      document.onmousemove = function() {
        self.newDragDiv();
      };

      return false;
    },
    newStartSecondDrag: function(e) {
      var self = this;
      if (!e) {
        var e = window.event;
      }
      if (e.preventDefault) e.preventDefault();
      targ = e.target ? e.target : e.srcElement;
      offsetX = e.clientX;
      changedSecIndex = targ.id;
      if (!targ.style.marginLeft) {
        targ.style.marginLeft = "0px";
      }
      coordX = parseInt(targ.style.marginLeft);
      drag = true;
      document.onmousemove = function() {
        self.newDragSecondDiv();
      };
      return false;
    },
    newDragSecondDiv: function(e) {
      timeEnd = 0;
      // var newIndex = changedSecIndex.split("endimg");
      // var index = newIndex[0];
      var marker = this.newTimeStamp[0];
      if (!drag) {
        return;
      }
      if (!e) {
        var e = window.event;
      }
      targ.style.marginLeft = coordX + e.clientX - offsetX + "px";
      var maleft = coordX + e.clientX - offsetX;
      var time = 0;
      time = maleft;
      timeEnd = Math.round(time / ratioPxBySeconds);
      var actualTimeEnd = this.calculateTime(timeEnd);
      marker.endtime.hh = actualTimeEnd.calHr;
      marker.endtime.mm = actualTimeEnd.calMin;
      marker.endtime.ss = actualTimeEnd.calSec;
      return false;
    },
    newDragDiv: function(e) {
      timeStart = 0;
      if (!drag) {
        return;
      }
      if (!e) {
        var e = window.event;
      }
      var marker = this.newTimeStamp[0];
      var finalStartTime =
        marker.starttime.hh * 3600 +
        marker.starttime.mm * 60 +
        marker.starttime.ss;
      var finalEndTime =
        marker.endtime.hh * 3600 + marker.endtime.mm * 60 + marker.endtime.ss;
      targ.style.marginLeft = coordX + e.clientX - offsetX + "px";
      var id = "endimg" + changedIndex;
      let markerWidth = (finalEndTime - finalStartTime) * ratioPxBySeconds;
      document.getElementById(id).style.marginLeft =
        coordX + e.clientX - offsetX + markerWidth + "px";
      var maleft = coordX + e.clientX - offsetX;
      var time = 0;
      time = maleft;
      timeStart = Math.round(time / ratioPxBySeconds);
      var actualTimeStart = this.calculateTime(timeStart);
      timeEnd = Math.round((time + markerWidth) / ratioPxBySeconds);
      var actualTimeEnd = this.calculateTime(timeEnd);
      marker.starttime.hh = actualTimeStart.calHr;
      marker.starttime.mm = actualTimeStart.calMin;
      marker.starttime.ss = actualTimeStart.calSec;
      marker.endtime.hh = actualTimeEnd.calHr;
      marker.endtime.mm = actualTimeEnd.calMin;
      marker.endtime.ss = actualTimeEnd.calSec;
      return false;
    },
    addNewMarker: function(ctx, ratioPxSec, height) {
      this.isNewMarkerActive = true;
      this.newTimeStamp = this.defaultTimeStamp;
      var ctx = canvas.getContext("2d");
      // ctx.clearRect(0, 0, canvas.width, canvas.height)
      try {
        // $("#info img").remove();
        var self = this;
        var img = document.createElement("img");
        var endImg = document.createElement("img");
        var imgId = timeStamp.length + 1;
        var endImgId = "endimg" + (timeStamp.length + 1);
        img.id = imgId;
        endImg.id = endImgId;
        var marker = this.newTimeStamp[0];
        var finalStartTime =
          marker.starttime.hh * 3600 +
          marker.starttime.mm * 60 +
          marker.starttime.ss;
        var finalEndTime =
          marker.endtime.hh * 3600 + marker.endtime.mm * 60 + marker.endtime.ss;
        let nx = finalStartTime * ratioPxSec;
        let ny = 0;
        let nw = (finalEndTime - finalStartTime) * ratioPxSec;
        let nh = parseFloat(height);
        ctx.fillStyle = "rgb(127, 51, 2, 0.9)";
        ctx.fillRect(nx, ny, nw, nh);
        img.src = "static/start_icon.svg";
        document.getElementById("info").appendChild(img);
        document.getElementById(imgId).style.marginLeft = Math.floor(nx) + "px";
        document.getElementById(imgId).style.position = "absolute";
        endImg.src = "static/end_icon.svg";
        document.getElementById("info").appendChild(endImg);
        document.getElementById(endImgId).style.marginLeft =
          Math.floor(nx) + Math.floor(nw) + "px";
        document.getElementById(endImgId).style.position = "absolute";
        // img.ondblclick = function() { self.showText(this.id); };
        img.draggable = true;
        img.onmousedown = function() {
          self.newStartDrag();
        };
        img.onmouseup = function() {
          self.stopDrag();
        };
        endImg.draggable = true;
        endImg.onmousedown = function() {
          self.newStartSecondDrag();
        };
        endImg.onmouseup = function() {
          self.stopDrag();
        };
        pos.push(Math.floor(nx));
      } catch (error) {
        console.log("Error:", error);
      }
    },
    submitNewMarker() {
      this.newTimeStamp[0].eventtype = this.newTimeStampEvent;
      this.isNewMarkerActive = false;
      this.newTimeStampEvent = "";
    },
    closeNewMarkerMode() {
      document.getElementById(timeStamp.length + 1).remove();
      document.getElementById("endimg" + (timeStamp.length + 1)).remove();
      this.newTimeStamp = {};
      this.isNewMarkerActive = false;
      this.newTimeStampEvent = "";
    },
    showText: function(id) {
      try {
        this.showTextbox = true;
        activeEvent = id;
        this.showTextValue = timeStamp[id].eventtype;
      } catch (error) {
        console.log("Error:", error);
      }
    },
    updateText: function() {
      try {
        this.showTextbox = false;
        if (timeStamp[activeEvent].eventtype !== this.showTextValue) {
          timeStamp[activeEvent].eventtype = this.showTextValue;
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },
    saveEvent: function() {
      timeStamp.push(...this.newTimeStamp);
      this.newTimeStamp = [];
      try {
        this.showTextbox = false;
        this.$apollo
          .mutate({
            mutation: SAVE_PREVIEW_VIDEO_DATA_MUTATION,
            variables: {
              videoid: this.previewVidid,
              videoname: this.preVideoname,
              total_duration: this.totalDuration,
              taskName: taskName,
              timestamp: timeStamp,
            },
          })
          .then((data) => {
            this.isQueryError = false;
            var ctx = canvas.getContext("2d");
            this.setMarkers(ctx, ratioPxBySeconds, canvas.height);
          })
          .catch((error) => {
            this.isQueryError = true;
            this.queryErrorResult = /:(.+)/.exec(error.message)[1];
          });
      } catch (error) {
        console.log("Error:", error);
      }
    },
    LoadVideoData: function() {
      try {
        var vid = document.getElementById("my_video");
        var vid_width = vid.videoWidth;
        var vid_height = vid.videoHeight;
        var co_efficient = 360 / vid_height;
        var adjusted_video_controls_bar_length = Math.floor(
          vid_width * co_efficient
        );
        this.showTextbox = false;
        var seekslider = document.getElementById("video-slider-container");
        var infoContainer = document.getElementById("info");
        var seekbar = document.getElementById("seekbar");
        var savebtn = document.getElementById("savebtn");
        // seekslider.style.width = (adjusted_video_controls_bar_length) +'px';
        // seekbar.style.width = (adjusted_video_controls_bar_length) +'px';
        // savebtn.style.marginLeft = (adjusted_video_controls_bar_length - 20) +'px';
        var widthProgressBar = window
          .getComputedStyle(seekslider, null)
          .getPropertyValue("width");
        var heightProgressBar = window
          .getComputedStyle(seekslider, null)
          .getPropertyValue("height");
        canvas = document.createElement("canvas");
        var w = (canvas.width = parseFloat(widthProgressBar));
        var h = (canvas.height = parseFloat(heightProgressBar));
        canvas.id = "markers";
        canvas.style.position = "absolute";
        infoContainer.parentNode.insertBefore(
          canvas,
          infoContainer.nextSibling
        );
        var ctx = canvas.getContext("2d");
        var videoDuration = vid.duration;
        ratioPxBySeconds = parseFloat(w) / videoDuration;
        this.setMarkers(ctx, ratioPxBySeconds, h);
      } catch (error) {
        console.log("Error:", error);
      }
    },
    getVideoAnnotator: function() {
      try {
        var div = document.createElement("div");
        var img = document.createElement("img");
        img.src = "static/loading.gif";
        img.style.cssText = "margin-top:20%;width:5%;height:10%;";
        div.style.cssText =
          "width: 100%;height: 100%;top: 0px;left: 0px;position: fixed;display: block;opacity: 0.7;background-color: #fff;z-index: 99;text-align: center";
        div.appendChild(img);
        document.body.appendChild(div);
        this.mainItems = [];
        this.$apollo
          .mutate({
            mutation: ALL_VIDEO_MUTATION,
            variables: {
              userid: this.userId,
              project_id: this.projectId,
            },
          })
          .then((data) => {
            div.style.display = "none";
            this.isQueryError = false;
            var videoData = data.data.allVideoData.videos;
            for (var i = 0; i < videoData.length; i++) {
              if (
                videoData[i].assigned == true &&
                videoData[i].processed == false
              ) {
                this.mainItems.push(videoData[i]);
              }
            }
            setTimeout(this.submitVideoList, 0);
            if (this.mainItems.length > 0) {
              SettingService.setSelectedVideo(this.mainItems[0]);
              SettingService.setAllVideo(this.mainItems);
            }
            this.projectId = data.data.allVideoData.last_project;
            if (this.projectId == 0) {
              this.isProjectSelect = true;
            }
            SettingService.setSelectedProject(this.projectId);
            for (var i = 0; i < this.allProjectList.length; i++) {
              if (this.allProjectList[i].id == this.projectId) {
                this.selectProject = this.allProjectList[i].name;
              }
            }
          })
          .catch((error) => {
            div.style.display = "none";
            this.isQueryError = true;
            this.queryErrorResult = /:(.+)/.exec(error.message)[1];
          });
      } catch (error) {
        div.style.display = "none";
        console.log("Error:", error);
      }
    },
    getUserProject: function() {
      try {
        this.$apollo
          .mutate({
            mutation: ALL_PROJECT_MUTATION,
            variables: {
              userid: this.userId,
              role: this.role,
            },
          })
          .then((data) => {
            let projectListData = [];
            this.allProjectList = [];
            this.selectProject = "";
            if (data.data.allProjectData.projects != null) {
              projectListData = data.data.allProjectData.projects;
            }
            if (projectListData != null) {
              for (let obj of projectListData) {
                if (projectListData.length) {
                  this.projectList.push(obj.project_name);
                  this.allProjectList.push({
                    id: obj.project_id,
                    name: obj.project_name,
                  });
                }
              }
              SettingService.setProjectList(this.projectList);
              if (this.projectId !== 0) {
                if (this.role == "ADMIN") {
                  this.getVideoValidator();
                } else if (this.role == "VALIDATOR") {
                  this.getVideoValidator();
                } else if (this.role == "ANNOTATOR") {
                  this.getVideoAnnotator();
                }
                return this.$parent.callInbox;
              } else {
                this.isProjectSelect = true;
              }
            }
          })
          .catch((error) => {
            this.isQueryError = true;
            this.queryErrorResult = /:(.+)/.exec(error.message)[1];
          });
      } catch (error) {
        console.log("Error:", error);
      }
    },
    updatedProject: function() {
      for (var i = 0; i < this.allProjectList.length; i++) {
        if (this.allProjectList[i].name == this.selectProject) {
          this.projectId = this.allProjectList[i].id;
          if (this.role == "ADMIN") {
            this.getVideoValidator();
          } else if (this.role == "VALIDATOR") {
            this.getVideoValidator();
          } else if (this.role == "ANNOTATOR") {
            this.getVideoAnnotator();
          }
        }
      }
    },
    getVideoValidator: function() {
      try {
        var div = document.createElement("div");
        var img = document.createElement("img");
        img.src = "static/loading.gif";
        img.style.cssText = "margin-top:20%;width:5%;height:10%;";
        div.style.cssText =
          "width: 100%;height: 100%;top: 0px;left: 0px;position: fixed;display: block;opacity: 0.7;background-color: #fff;z-index: 99;text-align: center";
        div.appendChild(img);
        document.body.appendChild(div);
        this.mainItems = [];
        this.$apollo
          .mutate({
            mutation: ALL_VIDEO_VALIDATOR_MUTATION,
            variables: {
              userid: this.userId,
              role: this.role,
              project_id: this.projectId,
            },
          })
          .then((data) => {
            div.style.display = "none";
            this.isQueryError = false;
            this.projectId = data.data.allVideoDataValidator.last_project;
            if (this.projectId == 0) {
              this.isProjectSelect = true;
            }
            SettingService.setSelectedProject(this.projectId);
            let videos = data.data.allVideoDataValidator.videos;
            this.mainItems = data.data.allVideoDataValidator.videos;
            SettingService.setSelectedVideo(this.mainItems[0]);
            for (var i = 0; i < this.allProjectList.length; i++) {
              if (this.allProjectList[i].id == this.projectId) {
                this.selectProject = this.allProjectList[i].name;
              }
            }
            this.assignUserList();
            this.count = 0;
            this.checked = [];
          })
          .catch((error) => {
            div.style.display = "none";
            this.isQueryError = true;
            this.queryErrorResult = /:(.+)/.exec(error.message)[1];
          });
      } catch (error) {
        div.style.display = "none";
        console.log("Error:", error);
      }
    },
    checkSubmittedVideo: function() {
      try {
        var videoList = this.mainItems;
        this.videoReopen = true;
        this.checked = this.checked.filter(function(e) {
          return e.status == true;
        });
      } catch (error) {
        console.log("Error:", error);
      }
    },
    checkUnsubmittedVideo: function() {
      try {
        this.videoReopen = false;
        this.checked = this.checked.filter(function(e) {
          return e.status == false;
        });
      } catch (error) {
        console.log("Error:", error);
      }
    },
    acceptRejectVideo: function(event, submitted) {
      try {
        this.videoId = event;
        var div = document.createElement("div");
        var img = document.createElement("img");
        img.src = "static/loading.gif";
        img.style.cssText = "margin-top:20%;width:5%;height:10%;";
        div.style.cssText =
          "width: 100%;height: 100%;top: 0px;left: 0px;position: fixed;display: block;opacity: 0.7;background-color: #fff;z-index: 99;text-align: center";
        div.appendChild(img);
        document.body.appendChild(div);
        this.$apollo
          .mutate({
            mutation: ACCEPT_REJECT_VIDEO_MUTATION,
            variables: {
              userid: this.userId,
              submitted: submitted,
              videoid: this.videoId,
            },
          })
          .then((data) => {
            this.isQueryError = false;
            div.style.display = "none";
            location.reload();
          })
          .catch((error) => {
            div.style.display = "none";
            this.isQueryError = true;
            this.queryErrorResult = /:(.+)/.exec(error.message)[1];
          });
      } catch (error) {
        console.log("Error:", error);
      }
    },
    getThemeMode: function() {
      this.isDarkMode = SettingService.getDarkMode();
    },
    reopenVideo: function(event) {
      try {
        var div = document.createElement("div");
        var img = document.createElement("img");
        img.src = "static/loading.gif";
        img.style.cssText = "margin-top:20%;width:5%;height:10%;";
        div.style.cssText =
          "width: 100%;height: 100%;top: 0px;left: 0px;position: fixed;display: block;opacity: 0.7;background-color: #fff;z-index: 99;text-align: center";
        div.appendChild(img);
        document.body.appendChild(div);
        this.videoId = event;
        this.$apollo
          .mutate({
            mutation: REOPEN_VIDEO,
            variables: {
              videoid: this.newArray,
            },
          })
          .then((data) => {
            div.style.display = "none";
            this.isQueryError = false;
            location.reload();
          })
          .catch((error) => {
            div.style.display = "none";
            this.isQueryError = true;
            this.queryErrorResult = /:(.+)/.exec(error.message)[1];
          });
        this.newArray = [];
      } catch (error) {
        console.log("Error:", error);
      }
    },
    clearSearch: function() {
      this.search = "";
    },
  },

  beforeMount() {
    this.getThemeMode();
    this.callInbox();
    this.updateSettings();
  },
};
