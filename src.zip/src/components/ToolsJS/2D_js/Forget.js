import Appfooter from "../../../shared/Appfooter.vue";
import SignupModel from "../../../model/SignupModel.js";
import { GETQUESTION } from "../../../constants/graphql";
import { RESETPASSWORD } from "../../../constants/graphql";
import SettingService from "../../../services/SettingService.js";


export default {
  name: "Forget",
  props: [],
  components: {
    Appfooter
  },
  data() {
    return SignupModel; // Moved to model SignupModel
  },  
  methods: {
    callLogin: function () {
      this.$router.push({ name: 'login' });
    },
    delayedCallLogin: function () {
      var self = this;
      setTimeout(function () { self.callLogin(); }, 3000);
    },
    changeSecurityQuestion (event) {
      this.selectedSecurityQuestion = event.target.options[event.target.options.selectedIndex].text
    },
    getQuestion: function (username) {
      // This function will get the security question and answer which was initially sett by user while sign-up
      try {        
        if(this.username != ""){
          this.tempUsername = this.username;
          this.dialogQueFlag = false;
          this.$apollo
            .mutate({
              mutation: GETQUESTION,
              variables: {
                username:username
              }
            })
            .then(data => {
              if (data.data.getquestion == null){
                   this.getUserError = true;
              }
              else{
                this.question = data.data.getquestion.question;
                this.answer = data.data.getquestion.answer;
                this.dialogQueFlag = true;
                this.getUserError = false;
              }

            }).catch(error => {
              this.isQueryError = true;
              this.queryErrorResult = /:(.+)/.exec(error.message)[1];
          }); 
          
        }
        else{
          // this.showError = true;
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },
    clearFields: function () {
      try{
            this.newPass1 = "";
            this.newPass = "";
            this.qanswer = "";
            this.username = "";
            this.dialogQueFlag = false;
            this.passwordWeak = false;
            this.passwordMedium = false;
            this.passwordStrong = false;
            this.passwordLength = false;
            this.isPasswordSame = false;
            this.isQueryError = false;
            this.showError = false;
            this.resetSuccessfully = false;
            this.resetPasswordError = false;

      } catch (error) {
        console.log("Error:", error);
      }
    },
    validateResetPassword: function(){
      try{
        var specialch = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]+/;
        if(/\s/.test(this.newPass) || (this.newPass.match(/[0-9]/g) || []).length == 0 || (this.newPass.match(/[a-z]/g) || []).length == 0 || (this.newPass.match(/[A-Z]/g) || []).length == 0  || !specialch.test(this.newPass)){
          this.resetPasswordError = true;
        }
        else{
          this.resetPasswordError = false;
          this.checkNewPasswordStrength();
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },
    checkNewPasswordStrength: function () {
      try{
        if(this.newPass.length < 8){
          this.passwordWeak = true;
          this.passwordStrong = false;
          this.passwordMedium = false;
          this.passwordLength = false;

        }
        else if(this.newPass.length == 8){
          this.passwordWeak = false;
          this.passwordStrong = false;
          this.passwordMedium = true;
          this.passwordLength = false;

        }
        else if(this.newPass.length < 13){
          this.passwordWeak = false;
          this.passwordStrong = true;
          this.passwordMedium = false;
          this.passwordLength = false;

        }
        else{
          this.passwordWeak = false;
          this.passwordMedium = false;
          this.passwordStrong = false;
          this.passwordLength = true;
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },
    comparePassword: function () {
      try{
        if(this.newPass == this.newPass1){
            this.isPasswordSame = false;
        }
        else{
          this.isPasswordSame = true;
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },
    // hideErrorMessage: function () {
    //   try{
    //     if(this.password != "" 
    //       && this.confirmpassword != ""){
    //         this.showError = false;
    //     }
    //   } catch (error) {
    //     console.log("Error:", error);
    //   }
    // },
    resetPassword: function (username,newPass) {
      // This function will update/reset the password of user in the database. 
      try {      
        this.showError = false;  
        username = this.tempUsername;
        if(this.passwordWeak == false && this.passwordLength == false && this.resetPasswordError == false && this.isPasswordSame == false && this.qanswer.toLowerCase() == this.answer.toLowerCase() && this.newPass.length != 0 && this.newPass1.length != 0){
          this.$apollo
            .mutate({
              mutation: RESETPASSWORD,
              variables: {
                username:username,
                newPass:newPass
              }
            })
            .then(data => {
              if (data.data.resetpassword.status = true){
                this.resetSuccessfully = true;
                this.delayedCallLogin();
              }
            }).catch(error => {
              this.isQueryError = true;
              this.queryErrorResult = /:(.+)/.exec(error.message)[1];
          }); 
          
        }
        else{
          if(this.qanswer.toLowerCase() != this.answer.toLowerCase()){
            this.showError = true;
           }        
          if(this.newPass.length == 0){
            this.passwordWeak = true;
           }        
          }
      } catch (error) {
        console.log("Error:", error);
      }
    },
    getThemeMode: function() {
      this.isDarkMode = SettingService.getDarkMode();
    },
  },
  
  mounted: function () {
    this.clearFields();
  }, 
  beforeMount() {
    this.getThemeMode();
  },
};
