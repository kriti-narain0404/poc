import Appfooter from "../../../shared/Appfooter.vue";
import DashboardHeader from "../../../shared/DashboardHeader.vue";
import MaskModel from "../../../model/MaskModel.js";
import { NEXT_OBJ_MASK_IMG_QUERY } from "../../../constants/graphql";
import { SAVE_MASK_MUTATION } from "../../../constants/graphql";
import SettingService from "../../../services/SettingService.js";

var imageSource, image, redoClicked = false, redoindex = 0, dataURL = "", base64string = "";
var ctx, canWidth=0, canHeight=0, undocount=0;

export default {
  name: "Mask",
  props: [],
  components: {
    Appfooter,
    "dashboard-header": DashboardHeader,
  },
  data() {
    return MaskModel; // Moved to model MaskModel
  },  
  computed: {
        filters() {
            this.filter = { filter: 'grayscale(' + this.grayscale + ') brightness(' + this.brightness + ') contrast(' + this.contrast + ')' }
        }
    },
  methods: {
    callInbox(link) {   
      this.$router.push({ path: link });
    },
    first_image: function () {
      try { 
        this.imageId = 0;
        this.fwdUserId = SettingService.getSelectedUserId();
        this.username = SettingService.getSelectedUserName();
        this.role = SettingService.getSelectedUserRole();
        this.projectId = SettingService.getSelectedProject();
        this.videoId = this.$route.query.videoid;
        this.videoName = this.$route.query.videoname;
        this.video_type = this.$route.query.video_type;         
        this.$apollo
            .mutate({
                mutation: NEXT_OBJ_MASK_IMG_QUERY,
                variables: {
                  imageid: this.imageId,
                  videoname: this.videoName
                }
            })
            .then(data => {
              this.imageId = data.data.nextObjMaskImage.imageId;
              this.imageName = data.data.nextObjMaskImage.imagename;
              this.videoName = data.data.nextObjMaskImage.videoname;
              this.tolatImageCount = data.data.nextObjMaskImage.imagecount;
              this.serverPath = data.data.nextObjMaskImage.src;
              image = new Image();
              image.src = 'data:image/jpeg;base64,' + data.data.nextObjMaskImage.encoded_string;  
              image.style.opacity = "0.4";  
              image.style.filter  = 'alpha(opacity=40)';
              this.init(document.getElementById('canvas'));
            }).catch(error => {
                this.isQueryError = true;
                this.queryErrorResult = /:(.+)/.exec(error.message)[1];
            });  
      } catch (error) {
          console.log("Error:", error);
      }
    }, 
    next_image: function () {
      try {      
        var element = document.getElementById("can");
        element.parentNode.removeChild(element);
        this.isFillToolOpen = false;
        this.isEraserToolOpen = false;
        this.isImageToolOpen = false;
        this.fillstart = false;
        this.Erasestart = false; 
        this.$apollo
            .mutate({
                mutation: NEXT_OBJ_MASK_IMG_QUERY,
                variables: {
                  imageid:  this.imageId + 1,
                  videoname: this.videoName
                }
            })
            .then(data => {
              this.imageId = data.data.nextObjMaskImage.imageId;
              this.imageName = data.data.nextObjMaskImage.imagename;
              this.videoName = data.data.nextObjMaskImage.videoname;
              this.tolatImageCount = data.data.nextObjMaskImage.imagecount;
              image = new Image();
              image.src = 'data:image/jpeg;base64,' + data.data.nextObjMaskImage.encoded_string;       
              this.init(document.getElementById('canvas'));
            }).catch(error => {
                this.isQueryError = true;
                this.queryErrorResult = /:(.+)/.exec(error.message)[1];
            });  
      } catch (error) {
          console.log("Error:", error);
      }
    },
    prev_image: function () {
      try {     
        var element = document.getElementById("can");
        element.parentNode.removeChild(element); 
        this.isFillToolOpen = false;
        this.isEraserToolOpen = false;
        this.isImageToolOpen = false;
        this.fillstart = false;
        this.Erasestart = false;
        this.$apollo
            .mutate({
                mutation: NEXT_OBJ_MASK_IMG_QUERY,
                variables: {
                  imageid:  this.imageId - 1,
                  videoname: this.videoName
                }
            })
            .then(data => {
              this.imageId = data.data.nextObjMaskImage.imageId;
              this.imageName = data.data.nextObjMaskImage.imagename;
              this.videoName = data.data.nextObjMaskImage.videoname;
              image = new Image();
              image.src = 'data:image/jpeg;base64,' + data.data.nextObjMaskImage.encoded_string;       
              this.init(document.getElementById('canvas'));
            }).catch(error => {
                this.isQueryError = true;
                this.queryErrorResult = /:(.+)/.exec(error.message)[1];
            });  
      } catch (error) {
          console.log("Error:", error);
      }
    },
    createCanvas: function (parent, width, height) {
      var canvas = {};
      this.brushPoint = [];
      let self = this;
      canvas.node = document.createElement('canvas');      
      canvas.context = canvas.node.getContext('2d');
      canvas.node.width = width || 100;
      canvas.node.height = height || 100;
      canWidth = canvas.node.width;
      canHeight = canvas.node.height;
      canvas.node.id = "can";
      parent.appendChild(canvas.node);    
      var rect = canvas.node.getBoundingClientRect(); 
      var offsetX = rect.left;
      var offsetY = rect.top;
      var mouseX = 0;
      var mouseY = 0;
      var mousedown = false;
      var tooltype = 'draw';
      ctx = canvas.context;
     // define a custom fillCircle method
      canvas.context.fillCircle = function(x, y, radius) {
        this.fillStyle = "#ddd";
        this.beginPath();
        this.moveTo(x, y);
        this.arc(x, y, radius, 0, Math.PI * 2, false);
        this.fill();
      };
      canvas.context.clearTo = function(callback) {
        ctx.clearRect(0,0,0,0);
        callback;
      };      
      canvas.context.clearTo(ctx.drawImage(image, 0, 0));
      // bind mouse events
      canvas.node.onmousemove = function(e) {
          if (self.Erase == true) {       // Eraser method
            var x = parseInt((e.clientX - offsetX)/(self.actualWidth/canvas.node.width));
            var y = parseInt((e.clientY - offsetY)/(self.actualHeight/canvas.node.height))
            var radius = self.eraserRadius; 
            var fillColor = '#ff0000';
            ctx.globalAlpha = 1;
            ctx.globalCompositeOperation = 'destination-out';
            ctx.fillCircle(x, y, radius, fillColor);
          }
          if(self.mousedown == true) { // fill method
            ctx.beginPath();
            if(tooltype=='draw') {
              ctx.globalCompositeOperation = 'source-over';
              ctx.strokeStyle = '#00ff00';
              ctx.globalAlpha = 1.0;
              ctx.lineWidth = self.fillRadius;
            } else {
              ctx.globalCompositeOperation = 'destination-out';
              ctx.lineWidth = 10;
            }
            ctx.moveTo((e.clientX - offsetX)/(self.actualWidth/canvas.node.width), (e.clientY - offsetY)/(self.actualHeight/canvas.node.height));
            ctx.lineTo((e.clientX - offsetX)/(self.actualWidth/canvas.node.width), (e.clientY - offsetY)/(self.actualHeight/canvas.node.height));
            ctx.lineJoin = ctx.lineCap = 'round';
            ctx.stroke();
            mouseX = parseInt(e.clientX - offsetX);
            mouseY = parseInt(e.clientY - offsetY);
            self.brushPoint.push({
              x: mouseX,
              y: mouseY
            });
          }          
      };
      canvas.node.onmousedown = function(e) {    
        canvas.isDrawing = true;
        if(self.Erasestart == true){          
          self.Erase = true;
          self.mousedown = false;
        }
        if(self.fillstart == true){
          self.Erase == false;
          self.mousedown = true;
        }
      };
      canvas.node.onmouseup = function(e) {
        canvas.isDrawing = false;
        self.Erase = false;
        self.mousedown = false;  
        if(self.fillstart == true){ 
          self.undo_list.push({
            drawing: self.brushPoint
          });
        }
        self.brushPoint = [];         
        undocount = self.undo_list.length;  
      };
      window.addEventListener("scroll",function(){
        rect = canvas.node.getBoundingClientRect(); 
        offsetX = rect.left;
        offsetY = rect.top;
      });
      window.addEventListener("keydown",function(e){
        if (e.keyCode == 90 && e.ctrlKey){
          self.undoEffect();
        }
        if (e.keyCode == 89 && e.ctrlKey){   
          self.redoEffect();
        }
        if (e.keyCode == 83){   
          self.saveMask();
        }
      });
    },
    chooseErase: function (radius) {
      this.eraserRadius = radius;
      this.isFillToolOpen =  false;
      this.Erasestart = true;
      this.fillstart = false;
    },
    chooseFill: function (radius) { 
      this.fillRadius = radius;     
      this.isEraserToolOpen = false;
      this.Erasestart = false;
      this.fillstart = true;
    },
    openImageWindow() {
      this.isImageToolOpen = !this.isImageToolOpen;
      this.isFillToolOpen =  false;
      this.isEraserToolOpen = false;
    },          
    init: function (container) {
      let self = this;
      self.isFillToolOpen = false;
      self.isEraserToolOpen = false;
      self.isImageToolOpen = false;
      self.fillstart = false;
      self.Erasestart = false;
      imageSource = this.$hostname + "/img_path/noesis_data/" + this.videoName + "/" + this.imageId;
      $("#canvas").css("background-image", "url(" + imageSource + ")");
      var bgImg = new Image();
      bgImg.src = $('#canvas').css('background-image').replace(/"/g,"").replace(/url\(|\)$/ig, "");
      bgImg.onload = function() {
        self.createCanvas(container, this.width, this.height);
        self.getImageWidth(this.width, this.height);
        $('#canvas').css({'height':this.height,'width':this.width});
      }     
    },
    getImageWidth: function (width, height) {
      this.actualHeight = height;
      this.actualWidth = width;    
    },     
    downloadMask: function () {
      try { 
        var a = document.createElement("a"); 
        a.href = 'data:image/jpeg;base64,' + base64string;
        a.download = this.imageName;
        a.click(); 
        this.isDownloadMask = false;
      } catch (error) {
          console.log("Error:", error);
      }
    },
    saveMask: function () {
      try { 
        var self = this;
        var canvas = document.getElementById('can');
        dataURL = canvas.toDataURL();         
        setTimeout(function () { self.showNotification = true; }, 200); 
        this.$apollo
            .mutate({
                mutation: SAVE_MASK_MUTATION,
                variables: {
                  imageid: this.imageId,
                  videoid: 0,
                  imagename: this.imageName,
                  serverpath: this.serverPath,
                  base64Image: dataURL,
                }
            })
            .then(data => {
              base64string = data.data.saveMask.annos_json;
              if(this.isDownloadMask == true){
                this.downloadMask();
              }
              canvas.clear();
              image = new Image();
              image.src = 'data:image/jpeg;base64,' + base64string;       
              this.init(document.getElementById('canvas'));               
            }).catch(error => {
                this.isQueryError = true;
                this.queryErrorResult = /:(.+)/.exec(error.message)[1];
            }); 
        setTimeout(function () { self.showNotification = false; }, 1000);
      } catch (error) {
          console.log("Error:", error);
      }
    }, 
    undoErase: function (points) {
      try{
        if(points !== undefined && points !== null){
          for (var i = 0; i < points.drawing.length; i++) {    
            var pt = points.drawing[i]; 
            ctx.beginPath();
            ctx.strokeStyle = '#00ff00';
            ctx.globalAlpha = 1.0;
            ctx.lineWidth = this.fillRadius;
            ctx.globalCompositeOperation = 'destination-out'; 
            ctx.moveTo((pt.x)/(this.actualWidth/canWidth), (pt.y)/(this.actualHeight/canHeight));
            ctx.lineTo((pt.x)/(this.actualWidth/canWidth), (pt.y)/(this.actualHeight/canHeight));
            ctx.lineJoin = ctx.lineCap = 'round';
            ctx.stroke();
          }
        }        
      } catch (error) {
          console.log("Error:", error);
      }
    },   
    redoFill: function (points) {
      try{  
        if(points !== undefined && points !== null){
          for (var i = 0; i < points.drawing.length; i++) {    
            var pt = points.drawing[i];   
            ctx.beginPath();
            ctx.globalCompositeOperation = 'source-over';
            ctx.strokeStyle = '#00ff00';
            ctx.globalAlpha = 1.0;
            ctx.lineWidth = this.fillRadius; 
            ctx.moveTo((pt.x)/(this.actualWidth/canWidth), (pt.y)/(this.actualHeight/canHeight));
            ctx.lineTo((pt.x)/(this.actualWidth/canWidth), (pt.y)/(this.actualHeight/canHeight));
            ctx.lineJoin = ctx.lineCap = 'round';
            ctx.stroke();
          }
        }
      } catch (error) {
          console.log("Error:", error);
      }
    },    
    undoEffect: function () {
      try{
        this.isFillToolOpen =  false;
        this.isEraserToolOpen = false;
        if(redoClicked == true){
          undocount = this.undo_list.length;
          redoClicked = false;
        } 
        var index = undocount = undocount - 1; // select which stroke is going to undo
        if(undocount >= 0){
          this.redo_list.push(this.undo_list[index]);
          redoindex = this.redo_list.length;
          this.undoErase(this.undo_list[index]);  
        }
      } catch (error) {
          console.log("Error:", error);
      }
    }, 
    redoEffect: function () {
      try{ 
        redoClicked = true;   
        var index = redoindex = redoindex - 1; // select which stroke is going to redo
        this.isFillToolOpen =  false;
        this.isEraserToolOpen = false;
        this.redoFill(this.redo_list[index]);      
      } catch (error) {
          console.log("Error:", error);
      }
    },  
  },
  mounted: function () {    
    this.first_image();       
  }, 
};
