import { labelTool } from "../config_3D_tool.js";
import * as THREE from "three";
import { GUI } from "three/examples/jsm/libs/dat.gui.module";
import Service3D from "../../../../services/Service_3D.js";
import { matrixProduct3x4, matrixProduct4x4 } from "./math.js";
import baseLabelTool from "../base_label_tool.js";
import Editor3DData from "../../../../model/Editor3DModel.js";

var canvas,
  line1,
  line2,
  line3,
  line4,
  line5,
  line6,
  line7,
  line8,
  line9,
  line10,
  line11,
  line12,
  text,
  oTrackId,
  currentChannel;

export let annotationObjects = {
  minXPos: -150,
  maxXPos: 150,
  minYPos: -150,
  maxYPos: 150,
  minZPos: -3,
  maxZPos: 3,
  contents: [],
  contentsDetections: [],
  folderBoundingBox3DArray: [],
  interpolationObjIndexNextFile: -1,
  folderPositionArray: [],
  numGUIOptions: 17,
  folderRotationArray: [],
  folderSizeArray: [],
  interpolationMode: false,
  updated: false,
  projPoints: {},
  width: 640,
  height: 480,
  localOnSelect: {
    CAM_FRONT_LEFT: function(index) {},
    CAM_FRONT: function(index) {},
    CAM_FRONT_RIGHT: function(index) {},
    CAM_BACK_RIGHT: function(index) {},
    CAM_BACK: function(index) {},
    CAM_BACK_LEFT: function(index) {},
    PCD: function(index) {},
  },
  onSelect: function(dataType, f) {
    this.localOnSelect[dataType] = f;
  },
  localOnChangeClass: {
    CAM_FRONT_LEFT: function(index, label) {},
    CAM_FRONT: function(index, label) {},
    CAM_FRONT_RIGHT: function(index, label) {},
    CAM_BACK_RIGHT: function(index, label) {},
    CAM_BACK: function(index, label) {},
    CAM_BACK_LEFT: function(index, label) {},
    PCD: function(index, label) {},
  },
  getObjectIndexByTrackIdAndClass: function(trackId, className, fileIdx) {
    for (let i = 0; i < this.contents[fileIdx].length; i++) {
      let obj = this.contents[fileIdx][i];
      if (obj["trackId"] === trackId && obj["class"] === className) {
        return i;
      }
    }
    return -1;
  },
  drawLines: function(coords, trackId, isChanging) {
    // if (isChanging) {
      canvas.remove(
        line1,
        line2,
        line3,
        line4,
        line5,
        line6,
        line7,
        line8,
        line9,
        line10,
        line11,
        line12,
        text
      );
    //}
    if (canvas !== undefined) {
      line1 = new fabric.Line(
        [coords[0].x, coords[0].y, coords[4].x, coords[4].y],
        {
          stroke: "cyan",
          strokeWidth: 3,
          opacity: 1,
          fill: "transparent",
          selectable: false,
        }
      );
      //Back Rigth Pillar
      line2 = new fabric.Line(
        [coords[1].x, coords[1].y, coords[5].x, coords[5].y],
        {
          stroke: "cyan",
          strokeWidth: 3,
          opacity: 1,
          fill: "transparent",
          selectable: false,
        }
      );
      //Back Left Pillar
      line3 = new fabric.Line(
        [coords[2].x, coords[2].y, coords[6].x, coords[6].y],
        {
          stroke: "cyan",
          strokeWidth: 3,
          opacity: 1,
          fill: "transparent",
          selectable: false,
        }
      );
      //Back Left Pillar
      line4 = new fabric.Line(
        [coords[3].x, coords[3].y, coords[7].x, coords[7].y],
        {
          stroke: "cyan",
          strokeWidth: 3,
          opacity: 1,
          fill: "transparent",
          selectable: false,
        }
      );
      //Top Left
      line5 = new fabric.Line(
        [coords[0].x, coords[0].y, coords[3].x, coords[3].y],
        {
          stroke: "cyan",
          strokeWidth: 3,
          opacity: 1,
          fill: "transparent",
          selectable: false,
        }
      );
      //Top Right
      line6 = new fabric.Line(
        [coords[1].x, coords[1].y, coords[0].x, coords[0].y],
        {
          stroke: "cyan",
          strokeWidth: 3,
          opacity: 1,
          fill: "transparent",
          selectable: false,
        }
      );
      line7 = new fabric.Line(
        [coords[5].x, coords[5].y, coords[4].x, coords[4].y],
        {
          stroke: "cyan",
          strokeWidth: 3,
          opacity: 1,
          fill: "transparent",
          selectable: false,
        }
      );
      line8 = new fabric.Line(
        [coords[1].x, coords[1].y, coords[2].x, coords[2].y],
        {
          stroke: "cyan",
          strokeWidth: 3,
          opacity: 1,
          fill: "transparent",
          selectable: false,
        }
      );
      line9 = new fabric.Line(
        [coords[5].x, coords[5].y, coords[6].x, coords[6].y],
        {
          stroke: "cyan",
          strokeWidth: 3,
          opacity: 1,
          fill: "transparent",
          selectable: false,
        }
      );
      line10 = new fabric.Line(
        [coords[2].x, coords[2].y, coords[3].x, coords[3].y],
        {
          stroke: "cyan",
          strokeWidth: 3,
          opacity: 1,
          fill: "transparent",
          selectable: false,
        }
      );
      line11 = new fabric.Line(
        [coords[6].x, coords[6].y, coords[7].x, coords[7].y],
        {
          stroke: "cyan",
          strokeWidth: 3,
          opacity: 1,
          fill: "transparent",
          selectable: false,
          id: trackId,
        }
      );
      line12 = new fabric.Line(
        [coords[4].x, coords[4].y, coords[7].x, coords[7].y],
        {
          stroke: "cyan",
          strokeWidth: 3,
          opacity: 1,
          fill: "transparent",
          selectable: false,
        }
      );
      text = new fabric.IText(`Id : ${trackId}`, {
        left: coords[1].x - 20,
        top: coords[2].y - 20,
        evented: false,
        fontFamily: "Helvetica",
        fill: "cyan",
        id: trackId,
        fontSize: 40,
      });
      if (trackId !== undefined) {
        canvas.add(
          line1,
          line2,
          line3,
          line4,
          line5,
          line6,
          line7,
          line8,
          line9,
          line10,
          line11,
          line12
        );

        canvas.add(text);
        canvas.bringToFront(
          line1,
          line2,
          line3,
          line4,
          line5,
          line6,
          line7,
          line8,
          line9,
          line10,
          line11,
          line12
        );
      }
      canvas.renderAll.bind(canvas);
    }
  },
  draw2DProjectionsChannel: function(params, channelSelect) {
    try {
      currentChannel = channelSelect;
      for (let i = 0; i < params.channels.length; i++) {
        if (params.channels[i].channel === channelSelect) {
          if (
            params.channels[i].channel !== undefined &&
            params.channels[i].channel !== ""
          ) {
            params.channels[i].projPoints = this.calculateProjectedBoundingBox(
              params.x,
              params.y,
              params.z,
              params.width,
              params.length,
              params.height,
              params.channels[i].channel,
              params.rotationYaw,
              params.rotationPitch,
              params.rotationRoll
            );
            if (
              params.channels[i].projPoints !== undefined &&
              params.channels[i].projPoints.length === 8
            ) {
              // if (annotationObjects.updated === true) {
              //   this.drawLines()
              // }

              oTrackId = params.trackId;
              this.drawLines(params.channels[i].projPoints, oTrackId, false);
            }
          }
        }
      }
    } catch (error) {
      console.log("Error :", error);
    }
  },
  load2dHSC: function(channelSelect) {
    try {
      if (baseLabelTool.annoData.annoContentLength > 0) {
        for (let i = 0; i < baseLabelTool.annoData.annoContentLength; i++) {
          //Loads 3d boxes on IMages
          this.draw2DProjectionsChannel(
            baseLabelTool.annoData.annoContent[
              baseLabelTool.annoData.annoContentIndex
            ][i],
            channelSelect
          );
        }
      }
    } catch (error) {
      console.log("Error :", error);
    }
  },

  configureCanvas: function(width, height) {
    try {
      canvas.selection = false;
      canvas.setDimensions({
        height: height,
        width: width,
      });
      canvas.setBackgroundImage(
        this.imageSource,
        canvas.renderAll.bind(canvas)
      );
    } catch (error) {
      console.log("Error: ", error);
    }
  },

  initCanvas: function(source) {
    try {
      document.getElementById("c").style.backgroundImage = "none";
      let self = this;
      if (canvas == null) {
        canvas = new fabric.Canvas("c");
      } else {
        canvas.dispose();
        canvas = new fabric.Canvas("c");
      }
      // canvas.setDimensions({
      //   height: height,
      //   width: width,
      // });
      var img = new Image();
      img.onload = function() {
        self.configureCanvas(this.width, this.height);
        self.width = this.width;
        self.height = this.height;
      };
      this.imageSource = source;
      img.src = this.imageSource;
    } catch (error) {
      console.log("Error:", error);
    }
  },
  calculateProjectedBoundingBox: function(
    xPos,
    yPos,
    zPos,
    width,
    length,
    height,
    channel,
    rotationYaw,
    rotationPitch,
    rotationRoll
  ) {
    // TODO: incorporate yaw, pitch and roll before projecting the 3D points into image plane
    let idx = Service3D.getChannelIndexByName(channel);
    // TODO: calculate scaling factor dynamically (based on top position of slider)
    let imageScalingFactor;
    // let imagePanelHeight = parseInt(
    //   $("#layout_layout_resizer_top").css("top"),
    //   10
    // );
    let imagePanelHeight = 360;
    //let imagePanelHeight = parseInt($("#loadSVG").css("height"), 10);
    if (labelTool.currentDataset === labelTool.datasets.NuScenes) {
      imageScalingFactor = 640 / imagePanelHeight; //5
      xPos = xPos + labelTool.translationVectorLidarToCamFront[1]; //lat
      yPos = yPos + labelTool.translationVectorLidarToCamFront[0]; //long
      zPos = zPos + labelTool.translationVectorLidarToCamFront[2]; //vertical
    }
    let cornerPoints = [];
    if (labelTool.currentDataset === labelTool.datasets.NuScenes) {
      cornerPoints.push(
        //THREE.Vector3 -> A class replresenting a 3d vector used to calc a point in 3d space
        //Makes 8 points of cube
        //Top 4 Points
        new THREE.Vector3(
          xPos - width / 2,
          yPos - length / 2,
          zPos + height / 2
        )
      );
      cornerPoints.push(
        new THREE.Vector3(
          xPos + width / 2,
          yPos - length / 2,
          zPos + height / 2
        )
      );
      cornerPoints.push(
        new THREE.Vector3(
          xPos + width / 2,
          yPos + length / 2,
          zPos + height / 2
        )
      );
      cornerPoints.push(
        new THREE.Vector3(
          xPos - width / 2,
          yPos + length / 2,
          zPos + height / 2
        )
      );
      /***************************Bottom 4 points */
      cornerPoints.push(
        new THREE.Vector3(
          xPos - width / 2,
          yPos - length / 2,
          zPos - height / 2
        )
      );
      cornerPoints.push(
        new THREE.Vector3(
          xPos + width / 2,
          yPos - length / 2,
          zPos - height / 2
        )
      );
      cornerPoints.push(
        new THREE.Vector3(
          xPos + width / 2,
          yPos + length / 2,
          zPos - height / 2
        )
      );
      cornerPoints.push(
        new THREE.Vector3(
          xPos - width / 2,
          yPos + length / 2,
          zPos - height / 2
        )
      );
    }
    let projectedPoints = [];
    for (let cornerPoint in cornerPoints) {
      let point = cornerPoints[cornerPoint];
      let point3D = [point.x, point.y, point.z, 1];
      let projectionMatrix, transformationMatrix;
      let point2D, tranformed2D, translate;
      let x, y, z, translateMatrix;
      if (labelTool.currentDataset === labelTool.datasets.NuScenes) {
        projectionMatrix = labelTool.camChannels[idx].projectionMatrixNuScenes;
        // transformationMatrix =
        //   labelTool.camChannels[idx].transformationMatrixEgoToCamNuScenes;
        translate = labelTool.translationVectorLidarToCamFront;
        x = translate[0];
        y = translate[1];
        z = translate[2];
        translateMatrix = [
          [1, 0, 0, -x],
          [0, 1, 0, -y],
          [0, 0, 1, -z],
          [0, 0, 0, 1],
        ];
        tranformed2D = matrixProduct4x4(translateMatrix, point3D);
        point2D = matrixProduct3x4(projectionMatrix, tranformed2D);
      }
      if (point2D[2] > 0) {
        // add only points that are in front of camera
        let windowX = point2D[0] / point2D[2];
        let windowY = point2D[1] / point2D[2];
        projectedPoints.push(new THREE.Vector2(windowX, windowY));
      } else {
        // do not draw bounding box if it is too close too camera or behind
        return [];
      }
    }
    return projectedPoints;
  },
  update2DBoundingBox: function(fileIndex, objectIndex, isSelected) {
    this.updated = true;

    let className = this.contents[fileIndex][objectIndex].class;
    for (let channelObject in this.contents[fileIndex][objectIndex].channels) {
      if (
        this.contents[fileIndex][objectIndex].channels.hasOwnProperty(
          channelObject
        )
      ) {
        let channelObj = this.contents[fileIndex][objectIndex].channels[
          channelObject
        ];
        if (channelObj.channel !== "") {
          let x = this.contents[fileIndex][objectIndex]["x"];
          let y = this.contents[fileIndex][objectIndex]["y"];
          let z = this.contents[fileIndex][objectIndex]["z"];
          let width = this.contents[fileIndex][objectIndex]["width"];
          let length = this.contents[fileIndex][objectIndex]["length"];
          let height = this.contents[fileIndex][objectIndex]["height"];
          let rotationYaw = this.contents[fileIndex][objectIndex][
            "rotationYaw"
          ];
          let rotationPitch = this.contents[fileIndex][objectIndex][
            "rotationPitch"
          ];
          let rotationRoll = this.contents[fileIndex][objectIndex][
            "rotationRoll"
          ];
          let channel = channelObj.channel;
          channelObj.projectedPoints = this.calculateProjectedBoundingBox(
            x,
            y,
            z,
            width,
            length,
            height,
            channel,
            rotationYaw,
            rotationPitch,
            rotationRoll
          );
          // remove previous drawn lines of all 6 channels
          // for (let lineObj in channelObj.lines) {
          //   if (channelObj.lines.hasOwnProperty(lineObj)) {
          //     let line = channelObj.lines[lineObj];
          //     if (line !== undefined) {
          //       line.remove();
          //     }
          //   }
          // }
          if (
            channelObj.projectedPoints !== undefined &&
            channelObj.projectedPoints.length === 8
          ) {
            if (channelObj.channel === currentChannel) {
              this.projPoints.projectedPoints = channelObj.projectedPoints;
              this.drawLines(this.projPoints.projectedPoints, oTrackId, true);
            }
          }
        }
      }
    }
  },
  disableStartPose: function() {
    // disable slider
    this.folderPositionArray[
      this.interpolationObjIndexNextFile
    ].domElement.style.opacity = 0.5;
    this.folderPositionArray[
      this.interpolationObjIndexNextFile
    ].domElement.style.pointerEvents = "none";
    this.folderRotationArray[
      this.interpolationObjIndexNextFile
    ].domElement.style.opacity = 0.5;
    this.folderRotationArray[
      this.interpolationObjIndexNextFile
    ].domElement.style.pointerEvents = "none";
    this.folderSizeArray[
      this.interpolationObjIndexNextFile
    ].domElement.style.opacity = 0.5;
    this.folderSizeArray[
      this.interpolationObjIndexNextFile
    ].domElement.style.pointerEvents = "none";
  },
  changeXCoord: function(value, bboxTrackId, bboxClass, isKeyBoard) {
    if (value >= this.minXPos && value < this.maxXPos) {
      // Note: Do not use insertIndex because it might change (if deleting e.g. an object in between)
      // use track id and class to calculate selection index
      let selectionIndex = this.getObjectIndexByTrackIdAndClass(
        bboxTrackId,
        bboxClass,
        labelTool.currentFileIndex
      );
      if (isKeyBoard) {
        labelTool.cubeArray[labelTool.currentFileIndex][
          selectionIndex
        ].position.x =
          labelTool.cubeArray[labelTool.currentFileIndex][selectionIndex]
            .position.x + value;
        this.contents[labelTool.currentFileIndex][selectionIndex]["x"] =
          labelTool.cubeArray[labelTool.currentFileIndex][selectionIndex]
            .position.x + value;
      } else {
        labelTool.cubeArray[labelTool.currentFileIndex][
          selectionIndex
        ].position.x = value;
        this.contents[labelTool.currentFileIndex][selectionIndex]["x"] = value;
      }

      if (labelTool.pointCloudOnlyAnnotation === false) {
        // update bounding box
        this.update2DBoundingBox(
          labelTool.currentFileIndex,
          selectionIndex,
          true
        );
      }
    }
  },
  changeYCoord: function(value, bboxTrackId, bboxClass, isKeyBoard) {
    if (value >= this.minYPos && value < this.maxYPos) {
      let selectionIndex = this.getObjectIndexByTrackIdAndClass(
        bboxTrackId,
        bboxClass,
        labelTool.currentFileIndex
      );
      if (isKeyBoard) {
        labelTool.cubeArray[labelTool.currentFileIndex][
          selectionIndex
        ].position.y =
          labelTool.cubeArray[labelTool.currentFileIndex][selectionIndex]
            .position.y + value;
        this.contents[labelTool.currentFileIndex][selectionIndex]["y"] =
          labelTool.cubeArray[labelTool.currentFileIndex][selectionIndex]
            .position.y + value;
      } else {
        labelTool.cubeArray[labelTool.currentFileIndex][
          selectionIndex
        ].position.y = value;
        this.contents[labelTool.currentFileIndex][selectionIndex]["y"] = value;
      }
      if (labelTool.pointCloudOnlyAnnotation === false) {
        // update bounding box
        this.update2DBoundingBox(
          labelTool.currentFileIndex,
          selectionIndex,
          true
        );
      }
    }
  },
  changeZCoord: function(value, bboxTrackId, bboxClass, isKeyBoard) {
    if (value >= this.minZPos && value < this.maxZPos) {
      let selectionIndex = this.getObjectIndexByTrackIdAndClass(
        bboxTrackId,
        bboxClass,
        labelTool.currentFileIndex
      );
      if (isKeyBoard) {
        labelTool.cubeArray[labelTool.currentFileIndex][
          selectionIndex
        ].position.z =
          labelTool.cubeArray[labelTool.currentFileIndex][selectionIndex]
            .position.z + value;
        this.contents[labelTool.currentFileIndex][selectionIndex]["z"] =
          this.contents[labelTool.currentFileIndex][selectionIndex]["z"] +
          value;
      } else {
        labelTool.cubeArray[labelTool.currentFileIndex][
          selectionIndex
        ].position.z = value;
        this.contents[labelTool.currentFileIndex][selectionIndex]["z"] = value;
      }
      if (labelTool.pointCloudOnlyAnnotation === false) {
        // update bounding box
        this.update2DBoundingBox(
          labelTool.currentFileIndex,
          selectionIndex,
          true
        );
      }
    }
  },
  changeRotationYaw: function(value, bboxTrackId, bboxClass, isKeyBoard) {
    let selectionIndex = this.getObjectIndexByTrackIdAndClass(
      bboxTrackId,
      bboxClass,
      labelTool.currentFileIndex
    );
    if (isKeyBoard) {
      labelTool.cubeArray[labelTool.currentFileIndex][
        selectionIndex
      ].rotation.z =
        labelTool.cubeArray[labelTool.currentFileIndex][selectionIndex].rotation
          .z + value;
      this.contents[labelTool.currentFileIndex][selectionIndex]["rotationYaw"] =
        this.contents[labelTool.currentFileIndex][selectionIndex][
          "rotationYaw"
        ] + value;
    } else {
      labelTool.cubeArray[labelTool.currentFileIndex][
        selectionIndex
      ].rotation.z = value;
      this.contents[labelTool.currentFileIndex][selectionIndex][
        "rotationYaw"
      ] = value;
    }

    if (labelTool.pointCloudOnlyAnnotation === false) {
      // update bounding box
      this.update2DBoundingBox(
        labelTool.currentFileIndex,
        selectionIndex,
        true
      );
    }
  },
  changeRotationPitch: function(value, bboxTrackId, bboxClass, isKeyBoard) {
    let selectionIndex = this.getObjectIndexByTrackIdAndClass(
      bboxTrackId,
      bboxClass,
      labelTool.currentFileIndex
    );
    if (isKeyBoard) {
      labelTool.cubeArray[labelTool.currentFileIndex][
        selectionIndex
      ].rotation.x =
        labelTool.cubeArray[labelTool.currentFileIndex][selectionIndex].rotation
          .x + value;
      this.contents[labelTool.currentFileIndex][selectionIndex][
        "rotationPitch"
      ] =
        this.contents[labelTool.currentFileIndex][selectionIndex][
          "rotationPitch"
        ] + value;
    } else {
      labelTool.cubeArray[labelTool.currentFileIndex][
        selectionIndex
      ].rotation.x = value;
      this.contents[labelTool.currentFileIndex][selectionIndex][
        "rotationPitch"
      ] = value;
    }

    if (labelTool.pointCloudOnlyAnnotation === false) {
      // update bounding box
      this.update2DBoundingBox(
        labelTool.currentFileIndex,
        selectionIndex,
        true
      );
    }
  },
  changeRotationRoll: function(value, bboxTrackId, bboxClass, isKeyBoard) {
    let selectionIndex = this.getObjectIndexByTrackIdAndClass(
      bboxTrackId,
      bboxClass,
      labelTool.currentFileIndex
    );
    if (isKeyBoard) {
      labelTool.cubeArray[labelTool.currentFileIndex][
        selectionIndex
      ].rotation.y =
        labelTool.cubeArray[labelTool.currentFileIndex][selectionIndex].rotation
          .y + value;
      this.contents[labelTool.currentFileIndex][selectionIndex][
        "rotationRoll"
      ] =
        this.contents[labelTool.currentFileIndex][selectionIndex][
          "rotationRoll"
        ] + value;
    } else {
      labelTool.cubeArray[labelTool.currentFileIndex][
        selectionIndex
      ].rotation.y = value;
      this.contents[labelTool.currentFileIndex][selectionIndex][
        "rotationRoll"
      ] = value;
    }

    if (labelTool.pointCloudOnlyAnnotation === false) {
      // update bounding box
      this.update2DBoundingBox(
        labelTool.currentFileIndex,
        selectionIndex,
        true
      );
    }
  },
  changeBboxLength: function(
    value,
    bboxTrackId,
    bboxClass,
    xCoord,
    yCoord,
    isKeyBoard
  ) {
    for (let i = 0; i < labelTool.numFrames; i++) {
      let selectionIndex = this.getObjectIndexByTrackIdAndClass(
        bboxTrackId,
        bboxClass,
        i
      );
      if (selectionIndex !== -1) {
        if (isKeyBoard) {
          let newValue = this.contents[i][selectionIndex]["length"] - value;

          let newXPos =
            labelTool.cubeArray[i][selectionIndex].position.x +
            ((newValue - labelTool.cubeArray[i][selectionIndex].scale.y) *
              Math.sin(labelTool.cubeArray[i][selectionIndex].rotation.z)) /
              2;
          labelTool.cubeArray[i][selectionIndex].position.x = newXPos;
          xCoord = newXPos;
          this.contents[i][selectionIndex]["x"] = newXPos;
          let newYPos =
            labelTool.cubeArray[i][selectionIndex].position.y -
            ((newValue - labelTool.cubeArray[i][selectionIndex].scale.y) *
              Math.cos(labelTool.cubeArray[i][selectionIndex].rotation.z)) /
              2;
          labelTool.cubeArray[i][selectionIndex].position.y = newYPos;
          yCoord = newYPos;
          this.contents[i][selectionIndex]["y"] = newYPos;

          labelTool.cubeArray[i][selectionIndex].scale.y = newValue;
          this.contents[i][selectionIndex]["length"] = newValue;
        } else {
          let newXPos =
            labelTool.cubeArray[i][selectionIndex].position.x +
            ((value - labelTool.cubeArray[i][selectionIndex].scale.y) *
              Math.sin(labelTool.cubeArray[i][selectionIndex].rotation.z)) /
              2;
          labelTool.cubeArray[i][selectionIndex].position.x = newXPos;
          xCoord = newXPos;
          this.contents[i][selectionIndex]["x"] = newXPos;
          let newYPos =
            labelTool.cubeArray[i][selectionIndex].position.y -
            ((value - labelTool.cubeArray[i][selectionIndex].scale.y) *
              Math.cos(labelTool.cubeArray[i][selectionIndex].rotation.z)) /
              2;
          labelTool.cubeArray[i][selectionIndex].position.y = newYPos;
          yCoord = newYPos;
          this.contents[i][selectionIndex]["y"] = newYPos;

          labelTool.cubeArray[i][selectionIndex].scale.y = value;
          this.contents[i][selectionIndex]["length"] = value;
        }
      }
    }
    if (labelTool.pointCloudOnlyAnnotation === false) {
      let selectionIndexCurrent = this.getObjectIndexByTrackIdAndClass(
        bboxTrackId,
        bboxClass,
        labelTool.currentFileIndex
      );
      this.update2DBoundingBox(
        labelTool.currentFileIndex,
        selectionIndexCurrent,
        true
      );
    }
  },
  changeBboxWidth: function(
    value,
    bboxTrackId,
    bboxClass,
    xCoord,
    yCoord,
    isKeyBoard
  ) {
    for (let i = 0; i < labelTool.numFrames; i++) {
      let selectionIndex = this.getObjectIndexByTrackIdAndClass(
        bboxTrackId,
        bboxClass,
        i
      );
      if (selectionIndex !== -1) {
        if (isKeyBoard) {
          let newValue = this.contents[i][selectionIndex]["width"] + value;
          let newXPos =
            labelTool.cubeArray[i][selectionIndex].position.x +
            ((newValue - labelTool.cubeArray[i][selectionIndex].scale.x) *
              Math.cos(labelTool.cubeArray[i][selectionIndex].rotation.z)) /
              2;
          labelTool.cubeArray[i][selectionIndex].position.x = newXPos;
          if (i === labelTool.currentFileIndex) {
            xCoord = newXPos;
          }
          this.contents[i][selectionIndex]["x"] = newXPos;
          let newYPos =
            labelTool.cubeArray[i][selectionIndex].position.y +
            ((newValue - labelTool.cubeArray[i][selectionIndex].scale.x) *
              Math.sin(labelTool.cubeArray[i][selectionIndex].rotation.z)) /
              2;
          labelTool.cubeArray[i][selectionIndex].position.y = newYPos;
          if (i === labelTool.currentFileIndex) {
            yCoord = newYPos;
          }
          this.contents[i][selectionIndex]["y"] = newYPos;
          labelTool.cubeArray[i][selectionIndex].scale.x = newValue;
          this.contents[i][selectionIndex]["width"] = newValue;
        } else {
          let newXPos =
            labelTool.cubeArray[i][selectionIndex].position.x +
            ((value - labelTool.cubeArray[i][selectionIndex].scale.x) *
              Math.cos(labelTool.cubeArray[i][selectionIndex].rotation.z)) /
              2;
          labelTool.cubeArray[i][selectionIndex].position.x = newXPos;
          if (i === labelTool.currentFileIndex) {
            xCoord = newXPos;
          }
          this.contents[i][selectionIndex]["x"] = newXPos;
          let newYPos =
            labelTool.cubeArray[i][selectionIndex].position.y +
            ((value - labelTool.cubeArray[i][selectionIndex].scale.x) *
              Math.sin(labelTool.cubeArray[i][selectionIndex].rotation.z)) /
              2;
          labelTool.cubeArray[i][selectionIndex].position.y = newYPos;
          if (i === labelTool.currentFileIndex) {
            yCoord = newYPos;
          }
          this.contents[i][selectionIndex]["y"] = newYPos;
          labelTool.cubeArray[i][selectionIndex].scale.x = value;
          this.contents[i][selectionIndex]["width"] = value;
        }
      }
    }
    if (labelTool.pointCloudOnlyAnnotation === false) {
      let selectionIndexCurrentFrame = this.getObjectIndexByTrackIdAndClass(
        bboxTrackId,
        bboxClass,
        labelTool.currentFileIndex
      );
      this.update2DBoundingBox(
        labelTool.currentFileIndex,
        selectionIndexCurrentFrame,
        true
      );
    }
  },
  changeBboxHeight: function(
    value,
    bboxTrackId,
    bboxClass,
    zCoord,
    isKeyBoard
  ) {
    for (let i = 0; i < labelTool.numFrames; i++) {
      let selectionIndex = this.getObjectIndexByTrackIdAndClass(
        bboxTrackId,
        bboxClass,
        i
      );
      if (selectionIndex !== -1) {
        if (isKeyBoard) {
          let newValue = this.contents[i][selectionIndex]["height"] + value;
          let newZPos =
            labelTool.cubeArray[i][selectionIndex].position.z +
            (newValue - labelTool.cubeArray[i][selectionIndex].scale.z) / 2;
          labelTool.cubeArray[i][selectionIndex].position.z = newZPos;
          zCoord = newZPos;
          labelTool.cubeArray[i][selectionIndex].scale.z = newValue;
          this.contents[i][selectionIndex]["height"] = newValue;
        } else {
          let newZPos =
            labelTool.cubeArray[i][selectionIndex].position.z +
            (value - labelTool.cubeArray[i][selectionIndex].scale.z) / 2;
          labelTool.cubeArray[i][selectionIndex].position.z = newZPos;
          zCoord = newZPos;
          labelTool.cubeArray[i][selectionIndex].scale.z = value;
          this.contents[i][selectionIndex]["height"] = value;
        }
      }
    }
    if (labelTool.pointCloudOnlyAnnotation === false) {
      let selectionIndexCurrent = this.getObjectIndexByTrackIdAndClass(
        bboxTrackId,
        bboxClass,
        labelTool.currentFileIndex
      );
      this.update2DBoundingBox(
        labelTool.currentFileIndex,
        selectionIndexCurrent,
        true
      );
    }
  },
  //register new bounding box
  // addBoundingBoxGui: function(bbox, bboxEndParams) {

  //     let insertIndex = this.folderBoundingBox3DArray.length;
  //     let bb;
  //     if (this.guiOptions.__folders[bbox.class + ' ' + bbox.trackId] === undefined) {
  //         bb = this.guiOptions.addFolder(bbox.class + ' ' + bbox.trackId);
  //     } else {
  //         bb = this.guiOptions.__folders[bbox.class + ' ' + bbox.trackId];
  //     }

  //     this.folderBoundingBox3DArray.push(bb);
  // },
  // let minZPos;
  // let maxZPos;

  // if (labelTool.currentDataset === labelTool.datasets.providentia) {
  //     minZPos = -7;
  //     maxZPos = -1;
  // } else {
  //     minZPos = -3;
  //     maxZPos = 3;
  // }

  // let folderPosition = this.folderBoundingBox3DArray[insertIndex].addFolder('Position');
  // let cubeX = folderPosition.add(bbox, 'x').name("x").min(this.minXPos).max(this.maxXPos).step(0.01).listen();
  // let cubeY = folderPosition.add(bbox, 'y').name("y").min(this.minYPos).max(this.maxYPos).step(0.01).listen();
  // let cubeZ = folderPosition.add(bbox, 'z').name("z").min(this.minZPos).max(this.maxZPos).step(0.01).listen();
  // let self = this;
  // folderPosition.close();
  // this.folderPositionArray.push(folderPosition);

  // let folderRotation = this.folderBoundingBox3DArray[insertIndex].addFolder('Rotation');
  // let cubeYaw = folderRotation.add(bbox, 'rotationYaw').name("rotationYaw").min(-Math.PI).max(Math.PI).step(0.01).listen();
  // // swap roll and pitch for providentia
  // let cubePitch;
  // let cubeRoll;
  // if (labelTool.currentDataset === labelTool.datasets.NuScenes) {
  //     cubePitch = folderRotation.add(bbox, 'rotationPitch').name("rotationPitch").min(-Math.PI).max(Math.PI).step(0.01).listen();
  //     cubeRoll = folderRotation.add(bbox, 'rotationRoll').name("rotationRoll").min(-Math.PI).max(Math.PI).step(0.01).listen();
  // } else {
  //     cubePitch = folderRotation.add(bbox, 'rotationPitch').name("rotationRoll").min(-Math.PI).max(Math.PI).step(0.01).listen();
  //     cubeRoll = folderRotation.add(bbox, 'rotationRoll').name("rotationPitch").min(-Math.PI).max(Math.PI).step(0.01).listen();
  // }
  // folderRotation.close();
  // this.folderRotationArray.push(folderRotation);

  // let folderSize = this.folderBoundingBox3DArray[insertIndex].addFolder('Size');
  // let cubeWidth = folderSize.add(bbox, 'width').name("width").min(0.3).max(20).step(0.01).listen();
  // let cubeLength = folderSize.add(bbox, 'length').name("length").min(0.3).max(20).step(0.01).listen();
  // let cubeHeight = folderSize.add(bbox, 'height').name("height").min(0.3).max(20).step(0.01).listen();
  // folderSize.close();
  // this.folderSizeArray.push(folderSize);

  // cubeX.onChange(function (value) {
  //     if (value >= this.minXPos && value < this.maxXPos) {
  //         // Note: Do not use insertIndex because it might change (if deleting e.g. an object in between)
  //         // use track id and class to calculate selection index
  //         let selectionIndex = self.getObjectIndexByTrackIdAndClass(bbox.trackId, bbox.class, labelTool.currentFileIndex);
  //         labelTool.cubeArray[labelTool.currentFileIndex][selectionIndex].position.x = value;
  //         self.contents[labelTool.currentFileIndex][selectionIndex]["x"] = value;
  //         if (labelTool.pointCloudOnlyAnnotation === false) {
  //             // update bounding box
  //             self.update2DBoundingBox(labelTool.currentFileIndex, selectionIndex, true);
  //         }
  //     }
  // });
  // cubeY.onChange(function (value) {
  //     if (value >= this.minYPos && value < this.maxYPos) {
  //         let selectionIndex = self.getObjectIndexByTrackIdAndClass(bbox.trackId, bbox.class, labelTool.currentFileIndex);
  //         labelTool.cubeArray[labelTool.currentFileIndex][selectionIndex].position.y = value;
  //         self.contents[labelTool.currentFileIndex][selectionIndex]["y"] = value;
  //         if (labelTool.pointCloudOnlyAnnotation === false) {
  //             // update bounding box
  //             self.update2DBoundingBox(labelTool.currentFileIndex, selectionIndex, true);
  //         }
  //     }
  // });
  // cubeZ.onChange(function (value) {
  //     if (value >= this.minZPos && value < this.maxZPos) {
  //         let selectionIndex = self.getObjectIndexByTrackIdAndClass(bbox.trackId, bbox.class, labelTool.currentFileIndex);
  //         labelTool.cubeArray[labelTool.currentFileIndex][selectionIndex].position.z = value;
  //         self.contents[labelTool.currentFileIndex][selectionIndex]["z"] = value;
  //         if (labelTool.pointCloudOnlyAnnotation === false) {
  //             // update bounding box
  //             self.update2DBoundingBox(labelTool.currentFileIndex, selectionIndex, true);
  //         }
  //     }
  // });
  // cubeYaw.onChange(function (value) {
  //     let selectionIndex = self.getObjectIndexByTrackIdAndClass(bbox.trackId, bbox.class, labelTool.currentFileIndex);
  //     labelTool.cubeArray[labelTool.currentFileIndex][selectionIndex].rotation.z = value;
  //     self.contents[labelTool.currentFileIndex][selectionIndex]["rotationYaw"] = value;
  //     if (labelTool.pointCloudOnlyAnnotation === false) {
  //         // update bounding box
  //         self.update2DBoundingBox(labelTool.currentFileIndex, selectionIndex, true);
  //     }
  // });
  // cubePitch.onChange(function (value) {
  //     let selectionIndex = self.getObjectIndexByTrackIdAndClass(bbox.trackId, bbox.class, labelTool.currentFileIndex);
  //     labelTool.cubeArray[labelTool.currentFileIndex][selectionIndex].rotation.x = value;
  //     self.contents[labelTool.currentFileIndex][selectionIndex]["rotationPitch"] = value;
  //     if (labelTool.pointCloudOnlyAnnotation === false) {
  //         // update bounding box
  //         self.update2DBoundingBox(labelTool.currentFileIndex, selectionIndex, true);
  //     }
  // });
  // cubeRoll.onChange(function (value) {
  //     let selectionIndex = self.getObjectIndexByTrackIdAndClass(bbox.trackId, bbox.class, labelTool.currentFileIndex);
  //     labelTool.cubeArray[labelTool.currentFileIndex][selectionIndex].rotation.y = value;
  //     self.contents[labelTool.currentFileIndex][selectionIndex]["rotationRoll"] = value;
  //     if (labelTool.pointCloudOnlyAnnotation === false) {
  //         // update bounding box
  //         self.update2DBoundingBox(labelTool.currentFileIndex, selectionIndex, true);
  //     }
  // });
  // cubeWidth.onChange(function (value) {
  //     for (let i = 0; i < labelTool.numFrames; i++) {
  //         let selectionIndex = self.getObjectIndexByTrackIdAndClass(bbox.trackId, bbox.class, i);
  //         if (selectionIndex !== -1) {
  //             let newXPos = labelTool.cubeArray[i][selectionIndex].position.x + (value - labelTool.cubeArray[i][selectionIndex].scale.x) * Math.cos(labelTool.cubeArray[i][selectionIndex].rotation.z) / 2;
  //             labelTool.cubeArray[i][selectionIndex].position.x = newXPos;
  //             if (i === labelTool.currentFileIndex) {
  //                 bbox.x = newXPos;
  //             }
  //             self.contents[i][selectionIndex]["x"] = newXPos;
  //             let newYPos = labelTool.cubeArray[i][selectionIndex].position.y + (value - labelTool.cubeArray[i][selectionIndex].scale.x) * Math.sin(labelTool.cubeArray[i][selectionIndex].rotation.z) / 2;
  //             labelTool.cubeArray[i][selectionIndex].position.y = newYPos;
  //             if (i === labelTool.currentFileIndex) {
  //                 bbox.y = newYPos;
  //             }
  //             self.contents[i][selectionIndex]["y"] = newYPos;
  //             labelTool.cubeArray[i][selectionIndex].scale.x = value;
  //             self.contents[i][selectionIndex]["width"] = value;
  //         }
  //     }
  //     if (labelTool.pointCloudOnlyAnnotation === false) {
  //         let selectionIndexCurrentFrame = self.getObjectIndexByTrackIdAndClass(bbox.trackId, bbox.class, labelTool.currentFileIndex);
  //         self.update2DBoundingBox(labelTool.currentFileIndex, selectionIndexCurrentFrame, true);
  //     }
  // });
  // cubeLength.onChange(function (value) {
  //     for (let i = 0; i < labelTool.numFrames; i++) {
  //         let selectionIndex = self.getObjectIndexByTrackIdAndClass(bbox.trackId, bbox.class, i);
  //         if (selectionIndex !== -1) {
  //             let newXPos = labelTool.cubeArray[i][selectionIndex].position.x + (value - labelTool.cubeArray[i][selectionIndex].scale.y) * Math.sin(labelTool.cubeArray[i][selectionIndex].rotation.z) / 2;
  //             labelTool.cubeArray[i][selectionIndex].position.x = newXPos;
  //             bbox.x = newXPos;
  //             self.contents[i][selectionIndex]["x"] = newXPos;
  //             let newYPos = labelTool.cubeArray[i][selectionIndex].position.y - (value - labelTool.cubeArray[i][selectionIndex].scale.y) * Math.cos(labelTool.cubeArray[i][selectionIndex].rotation.z) / 2;
  //             labelTool.cubeArray[i][selectionIndex].position.y = newYPos;
  //             bbox.y = newYPos;
  //             self.contents[i][selectionIndex]["y"] = newYPos;
  //             labelTool.cubeArray[i][selectionIndex].scale.y = value;
  //             self.contents[i][selectionIndex]["length"] = value;
  //         }
  //     }
  //     if (labelTool.pointCloudOnlyAnnotation === false) {
  //         let selectionIndexCurrent = self.getObjectIndexByTrackIdAndClass(bbox.trackId, bbox.class, labelTool.currentFileIndex);
  //         self.update2DBoundingBox(labelTool.currentFileIndex, selectionIndexCurrent, true);
  //     }
  // });
  // cubeHeight.onChange(function (value) {
  //     for (let i = 0; i < labelTool.numFrames; i++) {
  //         let selectionIndex = self.getObjectIndexByTrackIdAndClass(bbox.trackId, bbox.class, i);
  //         if (selectionIndex !== -1) {
  //             let newZPos = labelTool.cubeArray[i][selectionIndex].position.z + (value - labelTool.cubeArray[i][selectionIndex].scale.z) / 2;
  //             labelTool.cubeArray[i][selectionIndex].position.z = newZPos;
  //             bbox.z = newZPos;
  //             labelTool.cubeArray[i][selectionIndex].scale.z = value;
  //             self.contents[i][selectionIndex]["height"] = value;
  //         }
  //     }
  //     if (labelTool.pointCloudOnlyAnnotation === false) {
  //         let selectionIndexCurrent = self.getObjectIndexByTrackIdAndClass(bbox.trackId, bbox.class, labelTool.currentFileIndex);
  //         self.update2DBoundingBox(labelTool.currentFileIndex, selectionIndexCurrent, true);
  //     }

  // });

  // if (bboxEndParams !== undefined && this.interpolationMode === true) {
  //     //labelTool.interpolationObjIndexCurrentFile = annotationObjects.getSelectionIndex();
  //     this.interpolationObjIndexNextFile = this.getObjectIndexByTrackIdAndClass(this.contents[labelTool.currentFileIndex][labelTool.interpolationObjIndexCurrentFile]["trackId"], this.contents[labelTool.currentFileIndex][labelTool.interpolationObjIndexCurrentFile]["class"], bboxEndParams.newFileIndex);
  //     // change text
  //     let interpolationStartFileIndex = this.contents[labelTool.currentFileIndex][labelTool.interpolationObjIndexCurrentFile]["interpolationStartFileIndex"];
  //     this.folderPositionArray[this.interpolationObjIndexNextFile].domElement.firstChild.firstChild.innerText = "Interpolation Start Position (frame " + interpolationStartFileIndex + ")";
  //     this.folderRotationArray[this.interpolationObjIndexNextFile].domElement.firstChild.firstChild.innerText = "Interpolation Start Rotation (frame " + interpolationStartFileIndex + ")";
  //     this.folderSizeArray[this.interpolationObjIndexNextFile].domElement.firstChild.firstChild.innerText = "Interpolation Start Size (frame " + interpolationStartFileIndex + ")";

  //     if (interpolationStartFileIndex !== bboxEndParams.newFileIndex) {
  //         this.disableStartPose();
  //         // add folders for end position and end size
  //         labelTool.folderEndPosition = this.folderBoundingBox3DArray[this.interpolationObjIndexNextFile].addFolder("Interpolation End Position (frame " + (labelTool.currentFileIndex + 1) + ")");
  //         let cubeEndX = labelTool.folderEndPosition.add(bboxEndParams, 'x').name("x").min(minXPos).max(maxXPos).step(0.01).listen();
  //         let cubeEndY = labelTool.folderEndPosition.add(bboxEndParams, 'y').name("y").min(minYPos).max(maxYPos).step(0.01).listen();
  //         let cubeEndZ = labelTool.folderEndPosition.add(bboxEndParams, 'z').name("z)").min(minZPos).max(maxZPos).step(0.01).listen();
  //         let cubeEndYaw = labelTool.folderEndPosition.add(bboxEndParams, 'rotationYaw').name("rotationYaw").min(-Math.PI).max(Math.PI).step(0.01).listen();
  //         let cubeEndPitch = labelTool.folderEndPosition.add(bboxEndParams, 'rotationPitch').name("rotationPitch").min(-Math.PI).max(Math.PI).step(0.01).listen();
  //         let cubeEndRoll = labelTool.folderEndPosition.add(bboxEndParams, 'rotationRoll').name("rotationRoll").min(-Math.PI).max(Math.PI).step(0.01).listen();
  //         labelTool.folderEndPosition.domElement.id = 'interpolation-end-position-folder';
  //         labelTool.folderEndPosition.open();
  //         labelTool.folderEndSize = this.folderBoundingBox3DArray[this.interpolationObjIndexNextFile].addFolder("Interpolation End Size (frame " + (labelTool.currentFileIndex + 1) + ")");
  //         let cubeEndWidth = labelTool.folderEndSize.add(bboxEndParams, 'width').name("width").min(0.3).max(20).step(0.01).listen();
  //         let cubeEndLength = labelTool.folderEndSize.add(bboxEndParams, 'length').name("length").min(0.3).max(20).step(0.01).listen();
  //         let cubeEndHeight = labelTool.folderEndSize.add(bboxEndParams, 'height').name("height").min(0.3).max(20).step(0.01).listen();
  //         labelTool.folderEndPosition.domElement.id = 'interpolation-end-size-folder';
  //         labelTool.folderEndSize.open();
  //         let newFileIndex = bboxEndParams.newFileIndex;

  //         cubeEndX.onChange(function (value) {
  //             if (value >= minXPos && value < maxXPos) {
  //                 updateXPos(newFileIndex, value);
  //             }
  //         });
  //         cubeEndY.onChange(function (value) {
  //             if (value >= minYPos && value < maxYPos) {
  //                 labelTool.cubeArray[newFileIndex][this.interpolationObjIndexNextFile].position.y = value;
  //                 this.contents[newFileIndex][this.interpolationObjIndexNextFile]["interpolationEnd"]["position"]["y"] = value;
  //                 this.contents[newFileIndex][this.interpolationObjIndexNextFile]["y"] = value;
  //                 if (labelTool.pointCloudOnlyAnnotation === false) {
  //                     // update bounding box
  //                     this.update2DBoundingBox(labelTool.currentFileIndex, labelTool.interpolationObjIndexCurrentFile, true);
  //                 }
  //             }
  //         });
  //         cubeEndZ.onChange(function (value) {
  //             if (value >= minZPos && value < maxZPos) {
  //                 labelTool.cubeArray[newFileIndex][this.interpolationObjIndexNextFile].position.z = value;
  //                 this.contents[newFileIndex][this.interpolationObjIndexNextFile]["interpolationEnd"]["position"]["z"] = value;
  //                 this.contents[newFileIndex][this.interpolationObjIndexNextFile]["z"] = value;
  //                 if (labelTool.pointCloudOnlyAnnotation === false) {
  //                     // update bounding box
  //                     this.update2DBoundingBox(labelTool.currentFileIndex, labelTool.interpolationObjIndexCurrentFile, true);
  //                 }
  //             }
  //         });
  //         cubeEndYaw.onChange(function (value) {
  //             labelTool.cubeArray[newFileIndex][this.interpolationObjIndexNextFile].rotation.z = value;
  //             this.contents[newFileIndex][this.interpolationObjIndexNextFile]["interpolationEnd"]["position"]["rotationYaw"] = value;
  //             this.contents[newFileIndex][this.interpolationObjIndexNextFile]["rotationYaw"] = value;
  //             if (labelTool.pointCloudOnlyAnnotation === false) {
  //                 // update bounding box
  //                 this.update2DBoundingBox(labelTool.currentFileIndex, labelTool.interpolationObjIndexCurrentFile, true);
  //             }
  //         });
  //         cubeEndPitch.onChange(function (value) {
  //             labelTool.cubeArray[newFileIndex][this.interpolationObjIndexNextFile].rotation.x = value;
  //             this.contents[newFileIndex][this.interpolationObjIndexNextFile]["interpolationEnd"]["position"]["rotationPitch"] = value;
  //             this.contents[newFileIndex][this.interpolationObjIndexNextFile]["rotationPitch"] = value;
  //             if (labelTool.pointCloudOnlyAnnotation === false) {
  //                 // update bounding box
  //                 this.update2DBoundingBox(labelTool.currentFileIndex, labelTool.interpolationObjIndexCurrentFile, true);
  //             }
  //         });
  //         cubeEndRoll.onChange(function (value) {
  //             labelTool.cubeArray[newFileIndex][this.interpolationObjIndexNextFile].rotation.y = value;
  //             this.contents[newFileIndex][this.interpolationObjIndexNextFile]["interpolationEnd"]["position"]["rotationRoll"] = value;
  //             this.contents[newFileIndex][this.interpolationObjIndexNextFile]["rotationRoll"] = value;
  //             if (labelTool.pointCloudOnlyAnnotation === false) {
  //                 // update bounding box
  //                 this.update2DBoundingBox(labelTool.currentFileIndex, labelTool.interpolationObjIndexCurrentFile, true);
  //             }
  //         });
  //         cubeEndWidth.onChange(function (value) {
  //             let newXPos = labelTool.cubeArray[newFileIndex][this.interpolationObjIndexNextFile].position.x + (value - labelTool.cubeArray[newFileIndex][this.interpolationObjIndexNextFile].scale.x)
  //                 * Math.cos(labelTool.cubeArray[newFileIndex][this.interpolationObjIndexNextFile].rotation.z) / 2;
  //             labelTool.cubeArray[newFileIndex][this.interpolationObjIndexNextFile].position.x = newXPos;
  //             labelTool.cubeArray[labelTool.currentFileIndex][labelTool.interpolationObjIndexCurrentFile].position.x = newXPos;

  //             this.contents[newFileIndex][this.interpolationObjIndexNextFile]["interpolationEnd"]["position"]["x"] = newXPos;
  //             this.contents[newFileIndex][this.interpolationObjIndexNextFile]["x"] = newXPos;
  //             let newYPos = labelTool.cubeArray[newFileIndex][this.interpolationObjIndexNextFile].position.y + (value - labelTool.cubeArray[newFileIndex][this.interpolationObjIndexNextFile].scale.x)
  //                 * Math.sin(labelTool.cubeArray[newFileIndex][this.interpolationObjIndexNextFile].rotation.z) / 2;
  //             labelTool.cubeArray[newFileIndex][this.interpolationObjIndexNextFile].position.y = newYPos;
  //             labelTool.cubeArray[labelTool.currentFileIndex][labelTool.interpolationObjIndexCurrentFile].position.y = newYPos;

  //             this.contents[newFileIndex][this.interpolationObjIndexNextFile]["interpolationEnd"]["position"]["y"] = newYPos;
  //             this.contents[newFileIndex][this.interpolationObjIndexNextFile]["y"] = newYPos;
  //             labelTool.cubeArray[newFileIndex][this.interpolationObjIndexNextFile].scale.x = value;
  //             labelTool.cubeArray[labelTool.currentFileIndex][labelTool.interpolationObjIndexCurrentFile].scale.x = value;

  //             this.contents[newFileIndex][this.interpolationObjIndexNextFile]["interpolationEnd"]["size"]["width"] = value;
  //             this.contents[newFileIndex][this.interpolationObjIndexNextFile]["width"] = value;
  //             if (labelTool.pointCloudOnlyAnnotation === false) {
  //                 this.update2DBoundingBox(labelTool.currentFileIndex, labelTool.interpolationObjIndexCurrentFile, true);
  //             }
  //         });
  //         cubeEndLength.onChange(function (value) {
  //             let newXPos = labelTool.cubeArray[newFileIndex][this.interpolationObjIndexNextFile].position.x + (value - labelTool.cubeArray[newFileIndex][this.interpolationObjIndexNextFile].scale.y) * Math.sin(labelTool.cubeArray[newFileIndex][labelTool.interpolationObjIndexCurrentFile].rotation.z) / 2;
  //             labelTool.cubeArray[newFileIndex][this.interpolationObjIndexNextFile].position.x = newXPos;
  //             this.contents[newFileIndex][this.interpolationObjIndexNextFile]["interpolationEnd"]["position"]["x"] = newXPos;
  //             this.contents[newFileIndex][this.interpolationObjIndexNextFile]["x"] = newXPos;
  //             let newYPos = labelTool.cubeArray[newFileIndex][this.interpolationObjIndexNextFile].position.y - (value - labelTool.cubeArray[newFileIndex][this.interpolationObjIndexNextFile].scale.y) * Math.cos(labelTool.cubeArray[newFileIndex][labelTool.interpolationObjIndexCurrentFile].rotation.z) / 2;
  //             labelTool.cubeArray[newFileIndex][this.interpolationObjIndexNextFile].position.y = newYPos;
  //             // test with -newYPos
  //             this.contents[newFileIndex][this.interpolationObjIndexNextFile]["interpolationEnd"]["position"]["y"] = newYPos;
  //             this.contents[newFileIndex][this.interpolationObjIndexNextFile]["y"] = newYPos;

  //             labelTool.cubeArray[newFileIndex][this.interpolationObjIndexNextFile].scale.y = value;
  //             this.contents[newFileIndex][this.interpolationObjIndexNextFile]["interpolationEnd"]["size"]["length"] = value;
  //             this.contents[newFileIndex][this.interpolationObjIndexNextFile]["length"] = value;
  //             if (labelTool.pointCloudOnlyAnnotation === false) {
  //                 this.update2DBoundingBox(labelTool.currentFileIndex, labelTool.interpolationObjIndexCurrentFile, true);
  //             }
  //         });
  //         cubeEndHeight.onChange(function (value) {
  //             let newZPos = labelTool.cubeArray[newFileIndex][this.interpolationObjIndexNextFile].position.z + (value - labelTool.cubeArray[newFileIndex][this.interpolationObjIndexNextFile].scale.z) / 2;
  //             labelTool.cubeArray[newFileIndex][this.interpolationObjIndexNextFile].position.z = newZPos;
  //             labelTool.cubeArray[newFileIndex][this.interpolationObjIndexNextFile].scale.z = value;
  //             this.contents[newFileIndex][this.interpolationObjIndexNextFile]["interpolationEnd"]["size"]["height"] = value;
  //             this.contents[newFileIndex][this.interpolationObjIndexNextFile]["height"] = value;
  //             if (labelTool.pointCloudOnlyAnnotation === false) {
  //                 this.update2DBoundingBox(labelTool.currentFileIndex, labelTool.interpolationObjIndexCurrentFile, true);
  //             }
  //         });
  //     }
  // }

  //     let textBoxTrackId = this.folderBoundingBox3DArray[insertIndex].add(bbox, 'trackId').min(0).step(1).name('Track ID');
  //     textBoxTrackId.onChange(function (value) {
  //         // check validity
  //         // get smallest available track id for this class (look at all objects within that sequence)

  //         let minTrackId = getSmallestTrackId(bbox.class);
  //         if (value < 1 || value !== minTrackId) {
  //             labelTool.logger.error("You have entered an invalid track ID.");
  //         }
  //         labelTool.logger.success("Track ID for class " + bbox.class + " was set to " + minTrackId + ".");
  //         value = Math.round(minTrackId);
  //         // update cube name
  //         labelTool.cubeArray[labelTool.currentFileIndex][insertIndex].name = 'cube-' + bbox.class.charAt(0) + value;
  //         this.contents[labelTool.currentFileIndex][insertIndex]["trackId"] = value;
  //         if (labelTool.selectedMesh !== undefined) {
  //             labelTool.selectedMesh.name = 'cube-' + bbox.class.charAt(0) + value;
  //         }
  //         $("#bounding-box-3d-menu ul").children().eq(insertIndex + this.numGUIOptions).children().first().children().first().children().first().text(bbox.class + " " + value);
  //     });

  //     let labelAttributes = {
  //         'copy_label_to_next_frame': bbox.copyLabelToNextFrame,
  //         reset: function () {
  //             resetCube(insertIndex);
  //         },
  //         delete: function () {
  //             let labelIndex = annotationObjects.getObjectIndexByTrackIdAndClass(bbox.trackId, bbox.class, labelTool.currentFileIndex);
  //             deleteObject(bbox.class, bbox.trackId, labelIndex);
  //         }
  //     };
  //     let copyLabelToNextFrameCheckbox = this.folderBoundingBox3DArray[this.folderBoundingBox3DArray.length - 1].add(labelAttributes, 'copy_label_to_next_frame').name("Copy label to next frame");
  //     copyLabelToNextFrameCheckbox.domElement.id = 'copy-label-to-next-frame-checkbox-' + insertIndex;
  //     // check copy checkbox AND disable it for selected object if in interpolation mode
  //     if (this.interpolationMode === true && bboxEndParams !== undefined) {
  //         copyLabelToNextFrameCheckbox.domElement.firstChild.checked = true;
  //         disableCopyLabelToNextFrameCheckbox(copyLabelToNextFrameCheckbox.domElement);

  //     }
  //     copyLabelToNextFrameCheckbox.onChange(function (value) {
  //         this.contents[labelTool.currentFileIndex][insertIndex]["copyLabelToNextFrame"] = value;
  //     });

  //     this.folderBoundingBox3DArray[this.folderBoundingBox3DArray.length - 1].add(labelAttributes, 'reset').name("Reset");
  //     this.folderBoundingBox3DArray[this.folderBoundingBox3DArray.length - 1].add(labelAttributes, 'delete').name("Delete");
  // },

  increaseBrightness: function(hex, percent) {
    // strip the leading # if it's there
    hex = hex.replace(/^\s*#|\s*$/g, "");

    // convert 3 char codes --> 6, e.g. `E0F` --> `EE00FF`
    if (hex.length === 3) {
      hex = hex.replace(/(.)/g, "$1$1");
    }

    let r = parseInt(hex.substr(0, 2), 16),
      g = parseInt(hex.substr(2, 2), 16),
      b = parseInt(hex.substr(4, 2), 16);

    return (
      "#" +
      (0 | ((1 << 8) + r + ((256 - r) * percent) / 100))
        .toString(16)
        .substr(1) +
      (0 | ((1 << 8) + g + ((256 - g) * percent) / 100))
        .toString(16)
        .substr(1) +
      (0 | ((1 << 8) + b + ((256 - b) * percent) / 100)).toString(16).substr(1)
    );
  },

  addClassTooltip: function(fileIndex, trackId, color, bbox) {
    let classTooltipElement = $(
      "<div class='class-tooltip' id='tooltip-" +
        trackId +
        "'>" +
        trackId +
        "</div>"
    );
    // Sprite
    const spriteMaterial = new THREE.SpriteMaterial({
      alphaTest: 0.5,
      transparent: true,
      depthTest: false,
      depthWrite: false,
    });
    let sprite = new THREE.Sprite(spriteMaterial);
    sprite.position.set(
      bbox.x + bbox.width / 2,
      bbox.y + bbox.length / 2,
      bbox.z + bbox.height / 2
    );
    sprite.scale.set(1, 1, 1);
    sprite.name = "sprite-" + trackId;

    // add tooltip only to DOM if fileIndex is equal to current file index
    if (fileIndex === labelTool.currentFileIndex) {
      $("body").append(classTooltipElement);
      labelTool.scene.add(sprite);
    }
    labelTool.spriteArray[fileIndex].push(sprite);
  },

  get3DLabelLoadBox: function(parameters) {
    let bbox = parameters;
    let cubeGeometry = new THREE.BoxBufferGeometry(1.0, 1.0, 1.0); //width, length, height
    let color;

    if (
      parameters.fromFile === true &&
      classesBoundingBox[parameters.class].color !== undefined
    ) {
      color = classesBoundingBox[parameters.class].color;
    } else {
      color = classesBoundingBox.getCurrentAnnotationClassObject().color;
    }

    let cubeMaterialSide = new THREE.MeshBasicMaterial({
      color: color,
      transparent: true,
      opacity: 0.1,
      side: THREE.DoubleSide,
      morphTargets: false,
    });

    let cubeMaterialFrontSide = new THREE.MeshBasicMaterial({
      color: color,
      transparent: true,
      opacity: 0.9,
      side: THREE.DoubleSide,
      morphTargets: false,
    });

    let cubeMaterials = [
      cubeMaterialFrontSide,
      cubeMaterialSide,
      cubeMaterialSide,
      cubeMaterialSide,
      cubeMaterialSide,
      cubeMaterialSide,
    ];
    let faceMaterial = new THREE.MeshFaceMaterial(cubeMaterials);
    let cubeMesh = new THREE.Mesh(cubeGeometry, faceMaterial);

    cubeMesh.position.set(bbox.x, bbox.y, bbox.z);
    cubeMesh.scale.set(bbox.width, bbox.length, bbox.height);
    cubeMesh.rotation.x = bbox.rotationPitch;
    cubeMesh.rotation.y = bbox.rotationRoll;
    cubeMesh.rotation.z = bbox.rotationYaw;
    cubeMesh.name = "cube-" + parameters.trackId;
    // get bounding box from object
    let boundingBoxColor = this.increaseBrightness(color, 50);
    let edgesGeometry = new THREE.EdgesGeometry(cubeMesh.geometry);
    let edgesMaterial = new THREE.LineBasicMaterial({
      color: boundingBoxColor,
      linewidth: 4,
    });
    let edges = new THREE.LineSegments(edgesGeometry, edgesMaterial);
    cubeMesh.add(edges);

    // add object only to scene if file index is equal to current file index
    if (parameters.fileIndex === labelTool.currentFileIndex) {
      labelTool.scene.add(cubeMesh);
      // this.addBoundingBoxGui(bbox, undefined);
    }
    // class tooltip
    this.addClassTooltip(parameters.fileIndex, parameters.trackId, color, bbox);
    labelTool.cubeArray[parameters.fileIndex].push(cubeMesh);
    return bbox;
  },
  get3DLabelMakeBox: function(insertIndex, parameters) {
    let bbox = parameters;
    let cubeGeometry = new THREE.BoxBufferGeometry(1.0, 1.0, 1.0); //width, length, height
    let color = "yellow";

    let cubeMaterialSide = new THREE.MeshBasicMaterial({
      color: color,
      transparent: true,
      opacity: 0.1,
      side: THREE.DoubleSide,
      morphTargets: false,
    });

    let cubeMaterialFrontSide = new THREE.MeshBasicMaterial({
      color: color,
      transparent: true,
      opacity: 0.9,
      side: THREE.DoubleSide,
      morphTargets: false,
    });

    let cubeMaterials = [
      cubeMaterialFrontSide,
      cubeMaterialSide,
      cubeMaterialSide,
      cubeMaterialSide,
      cubeMaterialSide,
      cubeMaterialSide,
    ];
    let faceMaterial = new THREE.MeshFaceMaterial(cubeMaterials);
    let cubeMesh = new THREE.Mesh(cubeGeometry, faceMaterial);

    cubeMesh.position.set(bbox.x, bbox.y, bbox.z);
    cubeMesh.scale.set(bbox.width, bbox.length, bbox.height);
    cubeMesh.rotation.x = bbox.rotationPitch;
    cubeMesh.rotation.y = bbox.rotationRoll;
    cubeMesh.rotation.z = bbox.rotationYaw;
    cubeMesh.name = "cube-" + insertIndex;
    // get bounding box from object
    let boundingBoxColor = this.increaseBrightness(color, 50);
    let edgesGeometry = new THREE.EdgesGeometry(cubeMesh.geometry);
    let edgesMaterial = new THREE.LineBasicMaterial({
      color: boundingBoxColor,
      linewidth: 4,
    });
    let edges = new THREE.LineSegments(edgesGeometry, edgesMaterial);
    cubeMesh.add(edges);

    // add object only to scene if file index is equal to current file index
    if (parameters.fileIndex === labelTool.currentFileIndex) {
      labelTool.scene.add(cubeMesh);
      // this.addBoundingBoxGui(bbox, undefined);
    }
    // class tooltip
    this.addClassTooltip(parameters.fileIndex, insertIndex, color, bbox);
    labelTool.cubeArray[parameters.fileIndex].push(cubeMesh);
    return bbox;
  },
  onChangeClass: function(dataType, f) {
    this.localOnChangeClass[dataType] = f;
  },
  onRemove: function(dataType) {},
  get: function(index, channel) {
    if (this.contents[index] === undefined) {
      return undefined;
    }
    if (channel === undefined) {
      return this.contents[index];
    }
    return this.contents[index][channel];
  },
  set: function(insertIndex, params) {
    let obj = this.get3DLabelLoadBox(params);
    if (this.contents[params.fileIndex][insertIndex] === undefined) {
      this.contents[params.fileIndex].push(obj);
    } else {
      this.contents[params.fileIndex][insertIndex] = obj;
    }
    this.contents[params.fileIndex][insertIndex]["class"] = params.class;
    this.contents[params.fileIndex][insertIndex]["interpolationStart"] =
      params["interpolationStart"];
    this.contents[params.fileIndex][insertIndex][
      "interpolationStartFileIndex"
    ] = params.interpolationStartFileIndex;
    this.contents[params.fileIndex].insertIndex = insertIndex;
    if (params.fromFile === false && this.__selectionIndexCurrentFrame === -1) {
      if (
        labelTool.showOriginalNuScenesLabels === true &&
        labelTool.currentDataset === labelTool.datasets.NuScenes
      ) {
        this.contents[params.fileIndex][insertIndex]["trackId"] =
          classesBoundingBox[params.class].nextTrackId;
      } else {
        this.contents[params.fileIndex][insertIndex]["trackId"] =
          classesBoundingBox[params.class].nextTrackId;
      }
    } else {
      this.contents[params.fileIndex][insertIndex]["trackId"] = params.trackId;
    }
    this.contents[params.fileIndex][insertIndex]["channels"] = params.channels;
    this.contents[params.fileIndex][insertIndex]["fileIndex"] =
      params.fileIndex;
    this.contents[params.fileIndex][insertIndex]["copyLabelToNextFrame"] =
      params.copyLabelToNextFrame;
  },
  setMakeBox: function(insertIndex, params) {
    let obj = this.get3DLabelMakeBox(insertIndex, params);
    if (this.contents[params.fileIndex][insertIndex] === undefined) {
      this.contents[params.fileIndex].push(obj);
    } else {
      this.contents[params.fileIndex][insertIndex] = obj;
    }
    this.contents[params.fileIndex].insertIndex = insertIndex;
    this.contents[params.fileIndex][insertIndex]["trackId"] = insertIndex;
    this.contents[params.fileIndex][insertIndex]["channels"] = params.channels;
    this.contents[params.fileIndex][insertIndex]["fileIndex"] =
      params.fileIndex;
    this.contents[params.fileIndex][insertIndex]["copyLabelToNextFrame"] =
      params.copyLabelToNextFrame;
  },
  changeClass: function(selectedObjectIndex, newClassLabel) {
    if (
      this.contents[labelTool.currentFileIndex][selectedObjectIndex] ===
      undefined
    ) {
      return false;
    }

    // return if same class was chosen again
    let currentClassLabel = this.contents[labelTool.currentFileIndex][
      selectedObjectIndex
    ]["class"];
    // if (currentClassLabel === newClassLabel) {
    //     return false;
    // }

    // update id of sprite
    let currentTrackId = this.contents[labelTool.currentFileIndex][
      selectedObjectIndex
    ]["trackId"];
    let spriteElem = $(
      "#class-" + currentClassLabel.charAt(0) + currentTrackId
    );
    // use original track id if original class selected
    let nextTrackIdNewClass;
    if (
      newClassLabel ===
      this.contents[labelTool.currentFileIndex][selectedObjectIndex][
        "original"
      ]["class"]
    ) {
      nextTrackIdNewClass = this.contents[labelTool.currentFileIndex][
        selectedObjectIndex
      ]["original"]["trackId"];
    } else {
      nextTrackIdNewClass = classesBoundingBox[newClassLabel]["nextTrackId"];
    }

    $(spriteElem)
      .attr("id", "class-" + newClassLabel.charAt(0) + nextTrackIdNewClass)
      .attr("background", "rgba(255, 255, 255, 0.8)");

    // update background color of sprite
    $($(spriteElem)[0]).css(
      "background",
      classesBoundingBox[newClassLabel].color
    );

    // update class label
    this.contents[labelTool.currentFileIndex][selectedObjectIndex][
      "class"
    ] = newClassLabel;

    // update track id
    this.contents[labelTool.currentFileIndex][selectedObjectIndex][
      "trackId"
    ] = nextTrackIdNewClass;
    // set next highest track ID of current class

    setHighestAvailableTrackId(currentClassLabel);
    // increase track id of new class
    classesBoundingBox[newClassLabel]["nextTrackId"] =
      classesBoundingBox[newClassLabel]["nextTrackId"] + 1;

    // update text of sprite
    $($(spriteElem)[0]).text(
      newClassLabel.charAt(0) + nextTrackIdNewClass + " | " + newClassLabel
    );
    // update name of sprite
    labelTool.spriteArray[labelTool.currentFileIndex][
      selectedObjectIndex
    ].name = "sprite-" + nextTrackIdNewClass;

    // update class of folder and track id instead of creating new folder
    this.folderBoundingBox3DArray[
      selectedObjectIndex
    ].domElement.children[0].children[0].innerHTML =
      newClassLabel + " " + nextTrackIdNewClass;
    //                                                           ul        number      div       div[class c]    input
    this.folderBoundingBox3DArray[
      selectedObjectIndex
    ].domElement.children[0].children[4].children[0].children[1].children[0].value = nextTrackIdNewClass;

    this.guiOptions.__folders[
      newClassLabel + " " + nextTrackIdNewClass
    ] = this.guiOptions.__folders[currentClassLabel + " " + currentTrackId];
    delete this.guiOptions.__folders[currentClassLabel + " " + currentTrackId];

    // open current folder
    this.folderBoundingBox3DArray[selectedObjectIndex].open();
    this.folderPositionArray[selectedObjectIndex].open();
    this.folderRotationArray[selectedObjectIndex].open();
    this.folderSizeArray[selectedObjectIndex].open();
    // update name of selected object
    labelTool.selectedMesh.name = "cube-" + nextTrackIdNewClass;
    for (let channelObj in labelTool.camChannels) {
      if (labelTool.camChannels.hasOwnProperty(channelObj)) {
        let channelObject = labelTool.camChannels[channelObj];
        this.localOnChangeClass[channelObject.channel](
          selectedObjectIndex,
          newClassLabel
        );
      }
    }
    this.localOnChangeClass["PCD"](selectedObjectIndex, newClassLabel);
    let classPickerElem = $("#class-picker ul li");
    classPickerElem.css("background-color", "#353535");
    $(classPickerElem[classesBoundingBox[newClassLabel].index]).css(
      "background-color",
      "#525252"
    );
  },
  getSelectedBoundingBox: function() {
    if (
      this.__selectionIndexCurrentFrame === -1 ||
      this.contents[labelTool.currentFileIndex][
        this.__selectionIndexCurrentFrame
      ] === undefined
    ) {
      return undefined;
    } else {
      return this.contents[labelTool.currentFileIndex][
        this.__selectionIndexCurrentFrame
      ];
    }
  },
  setSelectionIndex: function(selectionIndex, channel) {
    // show bounding box highlighting
    this.__selectionIndexCurrentFrame = selectionIndex;
    if (selectionIndex !== -1) {
      this.localOnSelect[channel](selectionIndex);
      return true;
    } else {
      return false;
    }
  },
  select: function(objectIndex, channel) {
    this.setSelectionIndex(objectIndex, channel);
    this.localOnSelect["PCD"](objectIndex);
  },
  getSelectionIndex: function() {
    return this.__selectionIndexCurrentFrame;
  },
  selectEmpty: function() {
    this.setSelectionIndex(-1, undefined);
  },
  remove: function(index) {
    // remove 3d object
    this.removeObject(
      "cube-" + this.contents[labelTool.currentFileIndex][index]["trackId"]
    );
    // remove 2d object
    delete this.contents[labelTool.currentFileIndex][index];
    this.contents[labelTool.currentFileIndex].splice(index, 1);
    delete labelTool.cubeArray[labelTool.currentFileIndex][index];
    labelTool.cubeArray[labelTool.currentFileIndex].splice(index, 1);
    this.__insertIndex--;
    this.select(-1, undefined);
  },
  removeSelectedBoundingBox: function() {
    this.remove(this.__selectionIndexCurrentFrame);
  },
  removeObject: function(objectName) {
    for (let i = labelTool.scene.children.length - 1; i >= 0; i--) {
      let obj = labelTool.scene.children[i];
      if (obj.name === objectName) {
        labelTool.scene.remove(obj);
        return true;
      }
    }
    return false;
  },
  clear: function() {
    for (let j = 0; j < this.contents.length; j++) {
      for (let i = 0; i < this.contents[j].length; i++) {
        this.removeObject("cube-" + this.contents[j][i]["trackId"]);
      }
    }

    this.__selectionIndexCurrentFrame = -1;
    this.__selectionIndexNextFrame = -1;
    this.__insertIndex = 0;
    this.contents[labelTool.currentFileIndex] = [];
  },
  __selectionIndexCurrentFrame: -1,
  __selectionIndexNextFrame: -1,
  __insertIndex: 0,
};

export let classesBoundingBox = {
  colorIdx: 0,
  getCurrentAnnotationClassObject: function() {
    return this[this.currentClass];
  },
  select: function(label) {
    this.onChangeAnnotationClass(label);

    if (annotationObjects.getSelectedBoundingBox() !== undefined) {
      annotationObjects.changeClass(
        annotationObjects.__selectionIndexCurrentFrame,
        label
      );
    }

    if (annotationObjects.__selectionIndexCurrentFrame !== -1) {
      let changeClassOperation = {
        type: "classLabel",
        objectIndex: annotationObjects.__selectionIndexCurrentFrame,
        previousClass:
          annotationObjects.contents[labelTool.currentFileIndex][
            annotationObjects.__selectionIndexCurrentFrame
          ]["class"],
        currentClass: label,
      };
      operationStack.push(changeClassOperation);
    }
    this.currentClass = label;
  },
  onChangeAnnotationClass: function(currentClass) {
    this.currentClass = currentClass;
  },
  getColorByClass: function(label) {
    return this[label].color;
  },
  getCurrentClass: function() {
    return this.currentClass;
  },
  currentClass: "",
};

export function drawLine(channelIdx, pointStart, pointEnd, color) {
  if (
    pointStart !== undefined &&
    pointEnd !== undefined &&
    isFinite(pointStart.x) &&
    isFinite(pointStart.y) &&
    isFinite(pointEnd.x) &&
    isFinite(pointEnd.y)
  ) {
    let line = labelTool.paperArrayAll[labelTool.currentFileIndex][
      channelIdx
    ].path(["M", pointStart.x, pointStart.y, "L", pointEnd.x, pointEnd.y]);
    line.attr("stroke", color);
    line.attr("stroke-width", 3);
    return line;
  } else {
    return undefined;
  }
}
