import * as THREE from "three"

export let labelTool = {
    isAnyChange:false,
    scene:[],
    classObjNames:[],
    updatedHeight: (window.innerHeight - 42),
    updtedWidth: (window.innerWidth - 27),
    configFileName: 'config.json',
    canvasArray: [],
    canvasParamsArray: [],
    paperArray: [],
    paperArrayAll: [],
    imageArray: [],
    imageArrayAll: [],
    dataStructure: undefined,
    datasets: {},
    datasetArray: [],
    labelListAnno:[],
    selectedPcdView:"orthographic",
    sequencesNuScenes: [],
    currentDataset: "",
    currentDatasetIdx: 0,
    sequence: "",
    numFramesNuScenes: 50,
    numFramesProvidentia: 50,
    frameScreenshots: [],
    config_data: [],
    dataTypes: [],
    playSequence: false,
    currentFileIndex: 0,
    showCameraPosition: false,
    drawEgoVehicle: false,
    previousFileIndex: 0,
    currentFileName: null,
    takeCanvasScreenshot: false,
    timeDelay: 1000,
    pointCloudLoaded: false,
    imageCanvasInitialized: false,
    cameraImagesLoaded: false,
    timeDelayScreenshot: 2000,
    timeDelayPlay: 100,
    imageSizes: {},
    originalAnnotations: [],   // For checking modified or not
    skipFrameCount: 1,
    targetClass: "",
    // pageBox: document.getElementById('page_num'),
    savedFrames: [],
    cubeArray: [],
    spriteArray: [],
    bboxIndexArray: [],
    currentCameraChannelIndex: 0,
    interpolationObjIndexCurrentFile: -1,
    // LoadConfigJson Variables to use LoadConfigJson API kindly uncomment these variables
    
    isQueryError: false,
    queryErrorResult: null,
    camChannels:[],
    pointCloudOnlyAnnotation:false,
    positionLidarNuscenes:[],
    positionLidar:[],
    translationVectorLidarToCamFront:[],
    numFrames:0,

    /////////////

    // To use LoadConfigJson API kindly comment below variables section
    currentChannelLabel: document.getElementById('cam_channel'),
    // position of the lidar sensor in ego vehicle space
    // positionLidarNuscenes: [0.891067, 0.0, 1.84292],//(long, lat, vert)
    // positionLidar: [0.0, 0.0, 6.9],//(long, lat, vert)
    // translationVectorLidarToCamFront: [0.77, -0.02, -0.3],
    showOriginalNuScenesLabels: false,
    imageAspectRatioNuScenes: 1.777777778,
    // showFieldOfView: false,
    selectedMesh: undefined,
    folderEndPosition: undefined,
    folderEndSize: undefined,
    logger: undefined,
    timeElapsed: 0, // elapsed time in seconds
    timeElapsedScreenshot: 0, // elapsed time between two screenshots
    timeElapsedPlay: 0,
    pointSize: 1,
    pointMaterial: new THREE.PointsMaterial({size: 5, sizeAttenuation: false, vertexColors: THREE.VertexColors}),
    views: {perspective: "perspective", orthographic: "orthographic"},
    classes: [],
    classColors: [],
    /********** Externally defined functions **********
     * Define these functions in the labeling tools.
     **************************************************/

    onInitialize: function (dataType, f) {
        this.localOnInitialize[dataType] = f;
    },

    localOnLoadAnnotation: {
        "CAM_FRONT_LEFT":

            function (index, annotation) {
            }

        ,
        "CAM_FRONT":

            function (index, annotation) {
            }

        ,
        "CAM_FRONT_RIGHT":

            function (index, annotation) {
            }

        ,
        "CAM_BACK_RIGHT":

            function (index, annotation) {
            }

        ,
        "CAM_BACK":

            function (index, annotation) {
            }

        ,
        "CAM_BACK_LEFT":

            function (index, annotation) {
            }

        ,
        "PCD":

            function (index, annotation) {
            }
    },

    localOnSelectBBox: {
        "CAM_FRONT_LEFT":

            function (newIndex, oldIndex) {
            }

        ,
        "CAM_FRONT":

            function (newIndex, oldIndex) {
            }

        ,
        "CAM_FRONT_RIGHT":

            function (newIndex, oldIndex) {
            }

        ,
        "CAM_BACK_RIGHT":

            function (newIndex, oldIndex) {
            }

        ,
        "CAM_BACK":

            function (newIndex, oldIndex) {
            }

        ,
        "CAM_BACK_LEFT":

            function (newIndex, oldIndex) {
            }

        ,
        "PCD":

            function (newIndex, oldIndex) {
            }
    },

    localOnInitialize: {
        "CAM_FRONT_LEFT":

            function () {
            }

        ,
        "CAM_FRONT":

            function () {
            }

        ,
        "CAM_FRONT_RIGHT":

            function () {
            }

        ,
        "CAM_BACK_RIGHT":

            function () {
            }

        ,
        "CAM_BACK":

            function () {
            }

        ,
        "CAM_BACK_LEFT":

            function () {
            }

        ,
        "PCD":

            function () {
            }
    }, 

    addResizeEventForImage: function () {
        $(window).unbind("resize");
        $(window).resize(function () {
            // keepAspectRatio();
        });
    },
    
    getDefaultObject: function () {
        let params = {
            class: "",
            x: -1,
            y: -1,
            z: -1,
            delta_x: 0,
            delta_y: 0,
            delta_z: 0,
            width: -1,
            length: -1,
            height: -1,
            rotationYaw: 0,
            rotationPitch: 0,
            rotationRoll: 0,
            original: {
                x: -1,
                y: -1,
                z: -1,
                width: -1,
                length: -1,
                height: -1,
                rotationYaw: 0,
                rotationPitch: 0,
                rotationRoll: 0
            },
            interpolationStartFileIndex: -1,
            interpolationStart: {
                position: {
                    x: -1,
                    y: -1,
                    z: -1,
                    rotationYaw: 0,
                    rotationPitch: 0,
                    rotationRoll: 0
                },
                size: {
                    width: -1,
                    length: -1,
                    height: -1
                }
            },
            interpolationEnd: {
                position: {
                    x: -1,
                    y: -1,
                    z: -1,
                    rotationYaw: 0,
                    rotationPitch: 0,
                    rotationRoll: 0
                },
                size: {
                    width: -1,
                    length: -1,
                    height: -1
                }
            },
            trackId: -1,
            channels: [{
                rect: [],
                projectedPoints: [],
                lines: [],
                channel: 'CAM_FRONT_LEFT'
            }, {
                rect: [],
                projectedPoints: [],
                lines: [],
                channel: 'CAM_FRONT'
            }, {
                rect: [],
                projectedPoints: [],
                lines: [],
                channel: 'CAM_FRONT_RIGHT'
            }, {
                rect: [],
                projectedPoints: [],
                lines: [],
                channel: 'CAM_BACK_RIGHT'
            }, {
                rect: [],
                projectedPoints: [],
                lines: [],
                channel: 'CAM_BACK'
            }, {
                rect: [],
                projectedPoints: [],
                lines: [],
                channel: 'CAM_BACK_LEFT'
            }],
            fromFile: true,
            fileIndex: -1,
            copyLabelToNextFrame: false
        };
        return params;
    },
       
};
