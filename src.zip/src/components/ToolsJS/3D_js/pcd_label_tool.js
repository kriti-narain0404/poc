import * as THREE from "three";
import { labelTool } from "./config_3D_tool.js";
import { annotationFileExist, pad } from "./util/ajax_wrapper.js";
import { annotationObjects, classesBoundingBox } from "./util/boundingbox.js";
import { matrixProduct3x4 } from "./util/math.js";
import { dat } from "./lib/dat.gui.js";
import { Detector } from "./lib/Detector.js";
import { WEBGL } from "./lib/WebGL.js";
import "./lib/Projector.js";
import "./lib/jquery-1.10.2.min.js";
import "./lib/jquery-ui.min.js";
import "./lib/controls/KeyboardState.js";
import "./lib/controls/threex.keyboardstate.js";
import "./lib/controls/OrbitControls.js";
import "./lib/controls/MapControls.js";
import Service3D from "../../../services/Service_3D.js";
import { TransformControls } from "three/examples/jsm/controls/TransformControls";
import "./lib/renderer/CSS2DRenderer.js";
import "three/examples/jsm/utils/SceneUtils"; //need to check for removal
import "./lib/PCDLoader.js"; //need to check for removal
import "./lib/OBJLoader.js"; //need to check for removal
import "./lib/controls/PointerLockControls.js"; //need to check for removal
import Editor3DModel from "../../../model/Editor3DModel.js";

let currSelectedChannel;
let canvasBEV;
let canvasSideView;
let canvasFrontView;
let divBev;
let divSideView;
let divFrontView;

let views;
let grid;
let isDrawBox = false;
let operationStack = [];

let perspectiveCamera;
let cameraBEV;
let cameraSideView;
let cameraFrontView;

let currentOrbitControls;
let pointerLockControls;
let pointerLockObject;
export let transformControls;
let projector;
export let currentClassId;
let rendererBev;
let rendererSideView;
let rendererFrontView;

let clock;
let container;
let keyboard;
let moveForward = false;
let moveBackward = false;
let moveLeft = false;
let moveRight = false;
let moveUp = false;
let moveDown = false;
let rotateLeft = false;
let rotateRight = false;
let rotateUp = false;
let rotateDown = false;
let translationVelocity = new THREE.Vector3();
let rotationVelocity = new THREE.Vector3();
let translationDirection = new THREE.Vector3();
let rotationDirection = new THREE.Vector3();
let prevTime = performance.now();

let cube;
let interpolateBtn;
let pointSizeSlider;

let guiAnnotationClasses;
let guiBoundingBoxAnnotationsInitialized = false;
let guiBoundingBoxMenuInitialized = false;
let guiOptionsOpened = true;
let showProjectedPointsFlag = false;
let showGridFlag = false;
let filterGround = false;
let hideOtherAnnotations = false;
let showDetections = false;
let clickFlag = false;
let clickedObjectIndex = -1;
let clickedObjectIndexPrevious = -1;
let mousePos = { x: 0, y: 0 };
let intersectedObject;
let mouseDown = { x: 0, y: 0 };
let mouseUp = { x: 0, y: 0 };
let clickedPoint = new THREE.Vector3();
let groundPointMouseDown;
let groundPlaneArray = [];
let clickedPlaneArray = [];
let birdsEyeViewFlag = true;
let rotWorldMatrix;
let rotObjectMatrix;
let circleArray = [];
let colorMap = [];
let activeColorMap = "colorMapJet.js";
let currentPoints3D = [];
let currentDistances = [];
let spriteBehindObject;
export let pcd_param = {
  pointCloudScanMap: [],
  renderer: [],
  currentCamera: [],
  headerHeight: 0,
};
export let pointCloudScanNoGroundList = [];
let useTransformControls;
let dragControls = false;
let keyboardNavigation = false;
let canvas3D;
let pointSizeMax = 1;
let defaultBoxHeight = 1.468628;
let gridSize = 200;
export let parameters = {
  download_video: function() {
    downloadVideo();
  },
  download: function() {
    download();
  },
  undo: function() {
    undoOperation();
  },
  i: -1,
  views: "orthographic", // change into hardcoded comes from labelTool.views.orthographic,
  show_projected_points: false,
  show_nuscenes_labels: false, //change into hardcoded comes from labelTool.showOriginalNuScenesLabels,
  show_field_of_view: false,
  show_grid: false,
  filter_ground: false,
  hide_other_annotations: hideOtherAnnotations,
  select_all_copy_label_to_next_frame: function() {
    for (
      let i = 0;
      i < annotationObjects.contents[labelTool.currentFileIndex].length;
      i++
    ) {
      annotationObjects.contents[labelTool.currentFileIndex][i][
        "copyLabelToNextFrame"
      ] = true;
      let checkboxElem = document.getElementById(
        "copy-label-to-next-frame-checkbox-" + i
      );
      checkboxElem.firstChild.checked = true;
    }
  },
  unselect_all_copy_label_to_next_frame: function() {
    for (
      let i = 0;
      i < annotationObjects.contents[labelTool.currentFileIndex].length;
      i++
    ) {
      // set all to false, expect the selected object (if interpolation mode active)
      if (
        annotationObjects.interpolationMode === false ||
        i !== annotationObjects.getSelectionIndex()
      ) {
        annotationObjects.contents[labelTool.currentFileIndex][i][
          "copyLabelToNextFrame"
        ] = false;
        let checkboxElem = document.getElementById(
          "copy-label-to-next-frame-checkbox-" + i
        );
        checkboxElem.firstChild.checked = false;
        $(checkboxElem)
          .children()
          .first()
          .removeAttr("checked");
      } else {
        annotationObjects.contents[labelTool.currentFileIndex][i][
          "copyLabelToNextFrame"
        ] = true;
        let checkboxElem = document.getElementById(
          "copy-label-to-next-frame-checkbox-" + i
        );
        checkboxElem.firstChild.checked = true;
      }
    }
  },
  show_detections: false,
  interpolation_mode: false,
  interpolate: function() {
    if (annotationObjects.interpolationMode === true) {
      interpolate();
    }
  },
  reset_all: function() {
    labelTool.resetBoxes();
  },
  skip_frames: 1, //labelTool.skipFrameCount
};

function interpolate() {
  labelTool.interpolationObjIndexCurrentFile = annotationObjects.getSelectionIndex();
  let interpolationStartFileIndex = Number(
    annotationObjects.contents[labelTool.currentFileIndex][
      labelTool.interpolationObjIndexCurrentFile
    ]["interpolationStartFileIndex"]
  );
  if (interpolationStartFileIndex === -1) {
    labelTool.logger.error(
      "Interpolation failed. Select object to interpolate and try again."
    );
    return;
  }
  let numFrames = labelTool.currentFileIndex - interpolationStartFileIndex;
  let objectIndexStartFile = annotationObjects.getObjectIndexByTrackIdAndClass(
    annotationObjects.contents[labelTool.currentFileIndex][
      labelTool.interpolationObjIndexCurrentFile
    ]["trackId"],
    annotationObjects.contents[labelTool.currentFileIndex][
      labelTool.interpolationObjIndexCurrentFile
    ]["class"],
    interpolationStartFileIndex
  );
  let xDelta =
    (Number(
      annotationObjects.contents[labelTool.currentFileIndex][
        labelTool.interpolationObjIndexCurrentFile
      ]["interpolationEnd"]["position"]["x"]
    ) -
      Number(
        annotationObjects.contents[interpolationStartFileIndex][
          objectIndexStartFile
        ]["interpolationStart"]["position"]["x"]
      )) /
    numFrames;
  let yDelta =
    (Number(
      annotationObjects.contents[labelTool.currentFileIndex][
        labelTool.interpolationObjIndexCurrentFile
      ]["interpolationEnd"]["position"]["y"]
    ) -
      Number(
        annotationObjects.contents[interpolationStartFileIndex][
          objectIndexStartFile
        ]["interpolationStart"]["position"]["y"]
      )) /
    numFrames;
  let zDelta =
    (Number(
      annotationObjects.contents[labelTool.currentFileIndex][
        labelTool.interpolationObjIndexCurrentFile
      ]["interpolationEnd"]["position"]["z"]
    ) -
      Number(
        annotationObjects.contents[interpolationStartFileIndex][
          objectIndexStartFile
        ]["interpolationStart"]["position"]["z"]
      )) /
    numFrames;

  let rotationYawEnd = Number(
    annotationObjects.contents[labelTool.currentFileIndex][
      labelTool.interpolationObjIndexCurrentFile
    ]["interpolationEnd"]["position"]["rotationYaw"]
  );
  let rotationYawStart = Number(
    annotationObjects.contents[interpolationStartFileIndex][
      objectIndexStartFile
    ]["interpolationStart"]["position"]["rotationYaw"]
  );
  let rotationYawDelta = (rotationYawEnd - rotationYawStart) / numFrames;

  let rotationPitchEnd = Number(
    annotationObjects.contents[labelTool.currentFileIndex][
      labelTool.interpolationObjIndexCurrentFile
    ]["interpolationEnd"]["position"]["rotationPitch"]
  );
  let rotationPitchStart = Number(
    annotationObjects.contents[interpolationStartFileIndex][
      objectIndexStartFile
    ]["interpolationStart"]["position"]["rotationPitch"]
  );
  let rotationPitchDelta = (rotationPitchEnd - rotationPitchStart) / numFrames;

  let rotationRollEnd = Number(
    annotationObjects.contents[labelTool.currentFileIndex][
      labelTool.interpolationObjIndexCurrentFile
    ]["interpolationEnd"]["position"]["rotationRoll"]
  );
  let rotationRollStart = Number(
    annotationObjects.contents[interpolationStartFileIndex][
      objectIndexStartFile
    ]["interpolationStart"]["position"]["rotationRoll"]
  );
  let rotationRollDelta = (rotationRollEnd - rotationRollStart) / numFrames;

  let widthDelta =
    (Number(
      annotationObjects.contents[labelTool.currentFileIndex][
        labelTool.interpolationObjIndexCurrentFile
      ]["interpolationEnd"]["size"]["width"]
    ) -
      Number(
        annotationObjects.contents[interpolationStartFileIndex][
          objectIndexStartFile
        ]["interpolationStart"]["size"]["width"]
      )) /
    numFrames;
  let lengthDelta =
    (Number(
      annotationObjects.contents[labelTool.currentFileIndex][
        labelTool.interpolationObjIndexCurrentFile
      ]["interpolationEnd"]["size"]["length"]
    ) -
      Number(
        annotationObjects.contents[interpolationStartFileIndex][
          objectIndexStartFile
        ]["interpolationStart"]["size"]["length"]
      )) /
    numFrames;
  let heightDelta =
    (Number(
      annotationObjects.contents[labelTool.currentFileIndex][
        labelTool.interpolationObjIndexCurrentFile
      ]["interpolationEnd"]["size"]["height"]
    ) -
      Number(
        annotationObjects.contents[interpolationStartFileIndex][
          objectIndexStartFile
        ]["interpolationStart"]["size"]["height"]
      )) /
    numFrames;

  for (let i = 1; i < numFrames; i++) {
    // cloning
    let clonedObject = jQuery.extend(
      true,
      {},
      annotationObjects.contents[interpolationStartFileIndex][
        objectIndexStartFile
      ]
    );
    let clonedCubeObject = labelTool.cubeArray[interpolationStartFileIndex][
      objectIndexStartFile
    ].clone();
    let clonedSprite = labelTool.spriteArray[interpolationStartFileIndex][
      objectIndexStartFile
    ].clone();
    let objectIndexNextFrame = annotationObjects.getObjectIndexByTrackIdAndClass(
      annotationObjects.contents[labelTool.currentFileIndex][
        labelTool.interpolationObjIndexCurrentFile
      ]["trackId"],
      annotationObjects.contents[labelTool.currentFileIndex][
        labelTool.interpolationObjIndexCurrentFile
      ]["class"],
      interpolationStartFileIndex + i
    );
    // use length>2 because 1. element is insertIndex
    if (
      annotationObjects.contents[interpolationStartFileIndex + i] !==
        undefined &&
      annotationObjects.contents[interpolationStartFileIndex + i].length > 0 &&
      objectIndexNextFrame !== -1
    ) {
      // if frame contains some objects, then find object with same trackId and overwrite it
      annotationObjects.contents[interpolationStartFileIndex + i][
        objectIndexNextFrame
      ] = clonedObject;
      labelTool.cubeArray[interpolationStartFileIndex + i][
        objectIndexNextFrame
      ] = clonedCubeObject;
      labelTool.spriteArray[interpolationStartFileIndex + i][
        objectIndexNextFrame
      ] = clonedSprite;
    } else {
      // else clone object to new frame and adjusts interpolated position and size
      annotationObjects.contents[interpolationStartFileIndex + i].push(
        clonedObject
      );
      labelTool.cubeArray[interpolationStartFileIndex + i].push(
        clonedCubeObject
      );
      labelTool.spriteArray[interpolationStartFileIndex + i].push(clonedSprite);
      // recalculate index in next frame after cloning object
      objectIndexNextFrame = annotationObjects.getObjectIndexByTrackIdAndClass(
        annotationObjects.contents[labelTool.currentFileIndex][
          labelTool.interpolationObjIndexCurrentFile
        ]["trackId"],
        annotationObjects.contents[labelTool.currentFileIndex][
          labelTool.interpolationObjIndexCurrentFile
        ]["class"],
        interpolationStartFileIndex + i
      );
    }

    let newX =
      Number(
        annotationObjects.contents[interpolationStartFileIndex][
          objectIndexStartFile
        ]["interpolationStart"]["position"]["x"]
      ) +
      i * xDelta;
    annotationObjects.contents[interpolationStartFileIndex + i][
      objectIndexNextFrame
    ]["x"] = newX;
    labelTool.cubeArray[interpolationStartFileIndex + i][objectIndexNextFrame][
      "position"
    ]["x"] = newX;

    let newY =
      Number(
        annotationObjects.contents[interpolationStartFileIndex][
          objectIndexStartFile
        ]["interpolationStart"]["position"]["y"]
      ) +
      i * yDelta;
    annotationObjects.contents[interpolationStartFileIndex + i][
      objectIndexNextFrame
    ]["y"] = newY;
    labelTool.cubeArray[interpolationStartFileIndex + i][objectIndexNextFrame][
      "position"
    ]["y"] = newY;

    let newZ =
      Number(
        annotationObjects.contents[interpolationStartFileIndex][
          objectIndexStartFile
        ]["interpolationStart"]["position"]["z"]
      ) +
      i * zDelta;
    annotationObjects.contents[interpolationStartFileIndex + i][
      objectIndexNextFrame
    ]["z"] = newZ;
    labelTool.cubeArray[interpolationStartFileIndex + i][objectIndexNextFrame][
      "position"
    ]["z"] = newZ;

    let newRotationYaw =
      Number(
        annotationObjects.contents[interpolationStartFileIndex][
          objectIndexStartFile
        ]["interpolationStart"]["position"]["rotationYaw"]
      ) +
      i * rotationYawDelta;
    annotationObjects.contents[interpolationStartFileIndex + i][
      objectIndexNextFrame
    ]["rotationYaw"] = newRotationYaw;
    labelTool.cubeArray[interpolationStartFileIndex + i][objectIndexNextFrame][
      "rotation"
    ]["z"] = newRotationYaw;

    let newRotationPitch =
      Number(
        annotationObjects.contents[interpolationStartFileIndex][
          objectIndexStartFile
        ]["interpolationStart"]["position"]["rotationPitch"]
      ) +
      i * rotationPitchDelta;
    annotationObjects.contents[interpolationStartFileIndex + i][
      objectIndexNextFrame
    ]["rotationPitch"] = newRotationPitch;
    labelTool.cubeArray[interpolationStartFileIndex + i][objectIndexNextFrame][
      "rotation"
    ]["x"] = newRotationPitch;

    let newRotationRoll =
      Number(
        annotationObjects.contents[interpolationStartFileIndex][
          objectIndexStartFile
        ]["interpolationStart"]["position"]["rotationRoll"]
      ) +
      i * rotationRollDelta;
    annotationObjects.contents[interpolationStartFileIndex + i][
      objectIndexNextFrame
    ]["rotationRoll"] = newRotationRoll;
    labelTool.cubeArray[interpolationStartFileIndex + i][objectIndexNextFrame][
      "rotation"
    ]["y"] = newRotationRoll;

    let newWidth =
      Number(
        annotationObjects.contents[interpolationStartFileIndex][
          objectIndexStartFile
        ]["interpolationStart"]["size"]["width"]
      ) +
      i * widthDelta;
    annotationObjects.contents[interpolationStartFileIndex + i][
      objectIndexNextFrame
    ]["width"] = newWidth;
    labelTool.cubeArray[interpolationStartFileIndex + i][objectIndexNextFrame][
      "scale"
    ]["x"] = newWidth;

    let newLength =
      Number(
        annotationObjects.contents[interpolationStartFileIndex][
          objectIndexStartFile
        ]["interpolationStart"]["size"]["length"]
      ) +
      i * lengthDelta;
    annotationObjects.contents[interpolationStartFileIndex + i][
      objectIndexNextFrame
    ]["length"] = newLength;
    labelTool.cubeArray[interpolationStartFileIndex + i][objectIndexNextFrame][
      "scale"
    ]["y"] = newLength;

    let newHeight =
      Number(
        annotationObjects.contents[interpolationStartFileIndex][
          objectIndexStartFile
        ]["interpolationStart"]["size"]["height"]
      ) +
      i * heightDelta;
    annotationObjects.contents[interpolationStartFileIndex + i][
      objectIndexNextFrame
    ]["height"] = newHeight;
    labelTool.cubeArray[interpolationStartFileIndex + i][objectIndexNextFrame][
      "scale"
    ]["z"] = newHeight;
  }

  // Note: end frame index is the same as current file index
  // start position becomes current end position
  annotationObjects.contents[labelTool.currentFileIndex][
    labelTool.interpolationObjIndexCurrentFile
  ]["interpolationStart"]["position"]["x"] =
    annotationObjects.contents[labelTool.currentFileIndex][
      labelTool.interpolationObjIndexCurrentFile
    ]["interpolationEnd"]["position"]["x"];
  annotationObjects.contents[labelTool.currentFileIndex][
    labelTool.interpolationObjIndexCurrentFile
  ]["interpolationStart"]["position"]["y"] =
    annotationObjects.contents[labelTool.currentFileIndex][
      labelTool.interpolationObjIndexCurrentFile
    ]["interpolationEnd"]["position"]["y"];
  annotationObjects.contents[labelTool.currentFileIndex][
    labelTool.interpolationObjIndexCurrentFile
  ]["interpolationStart"]["position"]["z"] =
    annotationObjects.contents[labelTool.currentFileIndex][
      labelTool.interpolationObjIndexCurrentFile
    ]["interpolationEnd"]["position"]["z"];
  annotationObjects.contents[labelTool.currentFileIndex][
    labelTool.interpolationObjIndexCurrentFile
  ]["interpolationStart"]["position"]["rotationYaw"] =
    annotationObjects.contents[labelTool.currentFileIndex][
      labelTool.interpolationObjIndexCurrentFile
    ]["interpolationEnd"]["position"]["rotationYaw"];
  annotationObjects.contents[labelTool.currentFileIndex][
    labelTool.interpolationObjIndexCurrentFile
  ]["interpolationStart"]["position"]["rotationPitch"] =
    annotationObjects.contents[labelTool.currentFileIndex][
      labelTool.interpolationObjIndexCurrentFile
    ]["interpolationEnd"]["position"]["rotationPitch"];
  annotationObjects.contents[labelTool.currentFileIndex][
    labelTool.interpolationObjIndexCurrentFile
  ]["interpolationStart"]["position"]["rotationRoll"] =
    annotationObjects.contents[labelTool.currentFileIndex][
      labelTool.interpolationObjIndexCurrentFile
    ]["interpolationEnd"]["position"]["rotationRoll"];
  annotationObjects.contents[labelTool.currentFileIndex][
    labelTool.interpolationObjIndexCurrentFile
  ]["interpolationStart"]["size"]["x"] =
    annotationObjects.contents[labelTool.currentFileIndex][
      labelTool.interpolationObjIndexCurrentFile
    ]["interpolationEnd"]["size"]["x"];
  annotationObjects.contents[labelTool.currentFileIndex][
    labelTool.interpolationObjIndexCurrentFile
  ]["interpolationStart"]["size"]["y"] =
    annotationObjects.contents[labelTool.currentFileIndex][
      labelTool.interpolationObjIndexCurrentFile
    ]["interpolationEnd"]["size"]["y"];
  annotationObjects.contents[labelTool.currentFileIndex][
    labelTool.interpolationObjIndexCurrentFile
  ]["interpolationStart"]["size"]["z"] =
    annotationObjects.contents[labelTool.currentFileIndex][
      labelTool.interpolationObjIndexCurrentFile
    ]["interpolationEnd"]["size"]["z"];
  annotationObjects.contents[labelTool.currentFileIndex][
    labelTool.interpolationObjIndexCurrentFile
  ]["interpolationStartFileIndex"] = labelTool.currentFileIndex;
  // set current frame to start position and start size
  annotationObjects.folderPositionArray[
    labelTool.interpolationObjIndexCurrentFile
  ].domElement.firstChild.firstChild.innerText =
    "Interpolation Start Position (frame " +
    (labelTool.currentFileIndex + 1) +
    ")";
  annotationObjects.folderRotationArray[
    labelTool.interpolationObjIndexCurrentFile
  ].domElement.firstChild.firstChild.innerText =
    "Interpolation Start Rotation (frame " +
    (labelTool.currentFileIndex + 1) +
    ")";
  annotationObjects.folderSizeArray[
    labelTool.interpolationObjIndexCurrentFile
  ].domElement.firstChild.firstChild.innerText =
    "Interpolation Start Size (frame " + (labelTool.currentFileIndex + 1) + ")";
  // enable start position and start size
  enableStartPose();
  // remove end position folder and end position size
  annotationObjects.folderBoundingBox3DArray[
    labelTool.interpolationObjIndexCurrentFile
  ].removeFolder(
    "Interpolation End Position (frame " +
      (labelTool.previousFileIndex + 1) +
      ")"
  );
  annotationObjects.folderBoundingBox3DArray[
    labelTool.interpolationObjIndexCurrentFile
  ].removeFolder(
    "Interpolation End Size (frame " + (labelTool.previousFileIndex + 1) + ")"
  );
  // disable interpolate button
  // disableInterpolationBtn();

  labelTool.logger.success("Interpolation successfully!");
}

/**
 * The following operations can be undone:
 *  1. class label
 *  2. track ID
 *  3. delete object -> create it again
 *  4. position
 *  5. scale
 *  6. rotation
 *  7. reset (reset to previous position)
 *  8. add new object -> delete object
 *  9. interpolation (delete all non human annotations)
 *  10. change frame from 1 to 2 (go to prev. frame and remove all objects from frame 2 that were copied from frame 1)
 */
function undoOperation() {
  // get the last operation from the stack which is implemented as a map with key value pairs
  // the value is represented as a json object
  if (operationStack.length === 0) {
    return;
  }
  let lastOperation = operationStack[operationStack.length - 1];
  let lastOperationType = lastOperation["type"];

  // TODO: implement undo operations of all cases
  switch (lastOperationType) {
    case "classLabel":
      let objectIndex = Number(lastOperation["objectIndex"]);
      let previousClassLabel = lastOperation["previousClass"];
      annotationObjects.changeClass(objectIndex, previousClassLabel);
      // select previous class in class picker
      break;
    case "trackId":
      break;
    case "delete":
      break;
    case "position":
      break;
    case "scale":
      break;
    case "rotation":
      break;
    case "reset":
      break;
    case "add":
      break;
    case "interpolation":
      break;
    case "changeFrame":
      break;
  }
  // remove operation from stack
  operationStack.splice(operationStack.length - 1, 1);

  if (operationStack.length === 0) {
    // TODO: disable undo button
  }
}

/*********** Event handlers **************/

labelTool.onInitialize("PCD", function() {
  if (!Detector.webgl) {
    Detector.addGetWebGLMessage();
  }
  init();
  animate();
});

// Rotate an object around an arbitrary axis in world space
function rotateAroundWorldAxis(object, axis, radians) {
  rotWorldMatrix = new THREE.Matrix4();
  rotWorldMatrix.makeRotationAxis(axis.normalize(), radians);

  // old code for Three.JS pre r54:
  //  rotWorldMatrix.multiply(object.matrix);
  // new code for Three.JS r55+:
  rotWorldMatrix.multiply(object.matrix); // pre-multiply
  object.matrix = rotWorldMatrix;
  // code for r59+:
  object.rotation.setFromRotationMatrix(object.matrix);
}

function rotateAroundObjectAxis(object, axis, radians) {
  rotObjectMatrix = new THREE.Matrix4();
  rotObjectMatrix.makeRotationAxis(axis.normalize(), radians);

  // old code for Three.JS pre r54:
  // object.matrix.multiplySelf(rotObjectMatrix);      // post-multiply
  // new code for Three.JS r55+:
  object.matrix.multiply(rotObjectMatrix);

  // old code for Three.js pre r49:
  // object.rotation.getRotationFromMatrix(object.matrix, object.scale);
  // old code for Three.js r50-r58:
  // object.rotation.setEulerFromRotationMatrix(object.matrix);
  // new code for Three.js r59+:
  object.rotation.setFromRotationMatrix(object.matrix);
}

function addObject(sceneObject, name) {
  sceneObject.name = name;
  // search whether object already exist
  for (let i = labelTool.scene.children.length - 1; i >= 0; i--) {
    let obj = labelTool.scene.children[i];
    if (obj.name === name) {
      return;
    }
  }
  labelTool.scene.add(sceneObject);
}

function drawCameraPosition() {
  let camFrontGeometry = new THREE.BoxGeometry(0.1, 0.1, 0.1);
  camFrontGeometry.translate(-3.402 / 100, 60.7137 / 100, -10.4301 / 100);
  let material = new THREE.MeshBasicMaterial({
    color: 0xff0000,
    side: THREE.DoubleSide,
    transparent: false,
  });
  let camFrontMesh = new THREE.Mesh(camFrontGeometry, material);
  addObject(camFrontMesh, "cam-front-object");
  let camFrontRightGeometry = new THREE.BoxGeometry(0.1, 0.1, 0.1);
  material = new THREE.MeshBasicMaterial({
    color: 0x00ff00,
    side: THREE.DoubleSide,
    transparent: false,
  });
  // lat, long, vert
  camFrontRightGeometry.translate(
    59.35125262 / 100,
    41.21713246 / 100,
    -15.43223025 / 100
  );
  let camFrontRightMesh = new THREE.Mesh(camFrontRightGeometry, material);
  addObject(camFrontRightMesh, "cam-front-right-object");
  let camBackRightGeometry = new THREE.BoxGeometry(0.1, 0.1, 0.1);
  material = new THREE.MeshBasicMaterial({
    color: 0x0000ff,
    side: THREE.DoubleSide,
    transparent: false,
  });
  camBackRightGeometry.translate(
    47.93776844 / 100,
    -90.71772718 / 100,
    -8.13149812 / 100
  );
  let camBackRightMesh = new THREE.Mesh(camBackRightGeometry, material);
  addObject(camBackRightMesh, "cam-back-right-object");
  let camBackGeometry = new THREE.BoxGeometry(0.1, 0.1, 0.1);
  material = new THREE.MeshBasicMaterial({
    color: 0xffff00,
    side: THREE.DoubleSide,
    transparent: false,
  });
  camBackGeometry.translate(
    -4.07865574 / 100,
    -95.4603164 / 100,
    -13.38361257 / 100
  );
  let camBackMesh = new THREE.Mesh(camBackGeometry, material);
  addObject(camBackMesh, "cam-back-object");
  let camBackLeftGeometry = new THREE.BoxGeometry(0.1, 0.1, 0.1);
  material = new THREE.MeshBasicMaterial({
    color: 0x00ffff,
    side: THREE.DoubleSide,
    transparent: false,
  });
  camBackLeftGeometry.translate(
    -75.37243686 / 100,
    -77.11760848 / 100,
    -15.77163041 / 100
  );
  let camBackLeftMesh = new THREE.Mesh(camBackLeftGeometry, material);
  addObject(camBackLeftMesh, "cam-back-left-object");
  let camFrontLeftGeometry = new THREE.BoxGeometry(0.1, 0.1, 0.1);
  material = new THREE.MeshBasicMaterial({
    color: 0xff00ff,
    side: THREE.DoubleSide,
    transparent: false,
  });
  camFrontLeftGeometry.translate(
    -59.9910821 / 100,
    50.67448108 / 100,
    -14.11259497 / 100
  );
  let camFrontLeftMesh = new THREE.Mesh(camFrontLeftGeometry, material);
  addObject(camFrontLeftMesh, "cam-front-left-object");
}

annotationObjects.onSelect("PCD", function(selectionIndex) {
  clickedPlaneArray = [];
  for (let i = 0; i < annotationObjects.folderBoundingBox3DArray.length; i++) {
    if (annotationObjects.folderBoundingBox3DArray[i] !== undefined) {
      annotationObjects.folderBoundingBox3DArray[i].close();
    }
  }
  if (
    annotationObjects.folderBoundingBox3DArray[selectionIndex] !== undefined
  ) {
    annotationObjects.folderBoundingBox3DArray[selectionIndex].open();
  }
  if (annotationObjects.folderPositionArray[selectionIndex] !== undefined) {
    annotationObjects.folderPositionArray[selectionIndex].open();
  }
  if (annotationObjects.folderRotationArray[selectionIndex] !== undefined) {
    annotationObjects.folderRotationArray[selectionIndex].open();
  }
  if (annotationObjects.folderSizeArray[selectionIndex] !== undefined) {
    annotationObjects.folderSizeArray[selectionIndex].open();
  }
});

annotationObjects.onChangeClass("PCD", function(index, label) {
  if (
    Array.isArray(
      labelTool.cubeArray[labelTool.currentFileIndex][index].material
    )
  ) {
    for (
      let i = 0;
      i <
      labelTool.cubeArray[labelTool.currentFileIndex][index].material.length;
      i++
    ) {
      labelTool.cubeArray[labelTool.currentFileIndex][index].material[
        i
      ].color.setHex(classesBoundingBox[label].color.replace("#", "0x"));
    }
  } else {
    labelTool.cubeArray[labelTool.currentFileIndex][
      index
    ].material.color.setHex(classesBoundingBox[label].color.replace("#", "0x"));
  }
  // change also color of the bounding box
  labelTool.cubeArray[labelTool.currentFileIndex][
    index
  ].children[0].material.color.setHex(
    classesBoundingBox[label].color.replace("#", "0x")
  );
  annotationObjects.contents[labelTool.currentFileIndex][index][
    "class"
  ] = label;
});

//add remove function in dat.GUI
dat.GUI.prototype.removeFolder = function(name) {
  let folder = this.__folders[name];
  if (!folder) {
    return;
  }

  folder.close();
  this.__ul.removeChild(folder.domElement.parentNode);
  delete this.__folders[name];
  this.onResize();
};

//calculate inverse matrix
function inverseMatrix(inMax) {
  let det =
    inMax[0][0] * inMax[1][1] * inMax[2][2] * inMax[3][3] +
    inMax[0][0] * inMax[1][2] * inMax[2][3] * inMax[3][1] +
    inMax[0][0] * inMax[1][3] * inMax[2][1] * inMax[3][2] -
    inMax[0][0] * inMax[1][3] * inMax[2][2] * inMax[3][1] -
    inMax[0][0] * inMax[1][2] * inMax[2][1] * inMax[3][3] -
    inMax[0][0] * inMax[1][1] * inMax[2][3] * inMax[3][2] -
    inMax[0][1] * inMax[1][0] * inMax[2][2] * inMax[3][3] -
    inMax[0][2] * inMax[1][0] * inMax[2][3] * inMax[3][1] -
    inMax[0][3] * inMax[1][0] * inMax[2][1] * inMax[3][2] +
    inMax[0][3] * inMax[1][0] * inMax[2][2] * inMax[3][1] +
    inMax[0][2] * inMax[1][0] * inMax[2][1] * inMax[3][3] +
    inMax[0][1] * inMax[1][0] * inMax[2][3] * inMax[3][2] +
    inMax[0][1] * inMax[1][2] * inMax[2][0] * inMax[3][3] +
    inMax[0][2] * inMax[1][3] * inMax[2][0] * inMax[3][1] +
    inMax[0][3] * inMax[1][1] * inMax[2][0] * inMax[3][2] -
    inMax[0][3] * inMax[1][2] * inMax[2][0] * inMax[3][1] -
    inMax[0][2] * inMax[1][1] * inMax[2][0] * inMax[3][3] -
    inMax[0][1] * inMax[1][3] * inMax[2][0] * inMax[3][2] -
    inMax[0][1] * inMax[1][2] * inMax[2][3] * inMax[3][0] -
    inMax[0][2] * inMax[1][3] * inMax[2][1] * inMax[3][0] -
    inMax[0][3] * inMax[1][1] * inMax[2][2] * inMax[3][0] +
    inMax[0][3] * inMax[1][2] * inMax[2][1] * inMax[3][0] +
    inMax[0][2] * inMax[1][1] * inMax[2][3] * inMax[3][0] +
    inMax[0][1] * inMax[1][3] * inMax[2][2] * inMax[3][0];
  let inv00 =
    (inMax[1][1] * inMax[2][2] * inMax[3][3] +
      inMax[1][2] * inMax[2][3] * inMax[3][1] +
      inMax[1][3] * inMax[2][1] * inMax[3][2] -
      inMax[1][3] * inMax[2][2] * inMax[3][1] -
      inMax[1][2] * inMax[2][1] * inMax[3][3] -
      inMax[1][1] * inMax[2][3] * inMax[3][2]) /
    det;
  let inv01 =
    (-inMax[0][1] * inMax[2][2] * inMax[3][3] -
      inMax[0][2] * inMax[2][3] * inMax[3][1] -
      inMax[0][3] * inMax[2][1] * inMax[3][2] +
      inMax[0][3] * inMax[2][2] * inMax[3][1] +
      inMax[0][2] * inMax[2][1] * inMax[3][3] +
      inMax[0][1] * inMax[2][3] * inMax[3][2]) /
    det;
  let inv02 =
    (inMax[0][1] * inMax[1][2] * inMax[3][3] +
      inMax[0][2] * inMax[1][3] * inMax[3][1] +
      inMax[0][3] * inMax[1][1] * inMax[3][2] -
      inMax[0][3] * inMax[1][2] * inMax[3][1] -
      inMax[0][2] * inMax[1][1] * inMax[3][3] -
      inMax[0][1] * inMax[1][3] * inMax[3][2]) /
    det;
  let inv03 =
    (-inMax[0][1] * inMax[1][2] * inMax[2][3] -
      inMax[0][2] * inMax[1][3] * inMax[2][1] -
      inMax[0][3] * inMax[1][1] * inMax[2][2] +
      inMax[0][3] * inMax[1][2] * inMax[2][1] +
      inMax[0][2] * inMax[1][1] * inMax[2][3] +
      inMax[0][1] * inMax[1][3] * inMax[2][2]) /
    det;
  let inv10 =
    (-inMax[1][0] * inMax[2][2] * inMax[3][3] -
      inMax[1][2] * inMax[2][3] * inMax[3][0] -
      inMax[1][3] * inMax[2][0] * inMax[3][2] +
      inMax[1][3] * inMax[2][2] * inMax[3][0] +
      inMax[1][2] * inMax[2][0] * inMax[3][3] +
      inMax[1][0] * inMax[2][3] * inMax[3][2]) /
    det;
  let inv11 =
    (inMax[0][0] * inMax[2][2] * inMax[3][3] +
      inMax[0][2] * inMax[2][3] * inMax[3][0] +
      inMax[0][3] * inMax[2][0] * inMax[3][2] -
      inMax[0][3] * inMax[2][2] * inMax[3][0] -
      inMax[0][2] * inMax[2][0] * inMax[3][3] -
      inMax[0][0] * inMax[2][3] * inMax[3][2]) /
    det;
  let inv12 =
    (-inMax[0][0] * inMax[1][2] * inMax[3][3] -
      inMax[0][2] * inMax[1][3] * inMax[3][0] -
      inMax[0][3] * inMax[1][0] * inMax[3][2] +
      inMax[0][3] * inMax[1][2] * inMax[3][0] +
      inMax[0][2] * inMax[1][0] * inMax[3][3] +
      inMax[0][0] * inMax[1][3] * inMax[3][2]) /
    det;
  let inv13 =
    (inMax[0][0] * inMax[1][2] * inMax[2][3] +
      inMax[0][2] * inMax[1][3] * inMax[2][0] +
      inMax[0][3] * inMax[1][0] * inMax[2][2] -
      inMax[0][3] * inMax[1][2] * inMax[2][0] -
      inMax[0][2] * inMax[1][0] * inMax[2][3] -
      inMax[0][0] * inMax[1][3] * inMax[2][2]) /
    det;
  let inv20 =
    (inMax[1][0] * inMax[2][1] * inMax[3][3] +
      inMax[1][1] * inMax[2][3] * inMax[3][0] +
      inMax[1][3] * inMax[2][0] * inMax[3][1] -
      inMax[1][3] * inMax[2][1] * inMax[3][0] -
      inMax[1][1] * inMax[2][0] * inMax[3][3] -
      inMax[1][0] * inMax[2][3] * inMax[3][1]) /
    det;
  let inv21 =
    (-inMax[0][0] * inMax[2][1] * inMax[3][3] -
      inMax[0][1] * inMax[2][3] * inMax[3][0] -
      inMax[0][3] * inMax[2][0] * inMax[3][1] +
      inMax[0][3] * inMax[2][1] * inMax[3][0] +
      inMax[0][1] * inMax[2][0] * inMax[3][3] +
      inMax[0][0] * inMax[2][3] * inMax[3][1]) /
    det;
  let inv22 =
    (inMax[0][0] * inMax[1][1] * inMax[3][3] +
      inMax[0][1] * inMax[1][3] * inMax[3][0] +
      inMax[0][3] * inMax[1][0] * inMax[3][1] -
      inMax[0][3] * inMax[1][1] * inMax[3][0] -
      inMax[0][1] * inMax[1][0] * inMax[3][3] -
      inMax[0][0] * inMax[1][3] * inMax[3][1]) /
    det;
  let inv23 =
    (-inMax[0][0] * inMax[1][1] * inMax[2][3] -
      inMax[0][1] * inMax[1][3] * inMax[2][0] -
      inMax[0][3] * inMax[1][0] * inMax[2][1] +
      inMax[0][3] * inMax[1][1] * inMax[2][0] +
      inMax[0][1] * inMax[1][0] * inMax[2][3] +
      inMax[0][0] * inMax[1][3] * inMax[2][1]) /
    det;
  let inv30 =
    (-inMax[1][0] * inMax[2][1] * inMax[3][2] -
      inMax[1][1] * inMax[2][2] * inMax[3][0] -
      inMax[1][2] * inMax[2][0] * inMax[3][1] +
      inMax[1][2] * inMax[2][1] * inMax[3][0] +
      inMax[1][1] * inMax[2][0] * inMax[3][2] +
      inMax[1][0] * inMax[2][2] * inMax[3][1]) /
    det;
  let inv31 =
    (inMax[0][0] * inMax[2][1] * inMax[3][2] +
      inMax[0][1] * inMax[2][2] * inMax[3][0] +
      inMax[0][2] * inMax[2][0] * inMax[3][1] -
      inMax[0][2] * inMax[2][1] * inMax[3][0] -
      inMax[0][1] * inMax[2][0] * inMax[3][2] -
      inMax[0][0] * inMax[2][2] * inMax[3][1]) /
    det;
  let inv32 =
    (-inMax[0][0] * inMax[1][1] * inMax[3][2] -
      inMax[0][1] * inMax[1][2] * inMax[3][0] -
      inMax[0][2] * inMax[1][0] * inMax[3][1] +
      inMax[0][2] * inMax[1][1] * inMax[3][0] +
      inMax[0][1] * inMax[1][0] * inMax[3][2] +
      inMax[0][0] * inMax[1][2] * inMax[3][1]) /
    det;
  let inv33 =
    (inMax[0][0] * inMax[1][1] * inMax[2][2] +
      inMax[0][1] * inMax[1][2] * inMax[2][0] +
      inMax[0][2] * inMax[1][0] * inMax[2][1] -
      inMax[0][2] * inMax[1][1] * inMax[2][0] -
      inMax[0][1] * inMax[1][0] * inMax[2][2] -
      inMax[0][0] * inMax[1][2] * inMax[2][1]) /
    det;

  return [
    [inv00, inv01, inv02, inv03],
    [inv10, inv11, inv12, inv13],
    [inv20, inv21, inv22, inv23],
    [inv30, inv31, inv32, inv33],
  ];
}

function b64EncodeUnicode(str) {
  // first we use encodeURIComponent to get percent-encoded UTF-8,
  // then we convert the percent encodings into raw bytes which
  // can be fed into btoa.
  return btoa(
    encodeURIComponent(str).replace(/%([0-9A-F]{2})/g, function toSolidBytes(
      match,
      p1
    ) {
      return String.fromCharCode("0x" + p1);
    })
  );
}

// right padding s with c to a total of n chars
// print 0.12300
// alert(padding_right('0.123', '0', 5));
function paddingRight(s, c, n) {
  if (!s || !c || s.length >= n) {
    return s;
  }
  let max = (n - s.length) / c.length;
  for (let i = 0; i < max; i++) {
    s += c;
  }
  return s;
}

function downloadVideo() {
  if (labelTool.currentDataset === labelTool.datasets.NuScenes) {
    labelTool.takeCanvasScreenshot = true;
    labelTool.changeFrame(0);
    initScreenshotTimer();
  }
}

export function hideMasterView() {
  $("#canvasSideView").hide();
  $("#canvasFrontView").hide();
  $("#canvasBev").hide();
  $("#divBev").hide();
  $("#divFront").hide();
  $("#divSide").hide();
}

// make remove object as a function by NAT
function removeObject(objectName) {
  for (let i = labelTool.scene.children.length - 1; i >= 0; i--) {
    let obj = labelTool.scene.children[i];
    if (obj.name === objectName) {
      labelTool.scene.remove(obj);
      return true;
    }
  }
  return false;
}

//change camera position to bird view position
function switchView() {
  birdsEyeViewFlag = !birdsEyeViewFlag;
  if (birdsEyeViewFlag) {
    disablePointSizeSlider();
  } else {
    enablePointSizeSlider();
  }
  if (transformControls !== undefined) {
    labelTool.selectedMesh = undefined;
    transformControls.detach();
    transformControls = undefined;
    hideMasterView();
  }
  setCamera();
  removeObject("planeObject");
}

function updateXPos(newFileIndex, value) {
  labelTool.cubeArray[newFileIndex][
    annotationObjects.interpolationObjIndexNextFile
  ].position.x = value;
  annotationObjects.contents[newFileIndex][
    annotationObjects.interpolationObjIndexNextFile
  ]["interpolationEnd"]["position"]["x"] = value;
  annotationObjects.contents[newFileIndex][
    annotationObjects.interpolationObjIndexNextFile
  ]["x"] = value;
  if (labelTool.pointCloudOnlyAnnotation === false) {
    // update bounding box
    annotationObjects.update2DBoundingBox(
      labelTool.currentFileIndex,
      labelTool.interpolationObjIndexCurrentFile,
      true
    );
  }
}

/**
 * calculates the highest available track id for a specific class
 * @param label
 */
function setHighestAvailableTrackId(label) {
  for (
    let newTrackId = 0;
    newTrackId <= annotationObjects.contents[labelTool.currentFileIndex].length;
    newTrackId++
  ) {
    let exist = false;
    for (
      let i = 0;
      i < annotationObjects.contents[labelTool.currentFileIndex].length;
      i++
    ) {
      if (
        label ===
          annotationObjects.contents[labelTool.currentFileIndex][i]["class"] &&
        newTrackId ===
          annotationObjects.contents[labelTool.currentFileIndex][i]["trackId"]
      ) {
        exist = true;
        break;
      }
    }
    if (exist === false) {
      // track id was not used yet
      classesBoundingBox[label].nextTrackId = newTrackId;
      break;
    }
    classesBoundingBox[label].nextTrackId =
      annotationObjects.contents[labelTool.currentFileIndex].length + 1;
  }
}

function getSmallestTrackId(classNameToFind) {
  let trackIds = [];
  for (let i = 0; i < annotationObjects.contents.length; i++) {
    for (let j = 0; j < annotationObjects.contents[i].length; j++) {
      let className = annotationObjects.contents[i][j]["class"];
      if (className === classNameToFind) {
        let trackId = annotationObjects.contents[i][j]["trackId"];
        if ($.inArray(trackId, trackIds) === -1) {
          trackIds.push(trackId);
        }
      }
    }
  }
  trackIds.sort();
  for (
    let smallestAvailableTrackId = 1;
    smallestAvailableTrackId <= trackIds[trackIds.length - 1];
    smallestAvailableTrackId++
  ) {
    let exist = false;
    for (let j = 0; j < trackIds.length; j++) {
      if (smallestAvailableTrackId === trackIds[j]) {
        exist = true;
        break;
      }
    }
    if (exist === false) {
      return smallestAvailableTrackId;
    }
  }
  // return next highest track id
  return trackIds[trackIds.length - 1] + 1;
}

function deleteObject(trackId, labelIndex) {
  // hide 3D bounding box instead of removing it (in case redo button will be pressed)
  if (transformControls !== undefined) {
    transformControls.detach();
  }

  removeObject("transformControls");
  // NOTE: already removed in annotationObjects.remove()
  if (labelTool.pointCloudOnlyAnnotation === false) {
    let channels =
      annotationObjects.contents[labelTool.currentFileIndex][labelIndex]
        .channels;
    // iterate all channels and remove projection
    for (let channelIdx in channels) {
      if (channels.hasOwnProperty(channelIdx)) {
        let channelObj = channels[channelIdx];
        for (let lineObj in channelObj.lines) {
          if (channelObj.lines.hasOwnProperty(lineObj)) {
            let line = channelObj.lines[lineObj];
            if (line !== undefined) {
              line.remove();
            }
          }
        }
      }
    }
  }
  annotationObjects.remove(labelIndex);
  for (var i = 0; i < labelTool.labelListAnno.length; i++) {
    if (trackId === labelTool.labelListAnno[i].id) {
      labelTool.labelListAnno.splice(i, 1);
    }
  }
  // annotationObjects.folderBoundingBox3DArray[labelIndex].__folders = [];
  annotationObjects.folderBoundingBox3DArray.splice(labelIndex, 1);
  annotationObjects.folderPositionArray.splice(labelIndex, 1);
  annotationObjects.folderRotationArray.splice(labelIndex, 1);
  annotationObjects.folderSizeArray.splice(labelIndex, 1);
  annotationObjects.selectEmpty();
  labelTool.spriteArray[labelTool.currentFileIndex].splice(labelIndex, 1);
  if (trackId == -1) {
    removeObject("sprite-" + labelIndex);
    // NOTE: already removed in annotationObjects.remove()
    // remove sprite from DOM tree
    $("#tooltip-" + labelIndex).remove();
  } else {
    removeObject("sprite-" + trackId);
    // NOTE: already removed in annotationObjects.remove()
    // remove sprite from DOM tree
    $("#tooltip-" + trackId).remove();
  }
  labelTool.selectedMesh = undefined;

  // setHighestAvailableTrackId(bboxClass);
  // if last object in current frame was deleted than disable interpolation mode
  // if (annotationObjects.contents[labelTool.currentFileIndex].length === 0) {
  //     annotationObjects.interpolationMode = false;
  //     $("#interpolation-checkbox").children().first().prop("checked", false);
  //     $("#interpolation-checkbox").children().first().removeAttr("checked");
  // }
  //rename all ids following after insertIndexof
  // e.g. rename copy-label-to-next-frame-checkbox-1 to copy-label-to-next-frame-checkbox-0 if deleting first element
  // let copyIdList = document.querySelectorAll('[id^="copy-label-to-next-frame-checkbox-"]'); // e.g. 0,1
  // for (let i = labelIndex; i < annotationObjects.contents[labelTool.currentFileIndex].length; i++) {
  //     let idToChange = copyIdList[i].id;
  //     let elem = document.getElementById(idToChange);
  //     elem.id = "copy-label-to-next-frame-checkbox-" + (i);
  // }
  // hide master view
  // $("#canvasBev").hide();
  // $("#canvasSideView").hide();
  // $("#canvasFrontView").hide();
  hideMasterView();

  // move class picker to left
  $("#class-picker").css("left", 10);
  annotationObjects.__selectionIndexCurrentFrame = -1;
}

//reset cube parameter and position
function resetCube(index) {
  let reset_bbox =
    annotationObjects.contents[labelTool.currentFileIndex][index];
  reset_bbox.class = reset_bbox.original.class;
  reset_bbox.x = reset_bbox.original.x;
  reset_bbox.y = reset_bbox.original.y;
  reset_bbox.z = reset_bbox.original.z;
  reset_bbox.rotationYaw = reset_bbox.original.rotationYaw;
  reset_bbox.rotationPitch = reset_bbox.original.rotationPitch;
  reset_bbox.rotationRoll = reset_bbox.original.rotationRoll;
  reset_bbox.width = reset_bbox.original.width;
  reset_bbox.length = reset_bbox.original.length;
  reset_bbox.height = reset_bbox.original.height;
  labelTool.cubeArray[labelTool.currentFileIndex][index].position.x =
    reset_bbox.x;
  labelTool.cubeArray[labelTool.currentFileIndex][index].position.y =
    reset_bbox.y;
  labelTool.cubeArray[labelTool.currentFileIndex][index].position.z =
    reset_bbox.z;
  labelTool.cubeArray[labelTool.currentFileIndex][index].rotation.z =
    reset_bbox.rotationYaw;
  labelTool.cubeArray[labelTool.currentFileIndex][index].rotation.x =
    reset_bbox.rotationPitch;
  labelTool.cubeArray[labelTool.currentFileIndex][index].rotation.y =
    reset_bbox.rotationRoll;
  labelTool.cubeArray[labelTool.currentFileIndex][index].scale.x =
    reset_bbox.width;
  labelTool.cubeArray[labelTool.currentFileIndex][index].scale.y =
    reset_bbox.length;
  labelTool.cubeArray[labelTool.currentFileIndex][index].scale.z =
    reset_bbox.height;
  // TODO: redraw in 3D and 2D to change color
}

//change window size
function onWindowResize() {
  // update height and top position of helper views
  let imagePanelHeight = parseInt(
    $("#layout_layout_resizer_top").css("top"),
    80
  );
  let newHeight = Math.round(
    (labelTool.updatedHeight - pcd_param.headerHeight - imagePanelHeight) / 3.0
  );

  $("#canvasSideView").css("height", newHeight);
  $("#canvasSideView").css("top", pcd_param.headerHeight + imagePanelHeight);

  views[1].height = newHeight;
  views[1].top = 0;
  $("#canvasFrontView").css("height", newHeight);
  $("#canvasFrontView").css(
    "top",
    pcd_param.headerHeight + imagePanelHeight + newHeight
  );
  views[2].height = newHeight;
  views[2].top = newHeight;
  $("#canvasBev").css("height", newHeight);
  $("#canvasBev").css(
    "top",
    pcd_param.headerHeight + imagePanelHeight + 2 * newHeight
  );
  views[3].height = newHeight;
  views[3].top = 2 * newHeight;

  pcd_param.currentCamera.aspect =
    labelTool.updtedWidth / labelTool.updatedHeight;
  pcd_param.currentCamera.updateProjectionMatrix();
  pcd_param.renderer.setSize(labelTool.updtedWidth, labelTool.updatedHeight);
  if (rendererBev !== undefined) {
    rendererBev.setSize(labelTool.updtedWidth / 3, labelTool.updatedHeight / 3);
    rendererFrontView.setSize(
      labelTool.updtedWidth / 3,
      labelTool.updatedHeight / 3
    );
    rendererSideView.setSize(
      labelTool.updtedWidth / 3,
      labelTool.updatedHeight / 3
    );
  }
  animate();
}

function getObjectIndexByName(objectName) {
  let idToFind = objectName.split("-")[1]; // e.g. cube-V1
  if (idToFind >= 0) {
    return idToFind;
  }
}

function updateObjectPosition() {
  let objectIndexByTrackId = getObjectIndexByName(labelTool.selectedMesh.name);
  annotationObjects.contents[labelTool.currentFileIndex][objectIndexByTrackId][
    "x"
  ] = labelTool.selectedMesh.position.x;
  annotationObjects.contents[labelTool.currentFileIndex][objectIndexByTrackId][
    "y"
  ] = labelTool.selectedMesh.position.y;
  annotationObjects.contents[labelTool.currentFileIndex][objectIndexByTrackId][
    "z"
  ] = labelTool.selectedMesh.position.z;
  annotationObjects.contents[labelTool.currentFileIndex][objectIndexByTrackId][
    "width"
  ] = labelTool.selectedMesh.scale.x;
  annotationObjects.contents[labelTool.currentFileIndex][objectIndexByTrackId][
    "length"
  ] = labelTool.selectedMesh.scale.y;
  annotationObjects.contents[labelTool.currentFileIndex][objectIndexByTrackId][
    "height"
  ] = labelTool.selectedMesh.scale.z;
  annotationObjects.contents[labelTool.currentFileIndex][objectIndexByTrackId][
    "rotationYaw"
  ] = labelTool.selectedMesh.rotation.z;
  annotationObjects.contents[labelTool.currentFileIndex][objectIndexByTrackId][
    "rotationPitch"
  ] = labelTool.selectedMesh.rotation.x;
  annotationObjects.contents[labelTool.currentFileIndex][objectIndexByTrackId][
    "rotationRoll"
  ] = labelTool.selectedMesh.rotation.y;
  // update cube array
  labelTool.cubeArray[labelTool.currentFileIndex][objectIndexByTrackId]["x"] =
    labelTool.selectedMesh.position.x;
  labelTool.cubeArray[labelTool.currentFileIndex][objectIndexByTrackId]["y"] =
    labelTool.selectedMesh.position.y;
  labelTool.cubeArray[labelTool.currentFileIndex][objectIndexByTrackId]["z"] =
    labelTool.selectedMesh.position.z;
  labelTool.cubeArray[labelTool.currentFileIndex][objectIndexByTrackId][
    "width"
  ] = labelTool.selectedMesh.scale.x;
  labelTool.cubeArray[labelTool.currentFileIndex][objectIndexByTrackId][
    "length"
  ] = labelTool.selectedMesh.scale.y;
  labelTool.cubeArray[labelTool.currentFileIndex][objectIndexByTrackId][
    "height"
  ] = labelTool.selectedMesh.scale.z;
  labelTool.cubeArray[labelTool.currentFileIndex][objectIndexByTrackId][
    "rotationYaw"
  ] = labelTool.selectedMesh.rotation.z;
  labelTool.cubeArray[labelTool.currentFileIndex][objectIndexByTrackId][
    "rotationPitch"
  ] = labelTool.selectedMesh.rotation.x;
  labelTool.cubeArray[labelTool.currentFileIndex][objectIndexByTrackId][
    "rotationRoll"
  ] = labelTool.selectedMesh.rotation.y;

  if (
    annotationObjects.interpolationMode === true &&
    labelTool.selectedMesh !== undefined
  ) {
    // let selectionIndex = annotationObjects.getSelectionIndex();
    let interpolationStartFileIndex =
      annotationObjects.contents[labelTool.currentFileIndex][
        labelTool.interpolationObjIndexCurrentFile
      ]["interpolationStartFileIndex"];
    if (interpolationStartFileIndex !== labelTool.currentFileIndex) {
      annotationObjects.contents[labelTool.currentFileIndex][
        labelTool.interpolationObjIndexCurrentFile
      ]["interpolationEnd"]["position"]["x"] =
        labelTool.selectedMesh.position.x;
      annotationObjects.contents[labelTool.currentFileIndex][
        labelTool.interpolationObjIndexCurrentFile
      ]["interpolationEnd"]["position"]["y"] =
        labelTool.selectedMesh.position.y;
      annotationObjects.contents[labelTool.currentFileIndex][
        labelTool.interpolationObjIndexCurrentFile
      ]["interpolationEnd"]["position"]["z"] =
        labelTool.selectedMesh.position.z;
      annotationObjects.contents[labelTool.currentFileIndex][
        labelTool.interpolationObjIndexCurrentFile
      ]["interpolationEnd"]["position"]["rotationYaw"] =
        labelTool.selectedMesh.rotation.z;
      annotationObjects.contents[labelTool.currentFileIndex][
        labelTool.interpolationObjIndexCurrentFile
      ]["interpolationEnd"]["position"]["rotationPitch"] =
        labelTool.selectedMesh.rotation.x;
      annotationObjects.contents[labelTool.currentFileIndex][
        labelTool.interpolationObjIndexCurrentFile
      ]["interpolationEnd"]["position"]["rotationRoll"] =
        labelTool.selectedMesh.rotation.y;
      annotationObjects.contents[labelTool.currentFileIndex][
        labelTool.interpolationObjIndexCurrentFile
      ]["interpolationEnd"]["size"]["width"] = labelTool.selectedMesh.scale.x;
      annotationObjects.contents[labelTool.currentFileIndex][
        labelTool.interpolationObjIndexCurrentFile
      ]["interpolationEnd"]["size"]["length"] = labelTool.selectedMesh.scale.y;
      annotationObjects.contents[labelTool.currentFileIndex][
        labelTool.interpolationObjIndexCurrentFile
      ]["interpolationEnd"]["size"]["height"] = labelTool.selectedMesh.scale.z;
    }
  }
}

function onChangeHandler(event) {
  useTransformControls = true;
  // update 2d bounding box
  if (labelTool.pointCloudOnlyAnnotation === false) {
    if (dragControls === true) {
      if (labelTool.selectedMesh !== undefined) {
        updateObjectPosition();
        let objectIndexByTrackId = getObjectIndexByName(
          labelTool.selectedMesh.name
        );

        annotationObjects.update2DBoundingBox(
          labelTool.currentFileIndex,
          objectIndexByTrackId,
          true
        );
        labelTool.isAnyChange = true;
        render();
      }
    }
  }
  render();
}

function onDraggingChangedHandler(event) {
  useTransformControls = true;
  dragControls = true;
  // update 2d bounding box
  if (labelTool.selectedMesh !== undefined) {
    updateObjectPosition();
    if (labelTool.pointCloudOnlyAnnotation === false) {
      let objectIndexByTrackId = getObjectIndexByName(
        labelTool.selectedMesh.name
      );

      annotationObjects.update2DBoundingBox(
        labelTool.currentFileIndex,
        objectIndexByTrackId,
        true
      );
    }
    labelTool.isAnyChange = true;
    render();
  }
  // executed after drag finished
  // TODO: scale only on one side
  if (transformControls.getMode() === "scale") {
    // labelTool.selectedMesh.translateY(labelTool.selectedMesh.geometry.parameters.height / 2)
  }
}

function addTransformControls() {
  if (transformControls === undefined) {
    transformControls = new TransformControls(
      pcd_param.currentCamera,
      pcd_param.renderer.domElement
    );
    transformControls.name = "transformControls";
  } else {
    if (transformControls.object !== labelTool.selectedMesh) {
      transformControls.detach();
    } else {
      // transform controls are already defined and attached to selected object
      return;
    }
  }
  transformControls.removeEventListener("change", onChangeHandler);
  transformControls.addEventListener("change", onChangeHandler);
  transformControls.removeEventListener(
    "dragging-changed",
    onDraggingChangedHandler
  );
  transformControls.addEventListener(
    "dragging-changed",
    onDraggingChangedHandler
  );
  transformControls.attach(labelTool.selectedMesh);
  removeObject("transformControls");
  labelTool.scene.add(transformControls);
  window.removeEventListener("keydown", keyDownHandler);
  window.addEventListener("keydown", keyDownHandler);
  window.removeEventListener("keyup", keyUpHandler);
  window.addEventListener("keyup", keyUpHandler);
}

function keyUpHandler(event) {
  switch (event.keyCode) {
    case 17: // Ctrl
      transformControls.setTranslationSnap(null);
      transformControls.setRotationSnap(null);
      break;
  }
}

function keyDownHandler(event) {
  if (labelTool.selectedMesh !== undefined) {
    let currentAnnoIndex = annotationObjects.getSelectionIndex();
    let xCoord =
      annotationObjects.contents[labelTool.currentFileIndex][currentAnnoIndex]
        .x;
    let yCoord =
      annotationObjects.contents[labelTool.currentFileIndex][currentAnnoIndex]
        .y;
    let zCoord =
      annotationObjects.contents[labelTool.currentFileIndex][currentAnnoIndex]
        .z;
    let currentClass =
      annotationObjects.contents[labelTool.currentFileIndex][currentAnnoIndex][
        "class"
      ];

    //For change psitions of bounding boxes
    if (event.ctrlKey === true && event.shiftKey === false) {
      switch (event.keyCode) {
        //for X || ctrl+ ArrowRight || ctrl+ ArrowLeft
        case 39:
          annotationObjects.changeXCoord(
            +1,
            currentAnnoIndex,
            currentClass,
            true
          );
          labelTool.isAnyChange = true;
          break;
        case 37:
          annotationObjects.changeXCoord(
            -1,
            currentAnnoIndex,
            currentClass,
            true
          );
          labelTool.isAnyChange = true;
          break;

        //for Y || ctrl+ ArrowUp || ctrl+ ArrowDown

        case 38:
          annotationObjects.changeYCoord(
            +1,
            currentAnnoIndex,
            currentClass,
            true
          );
          labelTool.isAnyChange = true;
          break;
        case 40:
          annotationObjects.changeYCoord(
            -1,
            currentAnnoIndex,
            currentClass,
            true
          );
          labelTool.isAnyChange = true;
          break;
      }
    }

    if (event.altKey === true && event.shiftKey === true) {
      switch (event.keyCode) {
        //for X || ctrl+ ArrowRight || ctrl+ ArrowLeft
        case 39:
          annotationObjects.changeZCoord(
            +10,
            currentAnnoIndex,
            currentClass,
            true
          );
          labelTool.isAnyChange = true;
          break;
        case 37:
          annotationObjects.changeZCoord(
            -10,
            currentAnnoIndex,
            currentClass,
            true
          );
          labelTool.isAnyChange = true;
          break;
      }
    }
    //end for change psitions of bounding boxes
    // start for rotation of bounding boxes
    if (event.shiftKey === true && event.altKey === false) {
      // rotation
      switch (event.keyCode) {
        case 37:
          annotationObjects.changeRotationYaw(
            +0.1,
            currentAnnoIndex,
            currentClass,
            true
          );
          labelTool.isAnyChange = true;
          break;
        case 39:
          annotationObjects.changeRotationYaw(
            -0.1,
            currentAnnoIndex,
            currentClass,
            true
          );
          labelTool.isAnyChange = true;
          break;

        //changeRotationPitch
        case 38:
          annotationObjects.changeRotationPitch(
            +0.1,
            currentAnnoIndex,
            currentClass,
            true
          );
          labelTool.isAnyChange = true;
          break;
        case 40:
          annotationObjects.changeRotationPitch(
            -0.1,
            currentAnnoIndex,
            currentClass,
            true
          );
          labelTool.isAnyChange = true;
          break;
      }
    }

    if (event.shiftKey === true && event.ctrlKey === true) {
      // rotation
      switch (event.keyCode) {
        case 37:
          annotationObjects.changeRotationRoll(
            +0.1,
            currentAnnoIndex,
            currentClass,
            true
          );
          labelTool.isAnyChange = true;
          break;
        case 39:
          annotationObjects.changeRotationRoll(
            -0.1,
            currentAnnoIndex,
            currentClass,
            true
          );
          labelTool.isAnyChange = true;
          break;
      }
    }
    // end rotation of bounding boxes
    switch (event.keyCode) {
      // bounding box size control by keyboard

      case 65: // A
        annotationObjects.changeBboxLength(
          +1,
          currentAnnoIndex,
          currentClass,
          xCoord,
          yCoord,
          true
        );
        labelTool.isAnyChange = true;
        break;
      case 68: // D
        annotationObjects.changeBboxLength(
          -1,
          currentAnnoIndex,
          currentClass,
          xCoord,
          yCoord,
          true
        );
        labelTool.isAnyChange = true;
        break;
      case 87: // W
        annotationObjects.changeBboxWidth(
          +1,
          currentAnnoIndex,
          currentClass,
          xCoord,
          yCoord,
          true
        );
        labelTool.isAnyChange = true;
        break;
      case 83: //S
        annotationObjects.changeBboxWidth(
          -1,
          currentAnnoIndex,
          currentClass,
          xCoord,
          yCoord,
          true
        );
        labelTool.isAnyChange = true;
        break;
      case 69: // E
        annotationObjects.changeBboxHeight(
          +1,
          currentAnnoIndex,
          currentClass,
          zCoord,
          true
        );
        labelTool.isAnyChange = true;
        break;
      case 82: // R
        annotationObjects.changeBboxHeight(
          -1,
          currentAnnoIndex,
          currentClass,
          zCoord,
          true
        );
        labelTool.isAnyChange = true;
        break;
      // end bounding box size control by keyboard

      case 17: // Ctrl
        transformControls.setTranslationSnap(0.5);
        if (transformControls.getMode() === "rotate") {
          let newRotation = Math.ceil(
            labelTool.selectedMesh.rotation.z / THREE.Math.degToRad(15)
          );
          let lowerBound = newRotation * 15;
          if (
            labelTool.selectedMesh.rotation.z - lowerBound <
            THREE.Math.degToRad(15) / 2
          ) {
            // rotate to lower bound
            labelTool.selectedMesh.rotation.z = lowerBound;
          } else {
            // rotate to upper bound
            labelTool.selectedMesh.rotation.z =
              lowerBound + THREE.Math.degToRad(15);
          }
        }

        transformControls.setRotationSnap(THREE.Math.degToRad(15));
        break;
      case 27: // Esc- remove incomplete bbox
        let classPopup = document.getElementById("set");
        let boxIndex =
          annotationObjects.contents[labelTool.currentFileIndex].insertIndex;
        if (classPopup.style.display === "block") {
          let trackId =
            annotationObjects.contents[labelTool.currentFileIndex][boxIndex][
              "trackId"
            ];
          deleteObject(trackId, boxIndex);
          classPopup.style.display = "none";
          labelTool.isAnyChange = false;
        }
        break;
      case 73: //I
        if (annotationObjects.getSelectionIndex() !== -1) {
          if (annotationObjects.interpolationMode === true) {
            if (
              annotationObjects.contents[labelTool.currentFileIndex][
                annotationObjects.getSelectionIndex()
              ]["interpolationStartFileIndex"] !== labelTool.currentFileIndex
            ) {
              interpolate();
            } else {
              labelTool.logger.message("Please choose end frame.");
            }
          } else {
            labelTool.logger.message(
              "Please activate interpolation mode first."
            );
          }
        } else {
          labelTool.logger.message("Please select an object first.");
        }
      case 82: // R
        transformControls.setMode("rotate");
        transformControls.showX = false;
        transformControls.showY = false;
        transformControls.showZ = true;
        // enable gizmo
        transformControls.children[0].enabled = true;
        // disable planes (translation, scaling)
        transformControls.children[1].enabled = false;
        break;
      case 83: // S
        transformControls.setMode("scale");
        transformControls.showX = true;
        transformControls.showY = true;
        if (birdsEyeViewFlag === true) {
          transformControls.showZ = true;
        } else {
          transformControls.showZ = false;
        }
        // enable planes (translation, scaling)
        transformControls.children[1].enabled = false;
        break;
      case 84: // T
        transformControls.setMode("translate");
        transformControls.showX = true;
        transformControls.showY = true;
        if (birdsEyeViewFlag === true) {
          transformControls.showZ = true;
        } else {
          transformControls.showZ = false;
        }
        // enable planes (translation, scaling)
        transformControls.children[1].enabled = false;
        break;
      case 88: // X
        transformControls.showX = !transformControls.showX;
        break;
      case 89: // Y
        transformControls.showY = !transformControls.showY;
        break;
      case 90: // Z
        // only allow to switch z axis in 3d view
        if (birdsEyeViewFlag === false) {
          transformControls.showZ = !transformControls.showZ;
        } else {
          labelTool.logger.message(
            "Show/Hide z-axis only in 3D view possible."
          );
        }
        break;
      case 187:
      case 107: // +, =, num+
        transformControls.setSize(Math.min(transformControls.size + 0.1, 10));
        break;
      case 189:
      case 109: // -, _, num-
        transformControls.setSize(Math.max(transformControls.size - 0.1, 0.1));
        break;
    }
  }

  switch (event.keyCode) {
    case 67: // C
      switchView();
      break;
    case 75: //K
      toggleKeyboardNavigation();
      break;
    case 32: // Spacebar
      // play video sequence from current frame on to end
      labelTool.playSequence = !labelTool.playSequence;
      if (labelTool.playSequence === true) {
        initPlayTimer();
      }
      break;
    case 78: // N
      // next frame
      window.test.next_image();
      break;
    case 80: // P
      // previous frame
      window.test.prev_image();

      break;
    case 83: // S
      // previous frame
      window.test.saveAnnos();

      break;
    case 46:
      removeObjectOnDeleteKey();

      break;
  }
  if (event.keyCode == 190 && event.shiftKey) {
    if (
      Editor3DModel.copyMode == "manual" ||
      Editor3DModel.copyMode == "automatic"
    ) {
      if (Editor3DModel.copyDirection == "Forward") {
        window.test.next_image(3);
      }
    }
  }
  if (event.keyCode == 188 && event.shiftKey) {
    if (
      Editor3DModel.copyMode == "manual" ||
      Editor3DModel.copyMode == "automatic"
    ) {
      if (Editor3DModel.copyDirection == "Backward") {
        window.test.prev_image(4);
      }
    }
  }
}

// call on delete button
const removeObjectOnDeleteKey = () => {
  let ray;
  if (birdsEyeViewFlag === false) {
    let vector = new THREE.Vector3(mouseDown.x, mouseDown.y, 1);
    vector.unproject(pcd_param.currentCamera);
    ray = new THREE.Raycaster(
      pcd_param.currentCamera.position,
      vector.sub(pcd_param.currentCamera.position).normalize()
    );
  } else {
    ray = new THREE.Raycaster();
    let mouse = new THREE.Vector2();
    mouse.x = mouseDown.x;
    mouse.y = mouseDown.y;
    ray.setFromCamera(mouse, pcd_param.currentCamera);
  }

  let clickedObjects = ray.intersectObjects(
    labelTool.cubeArray[labelTool.currentFileIndex]
  );
  clickedObjectIndex = labelTool.cubeArray[labelTool.currentFileIndex].indexOf(
    clickedObjects[0].object
  );

  let trackId =
    annotationObjects.contents[labelTool.currentFileIndex][clickedObjectIndex][
      "trackId"
    ];
  deleteObject(trackId, clickedObjectIndex);
  labelTool.isAnyChange = true;
  // move button to left
  $("#left-btn").css("left", 0);
};
function setOrbitControls() {
  document.removeEventListener("keydown", onKeyDown, false);
  document.removeEventListener("keyup", onKeyUp, false);
  labelTool.scene.remove(pointerLockObject);

  pcd_param.currentCamera = new THREE.PerspectiveCamera(
    70,
    labelTool.updtedWidth / labelTool.updatedHeight,
    1,
    3000
  );
  pcd_param.currentCamera.position.set(0, 0, 5);
  pcd_param.currentCamera.up.set(0, 0, 1);

  currentOrbitControls = new THREE.OrbitControls(
    pcd_param.currentCamera,
    pcd_param.renderer.domElement
  );
  currentOrbitControls.enablePan = true;
  currentOrbitControls.enableRotate = true;
  currentOrbitControls.autoRotate = false; // true for demo
  currentOrbitControls.enableKeys = false;
  currentOrbitControls.maxPolarAngle = Math.PI / 2;
}

function onKeyDown(event) {
  switch (event.keyCode) {
    case 38: // up
      rotateUp = true;
      break;
    case 69: //E
      moveUp = true;
      break;
    case 81: //Q
      moveDown = true;
      break;
    case 87: // w
      moveForward = true;
      break;
    case 37: // left
      rotateLeft = true;
      break;
    case 65: // a
      moveLeft = true;
      break;
    case 40: // down
      rotateDown = true;
      break;
    case 83: // s
      moveBackward = true;
      break;
    case 39: // right
      rotateRight = true;
      break;
    case 68: // d
      moveRight = true;
      break;
  }
}

function onKeyUp(event) {
  switch (event.keyCode) {
    case 38: // up
      rotateUp = false;
      break;
    case 69: // E
      moveUp = false;
      break;
    case 81: //Q
      moveDown = false;
      break;
    case 87: // w
      moveForward = false;
      break;
    case 37: // left
      rotateLeft = false;
      break;
    case 65: // a
      moveLeft = false;
      break;
    case 40: // down
      rotateDown = false;
      break;
    case 83: // s
      moveBackward = false;
      break;
    case 39: // right
      rotateRight = false;
      break;
    case 68: // d
      moveRight = false;
      break;
  }
}

function setPointerLockControls() {
  pointerLockControls = new THREE.PointerLockControls(
    pcd_param.currentCamera,
    canvas3D
  );
  pointerLockObject = pointerLockControls.getObject();
  pointerLockObject.position.set(0, 0, 0);
  pointerLockObject.rotation.set(Math.PI / 2, 0, 0);
  labelTool.scene.add(pointerLockObject);
  window.addEventListener("keydown", onKeyDown, false);
  window.addEventListener("keyup", onKeyUp, false);
}

function setPerspectiveView() {
  // 3D mode (perspective mode)
  pcd_param.currentCamera = new THREE.PerspectiveCamera(
    70,
    labelTool.updtedWidth / labelTool.updatedHeight,
    1,
    3000
  );
  // currentCamera = perspectiveCamera;
  if (transformControls !== undefined) {
    if (labelTool.selectedMesh !== undefined) {
      addTransformControls();
      transformControls.size = 2;
      transformControls.showZ = true;
    } else {
      removeObject("transformControls");
    }
  }

  pcd_param.currentCamera.position.set(0, 0, 5);
  pcd_param.currentCamera.up.set(0, 0, 1);

  canvas3D.removeEventListener("keydown", canvas3DKeyDownHandler);
  canvas3D.addEventListener("keydown", canvas3DKeyDownHandler);

  if (keyboardNavigation === true) {
    setPointerLockControls();
  } else {
    setOrbitControls();
  }
  // TODO: enable to fly through the 3d scene using keys
}

function setOrthographicView() {
  // BEV
  if (transformControls !== undefined) {
    transformControls.showZ = false;
  }

  pcd_param.currentCamera = new THREE.OrthographicCamera(
    -40,
    40,
    20,
    -20,
    0.0001,
    2000
  );
  // currentCamera = orthographicCamera;
  pcd_param.currentCamera.position.set(0, 0, 5);
  pcd_param.currentCamera.up.set(0, 0, 1);

  currentOrbitControls = new THREE.OrbitControls(
    pcd_param.currentCamera,
    pcd_param.renderer.domElement
  );
  currentOrbitControls.enablePan = true;
  currentOrbitControls.enableRotate = false;
  currentOrbitControls.autoRotate = false;
  currentOrbitControls.enableKeys = false;
  currentOrbitControls.maxPolarAngle = Math.PI / 2;
}

//set camera type
function setCamera() {
  if (birdsEyeViewFlag === false) {
    setPerspectiveView();
  } else {
    setOrthographicView();
  }
  if (keyboardNavigation === false) {
    currentOrbitControls.update();
  }
}
// export function renderViews() {
//   //   alert("I run");
//   animate();
// }

function render() {
  // render main window
  let mainView = views[0];
  pcd_param.renderer.setViewport(
    mainView.left,
    mainView.top,
    mainView.width,
    mainView.height
  );
  pcd_param.renderer.setScissor(
    mainView.left,
    mainView.top,
    mainView.width,
    mainView.height
  );
  pcd_param.renderer.setScissorTest(true);
  pcd_param.renderer.setClearColor(mainView.background);

  pcd_param.currentCamera.aspect = mainView.width / mainView.height;
  pcd_param.currentCamera.updateProjectionMatrix();
  pcd_param.renderer.render(labelTool.scene, pcd_param.currentCamera);
  // renderer.clear();
  //This is the Code that enables views on click
  if (labelTool.selectedMesh !== undefined) {
    for (let i = 1; i < views.length; i++) {
      let view = views[i];
      let camera = view.camera;
      view.updateCamera(
        camera,
        labelTool.scene,
        labelTool.selectedMesh.position
      );
      pcd_param.renderer.setViewport(
        view.left,
        view.top,
        view.width,
        view.height
      );
      pcd_param.renderer.setScissor(
        view.left,
        view.top,
        view.width,
        view.height
      );
      pcd_param.renderer.setScissorTest(true);
      pcd_param.renderer.setClearColor(view.background);
      camera.aspect = view.width / view.height;
      camera.updateProjectionMatrix();
      pcd_param.renderer.render(labelTool.scene, camera);
    }
  }

  if (
    labelTool.cubeArray !== undefined &&
    labelTool.cubeArray.length > 0 &&
    labelTool.cubeArray[labelTool.currentFileIndex] !== undefined &&
    labelTool.cubeArray[labelTool.currentFileIndex].length > 0 &&
    labelTool.spriteArray !== undefined &&
    labelTool.spriteArray.length > 0 &&
    labelTool.spriteArray[labelTool.currentFileIndex] !== undefined &&
    labelTool.spriteArray[labelTool.currentFileIndex].length > 0
  ) {
    updateAnnotationOpacity();
    updateScreenPosition();
  }
  if (keyboardNavigation === false) {
    currentOrbitControls.update();
  }
}

function updateAnnotationOpacity() {
  for (
    let i = 0;
    i < labelTool.cubeArray[labelTool.currentFileIndex].length;
    i++
  ) {
    let obj = labelTool.cubeArray[labelTool.currentFileIndex][i];
    let sprite = labelTool.spriteArray[labelTool.currentFileIndex][i];
    let meshDistance = pcd_param.currentCamera.position.distanceTo(
      obj.position
    );
    let spriteDistance = pcd_param.currentCamera.position.distanceTo(
      sprite.position
    );
    spriteBehindObject = spriteDistance > meshDistance;
    sprite.material.opacity = spriteBehindObject ? 0.2 : 0.8;

    // if number should change size according to its position
    // then comment out the following line and the ::before pseudo-element
    sprite.material.opacity = 0;
  }
}

function updateScreenPosition() {
  try {
    for (
      let i = 0;
      i < labelTool.cubeArray[labelTool.currentFileIndex].length;
      i++
    ) {
      let cubeObj = labelTool.cubeArray[labelTool.currentFileIndex][i];
      let annotationObj =
        annotationObjects.contents[labelTool.currentFileIndex][i];
      const cubePosition = new THREE.Vector3(
        cubeObj.position.x,
        cubeObj.position.y,
        cubeObj.position.z + cubeObj.scale.z / 2
      );
      const canvas = pcd_param.renderer.domElement;
      cubePosition.project(pcd_param.currentCamera);
      cubePosition.x = Math.round((0.5 + cubePosition.x / 2) * canvas.width);
      cubePosition.y = Math.round((0.5 - cubePosition.y / 2) * canvas.height);

      if (annotationObj !== undefined) {
        let classTooltip = $("#tooltip-" + annotationObj.trackId)[0];
        if (classTooltip !== undefined) {
          let imagePaneHeight = parseInt(
            $("#layout_layout_resizer_top").css("top"),
            10
          );
          classTooltip.style.top = `${cubePosition.y +
            pcd_param.headerHeight +
            imagePaneHeight -
            21}px`;
          classTooltip.style.left = `${cubePosition.x}px`;
          classTooltip.style.opacity = spriteBehindObject ? 0.25 : 1;
        }
      }
    }
  } catch (error) {
    console.log("Error :", error);
  }
}

function update() {
  // disable rotation of orbit controls if object selected
  if (birdsEyeViewFlag === false) {
    if (labelTool.selectedMesh !== undefined) {
      currentOrbitControls.enableRotate = false;
    } else {
      currentOrbitControls.enableRotate = true;
    }
  }

  // find intersections
  // create a Ray with origin at the mouse position
  // and direction into the scene (camera direction)
  let vector = new THREE.Vector3(mousePos.x, mousePos.y, 1);
  vector.unproject(pcd_param.currentCamera);
  let ray = new THREE.Raycaster(
    pcd_param.currentCamera.position,
    vector.sub(pcd_param.currentCamera.position).normalize()
  );
  // set ray.camera in three.js version r126, otherwise error: THREE.Sprite: "Raycaster.camera" needs to be set in order to raycast against sprites.
  ray.camera = pcd_param.currentCamera;
  let intersects = ray.intersectObjects(labelTool.scene.children, true);

  // if there is one (or more) intersections
  if (intersects.length > 0) {
    // console.log("intersection");
    // if the closest object intersected is not the currently stored intersection object
    if (
      intersects[0].object !== intersectedObject &&
      intersects[0].object.name.startsWith("cube")
    ) {
      // restore previous intersection object (if it exists) to its original color
      if (intersectedObject) {
        if (Array.isArray(intersectedObject.material)) {
          for (let i = 0; i < intersectedObject.material.length; i++) {
            intersectedObject.material[i].color.setHex(
              intersectedObject.currentHex
            );
          }
        } else {
          intersectedObject.material.color.setHex(intersectedObject.currentHex);
        }
      }
      // store reference to closest object as current intersection object
      intersectedObject = intersects[0].object;
      // store color of closest object (for later restoration)
      if (
        Array.isArray(intersectedObject.material) &&
        intersectedObject.material.length > 0 &&
        intersectedObject.material[0] !== undefined
      ) {
        intersectedObject.currentHex = intersectedObject.material[0].color.getHex();
      } else {
        intersectedObject.currentHex = intersectedObject.material.color.getHex();
      }
      // set a new color for closest object
      // intersectedObject.material.color.setHex(0xff0000);
    }
  } else {
    // there are no intersections
    // restore previous intersection object (if it exists) to its original color
    if (intersectedObject) {
      if (Array.isArray(intersectedObject.material)) {
        for (let i = 0; i < intersectedObject.material.length; i++) {
          intersectedObject.material[i].color.setHex(
            intersectedObject.currentHex
          );
        }
      } else {
        intersectedObject.material.color.setHex(intersectedObject.currentHex);
      }
    }
    // remove previous intersection object reference
    //  by setting current intersection object to "nothing"
    intersectedObject = null;
  }

  keyboard.update();
}

//draw animation
function animate() {
  requestAnimationFrame(animate);

  update();
  if (keyboardNavigation === true && pointerLockControls !== undefined) {
    let time = performance.now();
    let delta = (time - prevTime) / 1000;
    translationVelocity.x -= translationVelocity.x * 10.0 * delta;
    translationVelocity.z -= translationVelocity.z * 10.0 * delta;
    translationVelocity.y -= translationVelocity.y * 10.0 * delta;
    rotationVelocity.x -= rotationVelocity.x * delta * 0.000000001;
    rotationVelocity.z -= rotationVelocity.z * delta * 0.000000001;
    rotationVelocity.y -= rotationVelocity.y * delta * 0.000000001;

    translationDirection.x = Number(moveLeft) - Number(moveRight);
    translationDirection.y = Number(moveForward) - Number(moveBackward);
    translationDirection.z = Number(moveUp) - Number(moveDown);
    translationDirection.normalize(); // this ensures consistent movements in all directions
    rotationDirection.x = Number(rotateUp) - Number(rotateDown);
    rotationDirection.y = Number(rotateRight) - Number(rotateLeft);
    rotationDirection.z = 0; // roll not used
    rotationDirection.normalize(); // this ensures consistent movements in all directions

    if (moveForward || moveBackward)
      translationVelocity.z -= translationDirection.y * 400.0 * delta;
    if (moveLeft || moveRight)
      translationVelocity.x -= translationDirection.x * 400.0 * delta;
    if (moveUp || moveDown)
      translationVelocity.y += translationDirection.z * 400.0 * delta;
    if (rotateUp || rotateDown)
      rotationVelocity.x += rotationDirection.x * delta;
    if (rotateRight || rotateLeft)
      rotationVelocity.y -= rotationDirection.y * delta;

    pointerLockControls.getObject().translateX(translationVelocity.x * delta); //lateral
    pointerLockControls.getObject().translateY(translationVelocity.y * delta); //vertical
    pointerLockControls.getObject().translateZ(translationVelocity.z * delta); //longitudinal

    if (rotateLeft) {
      pointerLockObject.rotateY(0.01); //pitch
    } else {
      pointerLockObject.rotateY(0); //pitch
    }
    if (rotateRight) {
      pointerLockObject.rotateY(-0.01); //pitch
    } else {
      pointerLockObject.rotateY(0); //pitch
    }

    prevTime = time;
  }
  render();
}

/**
 * Find the corresponding camera channels in that the 3D object is visible.
 * Note that an object can be visible in one or two camera channels
 * @param x Lateral position
 * @param y Longitudinal position
 * @returns channel One of the six camera channels
 */
function getChannelsByPosition(x, y) {
  let channels = [];
  let alphaRadian;
  if (x >= 0 && y >= 0) {
    alphaRadian = Math.atan(Math.abs(y) / Math.abs(x)) + Math.PI / 2;
  } else if (x < 0 && y >= 0) {
    alphaRadian = Math.atan(Math.abs(x) / Math.abs(y)) + Math.PI;
  } else if (x < 0 && y < 0) {
    alphaRadian = Math.atan(Math.abs(y) / Math.abs(x)) + 1.5 * Math.PI;
  } else {
    // x>=0 and y<0
    alphaRadian = Math.atan(Math.abs(x) / Math.abs(y));
  }
  let alphaDegrees = (360 * alphaRadian) / (2 * Math.PI);

  if (labelTool.currentDataset === labelTool.datasets.NuScenes) {
    if (
      (alphaDegrees >= 325 && alphaDegrees < 360) ||
      (alphaDegrees >= 0 && alphaDegrees < 35)
    ) {
      channels.push(labelTool.camChannels[1].channel);
    }
    if (alphaDegrees >= 20 && alphaDegrees < 90) {
      channels.push(labelTool.camChannels[2].channel);
    }
    if (alphaDegrees >= 75 && alphaDegrees < 145) {
      channels.push(labelTool.camChannels[3].channel);
    }
    if (alphaDegrees >= 115 && alphaDegrees < 245) {
      channels.push(labelTool.camChannels[4].channel);
    }
    if (alphaDegrees >= 215 && alphaDegrees < 285) {
      channels.push(labelTool.camChannels[5].channel);
    }
    if (alphaDegrees >= 270 && alphaDegrees < 340) {
      channels.push(labelTool.camChannels[0].channel);
    }
  } else {
    // GoPro Hero 4 Black, 4:3, wide angle, 122.6 degree
    if (
      (alphaDegrees >= 312.8 && alphaDegrees < 360) ||
      (alphaDegrees >= 0 && alphaDegrees < 47.2)
    ) {
      channels.push(labelTool.camChannels[1].channel);
    }
    if (alphaDegrees >= 20 && alphaDegrees < 90) {
      channels.push(labelTool.camChannels[2].channel);
    }
    if (alphaDegrees >= 75 && alphaDegrees < 145) {
      channels.push(labelTool.camChannels[3].channel);
    }
    if (alphaDegrees >= 115 && alphaDegrees < 245) {
      channels.push(labelTool.camChannels[4].channel);
    }
    if (alphaDegrees >= 215 && alphaDegrees < 285) {
      channels.push(labelTool.camChannels[5].channel);
    }
    if (alphaDegrees >= 270 && alphaDegrees < 340) {
      channels.push(labelTool.camChannels[0].channel);
    }
  }

  return channels;
}

function rotatePoint(pointX, pointY, originX, originY, angle) {
  angle = (angle * Math.PI) / 180.0;
  return {
    x:
      Math.cos(angle) * (pointX - originX) -
      Math.sin(angle) * (pointY - originY) +
      originX,
    y:
      Math.sin(angle) * (pointX - originX) +
      Math.cos(angle) * (pointY - originY) +
      originY,
  };
}

function changeDataset(datasetName) {
  labelTool.reset();
  labelTool.currentDataset = datasetName;
  labelTool.currentDatasetIdx = labelTool.datasetArray.indexOf(datasetName);
  labelTool.sequence =
    labelTool.dataStructure.datasets[
      labelTool.datasetArray.indexOf(datasetName)
    ].sequences[0];
  labelTool.classes =
    labelTool.dataStructure.datasets[
      labelTool.datasetArray.indexOf(datasetName)
    ].classes;
  labelTool.classColors =
    labelTool.dataStructure.datasets[
      labelTool.datasetArray.indexOf(datasetName)
    ].class_colors;
  labelTool.initClasses();
  initGuiBoundingBoxAnnotations();
  // move button to left
  $("#left-btn").css("left", 0);
  // move class picker to left
  $("#class-picker").css("left", 10);
  labelTool.start();
}

function changeSequence(sequence) {
  labelTool.sequence = sequence;
  labelTool.reset();
  labelTool.start();
}

function readPointCloud() {
  let rawFile = new XMLHttpRequest();
  try {
    if (labelTool.showOriginalNuScenesLabels === true) {
      let path =
        "static/input/" +
        labelTool.currentDataset +
        "/pointclouds/" +
        pad(labelTool.currentFileIndex, 6) +
        ".pcd";
      rawFile.open("GET", path, false);
    } else {
      let path =
        "static/input/" +
        labelTool.currentDataset +
        "/" +
        labelTool.sequence +
        "/pointclouds/" +
        pad(labelTool.currentFileIndex, 6) +
        ".pcd";
      rawFile.open("GET", path, false);
    }
  } catch (error) {
    // no labels available for this camera image
    // do not through an error message
  }

  let points3D = [];
  rawFile.onreadystatechange = function() {
    if (rawFile.readyState === 4) {
      if (rawFile.status === 200 || rawFile.status === 0) {
        let allText = rawFile.responseText;
        let allLines = allText.split("\n");
        for (let i = 0; i < allLines.length; i++) {
          if (i < 11) {
            // skip header
            continue;
          }
          let points3DStringArray = allLines[i].split(" ");
          let point3D = [];
          // skip the last value (intensity)
          for (let j = 0; j < points3DStringArray.length - 1; j++) {
            let value = Number(points3DStringArray[j]);
            // points are stored in meters within .h5 file and .pcd files
            if (labelTool.currentDataset === labelTool.datasets.NuScenes) {
              point3D.push(value);
            }
          }
          // make point a 4x1 vector to multiply it with the 3x4 projection matrix P*X
          point3D.push(1);
          points3D.push(point3D);
        }
        return points3D;
      }
    }
  };
  rawFile.send(null);
  return points3D;
}

function projectPoints(points3D, channelIdx) {
  let points2D = [];
  currentPoints3D = [];
  currentDistances = [];
  let projectionMatrix;
  let scalingFactor;
  let imagePanelHeight = parseInt(
    $("#layout_layout_resizer_top").css("top"),
    10
  );
  if (labelTool.currentDataset === labelTool.datasets.NuScenes) {
    scalingFactor = 900 / imagePanelHeight;
    projectionMatrix =
      labelTool.camChannels[channelIdx].projectionMatrixNuScenes;
  }

  for (let i = 0; i < points3D.length; i++) {
    let point3D = points3D[i];
    let point2D = matrixProduct3x4(projectionMatrix, point3D);
    if (point2D[2] > 0) {
      // use only points that are in front of the camera
      let windowX = point2D[0] / point2D[2];
      let windowY = point2D[1] / point2D[2];
      currentPoints3D.push(point3D);
      // calculate distance
      let distance = Math.sqrt(
        Math.pow(point3D[0], 2) +
          Math.pow(point3D[1], 2) +
          Math.pow(point3D[2], 2)
      );
      currentDistances.push(distance);
      points2D.push({ x: windowX / scalingFactor, y: windowY / scalingFactor });
    }
  }
  return points2D;
}

function normalizeDistances() {
  let maxDistance = 0;
  for (let distanceIdx in currentDistances) {
    if (currentDistances.hasOwnProperty(distanceIdx)) {
      let distance = currentDistances[distanceIdx];
      if (distance > maxDistance) {
        maxDistance = distance;
      }
    }
  }
  for (let i = 0; i < currentDistances.length; i++) {
    currentDistances[i] = (currentDistances[i] / maxDistance) * 255;
  }
}

function showProjectedPoints() {
  let points3D = readPointCloud();
  for (
    let channelIdx = 0;
    channelIdx < labelTool.camChannels.length;
    channelIdx++
  ) {
    let paper = labelTool.paperArrayAll[labelTool.currentFileIndex][channelIdx];
    let points2D = projectPoints(points3D, channelIdx);
    normalizeDistances();
    for (let i = 0; i < points2D.length; i++) {
      let pt2D = points2D[i];
      let circle = paper.circle(pt2D.x, pt2D.y, 1);
      let distance = currentDistances[i];
      let color = colorMap[Math.floor(distance)];
      circle.attr("stroke", color);
      circle.attr("stroke-width", 1);
      circleArray.push(circle);
    }
  }
}

function hideProjectedPoints() {
  for (let i = circleArray.length - 1; i >= 0; i--) {
    let circle = circleArray[i];
    circle.remove();
    circleArray.splice(i, 1);
  }
}

function loadColorMap() {
  let rawFile = new XMLHttpRequest();
  try {
    rawFile.open("GET", "static/colormaps/" + activeColorMap, false);
  } catch (error) {}

  rawFile.onreadystatechange = function() {
    if (rawFile.readyState === 4) {
      if (rawFile.status === 200 || rawFile.status === 0) {
        let allText = rawFile.responseText;
        colorMap = allText.replace(/"/g, "").split("\n");
      }
    }
  };
  rawFile.send(null);
}

function onDocumentMouseWheel(event) {
  let factor = 15;
  let mX = (event.clientX / jQuery(container).width()) * 2 - 1;
  let mY = -(event.clientY / jQuery(container).height()) * 2 + 1;
  let vector = new THREE.Vector3(mX, mY, 0.1);
  vector.unproject(pcd_param.currentCamera);
  vector.sub(pcd_param.currentCamera.position);
  if (event.deltaY < 0) {
    pcd_param.currentCamera.position.addVectors(
      pcd_param.currentCamera.position,
      vector.setLength(factor)
    );
    currentOrbitControls.target.addVectors(
      currentOrbitControls.target,
      vector.setLength(factor)
    );
  } else {
    pcd_param.currentCamera.position.subVectors(
      pcd_param.currentCamera.position,
      vector.setLength(factor)
    );
    currentOrbitControls.target.subVectors(
      currentOrbitControls.target,
      vector.setLength(factor)
    );
  }
}

function onDocumentMouseMove(event) {
  // update the mouse variable
  mousePos.x = (event.clientX / labelTool.updtedWidth) * 2 - 1;
  mousePos.y = -(event.clientY / labelTool.updatedHeight) * 2 + 1;
}

function enableStartPose() {
  // disable slider
  annotationObjects.folderPositionArray[
    labelTool.interpolationObjIndexCurrentFile
  ].domElement.style.opacity = 1.0;
  annotationObjects.folderPositionArray[
    labelTool.interpolationObjIndexCurrentFile
  ].domElement.style.pointerEvents = "all";
  annotationObjects.folderRotationArray[
    labelTool.interpolationObjIndexCurrentFile
  ].domElement.style.opacity = 1.0;
  annotationObjects.folderRotationArray[
    labelTool.interpolationObjIndexCurrentFile
  ].domElement.style.pointerEvents = "all";
  annotationObjects.folderSizeArray[
    labelTool.interpolationObjIndexCurrentFile
  ].domElement.style.opacity = 1.0;
  annotationObjects.folderSizeArray[
    labelTool.interpolationObjIndexCurrentFile
  ].domElement.style.pointerEvents = "all";
}

function scatter(vertices, size, color, texture = "") {
  let geometry = new THREE.BufferGeometry();
  let settings = {
    size: size,
    sizeAttenuation: false,
    alphaTest: 0.5,
    transparent: true,
  };
  if (texture !== "") {
    settings["map"] = new THREE.TextureLoader().load(texture);
  }
  geometry.addAttribute(
    "position",
    new THREE.Float32BufferAttribute(vertices, 3)
  );
  material = new THREE.PointsMaterial(settings);
  material.color.set(color);
  return new THREE.Points(geometry, material);
}

// function addViewToolTip(viewName) {
//   let viewTooltipElement = $(
//     "<div class='class-tooltip' id='tooltip-" +
//       viewName +
//       "'>" +
//       viewName +
//       "</div>"
//   );
//   const spriteMaterial = new THREE.SpriteMaterial({
//     alphaTest: 0.5,
//     transparent: true,
//     depthTest: false,
//     depthWrite: false,
//   });
//   let sprite = new THREE.Sprite(spriteMaterial);
//   sprite.position
//     .set
//     // BEV - Position sprite inside blue box
//     //Front View - Position below second box
//     //Side View - Position below third box
//     ();
//   sprite.scale.set(1, 1, 1);
//   sprite.name = "sprite-" + viewName;
//   $("body").append(viewTooltipElement);
//   labelTool.scene.add(sprite);
//   labelTool.spriteArray[fileIndex].push(sprite);
// }

function updateBEV(xPos, yPos, zPos) {
  let imagePaneHeight = parseInt(
    $("#layout_layout_resizer_top").css("top"),
    10
  );
  let panelTopPos = pcd_param.headerHeight + imagePaneHeight;
  canvasBEV.left = "0px";
  canvasBEV.top = panelTopPos;

  cameraBEV.position.set(xPos, yPos, zPos + 100);
  cameraBEV.lookAt(xPos, yPos, zPos);
  //addViewToolTip("Bird Eye View", xPos, yPos, zPos);
}

function initBev() {
  canvasBEV = document.createElement("canvas");
  canvasBEV.id = "canvasBev";
  let wBev = labelTool.updtedWidth / 3;
  canvasBEV.width = wBev;
  let imagePaneHeight = parseInt(
    $("#layout_layout_resizer_top").css("top"),
    10
  );
  let hBev;
  hBev =
    (labelTool.updatedHeight - imagePaneHeight - pcd_param.headerHeight) / 3;
  canvasBEV.height = hBev;
  $("body").append(canvasBEV);
  $("#canvasBev").css(
    "top",
    pcd_param.headerHeight + imagePaneHeight + 42 + 2 * hBev
  );
  $("#canvasBev").css({ left: 27 + "px" });

  cameraBEV = new THREE.OrthographicCamera(
    labelTool.updtedWidth / -4,
    labelTool.updtedWidth / 4,
    labelTool.updatedHeight / 4,
    labelTool.updatedHeight / -4,
    -5000,
    10000
  );
  cameraBEV.up = new THREE.Vector3(0, 0, -1);
  cameraBEV.lookAt(new THREE.Vector3(0, -1, 0));
  labelTool.scene.add(cameraBEV);
}

function showBEV(xPos, yPos, zPos) {
  if ($("#canvasBev").length === 0) {
    initBev();
  }
  updateBEV(xPos, yPos, zPos);

  divBev = document.createElement("div");
  divBev.id = "divBev";
  divBev.innerHTML += "Bird Eye/Top View";
  $("body").append(divBev);
  $("#divBev").css("top", "28vh");
  $("#divBev").css("left", "2vw");
  $("#divBev").css("position", "fixed");
  $("#divBev").css("color", "cyan");
  $("#divBev").css("z-index", "99999");
  $("#divBev").css("width", "10px");
  $("#divBev").css("height", "30px");
  $("#divBev").show();
  $("#canvasBev").show();
}

function initFrontView() {
  canvasFrontView = document.createElement("canvas");
  canvasFrontView.id = "canvasFrontView";
  let widthFrontView = labelTool.updtedWidth / 3;
  canvasFrontView.width = widthFrontView;
  let imagePanelTopPos = parseInt(
    $("#layout_layout_resizer_top").css("top"),
    10
  );
  let heightFrontView;
  heightFrontView =
    (labelTool.updatedHeight - imagePanelTopPos - pcd_param.headerHeight) / 3;
  canvasFrontView.height = heightFrontView;

  $("body").append(canvasFrontView);
  $("#canvasFrontView").css(
    "top",
    pcd_param.headerHeight + imagePanelTopPos + heightFrontView + 42
  );
  $("#canvasFrontView").css({ left: 27 + "px" });
  cameraFrontView = new THREE.OrthographicCamera(
    labelTool.updtedWidth / -4,
    labelTool.updtedWidth / 4,
    labelTool.updatedHeight / 4,
    labelTool.updatedHeight / -4,
    -5000,
    10000
  );
  cameraFrontView.lookAt(new THREE.Vector3(0, 0, -1));
  labelTool.scene.add(cameraFrontView);
}

function updateFrontView() {
  let imagePanelTopPos = parseInt(
    $("#layout_layout_resizer_top").css("top"),
    10
  );
  let panelTopPos = imagePanelTopPos + pcd_param.headerHeight + 270;
  canvasFrontView.left = "0px";
  canvasFrontView.top = panelTopPos;
  if (rendererFrontView === undefined) {
    rendererFrontView = new THREE.WebGLRenderer({
      antialias: true,
    });
  }
  rendererFrontView.setSize(labelTool.updtedWidth, labelTool.updatedHeight);
  rendererFrontView.setClearColor(0x000000, 1);
  rendererFrontView.autoClear = false;
}

function showFrontView() {
  if ($("#canvasFrontView").length === 0) {
    initFrontView();
  }
  updateFrontView();

  divFrontView = document.createElement("div");
  divFrontView.id = "divFront";
  divFrontView.innerHTML += "Front View";
  $("body").append(divFrontView);
  $("#divFront").css("top", "62vh");
  $("#divFront").css("left", "2vw");
  $("#divFront").css("position", "fixed");
  $("#divFront").css("color", "cyan");
  $("#divFront").css("z-index", "99999");
  $("#divFront").css("width", "10px");
  $("#divFront").css("height", "30px");
  $("#canvasFrontView").show();
  $("#divFront").show();
}

function initSideView() {
  canvasSideView = document.createElement("canvas");
  canvasSideView.id = "canvasSideView";
  let widthSideView = labelTool.updtedWidth / 3;
  let imagePaneHeight = parseInt(
    $("#layout_layout_resizer_top").css("top"),
    10
  );
  let heightSideView;
  heightSideView =
    (labelTool.updatedHeight - imagePaneHeight - pcd_param.headerHeight) / 3;
  canvasSideView.width = widthSideView;
  canvasSideView.height = heightSideView;
  $("body").append(canvasSideView);
  let sideHeight = imagePaneHeight;
  $("#canvasSideView").css({
    top: sideHeight + 42 + pcd_param.headerHeight + "px",
  });
  $("#canvasSideView").css({ left: 27 + "px" });

  cameraSideView = new THREE.OrthographicCamera(
    labelTool.updtedWidth / -4,
    labelTool.updtedWidth / 4,
    labelTool.updatedHeight / 4,
    labelTool.updatedHeight / -4,
    -5000,
    10000
  );
  cameraSideView.lookAt(new THREE.Vector3(1, 0, 0));

  // TODO: let user move bounding box also in helper views (master view)
  labelTool.scene.add(cameraSideView);
}

function updateSideView() {
  let imagePaneHeight = parseInt(
    $("#layout_layout_resizer_top").css("top"),
    10
  );
  let panelTopPos = pcd_param.headerHeight + imagePaneHeight;
  canvasSideView.left = "0px";
  canvasSideView.top = panelTopPos;
}

function showSideView() {
  if ($("#canvasSideView").length === 0) {
    initSideView();
  }
  updateSideView();
  $("#canvasSideView").show();
  divSideView = document.createElement("div");
  divSideView.id = "divSide";
  divSideView.innerHTML += "Side View";
  $("body").append(divSideView);
  $("#divSide").css("top", "95vh");
  $("#divSide").css("left", "2vw");
  $("#divSide").css("position", "fixed");
  $("#divSide").css("color", "cyan");
  $("#divSide").css("z-index", "99999");
  $("#divSide").css("width", "15px");
  $("#divSide").css("height", "30px");
  $("#divSide").show();
}

function showHelperViews(xPos, yPos, zPos) {
  showSideView();
  showFrontView();
  showBEV(xPos, yPos, zPos); //width along x axis (lateral), height along y axis (longitudinal)
  // move class picker to right
  $("#class-picker").css("left", labelTool.updtedWidth / 3 + 10);
}

// function enableInterpolationModeCheckbox(interpolationModeCheckbox) {
//     interpolationModeCheckbox.parentElement.parentElement.style.opacity = 1.0;
//     interpolationModeCheckbox.parentElement.parentElement.style.pointerEvents = "all";
//     $(interpolationModeCheckbox.firstChild).removeAttr("tabIndex");
// }

function enableInterpolationBtn() {
  interpolateBtn.domElement.parentElement.parentElement.style.pointerEvents =
    "all";
  interpolateBtn.domElement.parentElement.parentElement.style.opacity = 1.0;
  $(interpolateBtn.domElement.firstChild).removeAttr("tabIndex");
}

function classPopupPosition(e) {
  var popup = document.getElementById("set");
  popup.style.marginLeft = e.offsetX + "px";
  popup.style.marginTop = e.offsetY + "px";
}

function mouseUpLogic(ev) {
  dragControls = false;
  // check if scene contains transform controls
  useTransformControls = false;
  for (let i = 0; i < labelTool.scene.children.length; i++) {
    if (labelTool.scene.children[i].name === "transformControls") {
      useTransformControls = true;
    }
  }
  if (ev.button === 0) {
    let rect = ev.target.getBoundingClientRect();
    mouseUp.x =
      ((ev.clientX - rect.left) / $("#canvas3d canvas").attr("width")) * 2 - 1;
    mouseUp.y =
      -((ev.clientY - rect.top) / $("#canvas3d canvas").attr("height")) * 2 + 1;
    if (isDrawBox == true) {
      makeBox(ev);
    } else {
      loadBox();
    }
  }
}
//Runs on mouse click is released
function loadBox() {
  let ray = undefined;
  let insertIndex;
  let clickedObjects;
  if (birdsEyeViewFlag === false) {
    let vector = new THREE.Vector3(mouseUp.x, mouseUp.y, 1);
    vector.unproject(pcd_param.currentCamera);
    ray = new THREE.Raycaster(
      pcd_param.currentCamera.position,
      vector.sub(pcd_param.currentCamera.position).normalize()
    );
  } else {
    ray = new THREE.Raycaster();
    let mouse = new THREE.Vector2();
    mouse.x = mouseUp.x;
    mouse.y = mouseUp.y;
    ray.setFromCamera(mouse, pcd_param.currentCamera);
  }

  if (birdsEyeViewFlag === true) {
    clickedObjects = ray.intersectObjects(clickedPlaneArray);
  } else {
    clickedObjects = ray.intersectObjects(
      labelTool.cubeArray[labelTool.currentFileIndex]
    );
  }
  // close folders
  for (let i = 0; i < annotationObjects.folderBoundingBox3DArray.length; i++) {
    if (annotationObjects.folderBoundingBox3DArray[i] !== undefined) {
      annotationObjects.folderBoundingBox3DArray[i].close();
    }
  }

  if (clickedObjects.length > 0 && clickedObjectIndex !== -1) {
    // open folder of selected object
    annotationObjects.localOnSelect["PCD"](clickedObjectIndex);
    // set selected object

    labelTool.selectedMesh =
      labelTool.cubeArray[labelTool.currentFileIndex][clickedObjectIndex];
    if (labelTool.selectedMesh !== undefined) {
      for (
        let i = 0;
        i < annotationObjects.contents[labelTool.currentFileIndex].length;
        i++
      ) {
        $(
          "#tooltip-" +
            annotationObjects.contents[labelTool.currentFileIndex][i]["trackId"]
        ).show();
      }
      $(
        "#tooltip-" +
          annotationObjects.contents[labelTool.currentFileIndex][
            clickedObjectIndex
          ]["trackId"]
      ).hide();
      addTransformControls();

      if (transformControls.position !== undefined) {
        transformControls.detach();
        transformControls.attach(labelTool.selectedMesh);
      }

      transformControls.size = 2;
    } else {
      removeObject("transformControls");
    }

    for (let channelIdx in labelTool.camChannels) {
      if (labelTool.camChannels.hasOwnProperty(channelIdx)) {
        let camChannel = labelTool.camChannels[channelIdx].channel;
        annotationObjects.select(clickedObjectIndex, camChannel);
      }
    }

    if (labelTool.pointCloudOnlyAnnotation === false) {
      // uncolor previous selected object in image view
      if (clickedObjectIndexPrevious !== -1) {
        annotationObjects.update2DBoundingBox(
          labelTool.currentFileIndex,
          clickedObjectIndexPrevious,
          false
        );
      }
      // select object in cam images
      annotationObjects.update2DBoundingBox(
        labelTool.currentFileIndex,
        clickedObjectIndex,
        true
      );
    }

    let obj =
      annotationObjects.contents[labelTool.currentFileIndex][
        clickedObjectIndex
      ];
    showHelperViews(obj["x"], obj["y"], obj["z"]); // this is to show 3 window
    classesBoundingBox.currentClass = obj["class"];
  } else {
    if (labelTool.pointCloudOnlyAnnotation === false) {
      // remove selection in camera view if 2d label exist
      for (
        let i = 0;
        i < annotationObjects.contents[labelTool.currentFileIndex].length;
        i++
      ) {
        if (
          annotationObjects.contents[labelTool.currentFileIndex][i]["rect"] !==
          undefined
        ) {
          // removeBoundingBoxHighlight(i);
          removeTextBox(i);
        }
      }
    }
    // remove selection in birds eye view (lower opacity)
    for (let mesh in labelTool.cubeArray[labelTool.currentFileIndex]) {
      let meshObject = labelTool.cubeArray[labelTool.currentFileIndex][mesh];
      if (Array.isArray(meshObject.material)) {
        for (let i = 0; i < meshObject.material.length; i++) {
          if (i === 0) {
            meshObject.material[i].opacity = 0.9;
          } else {
            meshObject.material[i].opacity = 0.1;
          }
        }
      } else {
        meshObject.material.opacity = 0.9;
      }
    }

    // remove arrows (transform controls)
    if (transformControls !== undefined) {
      transformControls.detach();
    }
    removeObject("transformControls");
    labelTool.selectedMesh = undefined;
    annotationObjects.selectEmpty();

    // disable interpolate button

    // $("#canvasBev").hide();
    // $("#canvasSideView").hide();
    // $("#canvasFrontView").hide();
    hideMasterView();

    // move class picker to left
    $("#class-picker").css("left", 10);
  }
  if (clickFlag === true) {
    clickedPlaneArray = [];
    for (let channelIdx in labelTool.camChannels) {
      if (labelTool.camChannels.hasOwnProperty(channelIdx)) {
        let camChannel = labelTool.camChannels[channelIdx].channel;
        annotationObjects.select(clickedObjectIndex, camChannel);
      }
    }
    clickedObjectIndexPrevious = annotationObjects.__selectionIndexCurrentFrame;
    clickFlag = false;
  } else if (
    groundPlaneArray.length === 1 &&
    birdsEyeViewFlag === true &&
    useTransformControls === false
  ) {
    let groundUpObject = ray.intersectObjects(groundPlaneArray);
    if (groundUpObject === undefined || groundUpObject[0] === undefined) {
      return;
    }

    //  setHighestAvailableTrackId(classesBoundingBox.getCurrentClass());
    if (
      labelTool.showOriginalNuScenesLabels === true &&
      labelTool.currentDataset === labelTool.datasets.NuScenes
    ) {
      if (annotationObjects.__selectionIndexCurrentFrame === -1) {
        // no object selected in 3d scene (new object was created)-> use selected class from class menu
        insertIndex =
          annotationObjects.contents[labelTool.currentFileIndex].length;
      } else {
        // object was selected in 3d scene
        insertIndex = annotationObjects.__selectionIndexCurrentFrame;
      }
    } else {
      if (annotationObjects.__selectionIndexCurrentFrame === -1) {
        insertIndex =
          annotationObjects.contents[labelTool.currentFileIndex].length;
      } else {
        insertIndex = annotationObjects.__selectionIndexCurrentFrame;
      }
    }
  }
}
export function storeCurrChannel(channel) {
  currSelectedChannel = channel;
}
function makeBox(ev) {
  let ray = undefined;
  let insertIndex;
  let clickedObjects;
  isDrawBox = false;
  if (birdsEyeViewFlag === false) {
    let vector = new THREE.Vector3(mouseUp.x, mouseUp.y, 1);
    vector.unproject(pcd_param.currentCamera);
    ray = new THREE.Raycaster(
      pcd_param.currentCamera.position,
      vector.sub(pcd_param.currentCamera.position).normalize()
    );
  } else {
    ray = new THREE.Raycaster();
    let mouse = new THREE.Vector2();
    mouse.x = mouseUp.x;
    mouse.y = mouseUp.y;
    ray.setFromCamera(mouse, pcd_param.currentCamera);
  }

  if (birdsEyeViewFlag === true) {
    clickedObjects = ray.intersectObjects(clickedPlaneArray);
  } else {
    clickedObjects = ray.intersectObjects(
      labelTool.cubeArray[labelTool.currentFileIndex]
    );
  }
  // close folders
  for (let i = 0; i < annotationObjects.folderBoundingBox3DArray.length; i++) {
    if (annotationObjects.folderBoundingBox3DArray[i] !== undefined) {
      annotationObjects.folderBoundingBox3DArray[i].close();
    }
  }

  if (clickedObjects.length > 0 && clickedObjectIndex !== -1) {
    // open folder of selected object
    annotationObjects.localOnSelect["PCD"](clickedObjectIndex);
    // set selected object

    labelTool.selectedMesh =
      labelTool.cubeArray[labelTool.currentFileIndex][clickedObjectIndex];
    if (labelTool.selectedMesh !== undefined) {
      for (
        let i = 0;
        i < annotationObjects.contents[labelTool.currentFileIndex].length;
        i++
      ) {
        $(
          "#tooltip-" +
            annotationObjects.contents[labelTool.currentFileIndex][i]["trackId"]
        ).show();
      }
      $(
        "#tooltip-" +
          annotationObjects.contents[labelTool.currentFileIndex][
            clickedObjectIndex
          ]["trackId"]
      ).hide();
      addTransformControls();

      if (transformControls.position !== undefined) {
        transformControls.detach();
        transformControls.attach(labelTool.selectedMesh);
      }

      transformControls.size = 2;
    } else {
      removeObject("transformControls");
    }

    for (let channelIdx in labelTool.camChannels) {
      if (labelTool.camChannels.hasOwnProperty(channelIdx)) {
        let camChannel = labelTool.camChannels[channelIdx].channel;
        annotationObjects.select(clickedObjectIndex, camChannel);
      }
    }

    if (labelTool.pointCloudOnlyAnnotation === false) {
      // uncolor previous selected object in image view
      if (clickedObjectIndexPrevious !== -1) {
        annotationObjects.update2DBoundingBox(
          labelTool.currentFileIndex,
          clickedObjectIndexPrevious,
          false
        );
      }
      // select object in cam images
      annotationObjects.update2DBoundingBox(
        labelTool.currentFileIndex,
        clickedObjectIndex,
        true
      );
    }

    let obj =
      annotationObjects.contents[labelTool.currentFileIndex][
        clickedObjectIndex
      ];
    showHelperViews(obj["x"], obj["y"], obj["z"]);
  } else {
    if (labelTool.pointCloudOnlyAnnotation === false) {
      // remove selection in camera view if 2d label exist
      for (
        let i = 0;
        i < annotationObjects.contents[labelTool.currentFileIndex].length;
        i++
      ) {
        if (
          annotationObjects.contents[labelTool.currentFileIndex][i]["rect"] !==
          undefined
        ) {
          // removeBoundingBoxHighlight(i);
          removeTextBox(i);
        }
      }
    }

    // remove selection in birds eye view (lower opacity)
    for (let mesh in labelTool.cubeArray[labelTool.currentFileIndex]) {
      let meshObject = labelTool.cubeArray[labelTool.currentFileIndex][mesh];
      if (Array.isArray(meshObject.material)) {
        for (let i = 0; i < meshObject.material.length; i++) {
          if (i === 0) {
            meshObject.material[i].opacity = 0.9;
          } else {
            meshObject.material[i].opacity = 0.1;
          }
        }
      } else {
        meshObject.material.opacity = 0.9;
      }
    }

    // remove arrows (transform controls)
    if (transformControls !== undefined) {
      transformControls.detach();
    }
    removeObject("transformControls");
    labelTool.selectedMesh = undefined;
    annotationObjects.selectEmpty();

    // disable interpolate button

    // $("#canvasBev").hide();
    // $("#canvasSideView").hide();
    // $("#canvasFrontView").hide();

    hideMasterView();
    // move class picker to left
    $("#class-picker").css("left", 10);

    let interpolationModeCheckbox = document.getElementById(
      "interpolation-checkbox"
    );
    // disableInterpolationModeCheckbox(interpolationModeCheckbox);

    // move button to left
    $("#left-btn").css("left", 0);
  }
  if (clickFlag === true) {
    clickedPlaneArray = [];
    for (let channelIdx in labelTool.camChannels) {
      if (labelTool.camChannels.hasOwnProperty(channelIdx)) {
        let camChannel = labelTool.camChannels[channelIdx].channel;
        annotationObjects.select(clickedObjectIndex, camChannel);
      }
    }
    clickedObjectIndexPrevious = annotationObjects.__selectionIndexCurrentFrame;
    clickFlag = false;
  } else if (
    groundPlaneArray.length === 1 &&
    birdsEyeViewFlag === true &&
    useTransformControls === false
  ) {
    let groundUpObject = ray.intersectObjects(groundPlaneArray);
    if (groundUpObject === undefined || groundUpObject[0] === undefined) {
      return;
    }
    let groundPointMouseUp = groundUpObject[0].point;

    let trackId = -1;
    if (
      labelTool.showOriginalNuScenesLabels === true &&
      labelTool.currentDataset === labelTool.datasets.NuScenes
    ) {
      if (annotationObjects.__selectionIndexCurrentFrame === -1) {
        // no object selected in 3d scene (new object was created)-> use selected class from class menu
        insertIndex =
          annotationObjects.contents[labelTool.currentFileIndex].length;
      } else {
        // object was selected in 3d scene
        insertIndex = annotationObjects.__selectionIndexCurrentFrame;
      }
    } else {
      if (annotationObjects.__selectionIndexCurrentFrame === -1) {
        insertIndex =
          annotationObjects.contents[labelTool.currentFileIndex].length;
      } else {
        insertIndex = annotationObjects.__selectionIndexCurrentFrame;
      }
    }

    // set channel based on 3d position of new bonding box
    if (Math.abs(groundPointMouseUp.x - groundPointMouseDown.x) > 0.1) {
      let xPos = (groundPointMouseUp.x + groundPointMouseDown.x) / 2;
      let yPos = (groundPointMouseUp.y + groundPointMouseDown.y) / 2;
      let zPos = 0;

      // average car height in meters (ref: https://www.carfinderservice.com/car-advice/a-careful-look-at-different-sedan-dimensions)
      let addBboxParameters = labelTool.getDefaultObject();
      addBboxParameters.class = classesBoundingBox.getCurrentClass();
      addBboxParameters.x = xPos;
      addBboxParameters.y = yPos;
      if (labelTool.currentDataset === labelTool.datasets.providentia) {
        addBboxParameters.z =
          zPos + defaultBoxHeight / 2 - labelTool.positionLidar[2];
      } else {
        addBboxParameters.z =
          zPos + defaultBoxHeight / 2 - labelTool.positionLidarNuscenes[2];
      }
      addBboxParameters.width = Math.abs(
        groundPointMouseUp.x - groundPointMouseDown.x
      );
      addBboxParameters.length = Math.abs(
        groundPointMouseUp.y - groundPointMouseDown.y
      );
      addBboxParameters.height = defaultBoxHeight;
      addBboxParameters.rotationYaw = 0;
      addBboxParameters.rotationPitch = 0;
      addBboxParameters.rotationRoll = 0;
      addBboxParameters.original = {
        class: classesBoundingBox.getCurrentClass(),
        x: (groundPointMouseUp.x + groundPointMouseDown.x) / 2,
        y: (groundPointMouseUp.y + groundPointMouseDown.y) / 2,
        z: zPos + defaultBoxHeight / 2 - labelTool.positionLidarNuscenes[2],
        width: Math.abs(groundPointMouseUp.x - groundPointMouseDown.x),
        length: Math.abs(groundPointMouseUp.y - groundPointMouseDown.y),
        height: defaultBoxHeight,
        rotationYaw: 0,
        rotationPitch: 0,
        rotationRoll: 0,
        trackId: trackId,
      };
      addBboxParameters.trackId = trackId;
      addBboxParameters.fromFile = false;
      addBboxParameters.fileIndex = labelTool.currentFileIndex;
      addBboxParameters.copyLabelToNextFrame = false;
      if (labelTool.pointCloudOnlyAnnotation === false) {
        // calculate projected points for each channel
        for (let i = 0; i < labelTool.camChannels.length; i++) {
          let channel = labelTool.camChannels[i].channel;
          let projectedBoundingBox = annotationObjects.calculateProjectedBoundingBox(
            xPos,
            yPos,
            addBboxParameters.z,
            addBboxParameters.width,
            addBboxParameters.length,
            addBboxParameters.height,
            channel,
            addBboxParameters.rotationYaw,
            addBboxParameters.rotationPitch,
            addBboxParameters.rotationRoll
          );
          addBboxParameters.channels[i].projectedPoints = projectedBoundingBox;
        }

        // calculate 2D line segments
        for (let i = 0; i < addBboxParameters.channels.length; i++) {
          let channelObj = addBboxParameters.channels[i];
          if (channelObj.channel !== undefined && channelObj.channel !== "") {
            if (
              addBboxParameters.channels[i].projectedPoints !== undefined &&
              addBboxParameters.channels[i].projectedPoints.length === 8
            ) {
              // let horizontal =
              //   addBboxParameters.width > addBboxParameters.length;
              // addBboxParameters.channels[i][
              //   "lines"
              // ] = Service3D.calculateAndDrawLineSegments(
              //   channelObj,
              //   classesBoundingBox.getCurrentClass(),
              //   horizontal,
              //   true
              // );

              if (addBboxParameters.channels[i].projectedPoints !== undefined) {
                if (
                  currSelectedChannel === addBboxParameters.channels[i].channel
                ) {
                  annotationObjects.drawLines(
                    addBboxParameters.channels[i].projectedPoints,
                    addBboxParameters.trackId,
                    false
                  );
                }
              }
            }
          }
        }
      }

      annotationObjects.setMakeBox(insertIndex, addBboxParameters);
      labelTool.selectedMesh =
        labelTool.cubeArray[labelTool.currentFileIndex][insertIndex];
      if (labelTool.selectedMesh !== undefined) {
        addTransformControls();
      } else {
        removeObject("transformControls");
      }
      $(
        "#tooltip-" +
          annotationObjects.contents[labelTool.currentFileIndex][insertIndex][
            "trackId"
          ]
      ).hide();
      // move left button to right
      $("#left-btn").css("left", labelTool.updtedWidth / 3);
      showHelperViews(xPos, yPos, zPos);

      annotationObjects.__insertIndex++;

      for (let channelIdx in labelTool.camChannels) {
        if (labelTool.camChannels.hasOwnProperty(channelIdx)) {
          let camChannel = labelTool.camChannels[channelIdx].channel;
          annotationObjects.select(insertIndex, camChannel);
        }
      }
      let interpolationModeCheckbox = document.getElementById(
        "interpolation-checkbox"
      );
      // enableInterpolationModeCheckbox(interpolationModeCheckbox);

      if (annotationObjects.interpolationMode === true) {
        labelTool.interpolationObjIndexCurrentFile = insertIndex;
      }
      let classPopup = document.getElementById("set");
      if (classPopup.style.display === "none") {
        classPopup.style.display = "block";
        classPopupPosition(ev);
      }
    }
    groundPlaneArray = [];
  }
  currentClassId = insertIndex;
}

function handleMouseUp(ev) {
  if (rendererBev === undefined) {
    mouseUpLogic(ev);
  } else {
    if (ev.target !== rendererBev.domElement) {
      mouseUpLogic(ev);
    }
  }
}

function mouseDownLogic(ev) {
  let rect = ev.target.getBoundingClientRect();
  mouseDown.x = ((ev.clientX - rect.left) / labelTool.updtedWidth) * 2 - 1;
  mouseDown.y = -((ev.clientY - rect.top) / labelTool.updatedHeight) * 2 + 1;
  let ray;
  if (birdsEyeViewFlag === false) {
    let vector = new THREE.Vector3(mouseDown.x, mouseDown.y, 1);
    vector.unproject(pcd_param.currentCamera);
    ray = new THREE.Raycaster(
      pcd_param.currentCamera.position,
      vector.sub(pcd_param.currentCamera.position).normalize()
    );
  } else {
    ray = new THREE.Raycaster();
    let mouse = new THREE.Vector2();
    mouse.x = mouseDown.x;
    mouse.y = mouseDown.y;
    ray.setFromCamera(mouse, pcd_param.currentCamera);
  }
  let clickedObjects = ray.intersectObjects(
    labelTool.cubeArray[labelTool.currentFileIndex]
  );
  let geometry = new THREE.PlaneGeometry(2 * gridSize, 2 * gridSize);
  let material = new THREE.MeshBasicMaterial({
    color: 0x000000,
    wireframe: false,
    transparent: true,
    opacity: 0.0,
    side: THREE.DoubleSide,
  });
  let groundPlane = new THREE.Mesh(geometry, material);
  if (clickedObjects.length > 0) {
    if (ev.button === 0) {
      clickedObjectIndex = labelTool.cubeArray[
        labelTool.currentFileIndex
      ].indexOf(clickedObjects[0].object);
      clickFlag = true;
      clickedPoint = clickedObjects[0].point;
      let clickedCube =
        labelTool.cubeArray[labelTool.currentFileIndex][clickedObjectIndex];

      if (birdsEyeViewFlag === true) {
        groundPlane.position.x = clickedPoint.x;
        groundPlane.position.y = clickedPoint.y;
        groundPlane.position.z = -10; //clickedPoint.z;
        let normal = clickedObjects[0].face;
        if (
          [normal.a, normal.b, normal.c].toString() == [6, 3, 2].toString() ||
          [normal.a, normal.b, normal.c].toString() == [7, 6, 2].toString()
        ) {
          groundPlane.rotation.x = Math.PI / 2;
          groundPlane.rotation.y =
            labelTool.cubeArray[labelTool.currentFileIndex][
              clickedObjectIndex
            ].rotation.z;
        } else if (
          [normal.a, normal.b, normal.c].toString() == [6, 7, 5].toString() ||
          [normal.a, normal.b, normal.c].toString() == [4, 6, 5].toString()
        ) {
          groundPlane.rotation.x = -Math.PI / 2;
          groundPlane.rotation.y =
            -Math.PI / 2 -
            labelTool.cubeArray[labelTool.currentFileIndex][clickedObjectIndex]
              .rotation.z;
        } else if (
          [normal.a, normal.b, normal.c].toString() == [0, 2, 1].toString() ||
          [normal.a, normal.b, normal.c].toString() == [2, 3, 1].toString()
        ) {
          groundPlane.rotation.x = Math.PI / 2;
          groundPlane.rotation.y =
            Math.PI / 2 +
            labelTool.cubeArray[labelTool.currentFileIndex][clickedObjectIndex]
              .rotation.z;
        } else if (
          [normal.a, normal.b, normal.c].toString() == [5, 0, 1].toString() ||
          [normal.a, normal.b, normal.c].toString() == [4, 5, 1].toString()
        ) {
          groundPlane.rotation.x = -Math.PI / 2;
          groundPlane.rotation.y = -labelTool.cubeArray[
            labelTool.currentFileIndex
          ][clickedObjectIndex].rotation.z;
        } else if (
          [normal.a, normal.b, normal.c].toString() == [3, 6, 4].toString() ||
          [normal.a, normal.b, normal.c].toString() == [1, 3, 4].toString()
        ) {
          groundPlane.rotation.y = -Math.PI;
        }
        groundPlane.name = "planeObject";
        labelTool.scene.add(groundPlane);
        clickedPlaneArray.push(groundPlane);
      }
    } else if (ev.button === 2) {
      // rightclick
      clickedObjectIndex = labelTool.cubeArray[
        labelTool.currentFileIndex
      ].indexOf(clickedObjects[0].object);
      let bboxClass =
        annotationObjects.contents[labelTool.currentFileIndex][
          clickedObjectIndex
        ]["class"];
      let trackId =
        annotationObjects.contents[labelTool.currentFileIndex][
          clickedObjectIndex
        ]["trackId"];
      deleteObject(trackId, clickedObjectIndex);
      labelTool.isAnyChange = true;
      // move button to left
      $("#left-btn").css("left", 0);
    } //end right click
  } else {
    isDrawBox = true;
    for (
      let i = 0;
      i < annotationObjects.contents[labelTool.currentFileIndex].length;
      i++
    ) {
      $(
        "#tooltip-" +
          annotationObjects.contents[labelTool.currentFileIndex][i]["trackId"]
      ).show();
    }
    if (birdsEyeViewFlag === true) {
      clickedObjectIndex = -1;
      groundPlaneArray = [];
      groundPlane.position.x = 0;
      groundPlane.position.y = 0;
      groundPlane.position.z = -10;
      groundPlaneArray.push(groundPlane);
      let groundObject = ray.intersectObjects(groundPlaneArray);
      if (groundObject !== undefined && groundObject[0] !== undefined) {
        groundPointMouseDown = groundObject[0].point;
      }
    }
  }
}

function handleMouseDown(ev) {
  if (rendererBev === undefined) {
    mouseDownLogic(ev);
  } else {
    if (ev.target !== rendererBev.domElement) {
      mouseDownLogic(ev);
    }
  }
}

function isFullscreen() {
  return (
    Math.round(labelTool.updatedHeight * window.devicePixelRatio) ===
    screen.height
  );
}

function initViews() {
  let imagePanelTopPos;
  if (labelTool.pointCloudOnlyAnnotation === false) {
    imagePanelTopPos = parseInt($("#layout_layout_resizer_top").css("top"), 10);
  } else {
    imagePanelTopPos = 0;
  }
  let viewHeight;
  if (isFullscreen() === true) {
    viewHeight = Math.round(window.innerHeight / 3);
  } else {
    viewHeight = Math.round(window.innerHeight / 3) - 15;
  }

  views = [
    // main view
    {
      left: 0,
      top: 0,
      width: labelTool.updtedWidth,
      height: labelTool.updatedHeight,
      //background: new THREE.Color(22 / 256.0, 22 / 256.0, 22 / 256.0),
      background: new THREE.Color(1, 1, 1),
      up: [0, 1, 0],
      fov: 70,
    },
    // side view
    {
      left: 0,
      top: 0,
      width: labelTool.updtedWidth / 3,
      height: viewHeight,
      background: new THREE.Color(22 / 256.0, 22 / 256.0, 22 / 256.0),
      up: [-1, 0, 0],
      fov: 70,
      updateCamera: function(camera, scene, objectPosition) {
        camera.position.set(
          objectPosition.x + 10,
          objectPosition.y,
          objectPosition.z
        );
        camera.lookAt(objectPosition);
      },
    },
    // front view
    {
      left: 0,
      top: viewHeight,
      width: labelTool.updtedWidth / 3,
      height: viewHeight,
      background: new THREE.Color(22 / 256.0, 22 / 256.0, 22 / 256.0),
      up: [0, -1, 0],
      fov: 70,
      updateCamera: function(camera, scene, objectPosition) {
        camera.position.set(
          objectPosition.x,
          objectPosition.y + 10,
          objectPosition.z
        );
        camera.lookAt(objectPosition);
      },
    },
    // BEV
    {
      left: 0,
      top: 2 * viewHeight,
      width: labelTool.updtedWidth / 3,
      height: viewHeight,
      background: new THREE.Color(22 / 256.0, 22 / 256.0, 22 / 256.0),
      up: [1, 0, 0],
      fov: 70,
      updateCamera: function(camera, scene, objectPosition) {
        camera.position.set(
          objectPosition.x,
          objectPosition.y,
          objectPosition.z + 10
        );
        camera.lookAt(objectPosition);
      },
    },
  ];

  $("#canvasSideView").css("height", viewHeight);
  $("#canvasSideView").css("top", pcd_param.headerHeight + imagePanelTopPos);
  $("#canvasFrontView").css("height", viewHeight);
  $("#canvasFrontView").css(
    "top",
    pcd_param.headerHeight + imagePanelTopPos + viewHeight
  );
  $("#canvasBev").css("height", viewHeight);
  $("#canvasBev").css(
    "top",
    pcd_param.headerHeight + imagePanelTopPos + 2 * viewHeight
  );

  let mainView = views[0];
  let mainCamera = new THREE.PerspectiveCamera(
    70,
    labelTool.updtedWidth / labelTool.updatedHeight,
    1,
    3000
  );
  mainCamera.position.set(10, 10, 10); //default
  mainCamera.up.fromArray(mainView.up);
  mainView.camera = mainCamera;
  for (let i = 1; i < views.length; i++) {
    let view = views[i];
    let top = 5;
    let bottom = -5;
    let aspectRatio = view.width / view.height;
    let left = bottom * aspectRatio;
    let right = top * aspectRatio;
    let camera = new THREE.OrthographicCamera(
      left,
      right,
      top,
      bottom,
      0.001,
      2000
    );
    camera.position.set(0, 0, 0); //default
    camera.up.fromArray(view.up);
    view.camera = camera;
  }
}

// function disableInterpolationModeCheckbox(interpolationModeCheckbox) {
//     interpolationModeCheckbox.parentElement.parentElement.style.opacity = 0.5;
//     interpolationModeCheckbox.parentElement.parentElement.style.pointerEvents = "none";
//     interpolationModeCheckbox.firstChild.setAttribute("tabIndex", "-1");
// }

function disableCopyLabelToNextFrameCheckbox(copyLabelToNextFrameCheckbox) {
  copyLabelToNextFrameCheckbox.parentElement.parentElement.style.opacity = 0.5;
  copyLabelToNextFrameCheckbox.parentElement.parentElement.style.pointerEvents =
    "none";
  copyLabelToNextFrameCheckbox.firstChild.setAttribute("tabIndex", "-1");
}

function enableCopyLabelToNextFrameCheckbox(copyLabelToNextFrameCheckbox) {
  copyLabelToNextFrameCheckbox.parentElement.parentElement.style.opacity = 1.0;
  copyLabelToNextFrameCheckbox.parentElement.parentElement.style.pointerEvents =
    "all";
  $(copyLabelToNextFrameCheckbox.firstChild).removeAttr("tabIndex");
}

// function disableInterpolationBtn() {
//     interpolateBtn.domElement.parentElement.parentElement.style.pointerEvents = "none";
//     interpolateBtn.domElement.parentElement.parentElement.style.opacity = 0.5;
//     interpolateBtn.domElement.firstChild.setAttribute("tabIndex", "-1");
// }

// function enablePointSizeSlider() {
//     pointSizeSlider.domElement.parentElement.parentElement.style.pointerEvents = "all";
//     pointSizeSlider.domElement.parentElement.parentElement.style.opacity = 1.0;
// }

// function disablePointSizeSlider() {
//     pointSizeSlider.domElement.parentElement.parentElement.style.pointerEvents = "none";
//     pointSizeSlider.domElement.parentElement.parentElement.style.opacity = 0.5;
// }

function disableShowNuscenesLabelsCheckbox(showNuScenesLabelsCheckbox) {
  showNuScenesLabelsCheckbox.parentElement.parentElement.parentElement.style.pointerEvents =
    "none";
  showNuScenesLabelsCheckbox.parentElement.parentElement.parentElement.style.opacity = 0.5;
  showNuScenesLabelsCheckbox.tabIndex = -1;
}

function enableShowNuscenesLabelsCheckbox(showNuScenesLabelsCheckbox) {
  showNuScenesLabelsCheckbox.parentElement.parentElement.parentElement.style.pointerEvents =
    "all";
  showNuScenesLabelsCheckbox.parentElement.parentElement.parentElement.style.opacity = 1.0;
  $(showNuScenesLabelsCheckbox.firstChild).removeAttr("tabIndex");
}

function enableChooseSequenceDropDown(chooseSequenceDropDown) {
  chooseSequenceDropDown.parentElement.parentElement.parentElement.style.pointerEvents =
    "all";
  chooseSequenceDropDown.parentElement.parentElement.parentElement.style.opacity = 1.0;
  $(chooseSequenceDropDown.firstChild).removeAttr("tabIndex");
}

function disableChooseSequenceDropDown(chooseSequenceDropDown) {
  chooseSequenceDropDown.parentElement.parentElement.style.pointerEvents =
    "none";
  chooseSequenceDropDown.parentElement.parentElement.style.opacity = 0.5;
  chooseSequenceDropDown.tabIndex = -1;
}

function createGrid() {
  removeObject("grid");
  grid = new THREE.GridHelper(gridSize, gridSize);
  let posZLidar;
  let translationX;
  if (labelTool.currentDataset === labelTool.datasets.NuScenes) {
    posZLidar = labelTool.positionLidarNuscenes[2];
    translationX = 0;
  } else {
    posZLidar = labelTool.positionLidar[2];
    translationX = gridSize / 2;
  }
  grid.translateZ(-posZLidar);
  grid.translateX(translationX);
  grid.rotateX(Math.PI / 2);
  grid.name = "grid";
  if (showGridFlag === true) {
    grid.visible = true;
  } else {
    grid.visible = false;
  }
  labelTool.scene.add(grid);
}

function toggleKeyboardNavigation() {
  keyboardNavigation = !keyboardNavigation;
  if (keyboardNavigation === true) {
    setPointerLockControls();
  } else {
    setOrbitControls();
  }
}

function canvas3DKeyDownHandler(event) {
  switch (event.keyCode) {
    case 75: //K
      toggleKeyboardNavigation();
      break;
  }
}

function loadDetectedBoxes() {
  let rawFile = new XMLHttpRequest();
  try {
    rawFile.open(
      "GET",
      "static/input/" +
        labelTool.currentDataset +
        "/" +
        labelTool.sequence +
        "/detections/detections_lidar.json",
      false
    );
  } catch (error) {}

  rawFile.onreadystatechange = function() {
    if (rawFile.readyState === 4) {
      if (rawFile.status === 200 || rawFile.status === 0) {
        let allText = rawFile.responseText;
        let allLines = allText.replace(/"/g, "").split("\n");
        let objectIndexWithinFrame = 0;
        let frameNumber = 1;
        let frameNumberPrevious = -1;
        for (let i = 0; i < allLines.length; i++) {
          let line = allLines[i];
          if (line === "") {
            continue;
          }
          let params = labelTool.getDefaultObject();
          let attributes = line.split(",");
          frameNumber = parseFloat(attributes[0].trim().split(" ")[1]);
          if (frameNumber === frameNumberPrevious) {
            objectIndexWithinFrame = objectIndexWithinFrame + 1;
          } else {
            objectIndexWithinFrame = 0;
          }
          frameNumberPrevious = frameNumber;
          params.x = parseFloat(attributes[1].trim().split(" ")[2]);
          params.y = parseFloat(attributes[2].trim().split(" ")[2]);
          params.z = parseFloat(attributes[3].trim().split(" ")[2]);
          params.original.x = params.x;
          params.original.y = params.y;
          params.original.z = params.z;
          let tmpLength = parseFloat(attributes[4].trim().split(" ")[2]);
          let tmpWidth = parseFloat(attributes[5].trim().split(" ")[2]);
          let tmpHeight = parseFloat(attributes[6].trim().split(" ")[2]);
          let rotationYaw = parseFloat(attributes[7].trim().split(" ")[1]);
          let rotationPitch = parseFloat(attributes[8].trim().split(" ")[1]);
          let rotationRoll = parseFloat(attributes[9].trim().split(" ")[1]);
          params.class = "vehicle";
          params.rotationYaw = rotationYaw;
          params.rotationPitch = rotationPitch;
          params.rotationRoll = rotationRoll;
          params.original.rotationYaw = rotationYaw;
          params.original.rotationPitch = rotationPitch;
          params.original.rotationRoll = rotationRoll;
          params.trackId = objectIndexWithinFrame + 1;
          if (tmpWidth !== 0.0 && tmpLength !== 0.0 && tmpHeight !== 0.0) {
            tmpWidth = Math.max(tmpWidth, 0.0001);
            tmpLength = Math.max(tmpLength, 0.0001);
            tmpHeight = Math.max(tmpHeight, 0.0001);
            params.width = tmpWidth;
            params.length = tmpLength;
            params.height = tmpHeight;
            params.original.width = tmpWidth;
            params.original.length = tmpLength;
            params.original.height = tmpHeight;
          }
          params.fileIndex = frameNumber - 1;
          annotationObjects.set(objectIndexWithinFrame, params);
          classesBoundingBox.getCurrentAnnotationClassObject().nextTrackId++;
        }
      }
    }
  };
  rawFile.send(null);
}

function initGuiBoundingBoxAnnotations() {
  let parametersBoundingBox = {};
  for (let i = 0; i < labelTool.classes.length; i++) {
    parametersBoundingBox[labelTool.classes[i]] = function() {
      classesBoundingBox.select(labelTool.classes[i]);
      $("#class-picker ul li").css("background-color", "#323232");
      $($("#class-picker ul li")[i]).css("background-color", "#525252");
    };
  }
  let guiAnnotationClassesWidth;
  if (labelTool.currentDataset === labelTool.datasets.NuScenes) {
    guiAnnotationClassesWidth = 220;
  } else {
    guiAnnotationClassesWidth = 90;
  }
  guiAnnotationClasses = new dat.GUI({
    autoPlace: true,
    width: guiAnnotationClassesWidth,
    resizable: false,
  });

  let guiBoundingBoxAnnotationMap = {};
  for (let i = 0; i < labelTool.classes.length; i++) {
    guiBoundingBoxAnnotationMap[
      labelTool.classes[i]
    ] = guiAnnotationClasses
      .add(parametersBoundingBox, labelTool.classes[i])
      .name(labelTool.classes[i]);
  }
  guiAnnotationClasses.domElement.id = "class-picker";
}

export function showPcdViews(selectedView) {
  labelTool.selectedPcdView = selectedView;
  if (transformControls !== undefined) {
    labelTool.selectedMesh = undefined;
    transformControls.detach();
    transformControls = undefined;
    hideMasterView();
  }
  if (labelTool.selectedPcdView === labelTool.views.orthographic) {
    birdsEyeViewFlag = true;
    // enablePointSizeSlider();
    setOrthographicView();
  } else {
    birdsEyeViewFlag = false;
    // enablePointSizeSlider();
    setPerspectiveView();
  }
  if (keyboardNavigation === false) {
    currentOrbitControls.update();
  }
  removeObject("planeObject");
  labelTool.scene.remove("pointcloud-scan-" + labelTool.currentFileIndex);
  labelTool.scene.add(pcd_param.pointCloudScanMap[labelTool.currentFileIndex]);
}

export function init() {
  if (WEBGL.isWebGLAvailable() === false) {
    document.body.appendChild(WEBGL.getWebGLErrorMessage());
  }
  keyboard = new KeyboardState();
  clock = new THREE.Clock();
  labelTool.scene = new THREE.Scene();
  labelTool.scene.background = new THREE.Color(0x323232);

  labelTool.scene.fog = new THREE.Fog(labelTool.scene.background, 3500, 15000);

  let axisHelper = new THREE.AxisHelper(1);
  axisHelper.position.set(0, 0, 0);
  labelTool.scene.add(axisHelper);

  let light = new THREE.DirectionalLight(0xffffff, 0.7);
  light.position.set(0, 0, 6).normalize();
  labelTool.scene.add(light);

  canvas3D = document.getElementById("canvas3d");
  if (Editor3DModel.isSaving === true) {
    location.reload();
    Editor3DModel.isSaving = false;
  }

  if (birdsEyeViewFlag === false) {
    canvas3D.removeEventListener("keydown", canvas3DKeyDownHandler);
    canvas3D.addEventListener("keydown", canvas3DKeyDownHandler);
  }

  window.removeEventListener("keydown", keyDownHandler);
  window.addEventListener("keydown", keyDownHandler);

  pcd_param.renderer = new THREE.WebGLRenderer({
    antialias: true,
    clearColor: 0x000000,
    clearAlpha: 0,
    alpha: true,
    preserveDrawingBuffer: true,
  });
  // renderer.setPixelRatio(window.devicePixelRatio);
  pcd_param.renderer.setSize(labelTool.updtedWidth, labelTool.updatedHeight);

  setCamera();
  createGrid();

  if ($("#canvas3d").children().length > 0) {
    $($("#canvas3d").children()[0]).remove();
  }
  canvas3D.appendChild(pcd_param.renderer.domElement);

  // stats = new Stats();
  // canvas3D.appendChild(stats.dom);
  window.addEventListener("resize", onWindowResize, false);
  window.addEventListener(
    "contextmenu",
    function(e) {
      e.preventDefault();
    },
    false
  );

  projector = new THREE.Projector();
  canvas3D.addEventListener("mousemove", onDocumentMouseMove, false);

  canvas3D.onmousedown = function(ev) {
    handleMouseDown(ev);
  };

  canvas3D.onmouseup = function(ev) {
    handleMouseUp(ev);
  };

  labelTool.cubeArray = [];
  labelTool.spriteArray = [];
  labelTool.savedFrames = [];
  annotationObjects.contents = [];
  for (let i = 0; i < labelTool.numFrames; i++) {
    labelTool.cubeArray.push([]);
    labelTool.spriteArray.push([]);
    labelTool.savedFrames.push([]);
    annotationObjects.contents.push([]);
  }

  if (guiBoundingBoxAnnotationsInitialized === false) {
    guiBoundingBoxAnnotationsInitialized = true;
    // initGuiBoundingBoxAnnotations();
  }

  if (guiBoundingBoxMenuInitialized === false) {
    guiBoundingBoxMenuInitialized = true;
    // 3D BB controls
    // annotationObjects.guiOptions.add(parameters, 'download').name("Download Annotations");
    // annotationObjects.guiOptions.add(parameters, 'download_video').name("Create and Download Video");
    // annotationObjects.guiOptions.add(parameters, 'undo').name("Undo");

    // disablePointSizeSlider();
    // let showOriginalNuScenesLabelsCheckbox = annotationObjects.guiOptions.add(parameters, 'show_nuscenes_labels').name('NuScenes Labels').listen();
    // showOriginalNuScenesLabelsCheckbox.onChange(function (value) {
    //     labelTool.showOriginalNuScenesLabels = value;
    //     if (labelTool.showOriginalNuScenesLabels === true) {
    //         // TODO: improve:
    //         // - do not reset
    //         // - show current labels and in addition nuscenes labels
    //         labelTool.reset();
    //         labelTool.start();
    //     } else {
    //         // TODO: hide nuscenes labels (do not reset)
    //         labelTool.reset();
    //         labelTool.start();
    //     }
    // });
    // let allCheckboxes = $(":checkbox");
    // let showNuScenesLabelsCheckbox = allCheckboxes[0];
    // if (labelTool.currentDataset === labelTool.datasets.NuScenes) {
    //     enableShowNuscenesLabelsCheckbox(showNuScenesLabelsCheckbox);
    // }

    // let chooseSequenceDropDownController;
    // let currentDatasetDropDownController = annotationObjects.guiOptions.add(labelTool, 'currentDataset', labelTool.datasetArray).name("Choose dataset")
    //     .onChange(function (value) {
    //         changeDataset(value);
    //         chooseSequenceDropDownController = chooseSequenceDropDownController.options(labelTool.dataStructure.datasets[labelTool.currentDatasetIdx].sequences);
    //         let allCheckboxes = $(":checkbox");
    //         let showNuScenesLabelsCheckbox = allCheckboxes[0];
    //         if (value === labelTool.datasets.NuScenes) {
    //             enableShowNuscenesLabelsCheckbox(showNuScenesLabelsCheckbox);
    //         }
    //         hideMasterView();
    //     });

    // chooseSequenceDropDownController = annotationObjects.guiOptions.add(labelTool, 'sequence', labelTool.dataStructure.datasets[labelTool.currentDatasetIdx].sequences).name("Choose Sequence")
    //     .onChange(function (value) {
    //         changeSequence(value);
    //         hideMasterView();
    //     });

    // if (labelTool.pointCloudOnlyAnnotation === false) {
    //     let showProjectedPointsCheckbox = annotationObjects.guiOptions.add(parameters, 'show_projected_points').name('Show projected points').listen();
    //     showProjectedPointsCheckbox.onChange(function (value) {
    //         showProjectedPointsFlag = value;
    //         if (showProjectedPointsFlag === true) {
    //             showProjectedPoints();
    //         } else {
    //             hideProjectedPoints();
    //         }
    //     });
    // }

    // let hideOtherAnnotationsCheckbox = annotationObjects.guiOptions.add(parameters, 'hide_other_annotations').name('Hide other annotations').listen();
    // hideOtherAnnotationsCheckbox.onChange(function (value) {
    //     hideOtherAnnotations = value;
    //     let selectionIndex = annotationObjects.getSelectionIndex();
    //     if (hideOtherAnnotations === true) {
    //         for (let i = 0; i < annotationObjects.contents[labelTool.currentFileIndex].length; i++) {
    //             // remove 3D labels
    //             let mesh = labelTool.cubeArray[labelTool.currentFileIndex][i];
    //             if (Array.isArray(mesh.material)) {
    //                 for (let i = 0; i < mesh.material.length; i++) {
    //                     mesh.material[i].opacity = 0;
    //                 }
    //             } else {
    //                 mesh.material.opacity = 0;
    //             }

    //             if (labelTool.pointCloudOnlyAnnotation === false) {
    //                 // remove all 2D labels
    //                 for (let j = 0; j < annotationObjects.contents[labelTool.currentFileIndex][i].channels.length; j++) {
    //                     let channelObj = annotationObjects.contents[labelTool.currentFileIndex][i].channels[j];
    //                     // remove drawn lines of all 6 channels
    //                     for (let lineObj in channelObj.lines) {
    //                         if (channelObj.lines.hasOwnProperty(lineObj)) {
    //                             let line = channelObj.lines[lineObj];
    //                             if (line !== undefined) {
    //                                 line.remove();
    //                             }
    //                         }
    //                     }
    //                 }
    //             }
    //         }
    //         if (labelTool.pointCloudOnlyAnnotation === false) {
    //             if (selectionIndex !== -1) {
    //                 // draw selected object in 2D and 3D
    //                 annotationObjects.update2DBoundingBox(labelTool.currentFileIndex, selectionIndex, true);
    //             }
    //         }
    //     } else {
    //         for (let i = 0; i < annotationObjects.contents[labelTool.currentFileIndex].length; i++) {
    //             // show 3D labels
    //             let mesh = labelTool.cubeArray[labelTool.currentFileIndex][i];
    //             if (Array.isArray(mesh.material)) {
    //                 for (let i = 0; i < mesh.material.length; i++) {
    //                     if (i === 0) {
    //                         mesh.material[i].opacity = 0.9;
    //                     } else {
    //                         mesh.material[i].opacity = 0.1;
    //                     }
    //                 }
    //             } else {
    //                 mesh.material.opacity = 0.9;
    //             }

    //             if (labelTool.pointCloudOnlyAnnotation === false) {
    //                 // show 2D labels
    //                 if (selectionIndex === i) {
    //                     // draw selected object in 2D and 3D
    //                     annotationObjects.update2DBoundingBox(labelTool.currentFileIndex, selectionIndex, true);
    //                 } else {
    //                     if (selectionIndex !== -1) {
    //                         annotationObjects.update2DBoundingBox(labelTool.currentFileIndex, i, false);
    //                     }
    //                 }
    //             }

    //         }
    //     }

    // });

    // annotationObjects.guiOptions.add(parameters, 'select_all_copy_label_to_next_frame').name("Select all 'Copy label to next frame'");
    // annotationObjects.guiOptions.add(parameters, 'unselect_all_copy_label_to_next_frame').name("Unselect all 'Copy label to next frame'");

    // let interpolationModeCheckbox = annotationObjects.guiOptions.add(parameters, 'interpolation_mode').name('Interpolation Mode');
    // interpolationModeCheckbox.domElement.id = 'interpolation-checkbox';
    // // if scene contains no objects then deactivate checkbox
    // // if (annotationFileExist(0, undefined) === false || annotationObjects.interpolationMode === false) {
    // //     // no annotation file exist -> deactivate checkbox
    // //     disableInterpolationModeCheckbox(interpolationModeCheckbox.domElement);
    // // }

    // interpolationModeCheckbox.onChange(function (value) {
    //     annotationObjects.interpolationMode = value;
    //     if (annotationObjects.interpolationMode === true) {
    //         console.log("INN IFFFFFFFFFFFFFF")
    //         labelTool.interpolationObjIndexCurrentFile = annotationObjects.getSelectionIndex();
    //         if (labelTool.interpolationObjIndexCurrentFile !== -1) {
    //             // set interpolation start position
    //             let obj = annotationObjects.contents[labelTool.currentFileIndex][labelTool.interpolationObjIndexCurrentFile];
    //             obj["interpolationStart"]["position"]["x"] = obj["x"];
    //             obj["interpolationStart"]["position"]["y"] = obj["y"];
    //             obj["interpolationStart"]["position"]["z"] = obj["z"];
    //             obj["interpolationStart"]["position"]["rotationYaw"] = obj["rotationYaw"];
    //             obj["interpolationStart"]["position"]["rotationPitch"] = obj["rotationPitch"];
    //             obj["interpolationStart"]["position"]["rotationRoll"] = obj["rotationRoll"];
    //             obj["interpolationStart"]["size"]["width"] = obj["width"];
    //             obj["interpolationStart"]["size"]["length"] = obj["length"];
    //             obj["interpolationStart"]["size"]["height"] = obj["height"];
    //             // short interpolation start index (Interpolation Start Position (frame 400)
    //             annotationObjects.folderPositionArray[labelTool.interpolationObjIndexCurrentFile].domElement.firstChild.firstChild.innerText = "Interpolation Start Position (frame " + (labelTool.currentFileIndex + 1) + ")";
    //             annotationObjects.folderRotationArray[labelTool.interpolationObjIndexCurrentFile].domElement.firstChild.firstChild.innerText = "Interpolation Start Rotation (frame " + (labelTool.currentFileIndex + 1) + ")";
    //             annotationObjects.folderSizeArray[labelTool.interpolationObjIndexCurrentFile].domElement.firstChild.firstChild.innerText = "Interpolation Start Size (frame " + (labelTool.currentFileIndex + 1) + ")";
    //             // set start index
    //             annotationObjects.contents[labelTool.currentFileIndex][labelTool.interpolationObjIndexCurrentFile]["interpolationStartFileIndex"] = labelTool.currentFileIndex;
    //         }
    //         // check 'copy label to next frame' of selected object
    //         annotationObjects.contents[labelTool.currentFileIndex][labelTool.interpolationObjIndexCurrentFile]["copyLabelToNextFrame"] = true;
    //         let checkboxElem = document.getElementById("copy-label-to-next-frame-checkbox-" + labelTool.interpolationObjIndexCurrentFile);
    //         checkboxElem.firstChild.checked = true;
    //         // disable checkbox
    //         disableCopyLabelToNextFrameCheckbox(checkboxElem);
    //     } else {
    //         console.log("IN ELSEEEEEEEEEEEEEEEE")
    //         disableInterpolationBtn();
    //         if (labelTool.interpolationObjIndexCurrentFile !== -1) {
    //             annotationObjects.folderPositionArray[labelTool.interpolationObjIndexCurrentFile].domElement.firstChild.firstChild.innerText = "Position";
    //             annotationObjects.folderRotationArray[labelTool.interpolationObjIndexCurrentFile].domElement.firstChild.firstChild.innerText = "Rotation";
    //             annotationObjects.folderSizeArray[labelTool.interpolationObjIndexCurrentFile].domElement.firstChild.firstChild.innerText = "Size";
    //             enableStartPose();
    //             //[1].__folders[""Interpolation End Position (frame 1)""]
    //             for (let i = 0; i < annotationObjects.folderBoundingBox3DArray.length; i++) {
    //                 // get all keys of folders object
    //                 let keys = Object.keys(annotationObjects.folderBoundingBox3DArray[i].__folders);
    //                 for (let j = 0; j < keys.length; j++) {
    //                     if (keys[j].startsWith("Interpolation End")) {
    //                         annotationObjects.folderBoundingBox3DArray[i].removeFolder(keys[j]);
    //                     }
    //                 }
    //             }
    //             // enable checkbox
    //             let checkboxElem = document.getElementById("copy-label-to-next-frame-checkbox-" + labelTool.interpolationObjIndexCurrentFile);
    //             enableCopyLabelToNextFrameCheckbox(checkboxElem);
    //         }
    //         labelTool.interpolationObjIndexCurrentFile = -1;

    //     }
    // });
    // interpolateBtn = annotationObjects.guiOptions.add(parameters, 'interpolate').name("Interpolate");
    // interpolateBtn.domElement.id = 'interpolate-btn';
    // disableInterpolationBtn();

    // annotationObjects.guiOptions.domElement.id = 'bounding-box-3d-menu';
    // // add download Annotations button
    // let downloadAnnotationsItem = $($('#bounding-box-3d-menu ul li')[0]);
    // let downloadAnnotationsDivItem = downloadAnnotationsItem.children().first();
    // downloadAnnotationsDivItem.wrap("<a href=\"\"></a>");
    loadColorMap();
    if (labelTool.pointCloudOnlyAnnotation === false) {
      if (showProjectedPointsFlag === true) {
        showProjectedPoints();
      } else {
        hideProjectedPoints();
      }
    }
  } // end if guiBoundingBoxMenuInitialized

  let classPickerElem = $("#class-picker ul li");
  classPickerElem.css("background-color", "#353535");
  $(classPickerElem[0]).css("background-color", "#525252");
  classPickerElem.css("border-bottom", "0px");
  if (labelTool.currentDataset === labelTool.datasets.NuScenes) {
    $("#class-picker").css("width", "220px");
  }
  // $('#bounding-box-3d-menu').css('width', '480px');
  // $('#bounding-box-3d-menu ul li').css('background-color', '#353535');
  // $("#bounding-box-3d-menu .close-button").click(function () {
  //     guiOptionsOpened = !guiOptionsOpened;
  //     if (guiOptionsOpened === true) {
  //         $("#right-btn").css("right", 500);
  //     } else {
  //         $("#right-btn").css("right", 0);
  //     }
  // });
  // annotationObjects.guiOptions.open();
  classPickerElem.each(function(i, item) {
    let color = labelTool.classColors[i];
    let attribute = "20px solid" + " " + color;
    $(item).css("border-left", attribute);
    $(item).css("border-bottom", "0px");
  });
  initViews();
}
