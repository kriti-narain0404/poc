function keyUpHandler(event) {
    switch (event.keyCode) {
        case 17: // Ctrl
            transformControls.setTranslationSnap(null);
            transformControls.setRotationSnap(null);
            break;
    }
}

function keyDownHandler(event) {
    if (labelTool.selectedMesh !== undefined) {
        switch (event.keyCode) {
            case 17: // Ctrl
                transformControls.setTranslationSnap(0.5);
                if (transformControls.getMode() === "rotate") {
                    let newRotation = Math.ceil(labelTool.selectedMesh.rotation.z / THREE.Math.degToRad(15));
                    let lowerBound = newRotation * 15;
                    if (labelTool.selectedMesh.rotation.z - lowerBound < THREE.Math.degToRad(15) / 2) {
                        // rotate to lower bound
                        labelTool.selectedMesh.rotation.z = lowerBound;
                    } else {
                        // rotate to upper bound
                        labelTool.selectedMesh.rotation.z = lowerBound + THREE.Math.degToRad(15);
                    }
                }

                transformControls.setRotationSnap(THREE.Math.degToRad(15));
                break;
            case 27: // Esc- remove incomplete bbox
                let classPopup = document.getElementById('set');
                let boxIndex = annotationObjects.contents[labelTool.currentFileIndex].insertIndex;
                if (classPopup.style.display === "block") {
                    let trackId = annotationObjects.contents[labelTool.currentFileIndex][boxIndex]["trackId"];
                    deleteObject(trackId, boxIndex);
                    classPopup.style.display = "none";
                    labelTool.isAnyChange = false;
                }
                break;
            case 73: //I
                if (annotationObjects.getSelectionIndex() !== -1) {
                    if (annotationObjects.interpolationMode === true) {
                        if (annotationObjects.contents[labelTool.currentFileIndex][annotationObjects.getSelectionIndex()]["interpolationStartFileIndex"] !== labelTool.currentFileIndex) {
                            interpolate();
                        } else {
                            labelTool.logger.message("Please choose end frame.");
                        }
                    } else {
                        labelTool.logger.message("Please activate interpolation mode first.");
                    }
                } else {
                    labelTool.logger.message("Please select an object first.");
                }
            case 82: // R
                transformControls.setMode("rotate");
                transformControls.showX = false;
                transformControls.showY = false;
                transformControls.showZ = true;
                // enable gizmo
                transformControls.children[0].enabled = true;
                // disable planes (translation, scaling)
                transformControls.children[1].enabled = false;
                break;
            case 83: // S
                transformControls.setMode("scale");
                transformControls.showX = true;
                transformControls.showY = true;
                if (birdsEyeViewFlag === true) {
                    transformControls.showZ = true;
                } else {
                    transformControls.showZ = false;
                }
                // enable planes (translation, scaling)
                transformControls.children[1].enabled = false;
                break;
            case 84: // T
                transformControls.setMode("translate");
                transformControls.showX = true;
                transformControls.showY = true;
                if (birdsEyeViewFlag === true) {
                    transformControls.showZ = true;
                } else {
                    transformControls.showZ = false;
                }
                // enable planes (translation, scaling)
                transformControls.children[1].enabled = false;
                break;
            case 88: // X
                transformControls.showX = !transformControls.showX;
                break;
            case 89: // Y
                transformControls.showY = !transformControls.showY;
                break;
            case 90: // Z
                // only allow to switch z axis in 3d view
                if (birdsEyeViewFlag === false) {
                    transformControls.showZ = !transformControls.showZ;
                } else {
                    labelTool.logger.message("Show/Hide z-axis only in 3D view possible.");
                }
                break;
            case 187:
            case 107: // +, =, num+
                transformControls.setSize(Math.min(transformControls.size + 0.1, 10));
                break;
            case 189:
            case 109: // -, _, num-
                transformControls.setSize(Math.max(transformControls.size - 0.1, 0.1));
                break;
        }
    }

    switch (event.keyCode) {
        case 67: // C
            switchView();
            break;
        case 75: //K
            toggleKeyboardNavigation();
            break;
        case 32: // Spacebar
            // play video sequence from current frame on to end
            labelTool.playSequence = !labelTool.playSequence;
            if (labelTool.playSequence === true) {
                initPlayTimer();
            }
            break;
        case 78:// N
            // next frame
            baseLabelTool.nextFrame();
            break;
        case 80:// P
            // previous frame
            baseLabelTool.previousFrame();
            break;
    }


}

function setOrbitControls() {
    document.removeEventListener('keydown', onKeyDown, false);
    document.removeEventListener('keyup', onKeyUp, false);
    labelTool.scene.remove(pointerLockObject);


    pcd_param.currentCamera = new THREE.PerspectiveCamera(70, labelTool.updtedWidth / labelTool.updatedHeight, 1, 3000);
    pcd_param.currentCamera.position.set(0, 0, 5);
    pcd_param.currentCamera.up.set(0, 0, 1);

    currentOrbitControls = new THREE.OrbitControls(pcd_param.currentCamera, pcd_param.renderer.domElement);
    currentOrbitControls.enablePan = true;
    currentOrbitControls.enableRotate = true;
    currentOrbitControls.autoRotate = false;// true for demo
    currentOrbitControls.enableKeys = false;
    currentOrbitControls.maxPolarAngle = Math.PI / 2;
}

function onKeyDown(event) {
    switch (event.keyCode) {
        case 38: // up
            rotateUp = true;
            break;
        case 69: //E
            moveUp = true;
            break;
        case 81: //Q
            moveDown = true;
            break;
        case 87: // w
            moveForward = true;
            break;
        case 37: // left
            rotateLeft = true;
            break;
        case 65: // a
            moveLeft = true;
            break;
        case 40: // down
            rotateDown = true;
            break;
        case 83: // s
            moveBackward = true;
            break;
        case 39: // right
            rotateRight = true;
            break;
        case 68: // d
            moveRight = true;
            break;
    }
}

function onKeyUp(event) {
    switch (event.keyCode) {
        case 38: // up
            rotateUp = false;
            break;
        case 69: // E
            moveUp = false;
            break;
        case 81: //Q
            moveDown = false;
            break;
        case 87: // w
            moveForward = false;
            break;
        case 37: // left
            rotateLeft = false;
            break;
        case 65: // a
            moveLeft = false;
            break;
        case 40: // down
            rotateDown = false;
            break;
        case 83: // s
            moveBackward = false;
            break;
        case 39: // right
            rotateRight = false;
            break;
        case 68: // d
            moveRight = false;
            break;
    }
}