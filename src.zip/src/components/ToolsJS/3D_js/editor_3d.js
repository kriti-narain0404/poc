import Appfooter from "../../../shared/Appfooter.vue";
import HomeHeader from "../../../shared/HomeHeader.vue";
import Editor3DModel from "../../../model/Editor3DModel.js";
import baseLabelTool from "./base_label_tool.js";
import SettingService from "../../../services/SettingService.js";
import {
  LOAD_JSON_CONFIG_MUTATION,
  UI_VIEWER_MUTATION,
  SAVE_JSON_DATA_MUTATION,
  GET_SETTING_OBJ_DATA,
} from "../../../constants/graphql";
import { annotationObjects } from "./util/boundingbox.js";
import { hideMasterView, renderViews } from "../3D_js/pcd_label_tool";
import { init, storeCurrChannel } from "./pcd_label_tool.js";

let width = 640;
let height = 480;

export default {
  name: "Editor_3d",
  props: [],
  data: {
    test_data: [],
  },
  components: {
    Appfooter,
    "home-header": HomeHeader, // import header component
  },
  data() {
    return Editor3DModel; // Moved to model Editor3DModel
  },
  apollo: {
    getSettingObject: {
      // fetch setting
      query: GET_SETTING_OBJ_DATA,
      variables() {
        const userid = SettingService.getSelectedUserId();
        const projectId = SettingService.getSelectedProject();
        const fromFile = 0;
        const video_id = -1;
        return {
          userid,
          projectId,
          fromFile,
          video_id,
        };
      },
      result({ data }) {
        if (data.getSettingObject != null) {
          var settingData = [];
          settingData = JSON.parse(data.getSettingObject.settingObject);
          try {
            let paramObj = [];
            this.classObj = [];
            let subclassObj = [];
            let classObjNames = [];
            let cnt = 0;
            let paramCnt = 0;
            if (settingData != null) {
              for (var i = 0; i < settingData.length; i++) {
                if (settingData[i].selected === true) {
                  this.classObj.push({
                    id: settingData[i].id,
                    name: settingData[i].name,
                    selected: settingData[i].selected,
                    type: settingData[i].type,
                    color: settingData[i].color,
                    length: settingData[i].length,
                  });
                  classObjNames.push(settingData[i].name);
                  if (settingData[i].parameters) {
                    for (var j = 0; j < settingData[i].parameters.length; j++) {
                      if (settingData[i].parameters[j].selected === true) {
                        paramObj.push({
                          id: settingData[i].parameters[j].id,
                          name: settingData[i].parameters[j].name,
                          selected: settingData[i].parameters[j].selected,
                          type: settingData[i].parameters[j].type,
                          color: settingData[i].parameters[j].color,
                          paralength: settingData[i].parameters[j].length,
                        });
                        this.classObj[cnt]["param"] = paramObj;
                        if (
                          settingData[i].parameters[j].subClass &&
                          settingData[i].parameters[j].subClass !== undefined
                        ) {
                          for (
                            var k = 0;
                            k < settingData[i].parameters[j].subClass.length;
                            k++
                          ) {
                            if (
                              settingData[i].parameters[j].subClass[k]
                                .selected === true
                            ) {
                              subclassObj.push({
                                id: settingData[i].parameters[j].subClass[k].id,
                                name:
                                  settingData[i].parameters[j].subClass[k].name,
                                selected:
                                  settingData[i].parameters[j].subClass[k]
                                    .selected,
                                type:
                                  settingData[i].parameters[j].subClass[k].type,
                                color:
                                  settingData[i].parameters[j].subClass[k]
                                    .color,
                                paralength:
                                  settingData[i].parameters[j].subClass[k]
                                    .length,
                              });
                              this.classObj[cnt].param[paramCnt][
                                "subClass"
                              ] = subclassObj;
                            }
                          }
                          subclassObj = [];
                        }
                        paramCnt = paramCnt + 1;
                      }
                    }
                    paramObj = [];
                    paramCnt = 0;
                  }
                  cnt = cnt + 1;
                }
              }
            }
            this.removeActiveToolEffect("annotation-tool");
            this.addActiveToolEffect("ortho-view-tool");
          } catch (error) {
            console.log("Error:", error);
          }
        }
        baseLabelTool.loadSettingsData(data.getSettingObject);
      },
    },
  },
  methods: {
    updateChangesInfo: function() {
      // inform anychange in the pointCloud
      this.isCoordinatesListOpen = false;
      if (baseLabelTool.isFrameModified() == true) {
        this.isAnychange = true;
      }
    },

    navigateScreen: function(link) {
      // to navigate from 3d
      this.updateChangesInfo();
      if (this.isAnychange == false) {
        baseLabelTool.cleanView(); // clean active gui design views
        this.$router.push({ path: link });
      } else {
        this.showDialog = true;
      }
    },

    setClass: function() {
      // set selected class of annotated box
      try {
        let classPopup = document.getElementById("set");
        if (classPopup.style.display === "block") {
          classPopup.style.display = "none";
          baseLabelTool.selectedClass(this.radioSelect);
          this.isAnychange = true;
        }
        this.setAnnoLabel();
      } catch (error) {
        console.log("Error:", error);
      }
    },
    setAnnoLabel: function() {
      // add/update annotated box info in label-list
      try {
        let bbox3d = baseLabelTool.updateLabelList();
        let paramValueArray = [];
        if (bbox3d !== {}) {
          let paramArray = [];
          let classIndex = this.classObj
            .map(function(o) {
              return o.name.toLowerCase();
            })
            .indexOf(bbox3d.class.toLowerCase());
          if (bbox3d.class == this.classObj[classIndex].name) {
            paramArray.push({
              nam: this.classObj[classIndex].param[0].name,
              val: bbox3d.annoId,
            });
            paramValueArray.push(bbox3d.annoId);
            for (var j = 1; j < this.classObj[classIndex].param.length; j++) {
              paramArray.push({
                nam: this.classObj[classIndex].param[j].name,
                val: null,
              });
              paramValueArray.push(null);
            }
          }
          bbox3d.parameters = paramArray;
        }
        this.parameterLabel1.push(paramValueArray);
        this.sortedLabelList.push({
          id: bbox3d.annoId,
          label: this.radioSelect,
          bbox: bbox3d,
        });
      } catch (error) {
        console.log("Error:", error);
      }
    },
    copyAnnotations: function(i, flag) {
      console.log("inside copyAnnotations");
      console.log("flag:", flag);
      console.log("i:", i);
      try {
        if (flag) {
          this.copyAnnotationList.push(this.sortedLabelList[i]);
        } else {
          this.copyAnnotationList.pop(this.sortedLabelList[i]);
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },
    toggleLocks(i, track, annoId) {
      console.log("inside_toggle_locks");
      try {
        for (var j = 0; j < this.sortedLabelList.length; j++) {
          if (this.sortedLabelList[j].bbox != null) {
            if (this.sortedLabelList[j].bbox.annoId == annoId) {
              this.sortedLabelList[j].bbox.track = track;
              this.copyAnnotations(j, this.sortedLabelList[j].bbox.track);
            }
          }
        }
        this.setLockUnlockAllValue();
        this.isAnychange = true;
      } catch (error) {
        console.log("Error:", error);
      }
    },

    setLockUnlockAllValue: function() {
      console.log("inside setLockUnlockAllValue");
      try {
        if (this.sortedLabelList !== null) {
          var totalLength = this.sortedLabelList.filter(function(e) {
            return e.bbox && e.bbox.track === true;
          }).length;
          if (
            this.sortedLabelList.length == totalLength &&
            this.sortedLabelList.length !== 0
          ) {
            this.lockUnlockFlag = true;
          } else {
            this.lockUnlockFlag = false;
          }
        } else {
          this.lockUnlockFlag = false;
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },

    lockUnlockAllObjects: function() {
      console.log("inside lockUnlockAllObjects");
      try {
        if (this.isAnychange == false) {
          if (this.lockUnlockFlag == "true" || this.lockUnlockFlag == true) {
            for (var j = 0; j < this.sortedLabelList.length; j++) {
              if (this.sortedLabelList[j].bbox !== null) {
                this.sortedLabelList[j].bbox.track = true;
              }

              this.copyAnnotationList.push(this.sortedLabelList[j]);
            }
            this.isAnychange = true;
          } else {
            for (var j = 0; j < this.sortedLabelList.length; j++) {
              if (this.sortedLabelList[j].bbox !== null) {
                this.sortedLabelList[j].bbox.track = false;
              }
            }
            this.copyAnnotationList = [];
            this.isAnychange = true;
          }
        } else {
          this.lockUnlockFlag = false;
          this.showDialog = true;
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },

    setPointSize: function() {
      // set pcd cloud point size
      baseLabelTool.setPointSize(this.pointSize);
    },

    discardChanges: function() {
      // discard all changes
      this.isAnychange = false;
      baseLabelTool.cleanView(); // clean active gui design views
      baseLabelTool.isFrameModified(false);
      baseLabelTool.changeFrame(this.currentImageId, this.currentImageBboxData);
      this.sortedLabelList = baseLabelTool.loadLabelList();
      this.isCoordinatesListOpen = false;
    },

    saveAnnos: function() {
      console.log("inside saveAnnos");
      const projectId = SettingService.getSelectedProject();
      // save annotations in db
      try {
        this.saveStatus = false;
        this.isAnychange = false;
        baseLabelTool.isFrameModified(false);
        let annoData = baseLabelTool.saveData3D();
        if (annoData.labels.length > 0) {
          for (var i = 0; i < annoData.labels.length; i++) {
            if (annoData.labels[i].category == this.sortedLabelList[i].label) {
              annoData.labels[i].box3d.parameters = this.sortedLabelList[
                i
              ].bbox.parameters;
              annoData.labels[i].box3d.track = this.sortedLabelList[i].bbox
                .track
                ? this.sortedLabelList[i].bbox.track
                : false;
            }
          }
        }
        var self = this;
        this.$apollo
          .mutate({
            mutation: SAVE_JSON_DATA_MUTATION,
            variables: {
              video_id: this.videoId,
              image_id: this.currentImageId,
              json_data: JSON.stringify(annoData),
              project_id: projectId,
              auto_annotations: JSON.stringify(this.copyAnnotationList),
            },
          })
          .then((data) => {
            try {
              this.isQueryError = false;
              if (data.data.saveJsonData3d.status != null) {
                if (data.data.saveJsonData3d.status === true) {
                  this.image_loader(2);

                  setTimeout(function() {
                    self.saveStatus = true;
                  }, 200);
                  setTimeout(function() {
                    self.saveStatus = false;
                  }, 1000);
                }
                this.isSaving = true;
                init();
              }
            } catch (error) {
              console.log("Error:", error);
            }
          })
          .catch((error) => {
            this.isQueryError = true;
            this.queryErrorResult = error.message;
          });
      } catch (error) {
        console.log("Error : ", error);
      }
    },
    next_image: function(slideType = 1) {
      // move to next image
      try {
        this.removeActiveToolEffect("annotation-tool");
        this.addActiveToolEffect("ortho-view-tool");
        this.updateChangesInfo();
        if (this.isAnychange == false) {
          baseLabelTool.cleanView(); // clean active gui design views
          this.image_loader(1, slideType);
        } else {
          this.showDialog = true;
        }
      } catch (error) {
        console.log("Error : ", error);
      }
    },
    prev_image: function(slideType = 2) {
      // // move to previous image
      try {
        this.removeActiveToolEffect("annotation-tool");
        this.addActiveToolEffect("ortho-view-tool");
        this.updateChangesInfo();
        if (this.isAnychange == false) {
          baseLabelTool.cleanView(); // clean active gui design views
          this.image_loader(0, slideType);
        } else {
          this.showDialog = true;
        }
      } catch (error) {
        console.log("Error : ", error);
      }
    },
    config_loader: function() {
      // load 3d configuration for annotations
      try {
        this.videoId = this.$route.query.videoid;
        this.$apollo
          .mutate({
            mutation: LOAD_JSON_CONFIG_MUTATION,
            variables: {
              video_id: this.videoId,
            },
          })
          .then((data) => {
            try {
              this.isQueryError = false;
              if (data.data.jsonConfigLoader3d.jsonData != null) {
                baseLabelTool.loadConfig(data.data.jsonConfigLoader3d.jsonData);
                let config_data = JSON.parse(
                  data.data.jsonConfigLoader3d.jsonData
                );
                this.camChannelList = config_data.camChannels;
                //this.camChannelList.push({ channel: "All View" });
                this.tolatImageCount = config_data.numFramesDataset;
                this.image_loader(2);
              }
            } catch (error) {
              console.log("Error:", error);
            }
          })
          .catch((error) => {
            this.isQueryError = true;
            this.queryErrorResult = error.message;
          });
      } catch (error) {
        console.log("Error : ", error);
      }
    },

    image_loader: function(signal, slideType = -1) {
      // load images
      const projectId = SettingService.getSelectedProject();
      try {
        console.log("copyAnnotationList", this.copyAnnotationList);
        console.log("slideType", slideType);
        console.log("signal", signal);
        console.log("dir", Editor3DModel.copyDirection);
        console.log("typecheck", typeof Editor3DModel.copyDirection);
        this.$apollo
          .mutate({
            mutation: UI_VIEWER_MUTATION,
            variables: {
              video_id: this.videoId,
              image_id: this.currentImageId,
              signal: signal,
              project_id: projectId,
              auto_annotations: JSON.stringify(this.copyAnnotationList),
              configure_type: slideType,
              copy_direction: Editor3DModel.copyDirection,
            },
          })
          .then((data) => {
            console.log("check track from json", data);
            try {
              this.isQueryError = false;
              if (data.data.uiViewer3d != null) {
                this.currentImageId = data.data.uiViewer3d.image_id;
                this.currentImageBboxData = data.data.uiViewer3d;
                this.imgData = JSON.parse(data.data.uiViewer3d.images_data);
                if (signal == 2) {
                  baseLabelTool.loadImageData(data.data.uiViewer3d);
                  this.sortedLabelList = baseLabelTool.loadLabelList();
                  this.copyAnnotationList = [];
                }
                if (signal == 0) {
                  this.sortedLabelList = [];
                  this.parameterLabel1 = [];
                  baseLabelTool.previousFrame(data.data.uiViewer3d);
                  this.sortedLabelList = baseLabelTool.loadLabelList();
                  this.copyAnnotationList = [];
                }
                if (signal == 1) {
                  this.sortedLabelList = [];
                  this.parameterLabel1 = [];
                  baseLabelTool.nextFrame(data.data.uiViewer3d);
                  this.sortedLabelList = baseLabelTool.loadLabelList();
                  console.log("this.sortedLabelList", this.sortedLabelList);
                  this.copyAnnotationList = [];
                }
                if (this.sortedLabelList.length > 0) {
                  for (var i = 0; i < this.sortedLabelList.length; i++) {
                    this.parameterLabel1[i] = [0];
                    let paramValueArray = [];
                    let classIndex = this.classObj
                      .map(function(o) {
                        return o.name.toLowerCase();
                      })
                      .indexOf(this.sortedLabelList[i].label.toLowerCase());
                    if (
                      this.sortedLabelList[i].bbox != null &&
                      this.sortedLabelList[i].bbox.track
                    ) {
                      this.copyAnnotationList.push(this.sortedLabelList[i]);
                    }
                    if (classIndex !== -1) {
                      for (let prm of this.classObj[classIndex].param) {
                        var paramValue = this.sortedLabelList[i].bbox.parameters
                          .map(function(o) {
                            return o.nam.toLowerCase();
                          })
                          .indexOf(prm.name.toLowerCase());
                        if (paramValue !== -1) {
                          paramValueArray.push(
                            this.sortedLabelList[i].bbox.parameters[paramValue]
                              .val
                          );
                        } else {
                          paramValueArray.push(null);
                        }
                      }
                    }
                    this.parameterLabel1[i] = paramValueArray;
                    paramValueArray = [];
                    this.setLockUnlockAllValue();
                  }
                }
              }
            } catch (error) {
              console.log("Error:", error);
            }
          })
          .catch((error) => {
            this.isQueryError = true;
            this.queryErrorResult = error.message;
          });
      } catch (error) {
        console.log("Error : ", error);
      }
    },
    openCoordinatesWindow: function(selectedBboxAnnoId) {
      // open window and update coordinates from label list
      this.isCoordinatesListOpen = !this.isCoordinatesListOpen;
      this.checkCoords = selectedBboxAnnoId;
      for (var i = 0; i < this.sortedLabelList.length; i++) {
        if (this.sortedLabelList[i].bbox.annoId == this.checkCoords) {
          this.xCoord = parseFloat(this.sortedLabelList[i].bbox.x).toFixed(3);
          this.yCoord = parseFloat(this.sortedLabelList[i].bbox.y).toFixed(3);
          this.zCoord = parseFloat(this.sortedLabelList[i].bbox.z).toFixed(3);
          this.rotationYaw = parseFloat(
            this.sortedLabelList[i].bbox.rotationYaw
          ).toFixed(2);
          this.rotationPitch = parseFloat(
            this.sortedLabelList[i].bbox.rotationPitch
          ).toFixed(2);
          this.rotationRoll = parseFloat(
            this.sortedLabelList[i].bbox.rotationRoll
          ).toFixed(2);
          this.bboxLength = parseFloat(
            this.sortedLabelList[i].bbox.length
          ).toFixed(3);
          this.bboxWidth = parseFloat(
            this.sortedLabelList[i].bbox.width
          ).toFixed(3);
          this.bboxHeight = parseFloat(
            this.sortedLabelList[i].bbox.height
          ).toFixed(3);
          this.currentClass = this.sortedLabelList[i].label;
        }
      }
    },
    fieldOfView: function() {
      // change field-of view
      try {
        baseLabelTool.showFieldView(this.showfieldOfView);
      } catch (error) {
        console.log("Error : ", error);
      }
    },
    gridView: function() {
      // show/hide grid in pcd cloud
      try {
        baseLabelTool.createGrid(this.showGridView);
      } catch (error) {
        console.log("Error : ", error);
      }
    },
    filterGround: function() {
      // filter ground in pcd cloud
      try {
        baseLabelTool.showFilterGround(this.filterGroundStatus);
      } catch (error) {
        console.log("Error : ", error);
      }
    },
    removeActiveToolEffect: function(toolType, selectTool) {
      let selectedToolType = document.getElementsByClassName(toolType);
      let selectedTool = document.getElementById(selectTool);

      if (toolType == "annotation-tool") {
        for (var i = 0; i < selectedToolType.length; i++) {
          selectedToolType[i].classList.remove("active-tool");
        }
      } else if (selectTool != "") {
        selectedTool.classList.remove("active-tool");
      }
    },
    addActiveToolEffect: function(selectTool) {
      let selectedTool = document.getElementById(selectTool);
      selectedTool.classList.add("active-tool");
    },
    setPcdView: function() {
      // open pcd view selectionBox(ortho/perspective)
      try {
        console.log("this.pcdViews:", this.pcdViews);
        if (this.pcdViews == true) {
          this.addActiveToolEffect("pcd-view-tool");
          this.removeActiveToolEffect("annotation-tool");
        }
      } catch (error) {
        console.log("Error : ", error);
      }
    },
    setCameraView: function() {
      // open camera view selectionBox
      try {
        this.camViews = !this.camViews;
        if (this.camViews == true) {
          this.addActiveToolEffect("camera-view-tool");
        } else {
          this.removeActiveToolEffect("annotation-tool");
        }
      } catch (error) {
        console.log("Error : ", error);
      }
    },
    setSettingView: function() {
      // open setting dialog
      try {
        this.isToolSettingsOpen = !this.isToolSettingsOpen;
        if (this.isToolSettingsOpen == true) {
          this.addActiveToolEffect("setting-tool");
        } else {
          this.removeActiveToolEffect("annotation-tool");
        }
      } catch (error) {
        console.log("Error : ", error);
      }
    },
    selectPcdView: function(viewType) {
      // select pcd view(ortho/perspective)
      try {
        if (viewType == "orthographic") {
          this.removeActiveToolEffect("annotation-tool");
          this.addActiveToolEffect("ortho-view-tool");
        } else {
          this.removeActiveToolEffect("annotation-tool");
          this.addActiveToolEffect("persp-view-tool");
        }
        baseLabelTool.selectedPcdViews(viewType);
      } catch (error) {
        console.log("Error : ", error);
      }
    },
    selectCamView: function() {
      // show image on the basis of channel selection at hsc window
      try {
        if (this.channelSelect !== null && this.imgData) {
          let selectedImg = this.channelSelect;
          let channelImgSrc = this.imgData[selectedImg];
          this.isImageViewOpen = true;
          annotationObjects.initCanvas(channelImgSrc, width, height);
          annotationObjects.load2dHSC(this.channelSelect);
          storeCurrChannel(this.channelSelect);

          if (this.channelSelect == "All View") {
            this.isImageViewOpen = false;
            document.getElementById(
              "layout_layout_panel_top"
            ).style.visibility = "visible";
          } else {
            document.getElementById(
              "layout_layout_panel_top"
            ).style.visibility = "hidden";
          }
        }
      } catch (error) {
        console.log("Error : ", error);
      }
    },
    changeXCoord: function() {
      // update x coord
      try {
        this.xCoord = Number(this.xCoord);
        baseLabelTool.updateXCoord(
          this.xCoord,
          this.checkCoords,
          this.currentClass
        );
      } catch (error) {
        console.log("Error :", error);
      }
    },
    changeYCoord: function() {
      // update y coord
      try {
        this.yCoord = Number(this.yCoord);
        baseLabelTool.updateYCoord(
          this.yCoord,
          this.checkCoords,
          this.currentClass
        );
      } catch (error) {
        console.log("Error :", error);
      }
    },
    changeZCoord: function() {
      // update z coord
      try {
        this.zCoord = Number(this.zCoord);
        baseLabelTool.updateZCoord(
          this.zCoord,
          this.checkCoords,
          this.currentClass
        );
      } catch (error) {
        console.log("Error :", error);
      }
    },
    changeRotationYaw: function() {
      // update rotation yaw
      try {
        this.rotationYaw = Number(this.rotationYaw);
        baseLabelTool.updateRotationYaw(
          this.rotationYaw,
          this.checkCoords,
          this.currentClass
        );
      } catch (error) {
        console.log("Error :", error);
      }
    },
    changeRotationPitch: function() {
      // update rotation pitch
      try {
        this.rotationPitch = Number(this.rotationPitch);
        baseLabelTool.updateRotationPitch(
          this.rotationPitch,
          this.checkCoords,
          this.currentClass
        );
      } catch (error) {
        console.log("Error :", error);
      }
    },
    changeRotationRoll: function() {
      // update rotation roll
      try {
        this.rotationRoll = Number(this.rotationRoll);
        baseLabelTool.updateRotationRoll(
          this.rotationRoll,
          this.checkCoords,
          this.currentClass
        );
      } catch (error) {
        console.log("Error :", error);
      }
    },
    changeBboxLength: function() {
      // update box length
      try {
        this.bboxLength = Number(this.bboxLength);
        baseLabelTool.updateBboxLength(
          this.bboxLength,
          this.checkCoords,
          this.currentClass,
          this.xCoord,
          this.yCoord
        );
      } catch (error) {
        console.log("Error :", error);
      }
    },
    changeBboxWidth: function() {
      // update box width
      try {
        this.bboxWidth = Number(this.bboxWidth);
        baseLabelTool.updateBboxWidth(
          this.bboxWidth,
          this.checkCoords,
          this.currentClass,
          this.xCoord,
          this.yCoord
        );
      } catch (error) {
        console.log("Error :", error);
      }
    },
    changeBboxHeight: function() {
      // update box height
      try {
        this.bboxHeight = Number(this.bboxHeight);
        baseLabelTool.updateBboxHeight(
          this.bboxHeight,
          this.checkCoords,
          this.currentClass,
          this.zCoord
        );
      } catch (error) {
        console.log("Error :", error);
      }
    },

    fetchParam: function(i, label, track, name, parameter, id, index) {
      // update box parameters at label-list
      try {
        let parametersN = this.sortedLabelList[i].bbox.parameters;
        let getIndex = parametersN
          .map(function(o) {
            return o.nam.toLowerCase();
          })
          .indexOf(name.toLowerCase());
        if (getIndex !== -1) {
          if (parameter != parametersN[getIndex].val) {
            if (this.parameterLabel1[i][index] == parameter && track) {
              this.checkFlag = true;
            }
            if (parametersN[getIndex] && parametersN[getIndex].nam == name) {
              parametersN[getIndex].val = parameter;
            }
            this.isAnychange = true;
            this.sortedLabelList[i].bbox.parameters = parametersN;
            parametersN = [];
          }
        } else {
          let parametersAdd = [];
          let k = 0;
          let classIndex = this.classObj
            .map(function(o) {
              return o.name.toLowerCase();
            })
            .indexOf(label.toLowerCase());
          for (var j = 0; j < this.classObj[classIndex].param.length; j++) {
            if (this.classObj[classIndex].param[j].name !== name) {
              let paramIndex = parametersN
                .map(function(o) {
                  return o.nam.toLowerCase();
                })
                .indexOf(this.classObj[classIndex].param[j].name.toLowerCase());
              if (paramIndex == -1) {
                parametersAdd.push({
                  nam: this.classObj[classIndex].param[j].name,
                  val: null,
                });
              } else {
                parametersAdd.push({
                  nam: parametersN[k].nam,
                  val: parametersN[k].val,
                });
                k = k + 1;
              }
            }
            if (this.classObj[classIndex].param[j].name == name) {
              parametersAdd.push({
                nam: name,
                val: parameter,
              });
            }
          }
          this.isAnychange = true;
          this.sortedLabelList[i].bbox.parameters = parametersAdd;
          parametersN = [];
          parametersAdd = [];
        }
      } catch (error) {
        console.log("Error:", error);
      }
    },

    getThemeMode: function() {
      this.isDarkMode = SettingService.getDarkMode();
      console.log(this.isDarkMode);
    },
    openLabelList() {
      this.isAnnotationListOpen = !this.isAnnotationListOpen;
      if (this.isAnnotationListOpen == true) {
        this.addActiveToolEffect("label-list-btn");
      } else {
        this.removeActiveToolEffect("dialog-toggler", "label-list-btn");
      }
    },
    openRightPanel() {
      this.isRightPanelOpen = !this.isRightPanelOpen;
      if (this.isRightPanelOpen == true) {
        this.addActiveToolEffect("right-panel-btn");
      } else {
        this.removeActiveToolEffect("dialog-toggler", "right-panel-btn");
      }
    },
    setBoxView() {
      this.isViewPanelOpen = !this.isViewPanelOpen;
      if (this.isViewPanelOpen == true) {
        renderViews();
        this.addActiveToolEffect("right-panel-btn");
      } else {
        this.removeActiveToolEffect("dialog-toggler", "right-panel-btn");
      }
    },
  },
  mounted: function() {
    this.config_loader();
    window.test = this;
  },
  beforeMount() {
    this.getThemeMode();
  },
  beforeDestroy() {
    hideMasterView();
  },
};
