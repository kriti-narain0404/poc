import { labelTool } from "./config_3D_tool.js";
import { loadCameraImages } from "./image_label_tool.js";
import {
  pointCloudScanNoGroundList,
  showPcdViews,
  pcd_param,
  currentClassId,
  transformControls,
  hideMasterView,
} from "./pcd_label_tool.js";
import { loadConfigFile, pad, request } from "./util/ajax_wrapper.js";
import { annotationObjects, classesBoundingBox } from "./util/boundingbox.js";
import "./lib/jquery-1.10.2.min.js";
import "./lib/jquery-ui.min.js";
import "./lib/raphael.js";
import "./lib/PCDLoader";
import Service3D from "../../../services/Service_3D.js";
import "./lib/html2canvas";
import "./dragscroll.js";
import { apolloClient } from "../../../client_apollo.js";
window.$ = window.jQuery = require("jquery");
require("./lib/w2ui-1.5.rc1.min");
import * as THREE from "three";
let pointCloudFullURL, pointCloudWithoutGroundURL, annotationsData;

let annoContent, annoContentLength, annoContentIndex;

let baseLabelTool = {
  pointSize: 0.7,
  gridSize: 200,
  showGridFlag: false,
  saveJsonStatus: false,
  isQueryError: false,
  queryErrorResult: null,
  radioValue: "",
  modelSelection: "",
  folderPath: "",
  minheight: 0,
  minwidth: 0,
  annotationTip: "",
  paramObj: [],
  imageTagObj: [],
  classObj: [],
  subclassObj: [],
  classObjNames: [],
  selectedObjectClass: "",
  openChannel: false,
  annoData: {},

  loadImageData: function(data) {
    try {
      let images_data = JSON.parse(data.images_data);
      let pcd_data = JSON.parse(data.pcd_data);
      pointCloudFullURL = pcd_data.pointclouds;
      pointCloudWithoutGroundURL = pcd_data.pointclouds_without_ground;
      labelTool.currentFileIndex = data.image_id;
      labelTool.currentFileName = data.image_name;
      annotationsData = JSON.parse(data.annos_json);
      for (let i = 0; i < labelTool.numFrames; i++) {
        for (let camChannelObj in labelTool.camChannels) {
          if (labelTool.camChannels.hasOwnProperty(camChannelObj)) {
            let camChannelObject = labelTool.camChannels[camChannelObj];
            loadCameraImages(camChannelObject.channel, i, images_data);
          }
        }
        labelTool.imageArrayAll.push(labelTool.imageArray);
      }
      // show camera images of current frame
      for (let i = 0; i < labelTool.camChannels.length; i++) {
        labelTool.imageArrayAll[labelTool.currentFileIndex][i].toBack();
      }
      if (annotationsData !== null) {
        this.loadAnnotations(annotationsData);
      } else {
        labelTool.labelListAnno = [];
      }
      this.loadPointCloudData();
    } catch (error) {
      console.log("Error:", error);
    }
  },
  loadPointCloudData: function() {
    // ASCII pcd files
    let pcdLoader = new THREE.PCDLoader();
    let point = this.pointSize;
    pcdLoader.load(pointCloudFullURL, function(mesh) {
      mesh.name = "pointcloud-scan-" + labelTool.currentFileIndex;
      mesh.material.size = point;
      pcd_param.pointCloudScanMap[labelTool.currentFileIndex] = mesh;
      labelTool.scene.add(mesh);
    });
    pcdLoader.load(pointCloudWithoutGroundURL, function(mesh) {
      mesh.name = "pointcloud-scan-no-ground-" + labelTool.currentFileIndex;
      pointCloudScanNoGroundList.push(mesh);
    });

    // draw positions of cameras
    if (labelTool.showCameraPosition === true) {
      drawCameraPosition();
    }

    // draw ego vehicle
    if (labelTool.drawEgoVehicle === true) {
      let lexusTexture = new THREE.TextureLoader().load(
        "assets/models/lexus/lexus.jpg"
      );
      let lexusMaterial = new THREE.MeshBasicMaterial({ map: lexusTexture });
      let objLoader = new THREE.OBJLoader();
      objLoader.load("assets/models/lexus/lexus_hs.obj", function(object) {
        let lexusGeometry = object.children[0].geometry;
        let lexusMesh = new THREE.Mesh(lexusGeometry, lexusMaterial);

        lexusMesh.scale.set(0.065, 0.065, 0.065);
        lexusMesh.rotation.set(0, 0, -Math.PI / 2);
        lexusMesh.position.set(0, 0, -labelTool.positionLidarNuscenes[2]);

        labelTool.scene.add(lexusMesh);
      });
    }
  },
  // Set values to this.annotationObjects from allAnnotations
  loadAnnotations: function(frameObject) {
    let annoDataChannel;
    labelTool.labelListAnno = [];
    // Remove old bounding boxes of current frame.
    let frameAnnotations = frameObject.labels;
    // Add new bounding boxes
    for (let annotationIdx in frameAnnotations) {
      let bboxList = {};
      let bbox3DList = {};
      if (frameAnnotations.hasOwnProperty(annotationIdx)) {
        let annotation = frameAnnotations[annotationIdx];
        (bboxList = {
          class: annotation.category,
          annoId: annotation.id,
          track: annotation.box3d.track ? annotation.box3d.track : false,
          x: parseFloat(annotation.box3d.location.x),
          y: parseFloat(annotation.box3d.location.y),
          z: parseFloat(annotation.box3d.location.z),
          rotationYaw: parseFloat(annotation.box3d.orientation.rotationYaw),
          rotationPitch: parseFloat(annotation.box3d.orientation.rotationPitch),
          rotationRoll: parseFloat(annotation.box3d.orientation.rotationRoll),
          length: parseFloat(annotation.box3d.dimension.length),
          width: parseFloat(annotation.box3d.dimension.width),
          height: parseFloat(annotation.box3d.dimension.height),
          parameters: annotation.box3d.parameters,
        }),
          (bbox3DList = {
            label: annotation.category,
            annoId: annotation.id,
            track: annotation.box3d.track ? annotation.box3d.track : false,
            dimension: {
              height: parseFloat(annotation.box3d.dimension.height),
              length: parseFloat(annotation.box3d.dimension.length),
              width: parseFloat(annotation.box3d.dimension.width),
            },
            location: {
              x: parseFloat(annotation.box3d.location.x),
              y: parseFloat(annotation.box3d.location.y),
              z: parseFloat(annotation.box3d.location.z),
            },
            orientation: {
              rotationPitch: parseFloat(
                annotation.box3d.orientation.rotationPitch
              ),
              rotationRoll: parseFloat(
                annotation.box3d.orientation.rotationRoll
              ),
              rotationYaw: parseFloat(annotation.box3d.orientation.rotationYaw),
            },
            parameters: annotation.box3d.parameters,
          }),
          labelTool.labelListAnno.push({
            id: annotation.id,
            label: annotation.category,
            bbox: bbox3DList,
            bbox3d: bbox3DList,
          });
        let params = labelTool.getDefaultObject();
        params.class = annotation.category;
        params.rotationYaw = parseFloat(
          annotation.box3d.orientation.rotationYaw
        );
        params.original.rotationYaw = parseFloat(
          annotation.box3d.orientation.rotationYaw
        );
        params.rotationPitch = parseFloat(
          annotation.box3d.orientation.rotationPitch
        );
        params.original.rotationPitch = parseFloat(
          annotation.box3d.orientation.rotationPitch
        );
        params.rotationRoll = parseFloat(
          annotation.box3d.orientation.rotationRoll
        );
        params.original.rotationRoll = parseFloat(
          annotation.box3d.orientation.rotationRoll
        );
        params.trackId = annotation.id;
        // Nuscenes labels are stored in global frame in the database
        // Nuscenes: labels (3d positions) are transformed from global frame to point cloud (global -> ego, ego -> point cloud) before exporting them
        params.x = parseFloat(annotation.box3d.location.x);
        params.y = parseFloat(annotation.box3d.location.y);
        params.z = parseFloat(annotation.box3d.location.z);
        params.original.x = parseFloat(annotation.box3d.location.x);
        params.original.y = parseFloat(annotation.box3d.location.y);
        params.original.z = parseFloat(annotation.box3d.location.z);
        let tmpWidth = parseFloat(annotation.box3d.dimension.width);
        let tmpLength = parseFloat(annotation.box3d.dimension.length);
        let tmpHeight = parseFloat(annotation.box3d.dimension.height);
        if (tmpWidth > 0.3 && tmpLength > 0.3 && tmpHeight > 0.3) {
          tmpWidth = Math.max(tmpWidth, 0.0001);
          tmpLength = Math.max(tmpLength, 0.0001);
          tmpHeight = Math.max(tmpHeight, 0.0001);
          params.delta_x = 0;
          params.delta_y = 0;
          params.delta_z = 0;
          params.width = tmpWidth;
          params.length = tmpLength;
          params.height = tmpHeight;
          params.original.width = tmpWidth;
          params.original.length = tmpLength;
          params.original.height = tmpHeight;
        }
        params.fileIndex = Number(frameObject.index);
        // add new entry to contents array

        annotationObjects.set(annotationObjects.__insertIndex, params);

        annotationObjects.__insertIndex++;
        // if (isNaN(classesBoundingBox.getCurrentAnnotationClassObject().nextTrackId)) {
        //     classesBoundingBox.getCurrentAnnotationClassObject().nextTrackId = 0;
        // }
        // classesBoundingBox[classesBoundingBox.getCurrentClass()].nextTrackId++;
      }
    } //end for loop frame annotations
    // reset track ids for next frame if nuscenes dataset and showLabels=true
    if (
      labelTool.showOriginalNuScenesLabels === true &&
      labelTool.currentDataset === labelTool.datasets.NuScenes
    ) {
      for (let i = 0; i < this.classObj.length; i++) {
        classesBoundingBox[this.classObj[i].name].nextTrackId = 0;
      }
    }
    // reset insert index
    annotationObjects.__insertIndex = 0;
    for (let i = 0; i < this.classObj.length; i++) {
      classesBoundingBox[this.classObj[i].name].nextTrackId =
        classesBoundingBox[this.classObj[i].name].maxTrackId + 1;
    }
    // project 3D positions of current frame into 2D camera images
    if (labelTool.pointCloudOnlyAnnotation === false) {
      if (annotationObjects.contents[labelTool.currentFileIndex].length > 0) {
        this.annoData.annoContent = annotationObjects.contents;
        this.annoData.annoContentIndex = labelTool.currentFileIndex;
        this.annoData.annoContentLength =
          annotationObjects.contents[labelTool.currentFileIndex].length;

        // this.annoData.annoDataId =
        for (
          let i = 0;
          i < annotationObjects.contents[labelTool.currentFileIndex].length;
          i++
        ) {
          //Loads 3d boxes on IMages
          draw2DProjections(
            annotationObjects.contents[labelTool.currentFileIndex][i]
          );
        }
      }
    }
  },

  // Create annotations from this.annotationObjects
  createAnnotationFiles: function() {
    let annotationFiles = [];
    for (let j = 0; j < labelTool.numFrames; j++) {
      let annotationsInFrame = [];
      for (let i = 0; i < annotationObjects.contents[j].length; i++) {
        if (
          annotationObjects.contents[j][i] !== undefined &&
          labelTool.cubeArray[j][i] !== undefined
        ) {
          let annotationObj = annotationObjects.contents[j][i];
          // Nuscenes labels are stored in global frame within database
          // [optional] Nuscenes: transform 3d positions from lidar frame to global frame (lidar -> ego, ego -> global)
          let annotationObjectJSON = {
            id: annotationObj["trackId"],
            category: annotationObj["class"],
            box3d: {
              dimension: {
                width: labelTool.cubeArray[j][i].scale.x,
                length: labelTool.cubeArray[j][i].scale.y,
                height: labelTool.cubeArray[j][i].scale.z,
              },
              location: {
                x: labelTool.cubeArray[j][i].position.x,
                y: labelTool.cubeArray[j][i].position.y,
                z: labelTool.cubeArray[j][i].position.z,
              },
              orientation: {
                rotationYaw: labelTool.cubeArray[j][i].rotation.z,
                rotationPitch: labelTool.cubeArray[j][i].rotation.x,
                rotationRoll: labelTool.cubeArray[j][i].rotation.y,
              },
              parameters: [],
            },
          };
          annotationsInFrame.push(annotationObjectJSON);
        }
      }
      let annotationsInFrameJSON = {
        name: labelTool.currentFileName,
        timestamp: 0,
        index: j,
        labels: annotationsInFrame,
      };
      annotationFiles.push(annotationsInFrameJSON);
    }
    return annotationFiles;
  },

  saveData3D: function() {
    try {
      let annotationFile = baseLabelTool.createAnnotationFiles();
      let annosData = annotationFile[labelTool.currentFileIndex];
      return annosData;
    } catch (error) {
      console.log("Error :", error);
    }
  },

  loadSettingsData: function(data) {
    try {
      var settingData = [];
      settingData = JSON.parse(data.settingObject);
      this.radioValue = data.predType;
      this.modelSelection = data.modelType;
      this.folderPath = data.folderPath;
      this.minheight = data.minHeight;
      this.minwidth = data.minWidth;
      this.annotationTip = data.annoTip;
      this.paramObj = [];
      this.imageTagObj = [];
      this.classObj = [];
      this.subclassObj = [];
      labelTool.classObjNames = [];
      let cnt = 0;
      let paramCnt = 0;
      if (settingData != null) {
        for (var i = 0; i < settingData.length; i++) {
          if (settingData[i].selected === true) {
            this.classObj.push({
              id: settingData[i].id,
              name: settingData[i].name,
              selected: settingData[i].selected,
              type: settingData[i].type,
              color: settingData[i].color,
              length: settingData[i].length,
            });
            labelTool.classObjNames.push(settingData[i].name);
            if (settingData[i].parameters) {
              for (var j = 0; j < settingData[i].parameters.length; j++) {
                if (settingData[i].parameters[j].selected === true) {
                  this.paramObj.push({
                    id: settingData[i].parameters[j].id,
                    name: settingData[i].parameters[j].name,
                    selected: settingData[i].parameters[j].selected,
                    type: settingData[i].parameters[j].type,
                    color: settingData[i].parameters[j].color,
                    paralength: settingData[i].parameters[j].length,
                  });
                  this.classObj[cnt]["param"] = this.paramObj;
                  if (
                    settingData[i].parameters[j].subClass &&
                    settingData[i].parameters[j].subClass !== undefined
                  ) {
                    for (
                      var k = 0;
                      k < settingData[i].parameters[j].subClass.length;
                      k++
                    ) {
                      if (
                        settingData[i].parameters[j].subClass[k].selected ===
                        true
                      ) {
                        this.subclassObj.push({
                          id: settingData[i].parameters[j].subClass[k].id,
                          name: settingData[i].parameters[j].subClass[k].name,
                          selected:
                            settingData[i].parameters[j].subClass[k].selected,
                          type: settingData[i].parameters[j].subClass[k].type,
                          color: settingData[i].parameters[j].subClass[k].color,
                          paralength:
                            settingData[i].parameters[j].subClass[k].length,
                        });
                        this.classObj[cnt].param[paramCnt][
                          "subClass"
                        ] = this.subclassObj;
                      }
                    }
                    this.subclassObj = [];
                  }
                  paramCnt = paramCnt + 1;
                }
              }
              this.paramObj = [];
              paramCnt = 0;
            }
            cnt = cnt + 1;
          }
        }
      }
    } catch (error) {
      console.log("Error :", error);
    }
  },

  initPointCloudWindow: function() {
    let pointCloudContainer;
    if (labelTool.pointCloudOnlyAnnotation === true) {
      pointCloudContainer = $("#label-tool-wrapper");
    } else {
      pointCloudContainer = $("#layout_layout_panel_main .w2ui-panel-content");
    }
    pointCloudContainer.append('<div id="canvas3d" style="z-index: 0;"></div>');
    labelTool.localOnInitialize["PCD"]();
  },
  initClasses: function() {
    for (let i = 0; i < this.classObj.length; i++) {
      classesBoundingBox[this.classObj[i].name] = {
        color: this.classObj[i].color,
        index: i,
        nextTrackId: 0,
        maxTrackId: -1,
      };
    }
  },
  initClassPicker: function() {
    classesBoundingBox.currentClass = labelTool.classes[0];
    $(function() {
      $("#class-picker>ul>li").hover(
        function() {
          $(this).css("background-color", "#535353");
        },
        function() {
          // on mouseout, reset the background color if not selected
          let currentClass = classesBoundingBox.getCurrentClass();
          let currentClassIndex = classesBoundingBox[currentClass].index;
          let currentHoverIndex = $("#class-picker>ul>li").index(this);
          if (currentClassIndex !== currentHoverIndex) {
            $(this).css("background-color", "#353535");
          }
        }
      );
    });
    // let toasts = $(".toasts")[0];
    // this.logger = new Toast(toasts);  // toast is used for warning error we can use some other than toast after
  },
  createGrid: function(showGridFlag) {
    let grid;
    this.removeObject("grid");
    let gridSize = 200;
    grid = new THREE.GridHelper(gridSize, gridSize);
    let posZLidar;
    let translationX;
    if (labelTool.currentDataset === labelTool.datasets.NuScenes) {
      posZLidar = labelTool.positionLidarNuscenes[2];
      translationX = 0;
    } else {
      posZLidar = labelTool.positionLidar[2];
      translationX = this.gridSize / 2;
    }
    grid.translateZ(-posZLidar);
    grid.translateX(translationX);
    grid.rotateX(Math.PI / 2);
    grid.name = "grid";
    if (showGridFlag === "true") {
      grid.visible = true;
    } else {
      grid.visible = false;
    }
    labelTool.scene.add(grid);
  },
  showFilterGround: function(showGridStatus) {
    if (showGridStatus === "true") {
      this.removeObject("pointcloud-scan-" + labelTool.currentFileIndex);
      this.addObject(
        pointCloudScanNoGroundList[labelTool.currentFileIndex],
        "pointcloud-scan-no-ground-" + labelTool.currentFileIndex
      );
    } else {
      this.removeObject(
        "pointcloud-scan-no-ground-" + labelTool.currentFileIndex
      );
      this.addObject(
        pcd_param.pointCloudScanMap[labelTool.currentFileIndex],
        "pointcloud-scan-" + labelTool.currentFileIndex
      );
    }
  },
  setPointSize: function(pointSize) {
    pcd_param.pointCloudScanMap[
      labelTool.currentFileIndex
    ].material.size = pointSize;
    this.pointSize = pointSize;
  },
  showFieldView: function(showFieldStatus) {
    this.removeObject("rightplane");
    this.removeObject("leftplane");
    this.removeObject("prism");
    if (showFieldStatus === "true") {
      Service3D.drawFieldOfView();
    }
  },
  selectedPcdViews: function(selectedView) {
    showPcdViews(selectedView);
  },

  setPanelSize: function(index) {
    let panelHeight;
    // if (this.openChannel) {
    //   panelHeight = labelTool.imageSizes["NuScenes"]["minHeightNormal"];
    // } else {
    panelHeight = 0;
    // }
    $("#layout_layout_panel_top").css("height", panelHeight);
    $("#layout_layout_resizer_top").css("top", panelHeight);
    $("#layout_layout_panel_main").css("top", panelHeight);
    $("#image-cam-front-left").css("height", panelHeight);
    $("#image-cam-front").css("height", panelHeight);
    $("#image-cam-front-right").css("height", panelHeight);
    $("#image-cam-back-right").css("height", panelHeight);
    $("#image-cam-back").css("height", panelHeight);
    $("#image-cam-back-left").css("height", panelHeight);

    for (let i = 0; i < labelTool.camChannels.length; i++) {
      let id =
        "#image-" +
        labelTool.camChannels[i].channel.toLowerCase().replace(/_/g, "-");
      // bring all svgs into background
      let allSvg = $(id + " svg");
      for (let j = 0; j < allSvg.length; j++) {
        allSvg[j].style.zIndex = 0;
      }
      allSvg[labelTool.numFrames - index - 1].style.zIndex = 2;
      let imgWidth = labelTool.updtedWidth / 6;
      allSvg[labelTool.numFrames - index - 1].style.width = imgWidth;
      allSvg[labelTool.numFrames - index - 1].style.height =
        imgWidth / labelTool.imageAspectRatioNuScenes;
    }
  },
  // toggleChannel: function(flag) {
  //   if (flag) {
  //     this.openChannel = true;
  //   } else {
  //     this.openChannel = false;
  //   }
  //   //this.initPanes();
  // },
  setImageSize: function() {
    //calculate the image width given the window width
    // if (this.openChannel) {
    //   labelTool.imageSizes = {
    //     NuScenes: {
    //       minWidthNormal: Math.floor(labelTool.updtedWidth / 5),
    //       minHeightNormal: Math.floor(labelTool.updtedWidth / (6 * 1.77778)),
    //       maxWidthNormal: 640,
    //       maxHeightNormal: 360,
    //     },
    //   };
    // } else {
    labelTool.imageSizes = {
      NuScenes: {
        minWidthNormal: 0,
        minHeightNormal: 0,
        maxWidthNormal: 640,
        maxHeightNormal: 360,
      },
    };
    // }
  },
  //This function is for left panel resizing
  initPanes: function() {
    let maxHeight;
    let minHeight;
    if (labelTool.currentDataset === labelTool.datasets.NuScenes) {
      // if (this.openChannel) {
      //   minHeight = labelTool.imageSizes["NuScenes"]["minHeightNormal"];
      //   maxHeight = labelTool.imageSizes["NuScenes"]["maxHeightNormal"];
      //   console.log(maxHeight, minHeight);
      // } else {
      minHeight = 0;
      maxHeight = 0;
      // }
    }

    let topStyle =
      "background-color: #F5F6F7; border: 1px solid #dfdfdf; padding: 0px;";
    $("#label-tool-wrapper").w2layout({
      name: "layout",
      panels: [
        {
          type: "top",
          size: minHeight,
          resizable: true,
          style: topStyle,
          minSize: minHeight,
          maxSize: maxHeight,
        },
      ],
      onResizing: function(event) {
        let topElem = $("#layout_layout_panel_top")[0];
        let newImagePanelHeight = topElem.offsetHeight;
        let newWidth;
        if (labelTool.currentDataset === labelTool.datasets.NuScenes) {
          newWidth = newImagePanelHeight * labelTool.imageAspectRatioNuScenes;
        }
        if (newImagePanelHeight === 0 || newWidth === 0) {
          return;
        }
        for (let channelIdx in labelTool.camChannels) {
          if (labelTool.camChannels.hasOwnProperty(channelIdx)) {
            let channelObj = labelTool.camChannels[channelIdx];
            let channel = channelObj.channel;
            if (labelTool.currentDataset === labelTool.datasets.NuScenes) {
              changeCanvasSize(newWidth, newImagePanelHeight, channel);
            }
          }
        }
        w2ui["layout"].set("top", { size: newImagePanelHeight });
        // adjust height of helper views
        let newCanvasHeight =
          (labelTool.updatedHeight -
            pcd_param.headerHeight -
            newImagePanelHeight) /
          3;
        $("#canvasSideView").css("height", newCanvasHeight);
        $("#canvasSideView").css(
          "top",
          pcd_param.headerHeight + newImagePanelHeight
        );
        views[1].height = newCanvasHeight;
        views[1].top = 10;
        $("#canvasFrontView").css("height", newCanvasHeight);
        $("#canvasFrontView").css(
          "top",
          pcd_param.headerHeight + newImagePanelHeight + newCanvasHeight
        );
        views[2].height = newCanvasHeight;
        views[2].top = newCanvasHeight;
        $("#canvasBev").css("height", newCanvasHeight);
        $("#canvasBev").css(
          "top",
          pcd_param.headerHeight + newImagePanelHeight + 2 * newCanvasHeight
        );
        views[3].height = newCanvasHeight;
        views[3].top = 2 * newCanvasHeight;
        // update camera of helper views
        for (let i = 1; i < views.length; i++) {
          let view = views[i];
          view.height = newCanvasHeight;
          let top = 4;
          let bottom = -4;
          let aspectRatio = view.width / view.height;
          let left = bottom * aspectRatio;
          let right = top * aspectRatio;
          let camera = view.camera;
          camera.left = left;
          camera.right = right;
          camera.top = top;
          camera.bottom = bottom;
          camera.updateProjectionMatrix();
        }
        // update projection of bounding boxes on camera images
        // delete all labels
        remove2DBoundingBoxes();
      },
      onRefresh: function(event) {
        event.onComplete = function() {
          $("#layout_layout_resizer_top").on("click", function() {
            w2ui["layout"].resize();
          });
          $("#layout_layout_resizer_top").on("drag", function() {
            w2ui["layout"].resize();
          });
        };
      },
    });
    // w2ui['layout'].resizer = 10;
    // w2ui['layout'].resize();
    // w2ui['layout'].refresh();
  },
  initCameraWindows: function() {
    this.setImageSize();
    this.initPanes();
    let imageContainer = $("#layout_layout_panel_top .w2ui-panel-content");
    let imageWidth;
    let canvasElem;
    let imagePanelTopPos;
    for (let i = 0; i < labelTool.numFrames; i++) {
      labelTool.paperArray = [];
      for (
        let channelIdx = 0;
        channelIdx < labelTool.camChannels.length;
        channelIdx++
      ) {
        if (labelTool.imageCanvasInitialized === false) {
          let channel = labelTool.camChannels[channelIdx].channel;
          let id = "image-" + channel.toLowerCase().replace(/_/g, "-");
          let minWidth = labelTool.updtedWidth / 6;
          let minHeight = minWidth * 1.7778;
          imageContainer.append("<div id='" + id + "'></div>");
          $("#" + id).css("width", minWidth);
          $("#" + id).css("height", minHeight);
          canvasElem = imageContainer["0"].children[channelIdx];
          labelTool.canvasArray.push(canvasElem);
          imagePanelTopPos = parseInt(
            $("#layout_layout_resizer_top").css("top"),
            10
          );
          if (labelTool.currentDataset === labelTool.datasets.NuScenes) {
            imageWidth = labelTool.imageSizes["NuScenes"]["minWidthNormal"];
          }
        }
        labelTool.paperArray.push(
          Raphael(
            labelTool.canvasArray[channelIdx],
            imageWidth,
            imagePanelTopPos
          )
        );
      }
      labelTool.imageCanvasInitialized = true;
      labelTool.paperArrayAll.push(labelTool.paperArray);
    }
    // ---------------------------------------------------------------

    // make image container scrollable
    //$("#layout_layout_panel_top .w2ui-panel-content").addClass("dragscroll");
    //$("#layout_layout_panel_top .w2ui-panel-content").css("overflow", "scroll");

    labelTool.camChannels.forEach(
      function(channelObj) {
        labelTool.localOnInitialize[channelObj.channel]();
      }.bind(this)
    );

    if (labelTool.currentDataset === labelTool.datasets.NuScenes) {
      for (let channelIdx in labelTool.camChannels) {
        if (labelTool.camChannels.hasOwnProperty(channelIdx)) {
          let channel = labelTool.camChannels[channelIdx].channel;
          let id = "image-" + channel.toLowerCase().replace(/_/g, "-");
          let minWidth = labelTool.updtedWidth / 6;
          let minHeight = minWidth / 1.7778;
          $("#" + id).css("width", minWidth);
          $("#" + id).css("height", minHeight);
        }
      }
    }
    this.setPanelSize(labelTool.currentFileIndex);
  },

  reset() {
    for (let i = labelTool.scene.children.length; i >= 0; i--) {
      let obj = labelTool.scene.children[i];
      labelTool.scene.remove(obj);
    }

    // base label tool
    // labelTool.currentFileIndex = 0;  // commented need to check no need to make it zero
    this.originalAnnotations = [];
    this.targetClass = this.classes[0];
    this.savedFrames = [];
    labelTool.cubeArray = [];
    labelTool.currentCameraChannelIndex = 0;
    for (
      let i = 0;
      i < annotationObjects.contents[labelTool.currentFileIndex].length;
      i++
    ) {
      let annotationObj =
        annotationObjects.contents[labelTool.currentFileIndex][i];
      annotationObjects.guiOptions.removeFolder(
        annotationObj["class"] + " " + annotationObj["trackId"]
      );
    }
    annotationObjects.contents = [];
    $(".class-tooltip").remove();
    labelTool.spriteArray = [];
    this.selectedMesh = undefined;
    this.pointCloudLoaded = false;

    // pcd label tool
    annotationObjects.folderBoundingBox3DArray = [];
    annotationObjects.folderPositionArray = [];
    annotationObjects.folderRotationArray = [];
    annotationObjects.folderSizeArray = [];
    pcd_param.pointCloudScanMap = [];

    let classPickerElem = $("#class-picker ul li");
    classPickerElem.css("background-color", "#353535");
    $(classPickerElem[0]).css("background-color", "#525252");
    classPickerElem.css("border-bottom", "0px");

    // classesBoundingBox
    classesBoundingBox.colorIdx = 0;
    classesBoundingBox.currentClass = labelTool.classes[0];
    classPickerElem.each(function(i, item) {
      let color = labelTool.classColors[i];
      let attribute = "20px solid" + " " + color;
      $(item).css("border-left", attribute);
      $(item).css("border-bottom", "0px");
    });
    for (let i = 0; i < labelTool.classes.length; i++) {
      delete classesBoundingBox[labelTool.classes[i]];
    }
    // remove guiClassesBoundingBox
    $("#class-picker").remove();

    if (labelTool.pointCloudOnlyAnnotation === false) {
      // image label tool
      this.imageCanvasInitialized = false;
      labelTool.canvasArray = [];
      labelTool.canvasParamsArray = [];
      labelTool.paperArray = [];
      labelTool.paperArrayAll = [];
      labelTool.imageArray = [];

      // remove image divs
      $("#layout_layout_panel_top .w2ui-panel-content").empty();

      if (this.currentDataset === this.datasets.NuScenes) {
        w2ui["layout"].panels[0].minSize =
          Math.ceil(labelTool.updtedWidth) / (6 * 1.7778) - 27;
        w2ui["layout"].panels[0].maxSize = 360;
        w2ui["layout"].panels[0].size =
          Math.ceil(labelTool.updtedWidth) / (6 * 1.7778) - 27;
      }
      w2ui["layout"].resize();
    }

    $(".frame-selector__frames").empty();
  },

  initFrameSelector: function() {
    // add bar segments to frame selection bar
    for (let i = 0; i < labelTool.numFrames; i++) {
      let selectedClass = "";
      if (i === 0) {
        selectedClass = "selected";
      }
      let divElem = $(
        "<div data-tip=" +
          i +
          ' data-for="frame-selector" class="frame default ' +
          selectedClass +
          '"></div>'
      );
      $(divElem).on("click", function(item) {
        $("div.frame").attr("class", "frame default");
        item.target.className = "frame default selected";
        let elemIndex = Number(item.target.dataset.tip);
        labelTool.changeFrame(elemIndex);
      });
      $(".frame-selector__frames").append(divElem);
    }
    $(".current").text(
      labelTool.currentFileIndex + 1 + "/" + labelTool.numFrames
    );
  },
  initTimer: function() {
    labelTool.timeElapsed = 0;
    let hours = 0;
    let minutes = 0;
    let seconds = 0;
    let timeString = "";

    setInterval(function() {
      // increase elapsed time every second
      labelTool.timeElapsed = labelTool.timeElapsed + 1;
      seconds = labelTool.timeElapsed % 60;
      minutes = Math.floor(labelTool.timeElapsed / 60);
      if (minutes > 59) {
        minutes = 0;
      }
      hours = Math.floor(labelTool.timeElapsed / (60 * 60));
      timeString =
        pad(hours, 2) + ":" + pad(minutes, 2) + ":" + pad(seconds, 2);
      $("#time-elapsed").text(timeString);
    }, labelTool.timeDelay);
  },
  start() {
    this.initClasses();
    if (labelTool.pointCloudOnlyAnnotation === false) {
      this.initCameraWindows();
    }
    this.initPointCloudWindow();
  },
  loadConfig(data) {
    try {
      if (data != null) {
        labelTool.config_data = JSON.parse(data);
        labelTool.camChannels = labelTool.config_data.camChannels;
        labelTool.pointCloudOnlyAnnotation =
          labelTool.config_data.pointCloudOnlyAnnotation;
        labelTool.numFrames = labelTool.config_data.numFramesDataset;
        labelTool.positionLidarNuscenes =
          labelTool.config_data.positionLidarNuscenes;
        labelTool.positionLidar = labelTool.config_data.positionLidar;
        labelTool.translationVectorLidarToCamFront =
          labelTool.config_data.translationVectorLidarToCamFront;
        labelTool.dataStructure = loadConfigFile(labelTool.configFileName);
        for (let i = 0; i < labelTool.dataStructure.datasets.length; i++) {
          let datasetName = labelTool.dataStructure.datasets[i].name;
          labelTool.datasetArray.push(datasetName);
          labelTool.datasets[datasetName] = datasetName;
        }
        labelTool.currentDataset = labelTool.datasetArray[0];
        labelTool.currentDatasetIdx = 0;
        labelTool.sequence = labelTool.dataStructure.datasets[0].sequences[0];
        labelTool.classes = labelTool.dataStructure.datasets[0].classes;
        labelTool.classColors =
          labelTool.dataStructure.datasets[0].class_colors;
        labelTool.targetClass = labelTool.classes[0];
        this.start();
      }
    } catch (error) {
      console.log("Error:", error);
    }
  },

  selectedClass: function(objName) {
    try {
      classesBoundingBox.currentClass = objName;
      annotationObjects.contents[labelTool.currentFileIndex][
        currentClassId
      ].class = objName;
    } catch (error) {
      console.log("Error:", error);
    }
  },

  updateLabelList: function() {
    let bbox3d = {};
    bbox3d = {
      class:
        annotationObjects.contents[labelTool.currentFileIndex][currentClassId]
          .class,
      annoId:
        annotationObjects.contents[labelTool.currentFileIndex][currentClassId]
          .trackId,
      track: false,
      x:
        annotationObjects.contents[labelTool.currentFileIndex][currentClassId]
          .x,
      y:
        annotationObjects.contents[labelTool.currentFileIndex][currentClassId]
          .y,
      z:
        annotationObjects.contents[labelTool.currentFileIndex][currentClassId]
          .z,
      rotationYaw:
        annotationObjects.contents[labelTool.currentFileIndex][currentClassId]
          .rotationYaw,
      rotationPitch:
        annotationObjects.contents[labelTool.currentFileIndex][currentClassId]
          .rotationPitch,
      rotationRoll:
        annotationObjects.contents[labelTool.currentFileIndex][currentClassId]
          .rotationRoll,
      length:
        annotationObjects.contents[labelTool.currentFileIndex][currentClassId]
          .length,
      width:
        annotationObjects.contents[labelTool.currentFileIndex][currentClassId]
          .width,
      height:
        annotationObjects.contents[labelTool.currentFileIndex][currentClassId]
          .height,
      parameters: [],
    };
    return bbox3d;
  },

  previousFrame: function(data) {
    if (labelTool.currentFileIndex >= 1) {
      this.changeFrame(labelTool.currentFileIndex - 1, data);
    } else if (labelTool.currentFileIndex !== 0) {
      this.changeFrame(0, data);
    }
  },
  cleanView: function() {
    try {
      if (transformControls !== undefined) {
        labelTool.selectedMesh = undefined;
        transformControls.detach();
        hideMasterView();
      }
    } catch (error) {
      console.log("Error:", error);
    }
  },
  isFrameModified: function(flag) {
    try {
      if (flag == false) {
        return (labelTool.isAnyChange = false);
      } else {
        return labelTool.isAnyChange;
      }
    } catch (error) {
      console.log("Error:", error);
    }
  },
  nextFrame: function(data) {
    if (labelTool.currentFileIndex < labelTool.numFrames - 1) {
      this.changeFrame(labelTool.currentFileIndex + 1, data);
    } else if (labelTool.currentFileIndex !== labelTool.numFrames - 1) {
      this.changeFrame(labelTool.numFrames - 1, data);
    }
  },

  jumpFrame: function() {
    if (
      0 <= Number(this.pageBox.value) - 1 &&
      Number(this.pageBox.value) - 1 < labelTool.numFrames
    ) {
      this.changeFrame(Number(this.pageBox.value) - 1);
    }
  },

  removeObject: function(objectName) {
    for (let i = labelTool.scene.children.length - 1; i >= 0; i--) {
      let obj = labelTool.scene.children[i];
      if (obj.name === objectName) {
        labelTool.scene.remove(obj);
        return true;
      }
    }
    return false;
  },
  addObject: function(sceneObject, name) {
    sceneObject.name = name;
    // search whether object already exist
    for (let i = labelTool.scene.children.length - 1; i >= 0; i--) {
      let obj = labelTool.scene.children[i];
      if (obj.name === name) {
        return;
      }
    }
    labelTool.scene.add(sceneObject);
  },
  loadLabelList: function() {
    return labelTool.labelListAnno;
  },

  changeFrame: function(id, data) {
    annotationObjects.clear();
    labelTool.cubeArray = [];
    labelTool.spriteArray = [];
    labelTool.savedFrames = [];
    annotationObjects.contents = [];
    for (let i = 0; i < labelTool.numFrames; i++) {
      labelTool.cubeArray.push([]);
      labelTool.spriteArray.push([]);
      labelTool.savedFrames.push([]);
      annotationObjects.contents.push([]);
    }
    this.removeObject("pointcloud-scan-" + labelTool.currentFileIndex);
    this.removeObject(
      "pointcloud-scan-no-ground-" + labelTool.currentFileIndex
    );

    // bring current image into background instead of removing it
    if (labelTool.pointCloudOnlyAnnotation === false) {
      this.setPanelSize(id);
    }

    // remove all 3D BB objects from scene
    for (let i = labelTool.scene.children.length; i >= 0; i--) {
      let obj = labelTool.scene.children[i];
      labelTool.scene.remove(obj);
    }
    // remove all 2D BB objects from camera images
    remove2DBoundingBoxes();
    // remove all class labels in point cloud or bird eye view
    $(".class-tooltip").remove();
    // remove all folders
    // empty all folder arrays
    annotationObjects.folderBoundingBox3DArray = [];
    annotationObjects.folderPositionArray = [];
    annotationObjects.folderRotationArray = [];
    annotationObjects.folderSizeArray = [];
    if (labelTool.pointCloudOnlyAnnotation === false) {
      this.loadImageData(data);
    }
  },

  // addResizeEventForImage: function () {
  //     $(window).unbind("resize");
  //     $(window).resize(function () {
  //         // keepAspectRatio();
  //     });
  // },

  addResizeEventForPCD: function() {
    $(window).unbind("resize");
    $(window).resize(function() {
      $(function() {
        if ($("#image-cam-front-left").css("display") === "block") {
          let windowWidth = $("#label-tool-wrapper").width();
          let width = windowWidth / 4 > 100 ? windowWidth / 4 : 100;
          let height = (width * 5) / 8;
          // changeCanvasSize(width, height);
        }
      });
    });
  },

  resetBoxes: function() {
    for (
      let i = 0;
      i < annotationObjects.contents[labelTool.currentFileIndex].length;
      i++
    ) {
      let obj = annotationObjects.contents[labelTool.currentFileIndex][i];
      let cubeObj = labelTool.cubeArray[labelTool.currentFileIndex][i];
      if (obj["original"] !== undefined) {
        if (obj["original"]["class"] !== undefined) {
          if (obj["class"] !== obj["original"]["class"]) {
            obj["class"] = obj["original"]["class"];
            // TODO: update color in 6 cam images and in BEV

            if (labelTool.selectedMesh !== undefined) {
              // TODO: update class in classpicker if selected object not undefined
            }
          }
        }
        if (obj["original"]["x"] !== undefined) {
          obj["x"] = obj["original"]["x"];
          cubeObj["position"]["x"] = obj["original"]["x"];
        }
        if (obj["original"]["y"] !== undefined) {
          obj["y"] = obj["original"]["y"];
          cubeObj["position"]["y"] = obj["original"]["y"];
        }
        if (obj["original"]["z"] !== undefined) {
          obj["z"] = obj["original"]["z"];
          cubeObj["position"]["z"] = obj["original"]["z"];
        }
        if (obj["original"]["width"] !== undefined) {
          obj["width"] = obj["original"]["width"];
          cubeObj["scale"]["x"] = obj["original"]["width"];
        }
        if (obj["original"]["length"] !== undefined) {
          obj["length"] = obj["original"]["length"];
          cubeObj["scale"]["y"] = obj["original"]["length"];
        }
        if (obj["original"]["height"] !== undefined) {
          obj["height"] = obj["original"]["height"];
          cubeObj["scale"]["z"] = obj["original"]["height"];
        }
        if (obj["original"]["rotationYaw"] !== undefined) {
          obj["rotationYaw"] = obj["original"]["rotationYaw"];
          cubeObj["rotation"]["z"] = obj["original"]["rotationYaw"];
        }
        if (obj["original"]["rotationPitch"] !== undefined) {
          obj["rotationPitch"] = obj["original"]["rotationPitch"];
          cubeObj["rotation"]["x"] = obj["original"]["rotationPitch"];
        }
        if (obj["original"]["rotationRoll"] !== undefined) {
          obj["rotationRoll"] = obj["original"]["rotationRoll"];
          cubeObj["rotation"]["y"] = obj["original"]["rotationRoll"];
        }
      }
    }
  },

  updateXCoord: function(valueX, bboxTrackId, bboxClass) {
    if (bboxClass != null) {
      annotationObjects.changeXCoord(valueX, bboxTrackId, bboxClass);
      labelTool.isAnyChange = true;
    }
  },
  updateYCoord: function(valueY, bboxTrackId, bboxClass) {
    if (bboxClass != null) {
      annotationObjects.changeYCoord(valueY, bboxTrackId, bboxClass);
      labelTool.isAnyChange = true;
    }
  },
  updateZCoord: function(valueZ, bboxTrackId, bboxClass) {
    if (bboxClass != null) {
      annotationObjects.changeZCoord(valueZ, bboxTrackId, bboxClass);
      labelTool.isAnyChange = true;
    }
  },
  updateRotationYaw: function(valueYaw, bboxTrackId, bboxClass) {
    if (bboxClass != null) {
      annotationObjects.changeRotationYaw(valueYaw, bboxTrackId, bboxClass);
      labelTool.isAnyChange = true;
    }
  },
  updateRotationPitch: function(valuePitch, bboxTrackId, bboxClass) {
    if (bboxClass != null) {
      annotationObjects.changeRotationPitch(valuePitch, bboxTrackId, bboxClass);
      labelTool.isAnyChange = true;
    }
  },
  updateRotationRoll: function(valueRoll, bboxTrackId, bboxClass) {
    if (bboxClass != null) {
      annotationObjects.changeRotationRoll(valueRoll, bboxTrackId, bboxClass);
      labelTool.isAnyChange = true;
    }
  },
  updateBboxLength: function(
    valueLength,
    bboxTrackId,
    bboxClass,
    xCoord,
    yCoord
  ) {
    if (bboxClass != null) {
      annotationObjects.changeBboxLength(
        valueLength,
        bboxTrackId,
        bboxClass,
        xCoord,
        yCoord
      );
      labelTool.isAnyChange = true;
    }
  },
  updateBboxWidth: function(
    valueWidth,
    bboxTrackId,
    bboxClass,
    xCoord,
    yCoord
  ) {
    if (bboxClass != null) {
      annotationObjects.changeBboxWidth(
        valueWidth,
        bboxTrackId,
        bboxClass,
        xCoord,
        yCoord
      );
      labelTool.isAnyChange = true;
    }
  },
  updateBboxHeight: function(valueHeight, bboxTrackId, bboxClass, zCoord) {
    if (bboxClass != null) {
      annotationObjects.changeBboxHeight(
        valueHeight,
        bboxTrackId,
        bboxClass,
        zCoord
      );
      labelTool.isAnyChange = true;
    }
  },

  handlePressKey: function(code, value) {
    if (code === 13) {
      this.jumpFrame();
    }
  },
};

function setObjectParameters(annotationObj) {
  let params = {
    class: annotationObj["class"],
    x: annotationObj["x"],
    y: annotationObj["y"],
    z: annotationObj["z"],
    width: annotationObj["width"],
    length: annotationObj["length"],
    height: annotationObj["height"],
    rotationYaw: parseFloat(annotationObj["rotationYaw"]),
    rotationPitch: parseFloat(annotationObj["rotationPitch"]),
    rotationRoll: parseFloat(annotationObj["rotationRoll"]),
    channels: [
      {
        rect: [],
        projectedPoints: [],
        lines: [],
        channel: "",
      },
      {
        rect: [],
        projectedPoints: [],
        lines: [],
        channel: "",
      },
      {
        rect: [],
        projectedPoints: [],
        lines: [],
        channel: "",
      },
      {
        rect: [],
        projectedPoints: [],
        lines: [],
        channel: "",
      },
      {
        rect: [],
        projectedPoints: [],
        lines: [],
        channel: "",
      },
      {
        rect: [],
        projectedPoints: [],
        lines: [],
        channel: "",
      },
    ],
  };
  for (let i = 0; i < annotationObj["channels"].length; i++) {
    let channelObj = annotationObj["channels"][i];
    if (channelObj.channel !== undefined) {
      params["channels"][i]["channel"] = channelObj.channel;
    }
  }
  return params;
}

function getIndexByDimension(width, length, height) {
  for (let obj in annotationObjects.contents[labelTool.currentFileIndex]) {
    let annotation =
      annotationObjects.contents[labelTool.currentFileIndex][obj];
    if (
      annotation.width === width &&
      annotation.length === length &&
      annotation.height === height
    ) {
      return annotationObjects.contents[labelTool.currentFileIndex].indexOf(
        annotation
      );
    }
  }
  return -1;
}

function draw2DProjections(params) {
  for (let i = 0; i < params.channels.length; i++) {
    if (
      params.channels[i].channel !== undefined &&
      params.channels[i].channel !== ""
    ) {
      params.channels[
        i
      ].projectedPoints = annotationObjects.calculateProjectedBoundingBox(
        params.x,
        params.y,
        params.z,
        params.width,
        params.length,
        params.height,
        params.channels[i].channel,
        params.rotationYaw,
        params.rotationPitch,
        params.rotationRoll
      );
      // calculate line segments
      let channelObj = params.channels[i];
      if (
        params.channels[i].projectedPoints !== undefined &&
        params.channels[i].projectedPoints.length === 8
      ) {
        // let horizontal = params.width > params.length;
        // params.channels[i].lines = Service3D.calculateAndDrawLineSegments(
        //   channelObj,
        //   params.class,
        //   horizontal,
        //   false
        // );
      }
    }
  }
}

function numberToText(n) {
  if (n === 0) {
    return "";
  } else if (n <= 19) {
    let textNumbers = [
      "One",
      "Two",
      "Three",
      "Four",
      "Five",
      "Six",
      "Seven",
      "Eight",
      "Nine",
      "Ten",
      "Eleven",
      "Twelve",
      "Thirteen",
      "Fourteen",
      "Fifteen",
      "Sixteen",
      "Seventeen",
      "Eighteen",
      "Nineteen",
    ];
    return textNumbers[n - 1];
  } else if (n <= 99) {
    let textNumbers = [
      "Twenty",
      "Thirty",
      "Forty",
      "Fifty",
      "Sixty",
      "Seventy",
      "Eighty",
      "Ninety",
    ];
    let firstPart = textNumbers[Math.floor(n / 10) - 2];
    let secondPart = numberToText(n % 10);
    if (secondPart === "") {
      return firstPart;
    } else {
      return firstPart + "_" + secondPart;
    }
  } else if (n === 100) {
    return "Hundred";
  }
}

function remove2DBoundingBoxes() {
  for (
    let i = 0;
    i < annotationObjects.contents[labelTool.currentFileIndex].length;
    i++
  ) {
    for (
      let j = 0;
      j <
      annotationObjects.contents[labelTool.currentFileIndex][i].channels.length;
      j++
    ) {
      for (
        let k = 0;
        k <
        annotationObjects.contents[labelTool.currentFileIndex][i].channels[j]
          .lines.length;
        k++
      ) {
        let line =
          annotationObjects.contents[labelTool.currentFileIndex][i].channels[j]
            .lines[k];
        if (line !== undefined) {
          line.remove();
        }
      }
    }
  }
}

// $("#previous-frame-button").keyup(function (e) {
//     if (e.which === 32) {
//         return false;
//     }
// });

// $("#next-frame-button").keyup(function (e) {
//     if (e.which === 32) {
//         return false;
//     }
// });

function takeScreenshot() {
  let imgData = pcd_param.renderer.domElement.toDataURL();
  labelTool.frameScreenshots.push(imgData);
}

function getZipVideoFrames() {
  let zip = new JSZip();
  // for (let i = 0; i < 899; i++) {
  for (let i = 0; i < 449; i++) {
    let substring = labelTool.frameScreenshots[i].substring(
      22,
      labelTool.frameScreenshots[i].length
    );
    let byteArray = Base64Binary.decodeArrayBuffer(substring);
    zip.file(pad(i, 6) + ".png", byteArray);
  }
  return zip;
}

function initScreenshotTimer() {
  labelTool.timeElapsedScreenshot = 0;
  let screenshotIntervalHandle = setInterval(function() {
    // increase elapsed time every second
    labelTool.timeElapsedScreenshot = labelTool.timeElapsedScreenshot + 1;
    // take screenshot every 2 seconds
    if (labelTool.takeCanvasScreenshot === true) {
      if (labelTool.currentFileIndex < labelTool.numFramesNuScenes) {
        takeScreenshot();
        labelTool.changeFrame(labelTool.currentFileIndex + 1);
      } else {
        labelTool.takeCanvasScreenshot = false;
        let zip = getZipVideoFrames();
        zip.generateAsync({ type: "blob" }).then(function(content) {
          saveAs(
            content,
            labelTool.currentDataset +
              "_" +
              labelTool.sequence +
              "_video_frames.zip"
          );
        });
      }
    } else {
      clearInterval(screenshotIntervalHandle);
    }
  }, labelTool.timeDelayScreenshot);
}

function initPlayTimer() {
  labelTool.timeElapsedPlay = 0;
  let playIntervalHandle = setInterval(function() {
    labelTool.timeElapsedPlay = labelTool.timeElapsedPlay + 1;
    if (labelTool.playSequence === true) {
      if (labelTool.currentFileIndex < labelTool.numFrames) {
        labelTool.changeFrame(labelTool.currentFileIndex + 1);
      } else {
        clearInterval(playIntervalHandle);
      }
    } else {
      clearInterval(playIntervalHandle);
    }
  }, labelTool.timeDelayPlay);
}
export default baseLabelTool;
