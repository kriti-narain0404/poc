import { VueEditor } from "vue2-editor";
import HomeHeader from "../../../shared/HomeHeader.vue";
import {
	GET_SETTING_OBJ_DATA,
	SAVE_TEXT_MODERATION_QUERY,
	GET_TEXT_MODERATION_QUERY,
} from "../../../constants/graphql";
import SettingService from "../../../services/SettingService.js";
import TextEditorModel from "../../../model/TextEditorModel.js";
import { quill } from "quill";

var filePath;
var fromFile = 1;
var fileName, finalPath;
var userid, projectId, video_id, video_type;
var settingData,
	moderationSettings = [];	
var text,
	currentNode = [],
	taggedText = [],
	textArray = [],
	intentArray = [];
let regex_start = /<span(\s[\w="-:;]*)*(\sid="([\w-]*)")(\stitle="([\w\s-]*)")(\s[\w="-:;]*)*>/;
let regex_end = /<\/span>/;

export default {
	name: "textEditor",
	components: {
		HomeHeader,
		VueEditor,
	},
	data() {
		return TextEditorModel; // Moved to model EditorModel
	},
	apollo: {
		getSettingObject: {
			query: GET_SETTING_OBJ_DATA,
			variables() {
				userid = SettingService.getSelectedUserId();
				projectId = SettingService.getSelectedProject();
				video_id = 60;
				return {
					userid,
					projectId,
					fromFile,
					video_id,
				};
			},
			result({ data, loader, networkStatus }) {
				settingData = JSON.parse(data.getSettingObject.settingObject);
				// this.folderPath = data.getSettingObject.folderPath;
				// filePath = this.folderPath + "text/";
				 console.log('settingData',settingData);
				settingData.forEach((element) => {
					if (element.type === "Text Moderation") {
						moderationSettings.push(element);
					}
				});
				try {
					this.paramObj = [];
					this.imageTagObj = [];
					this.classObj = [];
					this.subclassObj = [];
					this.classObjNames = [];
					let cnt = 0;
					let paramCnt = 0;
					if (moderationSettings != null) {
						for (var i = 0; i < moderationSettings.length; i++) {
							if (moderationSettings[i].selected === true) {
								this.classObj.push({
									id: moderationSettings[i].id,
									name: moderationSettings[i].name,
									selected: moderationSettings[i].selected,
									type: moderationSettings[i].type,
									color: moderationSettings[i].color,
									length: moderationSettings[i].length,
								});
								this.classObjNames.push(moderationSettings[i].name);
								if (moderationSettings[i].parameters) {
									for (
										var j = 0;
										j < moderationSettings[i].parameters.length;
										j++
									) {
										if (moderationSettings[i].parameters[j].selected === true) {
											this.paramObj.push({
												id: moderationSettings[i].parameters[j].id,
												name: moderationSettings[i].parameters[j].name,
												selected: moderationSettings[i].parameters[j].selected,
												type: moderationSettings[i].parameters[j].type,
												color: moderationSettings[i].parameters[j].color,
												paralength: moderationSettings[i].parameters[j].length,
											});
											this.classObj[cnt]["param"] = this.paramObj;
											if (
												moderationSettings[i].parameters[j].subClass &&
												moderationSettings[i].parameters[j].subClass !==
													undefined
											) {
												for (
													var k = 0;
													k <
													moderationSettings[i].parameters[j].subClass.length;
													k++
												) {
													if (
														moderationSettings[i].parameters[j].subClass[k]
															.selected === true
													) {
														this.subclassObj.push({
															id:
																moderationSettings[i].parameters[j].subClass[k]
																	.id,
															name:
																moderationSettings[i].parameters[j].subClass[k]
																	.name,
															selected:
																moderationSettings[i].parameters[j].subClass[k]
																	.selected,
															type:
																moderationSettings[i].parameters[j].subClass[k]
																	.type,
															color:
																moderationSettings[i].parameters[j].subClass[k]
																	.color,
															paralength:
																moderationSettings[i].parameters[j].subClass[k]
																	.length,
														});
														this.classObj[cnt].param[paramCnt][
															"subClass"
														] = this.subclassObj;
													}
												}
												this.subclassObj = [];
											}
											paramCnt = paramCnt + 1;
										}
									}
									this.paramObj = [];
									paramCnt = 0;
								}
								cnt = cnt + 1;
							}
						}
					}
				} catch (error) {
					console.log("Error:", error);
				}
				// this.folderPath = data.getSettingObject.folderPath;
				// filePath = this.folderPath + "text/";
				// console.log(settingData);
			},
		},
	},
	methods: {
		/*****************************************************Starter Code -> Mounted*********************************************************************/

		loadTextEditor: function() {
			try {
				let editor;
				userid = SettingService.getSelectedUserId();
				projectId = SettingService.getSelectedProject();
				video_id = this.$route.query.videoid;
				this.videoName = this.$route.query.videoname;
				video_type = this.$route.query.video_type;

				video_id = parseInt(video_id);
				video_type = parseInt(video_type);

				$(".ql-editor").attr("contenteditable", "false");
			} catch (error) {
				console.log("Error", error);
			}
		},

		/*********************************************************GET/POST API************************************************************************/
		getSavedContent: function() {
			try {
				this.$apollo
					.mutate({
						mutation: GET_TEXT_MODERATION_QUERY,
						variables: {
							project_id: projectId,
							userid: userid,
							videoid: video_id,
							video_type: video_type,
							file: "NAT.txt",
							video_name: this.videoName,
						},
					})
					.then((data) => {
						this.content = data.data.getTextModerationObject.text;

						this.htmlContent += this.content;
						this.textAnnos = JSON.parse(
							data.data.getTextModerationObject.annos
						);
					});
			} catch (error) {
				console.log("Error", error);
			}
		},
		handleSavingContent: function() {
			try {
				finalPath = filePath + `${fileName}`;
				var fileContent = this.content;
				var filepath = finalPath;
				//this.saving = true;
				this.createAnnotations();
				console.log(this.saveAnnos);
				this.$apollo
					.mutate({
						mutation: SAVE_TEXT_MODERATION_QUERY,
						variables: {
							project_id: projectId,
							userid: userid,
							videoid: video_id,
							annos: JSON.stringify(this.saveAnnos),
							video_type: 3,
							file: "NAT.txt",
						},
					})
					.then((data) => {
						var self = this;
						self.showNotification = true;
						setTimeout(() => {
							self.showNotification = false;
						}, 5000);

						// this.getSavedContent();
					});
			} catch (error) {
				console.log("Error", error);
			}
		},
		// /***********************************************************CRUD******************************/

		getRandId: function() {
			let random_id_generated = Math.random()
				.toString(36)
				.substr(2, 4);
			//editormodel script
			let manual_anno_id = "A-" + random_id_generated;
			return manual_anno_id;
		},
		getSelectedText: function() {
			var selectedText = "";

			// window.getSelection
			if (window.getSelection) {
				selectedText = window.getSelection();
			}
			// document.getSelection
			else if (document.getSelection) {
				selectedText = document.getSelection();
			}
			// document.selection
			else if (document.selection) {
				selectedText = document.selection.createRange().text;
			} else return;
			// To write the selected text into the textarea
			console.log(selectedText);
		},

		addIdToSpan: function() {
			let editorText;
			this.htmlContent = "";
			editorText = $(".ql-editor").html();
			this.currentIntent = "";
			this.htmlContent += editorText;
		},

		allAnnotations: function(id, pos, intent) {
			this.saveAnnos.push({ id: id, pos: pos, intent: intent });
		},
		createAnnotations: function() {
			try {
				// let str = this.htmlContent;
				// let start_m, end_m;
				// start_m = regex_start.exec(str);
				// while (start_m !== null) {
				// 	str = str.replace(regex_start, "");
				// 	end_m = regex_end.exec(str);
				// 	str = str.replace(regex_end, "");
				// 	this.pos.push(start_m.index - 3, end_m.index - 3);
				// 	this.id += start_m[3];
				// 	this.markedIntent += start_m[5];
				// 	console.log("Data", this.id, this.pos, this.markedIntent);
				// 	this.allAnnotations(this.id, this.pos, this.markedIntent);
				// 	this.pos = [];
				// 	start_m = regex_start.exec(str);
				// 	this.markedIntent = "";
				// 	this.id = "";
			} catch (error) {
				console.log("Error", error);
			}
		},
		//**********************************************************Event Handlers******************************************************//
		// onHoverHandler: function(textObject) {
		// 	if (textObject !== undefined && textObject.text !== undefined) {
		// 		var self = this;
		// 		var editor,
		// 			highLightedNode = [];
		// 		[editor] = $(".ql-editor");
		// 		for (let i = 0; i < editor.childNodes.length; i++) {
		// 			highLightedNode = editor.childNodes[i].childNodes;
		// 			for (let j = 0; j < editor.childNodes[i].childNodes.length; j++) {
		// 				if (
		// 					highLightedNode[j].innerText !== undefined &&
		// 					highLightedNode[j].innerText !== ""
		// 				) {
		// 					if (highLightedNode[j].innerText === textObject.text) {
		// 						$("span").hover(
		// 							function() {
		// 								if (textObject.text === $(this).text()) {
		// 									self.showPopUp = true;
		// 									this.intentOfText = textObject.intent;
		// 									self.intentText[0] = this.intentOfText;
		// 								}
		// 							},
		// 							function() {
		// 								this.showPopUp = false;
		// 							}
		// 						);
		// 					}
		// 				}
		// 			}
		// 		}
		// 	}
		// },

		onHighlighSelect: function() {
			var self = this;
			let containerDiv = document.querySelector(".ql-editor");
			let selectionCordinates = {};
			$(containerDiv).mousedown(function(event) {
				let rect = containerDiv.getBoundingClientRect();
				let x = event.clientX - rect.left;
				let y = event.clientY - rect.top;
				selectionCordinates.start = { x, y };
			});

			$(containerDiv).mouseup(function(event) {
				var selection = document.getSelection();
				var selection_text = selection.toString();
				var span = document.createElement("SPAN");
				const id= Math.random().toString(36).substr(2, 4);
				console.log('rand id',id)
				span.setAttribute('id', 'selection_text');
				span.textContent = selection_text;
				//span.style.backgroundColor = "yellow";
				span.style.border = "1px solid red";
				span.style.color ="#fff"
				span.style.position="relative"
				// this.currentObject={
				// 	id: id,
				// 	content: selection_text,
				// 	classAttr:{} 
				// }
				if (selection_text !== "") {
				var textspan = document.createElement("span");
				textspan.style.backgroundColor = "var(--primary-blue)";
				//textspan.style.border = "1px solid red";
				//textspan.style.color ="var(--gray-0)";
				//textspan.style.position= "absolute";
				textspan.textContent="Class Requred"
				textspan.setAttribute('class', 'text-tooltip');
				textspan.setAttribute('id', "class_requred");
				span.appendChild(textspan);
				// this.currentObject.classAttr={
				// 	classId:'',
				// 	className:"class_requred",
				// 	color: '#fff',
				// 	attr:{
				// 		name:'',
				// 		value:''
				// 	}
				// }
				}
				
				// Get the parent and child node elements
// const parentNode = document.getElementById('parent');
// const newChildNode = document.createElement('div');
// newChildNode.textContent = 'This is a new child node';

// // Get an existing child node to use as a reference (optional)
// const existingChildNode = parentNode.firstChild; // Get the first child


// // Append the new child to the end of the parent
// parentNode.appendChild(newChildNode);


// // Insert before an existing child
// parentNode.insertBefore(newChildNode, existingChildNode);


// // Replace an existing child with the new child
// parentNode.replaceChild(newChildNode, existingChildNode);
				var range = selection.getRangeAt(0);

				range.deleteContents();
				range.insertNode(span);
                selection.removeAllRanges();
				if (selection_text !== "") {
					this.currentText = selection_text;

					self.isTagOpen = true;
				}
			});
		},

		/*******************************************************Saving Intent Settings************************************************************************/
		giveLabel: function(item, index) {
			//console.log('Current Object', TextEditorModel);

			if (item.name !== undefined) {
				console.log('item', item);
				this.currentIntent = item.name;	
				 $("#class_requred").text(this.currentIntent);
				 $("#class_requred").attr('id', item.id )
                 $("#selection_text").css({'background-color' : item.color, 'color': "var(--gray-1)"});
				 $("#selection_text").attr('id', '' )
				this.addIdToSpan();
				this.radioSelect= null
			}
		},
		getThemeMode: function() {
			this.isDarkMode = SettingService.getDarkMode();
		  },
	},

	// Vue Life Cycle Events/*
	mounted: function() {
		this.loadTextEditor();
		this.getSavedContent();
		this.onHighlighSelect();
		this.getThemeMode();
	},
};
