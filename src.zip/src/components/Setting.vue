<template>
  <v-app :dark = "isDarkMode == true">
    <home-header/>
    <input type="text" name :value="getUserId" style="display:none">
    <input type="text" name :value="disableBack" style="display:none">
  <main>
  <div class="settings-container">
            <v-layout xs12 row wrap heading-row class="tab-btn-container">
             <v-btn-toggle v-model="selectedTab" mandatory>
                <v-btn value="objects">Objects</v-btn>
                <v-btn value="configuration">Configuration</v-btn>
             </v-btn-toggle>
            </v-layout>
             <v-container v-if="selectedTab=='objects'" fluid class="page-content-container  objects-container">
                  <v-layout row wrap>          
                    <v-flex xs12 sm12 d-flex>
                      <v-layout row wrap>
                          <v-layout row wrap v-bind:class="role !='ADMIN' ? 'scroll-except-admin' : 'scroll-admin'">
                                <v-flex xs11 class="catogery-container" v-for="heading in allKeys">
                                    <h5 class="category-title">Category: <span>{{heading.charAt(0).toUpperCase() + heading.slice(1)}}</span></h5> 
                                  <v-layout row wrap class="class-option-background class-card-container">
                                      <v-flex xs2 class="single-class-card" v-for="(e,index) in finalSettingObj[heading]" :key="e.id">
                                        <div class="custom-control custom-checkbox class-title">
                                          <span>
                                          <input type="checkbox" class="select-unselect-layout" @click="selectSettingClassData(e)" v-bind:value="e.selected"
                                                    v-model="e.selected">
                                          <label class="custom-control-label class-label" :title=e.name for="checkobj">{{ e.name }}</label></span>
                                        </div>
                                      <div class="attribute-container">
                                      <v-flex class="single-attribute" xs12 v-for="(item,index) in e.parameters" :key="item.id">
                                          <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="select-unselect-layout" v-if="item.length == 0" id="checkparam + index" @click="selectSettingParamData(item)" v-bind:value="item.selected"
                                                v-model="item.selected">
                                            <label class="custom-control-label" for="checkparam" :title=item.name v-if="item.length == 0"><a class="terms" href="javascript:void(0)" @click="openSubParamList(item.subClass, item.name, e.name)">{{ item.name }}</a></label>                                            
                                          </div>
                                      </v-flex>
                                      </div>
                                      </v-flex>
                                  </v-layout>
                                </v-flex>
                          </v-layout>
                      </v-layout>
                    </v-flex>
                  </v-layout>
                 <v-flex xs12 class="button-style">
                   <v-btn  @click="AddObjectDialog = true" v-if="role=='ADMIN'" class="cust-btn danger-btn add-btn">Update Settings</v-btn>
                   <v-btn @click="saveSettingObj()" class="cust-btn cust-submit-btn cust-primary-btn">Submit</v-btn>
                </v-flex>
                   <v-dialog
              v-model="AddObjectDialog"
              class="dialog-style"
              v-if="AddObjectDialog==true"
              persistent
              light
              >

          <v-layout>
            <v-flex class="dialog-container form-container">
              <h3 class="dialog-title">Add New Object</h3>
              <v-flex setting-object-form v-if="role =='ADMIN'" class="dialog-form-container">
                                <v-flex class="input-container">
                                <v-flex class="flex-container">
                                <h3 class="input-label text-align--left">Object Category</h3>
                                </v-flex>
                                <input label="Object Category" id="objectType" v-model="objectType"
                              v-if="editCategory ==true" @dblclick="editObjectCategory()" class="field-settings cust-input-field" solo></input>
                              <v-select :items="category" v-model="objectType" label="Object Category"
                              v-if="editCategory ==false" @dblclick="editObjectCategory()" @input="changeObjectClass()" class="field-settings field-settings cust-input dropdown" solo></v-select>
                              </v-flex>
                              <v-flex class="input-container"> 
                              <v-flex class="flex-container">
                                <h3 class="input-label text-align--left">Object Class</h3>
                                </v-flex>
                                <input class="field-settings cust-input-field" solo label="Object Class" id="className" v-model="className"
                                  v-if="editClass ==true || editCategory ==true" @dblclick="editObjectClass()"></input>
                                <v-select class="field-settings field-settings cust-input dropdown" solo :items="objectClass" v-model="className" label="Object Class"
                              v-if="editClass ==false && editCategory ==false" @dblclick="editObjectClass()" @input="changeObjectParam()"></v-select>
                              </v-flex>
                                <v-flex class="input-container">
                                <v-flex class="flex-container">
                                <h3 class="input-label text-align--left">Object Attributes</h3>
                                </v-flex>
                              <input class="field-settings cust-input-field" solo label="Object Attributes" id="objectParam" v-model="objectParam"
                              v-if="editParam ==true || editCategory ==true" @dblclick="editObjectParam()"></input>
                              <v-select :items="parameterClass" v-model="objectParam" label="Object Attributes"
                              v-if="editParam ==false && editCategory ==false" @dblclick="editObjectParam()" class="field-settings field-settings cust-input dropdown" solo></v-select>
                                </v-flex>
                             <div class="error-message-container">
                            <span v-show="required==true" class="error-message">Object class and Attributes are required</span>
                            <span v-show="isObjectExist==true" class="error-message">{{ objectExistMessage }}</span>
                            <span v-show="isParameterExist==true" class="error-message">{{ paramExistMessage }}</span>
                            </div>
                        </v-flex>
                        <img class="close-btn" src="../assets/icon/close-cross.svg" @click="closeAddObjDialog()" alt="">
                    <v-flex class=" dialog-btn-container flex-container justify-cont--center ">
                      <v-btn  @click="checkExistingObject(className, objectType, objectParam)" v-if="role=='ADMIN'" class="cust-btn cust-primary-btn submit-btn">Add</v-btn>
                 <!-- <v-btn fab medium dark v-if="role=='ADMIN'" @click="deleteSettingObject()" class="objects-button-style danger-btn delete-btn"><img src="../assets/icon/trash.svg"></v-btn> -->
                      <v-btn class="cust-btn danger-btn" @click="deleteSettingObject()">Delete</v-btn>
                    </v-flex>
                 </v-flex>
                </v-layout>
                   </v-dialog>
                   <v-dialog
                      v-model="isQueryError"
                      persistent
                      width="auto"
                      class="dialog-container"
                      v-if="isQueryError ==true">
                      <v-card>
                        <v-card-title class="dialog-title">
                          <v-layout row wrap>
                            <v-flex>
                              <v-subheader>
                              <p class="dialog-header"><b>Something went wrong, please contact with admin.</b>  <br> {{"Error Message: "}} {{this.queryErrorResult}}</p>
                              </v-subheader>
                            </v-flex>
                          </v-layout>
                        </v-card-title>
                        <v-card-actions>
                          <v-spacer></v-spacer>
                          <v-btn class="action-button cust-btn cust-primary-btn " flat to="/login" @click="sessionStorage.clear()" @click.native="isQueryError = false">OK</v-btn>
                        </v-card-actions>
                      </v-card>
                   </v-dialog>
                   <v-dialog
                  persistent
                    v-model="openList"
                    width="50%"
                    class="dialog-container"
                    v-if="openList == true"
                  >
                     <v-card class="add-sub-class-dialog">
                      <div class="input-container" v-if="role =='ADMIN'">
                          <input type="textbox" class="" id="subTextbox" v-model="subclassName" placeholder="Sub-Class">                     
                          <v-btn small class="cust-primary-btn cust-btn add-class-btn" @click="validateSubclass(subclassName)"><img src="../assets/icon/plus.svg" alt="">ADD</v-btn>
                          <span v-show="isSubclassExist==true" class="error-message">{{ subclassExistMessage }}</span>
                          <span v-show="subclassNameError==true" class="error-message">{{ "subClass only contains whitespace (ie. spaces, tabs or line breaks)" }}</span>
                      </div>
                      <v-layout row wrap class="sub-class-container">
                              <v-flex xs2  v-for="(item,index) in showParamList" :key="item.id" class="single-sub-class">
                                      <input type="checkbox" class="select-unselect-layout" v-on:change="getSubclassSelected()" id="checkClass + index" v-bind:value="item.selected"
                                                v-model="item.selected">
                                      <label :title=item.name class="sub-class-label" for="checkTerms">{{ item.name }}</label>
                              </v-flex>
                      </v-layout>
            
                      <v-card-actions>
                        <v-spacer></v-spacer>  
                        <img class="close-btn" src="../assets/icon/close-cross.svg" v-if="!subclassSelectedFlag" @click="openList = false; subclassNameError = false" alt="">
                        <span v-show="subclassSelectedFlag" class="error-message"> Please select at least on sub class to continue </span>
                        <v-btn small class="action-button cust-btn danger-btn" v-if="role=='ADMIN'" @click="deleteSubclass(subclassName)">Delete</v-btn>
                      </v-card-actions>
                    </v-card>
                   </v-dialog>
             </v-container>
             <v-container v-if="selectedTab=='configuration'" fluid class="page-content-container configuration-container">
            <section class="settings-section">
              <v-flex xs12 sm11>
                        <v-flex xs12 class="input-container">
                           <h3 class="input-label">Model Selection</h3>
                           <v-flex class="field-container width--half">
                            <v-select :items="items" v-model="modelSelection" :error-messages="modelSelectionErrors" required @change="$v.modelSelection.$touch()" @blur="$v.modelSelection.$touch()" :disabled="role =='VALIDATOR' || role =='ANNOTATOR'"   label="Model Selection"  class="field-settings cust-input dropdown" solo></v-select>
                           </v-flex>
                         </v-flex> 
                        <v-flex xs12 class="input-container">
                           <h3 class="input-label">Load Type</h3>
                           <v-flex class="field-container width--half">
                            <v-select :items="loadType" v-model="radioValue" :error-messages="radioValueErrors" required  label="Model Selection" :disabled="role =='VALIDATOR' || role =='ANNOTATOR'" class="field-settings cust-input dropdown" solo></v-select>
                           </v-flex>
                         </v-flex> 
                        <v-flex xs12 class="input-container">
                           <h3 class="input-label">Output Format</h3>
                           <v-flex class="field-container width--half">
                            <v-select :items="items" v-model="outputFormat" label="Output Format" :disabled="role =='VALIDATOR'|| role =='ANNOTATOR'" class="field-settings cust-input dropdown" solo></v-select>
                           </v-flex>
                         </v-flex> 
                        <v-flex xs12 class="input-container">
                           <h3 class="input-label">Image Source Path</h3>
                           <v-flex class="field-container width--half">
                            <input label="Image source path" v-model="folderPath" :error-messages="pathErrors"  required @input="$v.folderPath.$touch()" @blur="$v.folderPath.$touch()" :disabled="role =='VALIDATOR'|| role =='ANNOTATOR'" class="field-settings cust-input-field " solo></input>
                           </v-flex>
                         </v-flex> 
                        <v-flex xs12 class="input-container">
                           <h3 class="input-label">Min BB Box</h3>
                         </v-flex> 
                          <v-flex xs12 class="input-container">
                           <h3 class="input-label">Height (px)</h3>
                           <v-flex class="field-container width--half">
                            <input type="number" label="Height (px)" v-model="height" :disabled="role =='VALIDATOR'|| role =='ANNOTATOR'" :error-messages="heightErrors" required @input="$v.height.$touch()" @blur="$v.height.$touch()"  class="field-settings cust-input-field" solo></input>
                           </v-flex>
                         </v-flex> 
                          <v-flex xs12 class="input-container">
                           <h3 class="input-label">Width (px)</h3>
                           <v-flex class="field-container width--half">
                            <input type="number" label="Width (px)" v-model="width" :error-messages="widthErrors" :disabled="role =='VALIDATOR'|| role =='ANNOTATOR'" required @input="$v.width.$touch()" @blur="$v.width.$touch()"  class="field-settings cust-input-field" solo></input>
                           </v-flex>
                         </v-flex> 
                          <v-flex xs12 class="input-container">
                           <h3 class="input-label">Frames to Interpolate</h3>
                           <v-flex class="field-container width--half">
                            <input type="number" label="Frames to Interpolate" v-model="FramesToInterpolate" :disabled="role =='VALIDATOR'|| role =='ANNOTATOR'"    class="field-settings cust-input-field" solo></input>
                           </v-flex>
                         </v-flex> 
                        
                          <v-btn v-if="role == 'ADMIN'" dark @click="saveSettingObj()" class=" cust-btn cust-primary-btn">Submit</v-btn>

                    </v-flex>
            </section>

    
             </v-container>
  </div>
         </main>

  </v-app>
</template>
<script src="./ToolsJS/2D_js/Setting.js"></script>
<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped src="@/assets/css/main.css"></style>
<style scoped src="@/assets/css/setting.css"></style>

