<template>
  <v-app :dark="isDarkMode == true">
    <home-header />
    <main>
      <div class="dashboard-container">
        <v-layout xs12 row wrap heading-row class="tab-btn-container">
          <v-btn-toggle v-model="selectedTab" mandatory>
            <v-btn value="productivity" @click="selectProductivity()"
              >Productivity</v-btn
            >
            <v-btn
              v-if="role == 'ADMIN'"
              value="accuracy"
              @click="selectAccuracy()"
              >Accuracy</v-btn
            >
          </v-btn-toggle>
        </v-layout>
        <v-layout row wrap class="top-container">
          <v-flex xs5 class="input-container" v-if="role == 'ADMIN' && selectedTab == 'productivity'">
            <h3 class="input-label">Select Validator</h3>
            <v-flex class="field-container">
              <v-select
                class="cust-input dropdown multi-user-select"
                multiple
                placeholder="Select Validator"
                :items="validatorList"
                v-model="selectedValidator"
                id="validators"
                @input="selectAllValToggle(), refreshProductivity()"
                solo
                return-object
              >
              </v-select>
            </v-flex>
          </v-flex>
          <v-flex xs5 class="input-container" v-if="role == 'VALIDATOR' && selectedTab == 'productivity'">
            <h3 class="input-label">Select Annotator</h3>
            <v-flex clas="field-container">
              <v-select
                class="cust-input dropdown multi-user-select"
                multiple
                placeholder="Select Annotator"
                :items="annoNameList"
                v-model="selectedAnnotator"
                id="annotators"
                @input="refreshProductivity(), refreshAccuracy()"
                return-object
                solo
              ></v-select>
            </v-flex>
          </v-flex>
          <v-flex xs7>
            <v-layout row wrap class="date-picker-group-container">
              <v-flex xs4 class="date-picker-container">
                <h3 class="input-label">From</h3>
                <input
                  @input="refreshProductivity(), refreshAccuracy()"
                  v-model="startDate"
                  type="date"
                  placeholder="dd-mm-yyyy"
                  class="cust-input-field"
                  :max="currentDate"
                />
              </v-flex>
              <v-flex xs4 class="date-picker-container">
                <h3 class="input-label">To</h3>
                <input
                  actions
                  @input="refreshProductivity(), refreshAccuracy()"
                  v-model="endDate"
                  type="date"
                  class="cust-input-field"
                  :min="startDate"
                  :max="currentDate"
                />
              </v-flex>
            </v-layout>
          </v-flex>
        </v-layout>

        <v-container
          v-if="selectedTab == 'productivity'"
          fluid
          class="dashboard-container productivity-container"
        >
          <v-layout row wrap class="chart-group-container">
            <!-- <img src="../assets/icon/Loading Graph.gif" id="Chart-Loader" alt=""> -->
            <v-flex
              xs12
              class="single-chart-container hide"
              id="validator-chart-container--admin"
              v-if="role == 'ADMIN'"
            >
              <v-flex xs12 class="title-container">
                <v-layout row wrap>
                  <v-flex xs7>
                    <p class="chart-title">Performance by</p>
                    <span
                      class="selected-names"
                      v-for="key in selectedValidatorList"
                      >{{ key }}</span
                    >
                  </v-flex>
                  <v-flex xs5 d-flex class="justify-cont--end">
                    <div class="chart-color-container">
                      <div class="single-color">
                        <div class="indication-color-box chart-blue"></div>
                        <span>Added Label</span>
                      </div>
                      <div class="single-color">
                        <div class="indication-color-box chart-yellow"></div>
                        <span>Edited Label</span>
                      </div>
                      <div class="single-color">
                        <div class="indication-color-box chart-red"></div>
                        <span>Deleted Label</span>
                      </div>
                    </div>
                  </v-flex>
                </v-layout>
              </v-flex>
              <v-flex xs12 class="container-title">
                <svg
                  viewBox="0 0 600 200"
                  perserveAspectRatio="xMinYMid"
                  id="validator-chart"
                ></svg>
              </v-flex>
            </v-flex>
            <v-flex
              xs12
              class="single-chart-container  hide"
              id="annotator-chart-container--admin"
            >
              <v-flex xs12 class="title-container">
                <v-layout row wrap>
                  <v-flex xs7>
                    <p class="chart-title" v-if="role == 'ADMIN'">
                      Performance by
                    </p>
                    <p
                      v-if="role == 'ADMIN'"
                      id="selected-validator-name"
                      class="selected-names"
                    >
                      {{ validator_name }}
                    </p>
                    <p class="chart-title" v-if="role == 'VALIDATOR'">
                      Performance by
                    </p>
                    <p
                      v-if="role == 'VALIDATOR'"
                      id="selected-validator-name"
                      class="selected-names"
                      v-for="key in selectedAnnotator"
                    >
                      {{ key }}
                    </p>
                  </v-flex>
                  <v-flex xs5 d-flex class="justify-cont--end">
                    <div class="chart-color-container">
                      <div class="single-color">
                        <div class="indication-color-box chart-blue"></div>
                        <span>Added Label</span>
                      </div>
                      <div class="single-color">
                        <div class="indication-color-box chart-yellow"></div>
                        <span>Edited Label</span>
                      </div>
                      <div class="single-color">
                        <div class="indication-color-box chart-red"></div>
                        <span>Deleted Label</span>
                      </div>
                    </div>
                  </v-flex>
                </v-layout>
              </v-flex>
              <v-flex xs12 class="container-title">
                <svg
                  viewBox="0 0 600 200"
                  perserveAspectRatio="xMinYMid"
                  id="annotator-chart"
                ></svg>
              </v-flex>
            </v-flex>
            <v-flex
              xs12
              class="single-chart-container hide"
              id="annotator-date-chart-container--admin"
            >
              <v-flex xs12 class="title-container">
                <v-layout row wrap>
                  <v-flex xs7>
                    <p class="chart-title">Performance by</p>
                    <p
                      v-if="role == 'ADMIN'"
                      id="selected-annotator-name"
                      class="selected-names"
                    ></p>
                  </v-flex>
                  <v-flex xs5 d-flex class="justify-cont--end">
                    <div class="chart-color-container">
                      <div class="single-color">
                        <div class="indication-color-box chart-blue"></div>
                        <span>Added Label</span>
                      </div>
                      <div class="single-color">
                        <div class="indication-color-box chart-yellow"></div>
                        <span>Edited Label</span>
                      </div>
                      <div class="single-color">
                        <div class="indication-color-box chart-red"></div>
                        <span>Deleted Label</span>
                      </div>
                    </div>
                  </v-flex>
                </v-layout>
              </v-flex>
              <v-flex xs12 class="container-title">
                <svg
                  viewBox="0 0 600 200"
                  perserveAspectRatio="xMinYMid"
                  id="annotator-date-chart"
                ></svg>
              </v-flex>
            </v-flex>
          </v-layout>
        </v-container>

        <v-container
          v-if="selectedTab == 'accuracy'"
          fluid
          class="dashboard-container accuracy-container"
        >
          <v-layout row wrap class="chart-group-container">
            <v-flex
              xs12
              class="single-chart-container"
              id="validator-chart-container--admin"
            >
              <v-flex xs12 class="title-container">
                <p class="chart-title accuracy-chart-title">
                  Project Health Chart
                </p>
                <div class="chart-color-container">
                  <div class="single-color">
                    <div class="indication-color-box chart-dark-red"></div>
                    <span>Scheduled Number of Objects</span>
                  </div>
                  <div class="single-color">
                    <div class="indication-color-box chart-dark-blue"></div>
                    <span>Actual Number of Objects</span>
                  </div>
                </div>
              </v-flex>
              <v-flex xs12 class="container-title">
                <!-- <div id="my_dataviz"></div> -->
                <svg
                  viewBox="0 0 600 200"
                  perserveAspectRatio="xMinYMid"
                  id="project-health-chart"
                ></svg>
                <div id="project-health-chart_no-data-text-container" class="no-data-text-container">
                      <p>No data to display</p>
                    </div>
              </v-flex>
            </v-flex>
          </v-layout>
          <v-layout
            row
            wrap
            class="chart-group-container accuracy-group-container"
          >
            <v-flex xs6>
              <v-layout row wrap>
                <v-flex
                  xs11
                  class="single-chart-container accuracy-chart-container"
                >
                  <v-flex class="chart-title-container">
                    <p class="chart-title accuracy-chart-title">
                      Overall Model Accuracy
                    </p>
                  </v-flex>
                  <v-layout row wrap>
                    <v-flex xs12>
                      <v-select
                        class="cust-input dropdown"
                        :items="accuracyUserDate_ModelKeys"
                        placeholder="Select Date"
                        v-model="accuracyModalDate"
                        @input="
                          renderDateAccuracyChart(accuracyUsersData),
                            renderClassAccuracyChart(accuracyUsersData)
                        "
                        solo
                      ></v-select>
                      <!-- <v-btn v-model="accuracyModalDate" :value="date.date" @click="accuracyModalDate=date.date" v-for="date in accuracyUsersData">{{date.date}}</v-btn> -->
                    </v-flex>
                  </v-layout>
                  <v-flex xs12 class="container-title pie-chart-container">
                    <svg
                      viewBox="0 0 600 400"
                      perserveAspectRatio="xMinYMid"
                      id="accuracy-chart--date"
                      class="accuracy-chart"
                    ></svg>
                    <div id="accuracy-chart--date_no-data-text-container" class="no-data-text-container">
                      <p>No data to display</p>
                    </div>
                  </v-flex>
                  <v-flex xs12 class="title-container al-center">
                    <div class="chart-color-container">
                      <div class="single-color">
                        <div class="indication-color-box chart-dark-blue"></div>
                        <span>Total Detection</span>
                      </div>
                      <div class="single-color">
                        <div class="indication-color-box chart-yellow"></div>
                        <span>Wrong Classification</span>
                      </div>
                      <div class="single-color">
                        <div class="indication-color-box chart-dark-red"></div>
                        <span>Wrong Coordinates</span>
                      </div>
                    </div>
                  </v-flex>
                </v-flex>
              </v-layout>
            </v-flex>
            <v-flex xs6 class="accuracy-chart-outer-container">
              <v-layout row wrap>
                <v-flex
                  xs11
                  class="single-chart-container accuracy-chart-container"
                >
                  <v-flex class="chart-title-container">
                    <p class="chart-title accuracy-chart-title">
                      Classwise Model Accuracy
                    </p>
                  </v-flex>
                  <v-layout row wrap>
                    <v-flex xs12>
                      <!-- <v-btn-toggle  v-model="selectModalDate" mandatory>
                       <v-btn v-for="date in accuracyUsersData">
                         {{date.date}}
                       </v-btn>
                    </v-btn-toggle> -->
                      <!-- <v-btn v-model="accuracyModalClass" :value="date.date" @click="accuracyModalDate=date.date" v-for="class_name in class_data">Hello{{date.date}}</v-btn> -->
                      <v-select
                        class="cust-input dropdown"
                        :items="accuracyModalClassList"
                        placeholder="Select Class"
                        v-model="accuracyModalClass"
                        @input="
                            renderClassAccuracyChart(accuracyUsersData)
                        "
                        solo
                      ></v-select>
                    </v-flex>
                  </v-layout>
                  <v-flex xs12 class="container-title">
                    <svg
                      viewBox="0 0 600 400"
                      perserveAspectRatio="xMinYMid"
                      id="accuracy-chart--class"
                      class="accuracy-chart"
                    ></svg>
                    <div id="accuracy-chart--class_no-data-text-container" class="no-data-text-container">
                      <p>No data to display</p>
                    </div>
                  </v-flex>
                  <v-flex xs12 class="title-container al-center">
                    <div class="chart-color-container">
                      <div class="single-color">
                        <div class="indication-color-box chart-dark-blue"></div>
                        <span>Total Detection</span>
                      </div>
                      <div class="single-color">
                        <div class="indication-color-box chart-yellow"></div>
                        <span>Wrong Classification</span>
                      </div>
                      <div class="single-color">
                        <div class="indication-color-box chart-dark-red"></div>
                        <span>Wrong Coordinates</span>
                      </div>
                    </div>
                  </v-flex>
                </v-flex>
              </v-layout>
            </v-flex>
          </v-layout>
        </v-container>
        <input type="text" name :value="disableBack" style="display:none" />
        <input type="text" name :value="getUserId" style="display:none" />
        <!-- <input
          type="text"
          name
          :value="refreshProductivity"
          style="display:none"
        /> -->
        <!-- <input type="text" name :value="getPerformanceChart" style="display:none"> -->
        <!-- <input type="text" name :value="refreshProductivity" style="display:none"> -->
      </div>

      <v-dialog
        v-model="isQueryError"
        persistent
        width="auto"
        class="dialog-container"
        v-if="isQueryError == true"
      >
        <v-card>
          <v-card-title class="dialog-title">
            <v-layout row wrap>
              <v-flex>
                <v-subheader>
                  <p class="dialog-header">
                    <b>Something went wrong, please contact with admin.</b>
                    <br />
                    {{ "Error Message: " }} {{ this.queryErrorResult }}
                  </p>
                </v-subheader>
              </v-flex>
            </v-layout>
          </v-card-title>
          <v-card-actions>
            <v-spacer></v-spacer>
            <v-btn
              small
              class="action-button cust-btn cust-primary-btn"
              flat
              to="/login"
              @click="sessionStorage.clear()"
              @click.native="isQueryError = false"
              >OK</v-btn
            >
          </v-card-actions>
        </v-card>
      </v-dialog>
    </main>
  </v-app>
</template>

<script src="./ToolsJS/2D_js/Dashboard.js"></script>
<style scoped src="@/assets/css/main.css"></style>
<style scoped src="@/assets/css/dashboard.css"></style>
