<script>
//Importing Line class from the vue-chartjs wrapper
import { Line, mixins } from "vue-chartjs";
const { reactiveProp } = mixins;
//Exporting this so it can be used in other components
export default {
  extends: Line,
  mixins: [reactiveProp],
  props: ["options"],
  data() {
    return {};
  },

  mounted() {
    // this.chartData is created in the mixin
    this.renderChart(this.chartData, {
      responsive: true,
      maintainAspectRatio: true,
      legend: {
        display: false
      }
    });
  }
};
</script>
