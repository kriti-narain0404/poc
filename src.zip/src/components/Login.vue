<template >
  <v-app :dark = "isDarkMode == true" class="page-container">
    <main>
      <v-layout row wrap class="main-container">
        <v-flex xs6 xm6 class="left-container">
          <div class="action-box-container">
            <p class="item-1">Annotate</p>
            <p class="item-2">Validate</p>
            <p class="item-3">Evaluate</p>
            <p class="item-4">Moderate</p>
            <!-- <p class="item-5">Polygon</p> -->
            <!-- <p class="item-8">3D Cube</p>
            <p class="item-9">Line</p>
            <p class="item-10">Dot</p> -->
          </div>
          <v-flex class="background-overlay left-inner-container">
            <img class="nat-logo" src="../assets/icon/PurifAI_boxed.svg" alt="" />
            <img
              class="noises-logo"
              src="../assets/icon/noises-logo.png"
              alt=""
            />
          </v-flex>
        </v-flex>

        <v-flex class="right-container">
          <div v-if="loginScreen === true" class="form-container">
            <h3 class="form-title">Login</h3>
            <form @click.native.prevent="login">
              <v-flex xs12 class="input-field-container">
                <input
                  v-model="username"
                  type="text"
                  placeholder="Username"
                  required
                  @keydown.space.prevent
                  class="cust-input-field username-field"
                />
              </v-flex>
              <v-flex xs12 xm12 class="input-field-container">
                <input
                  v-model="password"
                  type="password"
                  placeholder="Password"
                  @keyup.enter="login(username, password, path)"
                  required
                  class="cust-input-field"
                />
                <div
                  class="error-message"
                  v-if="required == true && noProjectAssigned == false"
                  :value="true"
                  type="error"
                >
                  Login Failed - Please Check your Credentials and try again
                </div>
                <div
                  class="error-message"
                  v-if="isAccountLocked == true"
                  :value="true"
                  type="error"
                >
                Your account is locked. Please contact your administrator
                </div>
                <div
                  class="error-message"
                  v-if="
                    required == false &&
                      isUsersignedUp == false &&
                      noProjectAssigned == true
                  "
                  :value="true"
                  type="error"
                >
                  You are not registered. Please click "Sign UP" to continue.
                </div>
                <div
                  class="error-message"
                  v-if="noProjectAssigned == true && required == false"
                  :value="true"
                  type="error"
                >
                  No Project Assigned Please Contact your Admin
                </div>
                <div v-if="isQueryError ==true" class="error-message">Something went wrong</div>
              </v-flex>
              <v-flex class="btn-container">
                <v-flex xs6>
                  <v-btn
                    class="login-btn cust-primary-btn"
                    @click="login(username, password, path)"
                    @keyup.enter="login(username, password, path)"
                    >log In</v-btn
                  >
                </v-flex>
                <v-flex xs6 class="forget-password-container">
                  <span class="forget-password-link">
                    <a class="link forget-password-link" @click="callForget()">Fogot Password?</a>
                  </span>
                </v-flex>
                <span class="sign-up-link"
                  >Don't have an account?
                  <a class="link" @click="callSignup()">Create account</a>
                </span>
              </v-flex>
            </form>
          </div>

          <label class="mode-toggle-btn">
            <input class='toggle-checkbox' :checked = "isDarkMode == true" type='checkbox' @click="themeModeToggle()"></input>
            <div class='toggle-slot'>
              <div class='sun-icon-wrapper'>
                <img src="../assets/icon/sun.svg" class="iconify sun-icon" data-icon="feather-sun" data-inline="false">
              </div>
              <div class='toggle-button'></div>
              <div class='moon-icon-wrapper'>
                <img src="../assets/icon/moon.svg" class="iconify moon-icon" data-icon="feather-moon" data-inline="false">
              </div>
            </div>
          </label>
        </v-flex>
      </v-layout>
    </main>
  </v-app>
</template>

<script src="./ToolsJS/2D_js/Login.js"></script>
<!-- Add "scoped" attribute to limit CSS to this component only -->
// <style scoped src="@/assets/css/main.css"></style>
<style scoped src="@/assets/css/login-signup.css"></style>
