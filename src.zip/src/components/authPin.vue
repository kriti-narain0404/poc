<template>
  <v-app :dark="isDarkMode == true" class="page-container">
    <main>
      <v-layout row wrap class="main-container">
        <v-flex xs6 xm6 class="left-container">
          <div class="action-box-container">
            <p class="item-1">Annotate</p>
            <p class="item-2">Validate</p>
            <p class="item-3">Evaluate</p>
            <p class="item-4">Annotate</p>
            <p class="item-5">Validate</p>
          </div>
          <v-flex class="background-overlay left-inner-container">
            <img class="nat-logo" src="../assets/icon/logo2.png" alt="" />
            <img class="noises-logo" src="../assets/icon/noises-logo.png" alt="" />
          </v-flex>
        </v-flex>

        <v-flex class="right-container">
          <div class="form-container get-username-container">
            <h3 v-if="secret != ''" class="form-title">Instructions!</h3>
            <h2 v-if="secret != ''">
              <li>Download Google Authenticator on your mobile.</li>
              <li>Create a new account with QRcode method.</li>
              <!-- <li>Provide the required details (name, secret key).</li> -->
              <li>Scan the given QRcode.</li>
              <li>Submit the generated OTP in the form.</li>
            </h2>
            <canvas id="canvas" height="224" width="224"> Your browser does not support this feature. Please switch to a different browser or enter {{ secret }}.  </canvas>
            <!-- <h2 class="form-title" >{{ secret }}</h2> -->
            <h3 class="form-title">OTP Authentication</h3>
            <v-form>
              <v-flex xs12 class="input-field-container">
                <input v-model="otp" type="text" placeholder="Enter Six Digits OTP"
                  class="cust-input-field username-field" 
                  required
                  @focus="isOtpIncorrect = false; getAuthPINError = false"/>
                <div class="error-message" v-if="getAuthPINError == true" :value="true" type="error">
                  Authentication PIN should be a 6 digits number only.
                </div>
                <div class="error-message" v-if="isPINMatchError == true" :value="true" type="error">
                  OTP should not be empty.
                </div>
                <div class="error-message" v-if="isOtpIncorrect == true && getAuthPINError == false" :value="true" type="error">
                  Your OTP is incorrect. Please try again.
                </div>
              </v-flex>

              <v-flex class="btn-container">
                <v-flex xs12>
                  <v-btn class="login-btn full-width-btn cust-primary-btn" @click="logintfa(otp)">Submit</v-btn>
                </v-flex>
                <span class="back-to-login-link">Back To
                  <a class="link" @click="callLogin()">Login</a>
                </span>
              </v-flex>
            </v-form>
          </div>
        </v-flex>
        <v-dialog
          v-model="isTfaSetupSuccess"
          persistent
          width="auto"
          class="dialog-container"
          v-if="isTfaSetupSuccess==true"
        >
          <v-card>
            <v-card-title class="dialog-title">
              <v-layout row wrap>
                <v-flex>
                  <v-subheader>
                    <p class="dialog-header">Two factor authentication is setup successfully</p>
                  </v-subheader>
                </v-flex>
              </v-layout>
            </v-card-title>
  
            <v-card-actions>
              <v-spacer></v-spacer>
              <v-btn small class="cust-btn cust-primary-btn" @click="isTfaSetupSuccess = false, callHome()">OK</v-btn>
            </v-card-actions>
          </v-card>
        </v-dialog>
        <v-dialog
          v-model="isAccountLocked"
          persistent
          width="auto"
          class="dialog-container"
          v-if="isAccountLocked==true"
        >
          <v-card>
            <v-card-title class="dialog-title">
              <v-layout row wrap>
                <v-flex>
                  <v-subheader>
                    <p class="dialog-header">Account Locked: You have made 3 incorrect attempts.</p>
                  </v-subheader>
                </v-flex>
              </v-layout>
            </v-card-title>
  
            <v-card-actions>
              <v-spacer></v-spacer>
              <v-btn small class="cust-btn cust-primary-btn" @click.native="isAccountLocked = false, callLogin()">OK</v-btn>
            </v-card-actions>
          </v-card>
        </v-dialog>
      </v-layout>
    </main>
  </v-app>
</template>



<script src="./ToolsJS/2D_js/authPin.js"></script>
<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped src="@/assets/css/main.css">
</style>
<style scoped src="@/assets/css/login-signup.css">
</style>
