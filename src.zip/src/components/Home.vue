<template>
  <v-app :dark="isDarkMode == true" id="vapp">
    <home-header />
    <main>
      <section class="main-section">
        <v-container fluid class="home-container">
          <v-layout xs12 row wrap heading-row>
            <v-flex xs3 sm3 d-flex>
              <v-layout>
                <v-flex class="search-container">
                  <div class="search-box">
                    <img class="search-icon" src="../assets/icon/search.svg" />
                    <input
                      class="search-field"
                      type="text"
                      v-model="search"
                      placeholder="Search"
                    />
                    <img
                      @click="clearSearch()"
                      v-if="search"
                      class="close-icon"
                      src="../assets/icon/close-cross.svg"
                    />
                  </div>
                </v-flex>
              </v-layout>
            </v-flex>
            <v-flex xs5 class="input-container justify-cont--end">
              <h3 class="input-label">Select Project</h3>
              <v-flex class="field-container width--half">
                <v-select
                  :items="projectList"
                  v-model="selectProject"
                  v-on:input="updatedProject"
                  v-on:change="checked = ''"
                  label="Project"
                  class="field-settings cust-input dropdown"
                  solo
                ></v-select>
              </v-flex>
            </v-flex>
          </v-layout>

          <v-card class="table-container">
            <v-data-table
              :headers="mainHeadersAdmin"
              :items="mainItems"
              :search="search"
              :pagination.sync="pagination"
              item-key="name"
              hide-actions
              expand
              class="elevation-1"
              v-if="role == 'ADMIN'"
            >
              <template slot="items" scope="props">
                <tr>
                  <td class="text-xs">
                    <input
                      type="checkbox"
                      :value="{
                        value: props.item.videoid,
                        status: props.item.submitted,
                      }"
                      :id="'videoAssignId' + props.item.videoid"
                      :checked="props.item.assigned"
                      @click="
                        videoAssign($event, props.item.videoid),
                          props.item.submitted == true
                            ? checkSubmittedVideo()
                            : checkUnsubmittedVideo()
                      "
                      slot="activator"
                      v-model="checked"
                    />
                    <span class="checkmark" />
                  </td>
                  <td class="text-xs">{{ props.item.videoname }}</td>
                  <td class="text-xs">{{ props.item.videodate }}</td>
                  <td class="text-xs">
                    <span
                      v-if="props.item.submitted == true"
                      id="circle4"
                      title="Approved By Validator"
                    ></span>
                    <span
                      v-if="
                        props.item.assigned == true &&
                          props.item.processed == true &&
                          props.item.submitted == false
                      "
                      id="circle3"
                      title="Submitted By Annotator"
                    ></span>
                    <span
                      v-if="
                        props.item.assigned == true &&
                          props.item.processed == false
                      "
                      id="circle1"
                      title="In Progress"
                    ></span>
                    <span
                      v-if="props.item.assigned == false"
                      id="circle2"
                      title="Not Started"
                    ></span>
                  </td>
                  <td class="text-xs">{{ props.item.validatorusername }}</td>
                  <td class="text-xs">{{ props.item.annotatorusername }}</td>
                </tr>
              </template>
            </v-data-table>
            <v-data-table
              :headers="mainHeadersVal"
              :items="mainItems"
              :search="search"
              :pagination.sync="pagination"
              item-key="name"
              hide-actions
              expand
              class="elevation-1"
              v-if="role == 'VALIDATOR'"
            >
              <template slot="items" scope="props">
                <tr>
                  <td class="text-xs">
                    <input
                      type="checkbox"
                      :value="props.item.videoid"
                      :id="'videoAssignId' + props.item.videoid"
                      :checked="props.item.assigned"
                      :disabled="props.item.submitted == true"
                      @click="videoAssign($event, props.item.videoid)"
                      slot="activator"
                      v-model="checked"
                    />
                  </td>
                  <td class="text-xs">
                    <img
                      title="Image Content"
                      slot="activator"
                      class="video-image"
                      v-if="
                        props.item.submitted == false &&
                          props.item.video_type == 0
                      "
                      src="../assets/icon/Image.svg"
                      @click="
                        toolView(
                          props.item.videoid,
                          props.item.videoname,
                          props.item.video_type,
                          0
                        )
                      "
                    />

                    <img
                      title="3D Annotations"
                      slot="activator"
                      class="video-image"
                      v-if="
                        props.item.submitted == false &&
                          props.item.video_type == 1
                      "
                      src="../assets/icon/3d-bbox.svg"
                      @click="
                        toolView(
                          props.item.videoid,
                          props.item.videoname,
                          props.item.video_type,
                          0
                        )
                      "
                    />
                    <img
                      title="Masks Annotations"
                      slot="activator"
                      class="video-image"
                      v-if="
                        props.item.submitted == false &&
                          props.item.video_type == 2
                      "
                      src="../assets/icon/masks-editor.svg"
                      @click="
                        toolView(
                          props.item.videoid,
                          props.item.videoname,
                          props.item.video_type,
                          0
                        )
                      "
                    />
                    <img
                      title="Text Content"
                      slot="activator"
                      class="video-image"
                      v-if="
                        props.item.submitted == false &&
                          props.item.video_type == 3
                      "
                      src="../assets/icon/textEditor.svg"
                      @click="
                        toolView(
                          props.item.videoid,
                          props.item.videoname,
                          props.item.video_type,
                          0
                        )
                      "
                    />
                    <img
                      title="Video Content"
                      slot="activator"
                      class="video-image"
                      v-if="
                        props.item.submitted == false &&
                          props.item.video_type == 4
                      "
                      src="../assets/icon/video-icon.svg"
                      @click="
                        toolView(
                          props.item.videoid,
                          props.item.videoname,
                          props.item.video_type,
                          0
                        )
                      "
                    />

                    <img
                      title="Image Content"
                      slot="activator"
                      class="video-image disabled-cursor"
                      v-if="
                        props.item.submitted == true &&
                          props.item.video_type == 0
                      "
                      src="../assets/icon/2d-bbox_disabled.svg"
                    />
                    <img
                      title="3D Annotations"
                      slot="activator"
                      class="video-image disabled-cursor"
                      v-if="
                        props.item.submitted == true &&
                          props.item.video_type == 1
                      "
                      src="../assets/icon/3d-bbox_disabled.svg"
                    />
                    <img
                      title="Masks Annotations"
                      slot="activator"
                      class="video-image disabled-cursor"
                      v-if="
                        props.item.submitted == true &&
                          props.item.video_type == 2
                      "
                      src="../assets/icon/masks-editor-disabled.svg"
                    />
                    <!--Text Editor -->
                    <img
                      title="Text Content"
                      slot="activator"
                      class="video-image disabled-cursor"
                      v-if="
                        props.item.submitted == true &&
                          props.item.video_type == 2
                      "
                      src="../assets/icon/textEditor.svg"
                    />
                    <img
                      title="Video Content"
                      slot="activator"
                      class="video-image disabled-cursor"
                      v-if="
                        props.item.submitted == true &&
                          props.item.video_type == 4
                      "
                      src="../assets/icon/video-icon.svg"
                    />
                  </td>
                  <td class="text-xs">{{ props.item.videoname }}</td>
                  <td class="text-xs">{{ props.item.videodate }}</td>
                  <td class="text-xs">
                    <v-progress-circular
                      :rotate="360"
                      :size="15"
                      :width="4"
                      :value="
                        (props.item.no_labeljsons / props.item.no_frames) * 100
                      "
                    >
                      <span
                        class="status-tooltip"
                        v-bind:title="
                          'Work Completion: ' +
                            Math.round(
                              (props.item.no_labeljsons /
                                props.item.no_frames) *
                                100
                            ) +
                            '%' +
                            '\n' +
                            'Total: ' +
                            props.item.no_frames +
                            '\n' +
                            'Remaining: ' +
                            (props.item.no_frames - props.item.no_labeljsons)
                        "
                      >
                        <span style="visibility: hidden;">{{ 1 }}</span>
                      </span>
                    </v-progress-circular>
                  </td>
                  <td class="text-xs">{{ props.item.annotatorusername }}</td>
                  <!-- <span v-if="props.item.submitted ==true" id="circle4"></span>
                    <span
                      v-if="props.item.assigned ==true && props.item.processed ==true && props.item.submitted ==false"
                      id="circle3"
                    ></span>
                    <span
                      v-if="props.item.assigned ==true && props.item.processed ==false "
                      id="circle1"
                    ></span>
                    <span v-if="props.item.assigned ==false" id="circle2"></span>
                  </td> -->

                  <td class="text-xs action-column">
                    <img
                      class="video-image preview-btn"
                      title="Preview"
                      src="../assets/icon/preview.svg"
                      slot="activator"
                      v-on:click="previewmode = true"
                      @click="
                        (selectedId = props.item.videoid),
                          (selectedName = props.item.videoname),
                          (selectedVideoType = props.item.video_type)
                      "
                    />
                    <img
                      class="accept-img-icon"
                      v-if="
                        props.item.processed == true &&
                          props.item.submitted == false
                      "
                      src="../assets/icon/success-tick1.svg"
                      title="Accept"
                      slot="activator"
                      @click="acceptRejectVideo(props.item.videoid, 1)"
                    />

                    <img
                      class="reject-img-icon"
                      v-if="
                        props.item.processed == true &&
                          props.item.submitted == false
                      "
                      src="../assets/icon/decline-cross1.svg"
                      title="Reject"
                      slot="activator"
                      @click="acceptRejectVideo(props.item.videoid, 0)"
                    />
                  </td>
                </tr>
              </template>
            </v-data-table>
            <v-data-table
              :headers="mainHeadersanno"
              :items="mainItems"
              :search="search"
              :pagination.sync="pagination"
              item-key="name"
              hide-actions
              expand
              class="elevation-1"
              v-if="role == 'ANNOTATOR'"
            >
              <template slot="items" scope="props">
                <tr>
                  <td class="text-xs">
                    <input
                      type="checkbox"
                      :value="props.item.videoid"
                      :id="'videoAssignId' + props.item.videoid"
                      :checked="props.item.assigned"
                      @click="selectedVideo($event, props.item.videoid)"
                      slot="activator"
                      v-model="checked"
                    />
                  </td>
                  <td class="text-xs">
                    <img
                      title="Image Content"
                      class="video-image"
                      v-if="props.item.video_type == 0"
                      src="../assets/icon/Image.svg"
                      @click="
                        toolView(
                          props.item.videoid,
                          props.item.videoname,
                          props.item.video_type,
                          0
                        )
                      "
                    />

                    <img
                      title="3D Annotations"
                      class="video-image"
                      v-if="props.item.video_type == 1"
                      src="../assets/icon/3d-bbox.svg"
                      @click="
                        toolView(
                          props.item.videoid,
                          props.item.videoname,
                          props.item.video_type,
                          0
                        )
                      "
                    />
                    <img
                      title="Masks Annotations"
                      class="video-image"
                      v-if="props.item.video_type == 2"
                      src="../assets/icon/masks-editor.svg"
                      @click="
                        toolView(
                          props.item.videoid,
                          props.item.videoname,
                          props.item.video_type,
                          0
                        )
                      "
                    />
                    <img
                      title="Text Content"
                      class="video-image"
                      v-if="props.item.video_type == 3"
                      src="../assets/icon/textEditor.svg"
                      @click="
                        toolView(
                          props.item.videoid,
                          props.item.videoname,
                          props.item.video_type,
                          0
                        )
                      "
                    />
                    <img
                      title="Video Content"
                      class="video-image"
                      v-if="props.item.video_type == 4"
                      src="../assets/icon/video-icon.svg"
                      @click="
                        toolView(
                          props.item.videoid,
                          props.item.videoname,
                          props.item.video_type,
                          0
                        )
                      "
                    />
                  </td>
                  <td class="text-xs">{{ props.item.videoname }}</td>
                  <td class="text-xs">{{ props.item.videodate }}</td>
                  <td class="text-xs">
                    <v-progress-circular
                      :rotate="360"
                      :size="15"
                      :width="4"
                      :value="
                        (props.item.no_labeljsons / props.item.no_frames) * 100
                      "
                    >
                      <span
                        class="status-tooltip"
                        v-bind:title="
                          'Work Completion: ' +
                            Math.round(
                              (props.item.no_labeljsons /
                                props.item.no_frames) *
                                100
                            ) +
                            '%' +
                            '\n' +
                            'Total: ' +
                            props.item.no_frames +
                            '\n' +
                            'Remaining: ' +
                            (props.item.no_frames - props.item.no_labeljsons)
                        "
                      >
                        <span style="visibility: hidden;">{{ 1 }}</span>
                      </span>
                    </v-progress-circular>
                  </td>

                  <td class="text-xs">
                    <img
                      class="video-image preview-btn"
                      src="../assets/icon/preview.svg"
                      title="Preview"
                      slot="activator"
                      v-on:click="previewmode = true"
                      @click="
                        (selectedId = props.item.videoid),
                          (selectedName = props.item.videoname),
                          (selectedVideoType = props.item.video_type)
                      "
                    />
                  </td>
                </tr>
              </template>
            </v-data-table>
          </v-card>

          <!-- pagination -->
          <v-layout class="pagination-layout disabled-selection">
            <v-flex xs class="pagination-container">
              <div
                class="text-xs-center"
                v-if="role == 'ADMIN' && mainItems.length != 0"
              >
                <v-pagination
                  v-model="pagination.page"
                  :length="pages"
                  :total-visible="14"
                ></v-pagination>
              </div>
              <div
                class="text-xs-center"
                v-if="role == 'VALIDATOR' && mainItems.length != 0"
              >
                <v-pagination
                  v-model="pagination.page"
                  :length="pages"
                  :total-visible="14"
                ></v-pagination>
              </div>
              <div
                class="text-xs-center"
                v-if="role == 'ANNOTATOR' && mainItems.length != 0"
              >
                <v-pagination
                  v-model="pagination.page"
                  :length="pages"
                  :total-visible="14"
                ></v-pagination>
              </div>
            </v-flex>
          </v-layout>
          <v-flex xs12 submit-btn-style>
            <v-btn
              dark
              style="float: right;"
              v-if="role !== 'ADMIN' && role !== 'VALIDATOR' && count > 0"
              slot="activator"
              @click="getAnnoVideo()"
              :disabled="checked == ''"
              @click.native="submitNotification = true"
              class=" cust-btn cust-primary-btn submit-btn"
              >Submit</v-btn
            >
          </v-flex>
          <v-dialog
            persistent
            v-model="submitNotification"
            v-if="submitNotification && isQueryError == false"
            width="400"
          >
            <v-card class="dialog-container">
              <p class="submit-dialog-title">
                Are you sure, you want to submit the data?
              </p>
              <v-flex class="btn-container justify-cont--end">
                <v-btn
                  class="cust-btn cust-primary-btn"
                  v-on:click="submitNotification = false"
                  @click="finalSubmit()"
                  >Yes</v-btn
                >
                <v-btn
                  class="cust-btn danger-btn"
                  v-on:click="submitNotification = false"
                  >Cancel</v-btn
                >
              </v-flex>
            </v-card>
          </v-dialog>

          <!-- <v-dialog
            persistent
            v-model="Videosopen"
            v-if="Videosopen == true"
            width="auto"
            height="360px"
            @input="stopPreview"
          >
            <v-card class="video-preview">
              <v-card-actions style="padding:2px">
                <div id="video_player_box">
                  <div v-if="showNoVid" id="NoVidDiv">
                    Sorry! No Video Found.
                  </div>
                  <video
                    id="my_video"
                    width="auto"
                    height="360px"
                    v-on:loadedmetadata="LoadVideoData"
                    v-on:timeupdate="seektimeupdate"
                    autoplay
                  ></video>
                  <div id="video_controls_bar">
                    <span id="seekbar"
                      ><progress
                        id="seekslider"
                        v-on:click="videoSeek"
                        class="seekslider"
                        style="object-fit:cover; z-index=10000"
                        min="0"
                        max="100"
                        value="0"
                      ></progress
                    ></span>
                    <span id="vid_controls">
                      <img
                        id="playpausebtn"
                        v-if="videoPlay == 'Play'"
                        src="../assets/icon/vidplay.png"
                        @click="playPause()"
                      />
                      <img
                        id="playpausebtn"
                        v-if="videoPlay == 'Pause'"
                        src="../assets/icon/vidpause.png"
                        @click="playPause()"
                      />
                      <span id="curtimetext">00:00:00</span> /
                      <span id="durtimetext">00:00:00</span>
                    </span>
                    <img
                      id="savebtn"
                      src="../assets/icon/saveEvent.png"
                      @click="(showTextbox = false), saveEvent()"
                    />
                  </div>
                  <div id="info"></div>
                </div>
              </v-card-actions>
            </v-card>
            <div id="Event-Text">
              <v-card v-show="showTextbox" :isOpen.sync="showTextbox">
                <div id="boxset" class="freetext-card-parameters">
                  <input
                    type="text"
                    v-on:blur="updateText"
                    placeholder="Event Type"
                    v-model="showTextValue"
                    class="freetext-card-input"
                  />
                </div>
              </v-card>
            </div>
          </v-dialog> -->

          <!-- ------------------------------------------------------------------------------------- -->
          <v-dialog
            width="60%"
            class="preview-img-dialog"
            :fullscreen="openFullSize"
            v-model="Videosopen"
            v-if="Videosopen == true"
            @input="stopPreview"
            persistent
          >
            <v-card class="dialog-preview">
              <img
                @click="
                  Videosopen = false;
                  isPause = true;
                "
                class="close-btn"
                id="prev-close-btn"
                src="../assets/icon/close-cross.svg"
              />
              <v-card-title>
                <video
                  id="my_video"
                  width="100%"
                  height="auto"
                  v-on:loadedmetadata="LoadVideoData"
                  v-on:timeupdate="seektimeupdate"
                  autoplay
                  @ended="isPause = true"
                ></video>
                <v-layout class="search-ImageList">
                  <div class="img-count-container flex-container">
                    <span id="curtimetext">00:00</span><span> </span> /
                    <span id="durtimetext">00:00</span>
                  </div>
                  <div
                    class="img-slider-container flex-container"
                    id="video-slider-container"
                  >
                    <span id="seekbar"
                      ><progress
                        id="seekslider"
                        v-on:click="videoSeek"
                        class="seekslider"
                        style="object-fit:cover; z-index=10000"
                        min="0"
                        max="100"
                        value="0"
                      ></progress
                    ></span>
                    <div id="info"></div>
                  </div>
                  <div class="speed-selector-container flex-container">
                    <select
                      title="Playback Speed"
                      placeholder="Playback Speed"
                      v-model="videoPlaybackSpeed"
                      class="speed-selector-dropdown"
                      id="class-filter-input"
                      @change="changePlaybackSpeed()"
                    >
                      <option class="select-option" value="0.125"
                        >0.125x</option
                      >
                      <option class="select-option" value="0.25">0.25x</option>
                      <option class="select-option" value="0.5">0.5x</option>
                      <option class="select-option" value="1">1x</option>
                      <option class="select-option" value="2">2x</option>
                      <option class="select-option" value="4">4x</option>
                    </select>
                  </div>
                </v-layout>

                <div class="dialog-preview--image">
                  <div class="left-btn-container">
                    <!-- <v-btn
                    id="savebtn"
                    class="cust-btn cust-primary-btn go-btn"
                    @click="saveEvent()"
                    >Save</v-btn
                  > -->
                    <img
                      class="dialog-preview--image-style play-btn"
                      src="../assets/icon/save_icon.svg"
                      @click="saveEvent()"
                      title="Save"
                      id="savebtn"
                    />
                    <img
                      class="dialog-preview--image-style play-btn"
                      src="../assets/icon/add_mark_icon.svg"
                      @click="addNewMarker()"
                      title="Add new mark"
                    />
                  </div>
                  <v-card
                    id="event_type_conatainer"
                    v-show="showTextbox"
                    :isOpen.sync="showTextbox"
                  >
                    <input
                      type="text"
                      v-on:blur="updateText"
                      placeholder="Event Type"
                      v-model="showTextValue"
                      class="cust-input cust-input-field"
                    />
                  </v-card>
                  <div id="event-textbox-container" v-show="isNewMarkerActive">
                    <input
                      type="text"
                      v-on:blur="newTimeStampEvent"
                      placeholder="Event Type"
                      v-model="newTimeStampEvent"
                      class="cust-input cust-input-field"
                    />
                    <img
                      class="dialog-preview--image-style play-btn white-svg"
                      src="../assets/icon/success-tick-green.svg"
                      @click="submitNewMarker()"
                      title="Add new mark"
                    />
                    <img
                      class="dialog-preview--image-style play-btn white-svg"
                      src="../assets/icon/decline-cross-red.svg"
                      @click="closeNewMarkerMode()"
                      title="Add new mark"
                    />
                  </div>

                  <div class="media-control-btn-container">
                    <img
                      class="dialog-preview--image-style pause-btn"
                      src="../assets/icon/skip_backward.svg"
                      slot="activator"
                      @click="seekBackward()"
                      title="Skip 2s Backward"
                    />
                    <img
                      class="dialog-preview--image-style play-btn"
                      src="../assets/icon/pause.svg"
                      slot="activator"
                      v-on:click="isPause = !isPause"
                      @click="playPause()"
                      v-if="isPause == false"
                      title="Pause"
                    />
                    <img
                      class="dialog-preview--image-style pause-btn"
                      src="../assets/icon/play.svg"
                      slot="activator"
                      v-on:click="isPause = !isPause"
                      @click="playPause()"
                      v-if="isPause == true"
                      title="Play"
                    />
                    <img
                      class="dialog-preview--image-style pause-btn"
                      src="../assets/icon/skip_forward.svg"
                      slot="activator"
                      @click="seekForward()"
                      title="Skip 2s forward"
                    />
                  </div>
                  <div class="full-screen-toggler-container"></div>
                </div>
                <span v-if="showNoVid" id="NoVidDiv" class="error-results"
                  >Sorry! No Video Found.</span
                >
              </v-card-title>
            </v-card>
          </v-dialog>

          <!-- ----------------------------------------------------------------------------------------- -->

          <v-dialog
            width="60%"
            class="preview-img-dialog"
            :fullscreen="openFullSize"
            v-model="PreviewImgOpen"
            v-if="PreviewImgOpen == true"
            @input="stopPreview"
          >
            <v-card class="dialog-preview">
              <v-card-title>
                <!-- <img @click="PreviewImgOpen = false, stopPreview()" class="close-btn" src="../assets/icon/close-cross.svg"> -->
                <img id="imgpre" class="dialog-preview" />
                <v-layout class="search-ImageList">
                  <div class="img-count-container flex-container">
                    <span
                      class="header-index-label"
                      v-if="searchImageId < imagecount && searchImageId >= 0"
                      >{{ searchImageId + 1 }}/{{ imagecount }}</span
                    >
                  </div>
                  <div class="img-slider-container flex-container">
                    <v-slider
                      @click="jumpToFrame(searchImageId)"
                      v-model="searchImageId"
                      :max="imagecount"
                      :min="0"
                      :step="1"
                    ></v-slider>
                  </div>
                  <div class="speed-selector-container flex-container">
                    <select
                      placeholder="Select Class"
                      v-model="selectPreviewDuration"
                      class="speed-selector-dropdown"
                      id="class-filter-input"
                      @click="
                        isPause = true;
                        pauseSlideshow();
                      "
                    >
                      <option class="select-option" value="2">2s</option>
                      <option class="select-option" value="4">4s</option>
                      <option class="select-option" value="6">6s</option>
                      <option class="select-option" value="8">8s</option>
                      <option class="select-option" value="10">10s</option>
                    </select>
                  </div>
                </v-layout>

                <div class="dialog-preview--image">
                  <v-btn
                    class="cust-btn cust-primary-btn go-btn"
                    @click="goToEditor()"
                    >Open in Editor</v-btn
                  >

                  <div class="media-control-btn-container">
                    <img
                      class="dialog-preview--image-style prev-img-btn"
                      src="../assets/icon/prevImg.svg"
                      slot="activator"
                      @click="prevImgOpen()"
                    />
                    <img
                      class="dialog-preview--image-style play-btn"
                      src="../assets/icon/pause.svg"
                      slot="activator"
                      v-on:click="isPause = !isPause"
                      @click="pauseSlideshow()"
                      v-if="isPause == true"
                    />
                    <img
                      class="dialog-preview--image-style pause-btn"
                      src="../assets/icon/play.svg"
                      slot="activator"
                      v-on:click="isPause = !isPause"
                      @click="pauseSlideshow()"
                      v-if="isPause == false"
                    />
                    <img
                      class="dialog-preview--image-style next-img-btn"
                      src="../assets/icon/next-img.svg"
                      slot="activator"
                      v-on:click="isnextClicked = true"
                      @click="nextImgOpen()"
                    />
                  </div>
                  <div class="full-screen-toggler-container">
                    <img
                      class="dialog-preview--image-style full-screen-btn"
                      src="../assets/icon/full-size.svg"
                      slot="activator"
                      v-if="openFullSize == false"
                      @click="
                        openFullSize = true;
                        openPreImage();
                      "
                    />
                    <img
                      class="dialog-preview--image-style full-screen-btn"
                      src="../assets/icon/exit-full-screen.svg"
                      slot="activator"
                      v-if="openFullSize == true"
                      @click="
                        openFullSize = false;
                        openPreImage();
                      "
                    />
                  </div>
                </div>
                <span v-show="previewImageError == true" class="error-results"
                  >Image not available - Please try again.</span
                >
              </v-card-title>
            </v-card>
          </v-dialog>
          <div v-if="PreviewImgOpen == false && Videosopen == false">
            <v-dialog
              persistent
              v-model="previewmode"
              v-if="previewmode == true"
              width="500px"
            >
              <v-card class="dialog-container">
                <h3 class="dialog-title">Preview</h3>
                <v-flex class="input-container justify-cont--end">
                  <h3 class="input-label">Select Mode</h3>
                  <v-flex class="field-container">
                    <v-select
                      :items="previewItems"
                      v-model="modeType"
                      item-text="previewMode"
                      label="Select"
                      return-object
                      class="field-settings cust-input dropdown"
                      solo
                    ></v-select>
                  </v-flex>
                </v-flex>
                <v-flex class="btn-container justify-cont--end">
                  <v-btn
                    class="cust-btn cust-primary-btn"
                    @click="SelectPreMode()"
                    >View</v-btn
                  >
                  <v-btn
                    class="cust-btn danger-btn"
                    @click.native="previewmode = false"
                    >Cancel</v-btn
                  >
                </v-flex>
              </v-card>
            </v-dialog>
          </div>

          <v-dialog
            persistent
            v-model="noFilesSubmitted"
            width="auto"
            class="dialog-container"
            v-if="noFilesSubmitted"
          >
            <v-card>
              <v-card-title class="dialog-title">
                <v-layout row wrap>
                  <v-flex>
                    <v-subheader>
                      <p class="dialog-header">No files modified</p>
                    </v-subheader>
                  </v-flex>
                </v-layout>
              </v-card-title>
            </v-card>
          </v-dialog>
          <v-dialog
            v-model="filesModified"
            width="auto"
            class="dialog-container"
            v-if="filesModified"
          >
            <v-card>
              <v-card-title class="dialog-title">
                <v-layout row wrap>
                  <v-flex>
                    <v-subheader>
                      <p class="dialog-header">
                        {{ totalModifiedFile }} file(s) modified and submitted.
                        Reloading...
                      </p>
                    </v-subheader>
                  </v-flex>
                </v-layout>
              </v-card-title>
            </v-card>
          </v-dialog>
          <v-dialog
            persistent
            v-model="isProjectSelect"
            width="auto"
            class="dialog-container"
            v-if="isProjectSelect"
          >
            <v-card>
              <v-card-title class="dialog-title">
                <v-layout row wrap>
                  <v-flex>
                    <v-subheader>
                      <p class="dialog-header">
                        Please select your project first.
                      </p>
                    </v-subheader>
                  </v-flex>
                </v-layout>
              </v-card-title>
              <v-card-actions>
                <v-spacer></v-spacer>
                <v-btn
                  class="cust-btn cust-primary-btn"
                  @click.native="isProjectSelect = false"
                  >OK</v-btn
                >
              </v-card-actions>
            </v-card>
          </v-dialog>
          <v-dialog
            v-model="isQueryError"
            persistent
            width="auto"
            class="dialog-container"
            v-if="isQueryError == true"
          >
            <v-card>
              <v-card-title class="dialog-title">
                <v-layout row wrap>
                  <v-flex>
                    <v-subheader>
                      <p class="dialog-header">
                        <b>Something went wrong, please contact with admin.</b>
                        <br />
                        {{ "Error Message: " }} {{ queryErrorResult }}
                      </p>
                    </v-subheader>
                  </v-flex>
                </v-layout>
              </v-card-title>
              <v-card-actions>
                <v-spacer></v-spacer>
                <v-btn
                  class="cust-btn cust-primary-btn"
                  flat
                  to="/login"
                  @click="sessionStorage.clear()"
                  @click.native="isQueryError = false"
                  >OK</v-btn
                >
              </v-card-actions>
            </v-card>
          </v-dialog>
          <v-flex class="btn-container justify-cont--end">
            <v-btn
              dark
              :value="videoid"
              class="cust-btn cust-primary-btn assign-btn"
              slot="activator"
              @click="reopenVideo(videoid)"
              v-if="role == 'ADMIN' && videoReopen && count > 0"
              :disabled="checked == ''"
              >Reopen</v-btn
            >
            <v-dialog
              persistent
              scope="props"
              v-model="assignD"
              width="500px"
              v-if="
                (role == 'ADMIN' || role == 'VALIDATOR') &&
                  count > 0 &&
                  videoReopen == false
              "
            >
              <v-btn
                dark
                class="cust-btn cust-primary-btn"
                slot="activator"
                :disabled="checked == ''"
                >Reassign</v-btn
              >
              <v-card class="dialog-container">
                <div class="assign-video-header">
                  <h3 class="dialog-title">Assign Video</h3>
                </div>
                <v-flex class="input-container justify-cont--end">
                  <h3 v-if="role == 'ADMIN'" class="input-label">
                    Select Validator
                  </h3>
                  <h3 v-if="role == 'VALIDATOR'" class="input-label">
                    Select Annotator
                  </h3>
                  <v-flex class="field-container">
                    <v-select
                      v-if="role == 'ADMIN'"
                      :items="items"
                      v-model="AssignValue"
                      item-text="username"
                      label="Select"
                      return-object
                      class="field-settings cust-input dropdown"
                      solo
                    ></v-select>
                    <v-select
                      v-if="role == 'VALIDATOR'"
                      :items="items"
                      v-model="AssignValue"
                      item-text="username"
                      label="Select"
                      return-object
                      class="field-settings cust-input dropdown"
                      solo
                    ></v-select>
                  </v-flex>
                </v-flex>
                <div class="flex xs">
                  <div v-if="userNotAssigned == true">
                    <span class="error-message">User not selected!</span>
                  </div>
                </div>
                <v-flex class="btn-container justify-cont--end">
                  <v-btn
                    class="cust-btn cust-primary-btn"
                    @click="assignVideo()"
                    >Save</v-btn
                  >
                  <v-btn
                    class="cust-btn danger-btn"
                    @click.native="(assignD = false), (AssignValue = null)"
                    >Cancel</v-btn
                  >
                </v-flex>
              </v-card>
            </v-dialog>
            <v-btn
              dark
              :value="videoid"
              class="cust-btn danger-btn delete-btn"
              slot="activator"
              @click="deleteDialog = true"
              v-if="role == 'ADMIN' && count > 0"
              :disabled="checked == ''"
              >Delete</v-btn
            >
          </v-flex>
          <v-dialog
            v-model="deleteDialog"
            width="30%"
            class="dialog-container"
            v-if="deleteDialog"
          >
            <v-card class="dialog-container">
              <v-card-title class="dialog-title">
                <v-layout row wrap>
                  <v-flex>
                    <p class="dialog-header">
                      Are you sure you want to delete?
                    </p>
                  </v-flex>
                </v-layout>
              </v-card-title>

              <v-flex class="btn-container justify-cont--end">
                <v-btn
                  class="cust-btn cust-primary-btn"
                  @click.native="
                    deleteDialog = false;
                    deleteVideo(videoid);
                  "
                  >Yes</v-btn
                >
                <v-btn
                  class="cust-btn danger-btn"
                  @click.native="deleteDialog = false"
                  >Cancel</v-btn
                >
              </v-flex>
            </v-card>
          </v-dialog>
        </v-container>
      </section>
      <!-- <app-footer /> -->
    </main>
  </v-app>
</template>
<script src="./ToolsJS/2D_js/Home.js"></script>
<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped src="@/assets/css/main.css"></style>
<style scoped src="@/assets/css/home.css"></style>
