<template>
  <v-app :dark = "isDarkMode == true" class="page-container">
    <main>
      <v-layout row wrap class="main-container">
        <v-flex xs6 xm6 class="left-container">
          <div class="action-box-container">
            <p class="item-1">Annotate</p>
            <p class="item-2">Validate</p>
            <p class="item-3">Evaluate</p>
            <p class="item-4">Annotate</p>
            <p class="item-5">Validate</p>
          </div>
          <v-flex class="background-overlay left-inner-container">
            <img class="nat-logo" src="../assets/icon/logo2.png" alt="" />
            <img
              class="noises-logo"
              src="../assets/icon/noises-logo.png"
              alt=""
            />
          </v-flex>
        </v-flex>

        <v-flex class="right-container">
          <div
            class="form-container get-username-container"
            v-if="dialogQueFlag == false"
          >
            <h3 class="form-title">Reset Password</h3>
            <v-form>
              <v-flex xs12 class="input-field-container">
                <input
                  v-model="username"
                  type="text"
                  placeholder="Username"
                  class="cust-input-field username-field"
                />
                <div
                  class="error-message"
                  v-if="getUserError == true"
                  :value="true"
                  type="error"
                >
                  User not found
                </div>
              </v-flex>

              <v-flex class="btn-container">
                <v-flex xs12>
                  <v-btn
                    class="login-btn full-width-btn cust-primary-btn"
                    @click="getQuestion(username), clearFields()"
                    @keyup.enter="getQuestion(username)"
                    >Find Account</v-btn
                  >
                </v-flex>
                <span class="back-to-login-link"
                  >Back To
                  <a class="link" @click="callLogin()">Login</a>
                </span>
              </v-flex>
            </v-form>
          </div>
          <div
            class="form-container get-username-container"
            v-if="dialogQueFlag == true"
          >
            <h3 class="form-title">Reset Password</h3>

            <form>
              <v-layout>
                <v-flex class="form-container">
                  <h3 class="security-question">{{ question }}</h3>
                  <v-flex xs12 class="input-field-container">
                    <input
                      v-model="qanswer"
                      class="cust-input-field username-field"
                      type="password"
                      placeholder="Answer"
                      @focus="showError = false"
                    />
                      <div class="error-message" v-if="showError == true" :value="true" type="error"
                      >Please enter correct answer</div
                    >
                  </v-flex>
                  <v-flex xs12 class="input-field-container">
                    <input
                      @keydown.space.prevent
                      v-model="newPass"
                      class="cust-input-field"
                      type="password"
                      placeholder="Enter new password"
                      @blur="validateResetPassword()"
                      @focus="passwordWeak == false;passwordMedium == false;passwordStrong == false;passwordLength == false;resetPasswordError == false"

                    />
                    <div
                    class="username-password-title  error-message"
                    v-if="passwordWeak == true"
                  >
                    WEAK! Your password should be atleast 8 characters long.
                  </div>
                  <div
                    v-if="passwordMedium == true"
                    class="medium-password error-message"
                  >
                    Medium!
                  </div>
                  <div
                    v-if="passwordStrong == true"
                    class="strong-password error-message"
                  >
                    Strong!
                  </div>
                  <div
                    v-if="passwordLength == true"
                    class="username-password-title  error-message"
                  >
                    Your password should not be more than 12 characters long.
                  </div>
                  <div
                    v-if="resetPasswordError == true"
                    class="username-password-title  error-message"
                  >
                   Password must contain: <ul><li> At least one capital letter</li> <li> At least one small letter</li> <li> At least one special character </li><li> At least one numeric value</li></ul>
                  </div>

                  </v-flex>
                  <v-flex xs12 class="input-field-container">
                    <input
                      @keydown.space.prevent
                      v-model="newPass1"
                      class="cust-input-field"
                      type="password"
                      placeholder="Re-type new password"
                      @blur="comparePassword()"

                    />
                    <div
                    v-if="isPasswordSame == true"
                    class="username-password-title  error-message"
                    :value="true"
                    type="error"
                  >
                    Password and Confirm Password is not same
                  </div>
                    <div
                    v-if="resetSuccessfully == true"
                    class="strong-password  error-message"
                    :value="true"
                  >
                    Your password has been changed successfully 
                  </div>
                    <div v-if="isQueryError ==true" class="error-message">Something went wrong</div>
                  </v-flex>
                  <v-flex class="btn-container">
                    <v-flex xs5>
                      <v-btn
                      class="login-btn cust-primary-btn"
                      @click="resetPassword(username, newPass),validateResetPassword(), comparePassword() "
                      >Reset password</v-btn
                    >                   
                    </v-flex>
                      <v-flex xs5>
                      <v-btn
                      class="login-btn danger-btn"
                      @click="dialogQueFlag = false, clearFields()"
                      >Cancel</v-btn
                    >  
                  <span class="back-to-login-link"
                  >Back To
                  <a class="link" @click="callLogin(), dialogQueFlag = false">Login</a>
                </span>                 
                    </v-flex>
                  </v-flex>
                </v-flex>
              </v-layout>
            </form>
          </div>
        </v-flex>
      </v-layout>
    </main>
  </v-app>
</template>

<script src="./ToolsJS/2D_js/Signup.js"></script>
<script src="./ToolsJS/2D_js/Forget.js"></script>
<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped src="@/assets/css/main.css"></style>
<style scoped src="@/assets/css/login-signup.css"></style>
