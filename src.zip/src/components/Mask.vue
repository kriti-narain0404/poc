<template>
  <v-app id="VTool" :dark = "isDarkTheme == true" class="edit-container">
    <v-toolbar fixed class="header-toolbar">
      <v-toolbar-title xs4 sm4 @click="callInbox(homePath)" class="toolbar-title">
        <img src="../assets/icon/logo2.png" class="toolbar-title-img">
      </v-toolbar-title>
      <v-toolbar-title xs4 sm4 class="toolbar-title-blank">
        <span></span>
      </v-toolbar-title>
      <v-toolbar-items xs4 sm4 class="toolbar-items">
        <v-btn
          flat
          @click="callInbox(homePath)"
          class="header-items"
        >
          <i class="fa fa-envelope font-size"></i> <span class="toolbar-items--margin">Inbox</span>
        </v-btn>
      </v-toolbar-items>
      <v-toolbar-items xs4 sm4 class="save-style">
      <span class="header-videoname">{{videoName}}</span>
      <span class="header-index-label">{{imageId + 1}}.</span>
      <span style="margin-right: 10px" class="header-index-label" v-bind:title="imageName">{{imageName}}</span>
        <a id="download">
      <v-btn
      small dark
        icon
        @click="showDownloadMsg = true"        
        title = "Save"        
      >
        <i class="fa fa-save save-icon"></i>
      </v-btn>
      </a>
      </v-toolbar-items>
    </v-toolbar>

<input type="file" accept="image/*" id="file" ref="file" name="myfile" v-on:change="nextImage()" style="display:none"/>
    <div class="prev-img-container">
      <v-btn
        small
        class="prev-img"
        icon
        v-if="imageId > 0"
        @click="prev_image()"
        v-tooltip:right="{ html: 'Previous image' }"
      >
        <i class="fa fa-chevron-left save-icon"></i>
      </v-btn>
    </div>
    <div class="next-img-container">
      <v-btn
        small
        class="next-img"
        icon
        v-if="imageId <= tolatImageCount-2"
        @click="next_image()"
        v-tooltip:left="{ html: 'Next image' }"
      >
        <i class="fa fa-chevron-right save-icon"></i>
      </v-btn>
    </div>


         <v-list
            class="fill-tool"
            v-model="fillscale"
            :closeButton="true"
            v-if="isFillToolOpen == true"
          >
          <strong class="slider-style">Fill ({{fillscale}})</strong>
          <input type="range" v-model="fillscale" max="42" min="2" step="4" @click="chooseFill(fillscale)" class="slider-margin">
          </v-list>
          <v-list
            class="eraser-tool"
            v-model="erasescale"
            :closeButton="true"
            v-if="isEraserToolOpen == true"
          >
            <strong class="slider-style">Erase ({{erasescale}})</strong>
            <input type="range" v-model="erasescale" max="22" min="2" step="2" @click="chooseErase(erasescale)" class="slider-margin">
          </v-list>

      <hsc-window-style-metal>
          <hsc-window
            positionHint="-5 / 50"
            title="Image Edit Tools"
            class="image-edit-tool"
            :closeButton="true"
            :isOpen.sync="isImageToolOpen"
          >
            <div class="image-edit-tool--display">
              <table>
                <tr>
                  <td>
                    <strong class="tool-pty-name">Grayscale({{grayscale}})</strong>
                  </td>
                  <td>
                    <input type="range" v-model="grayscale" max="8" min="0" step="0.01">
                  </td>
                  <td></td>
                </tr>
                <tr>
                  <td>
                    <strong class="tool-pty-name">Brightness({{brightness}})</strong>
                  </td>
                  <td>
                    <input type="range" v-model="brightness" max="3" min="0" step="0.01">
                  </td>
                  <td></td>
                </tr>
                <tr>
                  <td>
                    <strong class="tool-pty-name">Contrast({{contrast}})</strong>
                  </td>
                  <td>
                    <input type="range" v-model="contrast" max="2" min="0" step="0.01">
                  </td>
                  <td>
                    <img title="Reset" class="image-edit-tool--reset"
                    @click="grayscale=0, brightness=1, contrast=1, tolerance=1" src="../assets/icon/resetool.png">
                  </td>
                </tr>
              </table>
            </div>
          </hsc-window>
        </hsc-window-style-metal>

    <template>
  <v-card class="sidebar-icons">
    <v-list class="pt-0 sidebar-icons--list">
              <v-list-tile v-on:click="isFillToolOpen = !isFillToolOpen, isEraserToolOpen=false, chooseFill(fillscale)" class="toolbar-list-width"  title="Fill Tool">
                <img src="../assets/icon/paintbrush.png">
                <i class="fa fa-angle-right icon-style"></i>
              </v-list-tile>
              <v-list-tile v-on:click="isEraserToolOpen = !isEraserToolOpen, isFillToolOpen=false, chooseErase(erasescale)" class="toolbar-list-width"  title="Eraser Tool">
                <img src="../assets/icon/eraser.png" width="16" height="16">
                <i class="fa fa-angle-right icon-style"></i>
              </v-list-tile>
              <v-list-tile @click="undoEffect()" class="toolbar-list-width"  title="Undo">
                <img src="../assets/icon/undo.png">
              </v-list-tile>
              <v-list-tile @click="redoEffect()" class="toolbar-list-width"  title="Redo">
                <img src="../assets/icon/redo.png">
              </v-list-tile>
              <v-list-tile @click="openImageWindow()" class="toolbar-list-width"  title="Image Tool">
                <img src="../assets/icon/range.png">
              </v-list-tile>
    </v-list>
  </v-card>
  <v-dialog
        v-model="showNotification"
        width="auto"
        class="dialog-container"
        v-if="showNotification==true"
      >
        <v-card>
          <v-card-title class="dialog-title">
            <v-layout row wrap>
              <v-flex>
                <v-subheader>
                  <p class="dialog-header">Your changes has been saved successfully.</p>
                </v-subheader>
              </v-flex>
            </v-layout>
          </v-card-title>
        </v-card>
      </v-dialog>
  <v-dialog
        v-model="showDownloadMsg"
        width="auto"
        class="dialog-container"
        v-if="showDownloadMsg==true"
      >
        <v-card>
          <v-card-title class="dialog-title">
            <v-layout row wrap>
              <v-flex>
                <v-subheader>
                  <p class="dialog-header">If you want to save please click on SAVE or to download JSON please click on DOWNLOAD.</p>
                </v-subheader>
              </v-flex>
            </v-layout>
          </v-card-title>

          <v-card-actions>
            <v-spacer></v-spacer>
            <v-btn small class="action-button" @click.native="showDownloadMsg = false" @click="saveMask()">SAVE</v-btn>
            <v-btn small class="action-button" @click.native="showDownloadMsg = false, isDownloadMask = true" @click="saveMask()">DOWNLOAD</v-btn>
            <v-spacer></v-spacer>
          </v-card-actions>
        </v-card>
      </v-dialog>
</template>

    <main>
      <div id="canvas" v-bind:style="[filter, filters]">
      </div>
    </main>
  </v-app>
</template>

 

<script src="./ToolsJS/2D_js/Mask.js"></script>
<style scoped src="@/assets/css/mask.css"></style>
<style src="@/assets/css/mask.css"></style>