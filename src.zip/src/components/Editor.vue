<template>
  <v-app :dark="isDarkMode == true" id="VTool" class="edit-container">
    <home-header style="z-index: 99999; position: fixed;" />

    <div class="right-toolbar-container">
      <hsc-window-style-white>
        <hsc-window
          :isOpen.sync="isRightPanelOpen"
          positionHint="-40 / 50"
          :closeButton="true"
          :resizable="false"
          :isScrollable="false"
          :isDraggable="true"
          class="dialog-box-container"
          style="z-index: 2"
        >
          <img
            src="../assets/icon/close-cross.svg"
            @click="openRightPanel()"
            class="close-dialog-btn"
            id="right-panel-close-btn"
            alt=""
          />
          <v-flex class="inner-dialog-box-container">
            <div class="dialog-box">
              <!-- <v-flex xs3 sm3 style="display:none;">
        <v-slider
          label="Accelerate:"
          v-on="adjustThreshold()"
          v-model="sliderValue"
          :step="5"
          snap
          thumb-label
          dark
        ></v-slider>
      </v-flex> -->
              <v-flex xs12> </v-flex>
              <v-layout class="dialog-box-sub-container">
                <v-flex row wrap style="display: flex">
                  <v-flex xs6>
                    <h3 class="radio-input-label">Label Count</h3>
                  </v-flex>
                  <v-flex xs7>
                    <h3 class="radio-input-label">
                      <span class="seek-image-count">{{
                        sortedLabelList.length
                      }}</span>
                    </h3>
                  </v-flex>
                </v-flex>
              </v-layout>

              <v-layout class="dialog-box-sub-container">
                <v-flex
                  row
                  wrap
                  class="seek-image-container"
                  style="display: flex"
                >
                  <v-flex xs6>
                    <h3
                      class="radio-input-label"
                      v-bind:title="image.id"
                      v-if="imageId < tolatImageCount && imageId >= 0"
                    >
                      Seek Image<span class="seek-image-count">{{
                        imageId + 1
                      }}</span>
                    </h3>
                  </v-flex>
                  <v-flex xs7>
                    <v-slider
                      @click="
                        requestImage(
                          imageId,
                          listOfAnnotation,
                          flagOfRequestImage
                        )
                      "
                      v-model="imageId"
                      :thumb-size="24"
                      :max="tolatImageCount - 1"
                      :min="0"
                      :step="1"
                      snap
                      dark
                      width="100%"
                      class="seek-image-slider"
                    >
                    </v-slider>
                  </v-flex>
                </v-flex>
              </v-layout>

              <v-layout class="dialog-box-sub-container switch-btn-container">
                <v-flex xs6 class="switch-btn-label-container">
                  <h3 class="radio-input-label">Interpolation Type</h3>
                </v-flex>
                <v-flex xs6 class="switch-btn-container">
                  <v-btn-toggle
                    mandatory
                    v-model="copyMode"
                    class="switch-btn-group"
                  >
                    <v-btn
                      class="switch-btn left-btn"
                      name="myfield"
                      value="manual"
                      v-model="copyMode"
                      title="manual"
                      ><img src="../assets/icon/manual.svg"
                    /></v-btn>
                    <v-btn
                      class="switch-btn right-btn"
                      name="myfield"
                      value="automatic"
                      v-model="copyMode"
                      title="automatic"
                      ><img src="../assets/icon/robot-3.svg"
                    /></v-btn>
                  </v-btn-toggle>
                </v-flex>
              </v-layout>
              <v-layout class="dialog-box-sub-container switch-btn-container">
                <v-flex xs6 class="switch-btn-label-container">
                  <h3 class="radio-input-label">Interpolation</h3>
                </v-flex>
                <v-flex xs6 class="switch-btn-container">
                  <v-btn-toggle
                    mandatory
                    v-model="copyDirection"
                    class="switch-btn-group"
                  >
                    <v-btn
                      class="switch-btn left-btn"
                      name="myfield_1"
                      value="Backward"
                      @click="resetCopyAnno()"
                      v-model="copyDirection"
                      title="Backward"
                      ><img src="../assets/icon/backward-interpolation.svg"
                    /></v-btn>
                    <v-btn
                      class="switch-btn right-btn"
                      name="myfield_1"
                      value="Forward"
                      @click="resetCopyAnno()"
                      v-model="copyDirection"
                      title="Forward"
                      ><img src="../assets/icon/forward-interpolation.svg"
                    /></v-btn>
                  </v-btn-toggle>
                </v-flex>
              </v-layout>
              <v-layout
                class="dialog-box-sub-container"
                v-if="propInFrame.length > 0"
              >
                <v-flex xs6 class="switch-btn-label-container">
                  <h3 class="radio-input-label">Class Filter</h3>
                </v-flex>
                <v-flex xs6 class="switch-btn-container">
                  <select
                    :title="radioSelectObj"
                    placeholder="Select Class"
                    v-model="radioSelectObj"
                    id="class-filter-input"
                    @click="triggerLoadAnnotation()"
                  >
                    <option
                      v-for="settingItem in propInFrame"
                      :value="settingItem.name"
                      v-model="radioSelectObj"
                      >{{ settingItem.name }}</option
                    >
                  </select>
                </v-flex>
              </v-layout>
            </div>
            <div
              class="dialog-box"
              id="label-list-dialog"
              v-if="isAnnotationListOpen == true && sortedLabelList.length != 0"
            >
              <img
                src="../assets/icon/close-cross.svg"
                class="close-dialog-btn"
                alt=""
                @click="openLabelList()"
              />
              <v-layout class="lock-unlock-toggler">
                <v-flex row wrap>
                  <v-flex xs12 class="lock-unlock-toggler-container">
                    <input
                      type="checkbox"
                      slot="activator"
                      v-bind:true-value="'true'"
                      v-bind:false-value="'false'"
                      v-model="lockUnlockFlag"
                      @click="selectObjects()"
                    />
                    <h3 class="radio-input-label">Lock/Unlock All</h3>
                  </v-flex>
                </v-flex>
              </v-layout>
              <v-layout>
                <v-flex row wrap>
                  <v-flex xs12>
                    <v-flex
                      class="single-class-container"
                      v-for="(settingItem, i) in sortedLabelList"
                      :key="i"
                    >
                      <v-flex
                        class="label-class-name-container"
                        v-if="
                          settingItem.bbox != null ||
                            settingItem.polygon != null
                        "
                      >
                        <span class="lock-icon-container">
                          <img
                            v-if="
                              settingItem.bbox &&
                                settingItem.bbox.track == false
                            "
                            class="annotation-list--icons unlock-icon"
                            @click="
                              annoToggle(i, true, settingItem.bbox.annoId)
                            "
                            src="../assets/icon/unlock.svg"
                          />
                          <img
                            v-if="
                              settingItem.bbox && settingItem.bbox.track == true
                            "
                            class="annotation-list--icons lock-icon"
                            @click="
                              annoToggle(i, false, settingItem.bbox.annoId)
                            "
                            src="../assets/icon/lock.svg"
                          />
                          <img
                            v-if="
                              settingItem.polygon &&
                                settingItem.polygon.track == false
                            "
                            class="annotation-list--icons unlock-icon"
                            @click="
                              annoToggle(i, true, settingItem.polygon.annoId)
                            "
                            src="../assets/icon/unlock.svg"
                          />
                          <img
                            v-if="
                              settingItem.polygon &&
                                settingItem.polygon.track == true
                            "
                            class="annotation-list--icons lock-icon"
                            @click="
                              annoToggle(i, false, settingItem.polygon.annoId)
                            "
                            src="../assets/icon/lock.svg"
                          />
                        </span>
                        <span
                          v-if="
                            (sortedLabelList[i].bbox != null &&
                              sortedLabelList[i].bbox.score) ||
                              (sortedLabelList[i].polygon != null &&
                                sortedLabelList[i].polygon.score)
                          "
                          v-model="highlightanno"
                          @click="highlightSelectedByList(settingItem, i)"
                          class="setting-lbl-error single-class-name"
                          :title="settingItem.label"
                          v-bind:class="
                            settingItem.id == highlightanno
                              ? 'setting-lbl-selected'
                              : 'setting-lbl-error'
                          "
                          ><p :title="settingItem.label" class="label">
                            {{ settingItem.label }}
                          </p>
                          <span class="bb-id">
                            [{{ settingItem.id }}]</span
                          ></span
                        >
                        <span
                          v-if="
                            (sortedLabelList[i].bbox != null &&
                              sortedLabelList[i].bbox.score == 0) ||
                              (sortedLabelList[i].polygon != null &&
                                sortedLabelList[i].polygon.score == 0)
                          "
                          v-model="highlightanno"
                          @click="highlightSelectedByList(settingItem, i)"
                          class="setting-lbl single-class-name"
                          v-bind:class="
                            settingItem.id == highlightanno
                              ? 'setting-lbl-selected'
                              : 'setting-lbl'
                          "
                          ><p :title="settingItem.label" class="label">
                            {{ settingItem.label }}
                          </p>
                          <span class="bb-id"
                            >[{{ settingItem.id }}]</span
                          ></span
                        >
                      </v-flex>
                      <v-flex class="attributes-container">
                        <v-layout
                          class="attributes-sub-group"
                          row
                          wrap
                          v-for="element in classObj"
                          v-if="settingItem.bbox != null"
                        >
                          <v-flex
                            :key="index"
                            class="single-attribute"
                            v-for="(extraObject1, index) in element.param"
                            v-if="
                              extraObject1.name != 'Id' &&
                                element.name == settingItem.label
                            "
                          >
                            <p
                              class="attribute-label"
                              :title="extraObject1.name"
                            >
                              {{ extraObject1.name }}
                            </p>
                            <select
                              v-model="parameterLabel1[i][index]"
                              :title="parameterLabel1[i][index]"
                              size="1"
                              v-on:change="
                                fetchParam(
                                  i,
                                  settingItem.label,
                                  settingItem.bbox.track,
                                  extraObject1.name,
                                  parameterLabel1[i][index],
                                  settingItem.id,
                                  index
                                )
                              "
                              onblur="this.size=0;"
                            >
                              <option
                                v-for="objects in element.param[index].subClass"
                                :value="objects.name"
                                :title="objects.name"
                                :key="objects.id"
                                class="select-option"
                                >{{ objects.name }}</option
                              >
                            </select>
                          </v-flex>
                        </v-layout>

                        <v-layout
                          class="attributes-sub-group"
                          row
                          wrap
                          v-for="element in classObj"
                          v-if="settingItem.polygon != null"
                        >
                          <v-flex
                            :key="index"
                            class="single-attribute"
                            v-for="(extraObject1, index) in element.param"
                            v-if="
                              extraObject1.name != 'Id' &&
                                element.name == settingItem.label
                            "
                          >
                            <p
                              class="attribute-label"
                              :title="extraObject1.name"
                            >
                              {{ extraObject1.name }}
                            </p>
                            <select
                              v-model="parameterLabel1[i][index]"
                              :title="parameterLabel1[i][index]"
                              size="1"
                              v-on:change="
                                fetchParam(
                                  i,
                                  settingItem.label,
                                  settingItem.polygon.track,
                                  extraObject1.name,
                                  parameterLabel1[i][index],
                                  settingItem.id,
                                  index
                                )
                              "
                              onblur="this.size=0;"
                            >
                              <option
                                v-for="objects in element.param[index].subClass"
                                :value="objects.name"
                                :key="objects.id"
                                class="select-option"
                                >{{ objects.name }}</option
                              >
                            </select>
                          </v-flex>
                        </v-layout>
                      </v-flex>
                    </v-flex>
                  </v-flex>
                </v-flex>
              </v-layout>
            </div>

            <div
              class="dialog-box"
              id="image-list"
              v-if="isImageListOpen == true"
            >
              <img
                src="../assets/icon/close-cross.svg"
                @click="openFrameList()"
                class="close-dialog-btn"
                alt=""
              />
              <v-flex xs8>
                <h3 class="dialog-box-title">Image List</h3>
              </v-flex>
              <v-layout
                row
                wrap
                class="dialog-box-sub-container"
                id="color-plattr-class-container"
              >
                <v-flex xs12 class="search-container">
                  <div class="search-box">
                    <img class="search-icon" src="../assets/icon/search.svg" />
                    <input
                      class="input-field"
                      type="text"
                      v-model="search"
                      placeholder="Search"
                    />
                    <img
                      @click="clearSearch()"
                      v-if="search"
                      class="close-icon"
                      src="../assets/icon/close-cross.svg"
                    />
                  </div>
                </v-flex>
              </v-layout>
              <v-layout class="dialog-box-sub-container">
                <v-flex class="img-list-container" row wrap>
                  <v-flex
                    class="single-img"
                    v-for="(item, index) in filteredImageList"
                    @click="requestIndex(item)"
                    xs12
                  >
                    <span
                      class="circle img-status"
                      v-bind:class="
                        allJsons[item] ? 'true_circle' : 'false_circle'
                      "
                    ></span>
                    <span class="img-label" :title="item"
                      >{{ index + 1 }}. {{ item }}</span
                    >
                  </v-flex>
                </v-flex>
              </v-layout>
            </div>

            <div
              class="dialog-box"
              id="color-palatte"
              v-if="isColorListOpen == true"
            >
              <img
                src="../assets/icon/close-cross.svg"
                class="close-dialog-btn"
                alt=""
                @click="openColorWindow()"
              />
              <v-flex xs6>
                <h3 class="dialog-box-title">Color Palette</h3>
              </v-flex>
              <v-layout
                row
                wrap
                class="dialog-box-sub-container"
                id="color-plattr-class-container"
              >
                <v-flex xs7>
                  <select
                    placeholder="Select Class"
                    v-model="fillColor"
                    id="color-plttr-class-selector"
                    @change="changeColorProp()"
                    @mousedown="OnButtonDown(this)"
                    onchange="this.blur()"
                    onblur="this.size=0;"
                  >
                    <option
                      v-for="objects in objList"
                      :value="objects"
                      :key="objects"
                      class="select-option"
                      >{{ objects }}</option
                    >
                  </select>
                </v-flex>
                <v-flex xs5 class="fill-border-checkbox-container">
                  <input
                    type="checkbox"
                    slot="activator"
                    v-bind:true-value="'true'"
                    v-bind:false-value="'false'"
                    v-model="fillBorder"
                    @click="changeColorProp()"
                  />
                  <span class="fill-border-label">Fill Border</span>
                </v-flex>
              </v-layout>
              <v-layout class="dialog-box-sub-container">
                <v-flex row wrap>
                  <v-flex xs12>
                    <swatches
                      v-model="color"
                      :colors="[
                        '#FF0000',
                        '#008000',
                        '#FFFF00',
                        '#0000FF',
                        '#000000',
                      ]"
                      @input="changeColorProp(), changeColorPropTooltip()"
                      inline
                    ></swatches>
                  </v-flex>
                </v-flex>
              </v-layout>
              <v-layout class="dialog-box-sub-container">
                <v-flex row wrap>
                  <v-flex xs12>
                    <v-flex class="opacity-value-container">
                      <h4 class="opacity-title">
                        Opacity <span>{{ opacity }}</span>
                      </h4>
                    </v-flex>
                    <input
                      type="range"
                      v-model="opacity"
                      max="1"
                      min="0.1"
                      step="0.01"
                      style="width: 100%"
                      @change="changeColorProp()"
                    />
                  </v-flex>
                </v-flex>
              </v-layout>
              <v-flex id="reset-btn-container">
                <span
                  class="reset-img-setting-label"
                  @click="reset(), changeColorProp()"
                  ><img
                    title="Reset Settings"
                    class="reset-opacity-btn"
                    id="reset-img-setting-btn"
                    src="../assets/icon/refresh.svg"
                  />Reset</span
                >
              </v-flex>
            </div>

            <div
              class="dialog-box"
              id="image-edit-tool"
              v-if="isImageToolOpen == true"
            >
              <img
                src="../assets/icon/close-cross.svg"
                @click="openImageWindow()"
                class="close-dialog-btn"
                alt=""
              />
              <v-flex xs8>
                <h3 class="dialog-box-title">Image Edit Tool</h3>
              </v-flex>
              <v-layout class="dialog-box-sub-container">
                <v-flex row wrap>
                  <v-flex xs12>
                    <v-flex class="opacity-value-container">
                      <h4 class="opacity-title">
                        GrayScale <span>{{ grayscale }}</span>
                      </h4>
                    </v-flex>
                    <input
                      type="range"
                      v-model="grayscale"
                      max="8"
                      min="0"
                      step="0.01"
                      style="width: 100%"
                    />
                  </v-flex>
                </v-flex>
              </v-layout>
              <v-layout class="dialog-box-sub-container">
                <v-flex row wrap>
                  <v-flex xs12>
                    <v-flex class="opacity-value-container">
                      <h4 class="opacity-title">
                        Brightness <span>{{ brightness }}</span>
                      </h4>
                    </v-flex>
                    <input
                      type="range"
                      v-model="brightness"
                      max="3"
                      min="0"
                      step="0.01"
                      style="width: 100%"
                    />
                  </v-flex>
                </v-flex>
              </v-layout>
              <v-layout class="dialog-box-sub-container">
                <v-flex row wrap>
                  <v-flex xs12>
                    <v-flex class="opacity-value-container">
                      <h4 class="opacity-title">
                        Contrast <span>{{ contrast }}</span>
                      </h4>
                    </v-flex>
                    <input
                      type="range"
                      v-model="contrast"
                      max="2"
                      min="0"
                      step="0.01"
                      style="width: 100%"
                    />
                  </v-flex>
                </v-flex>
              </v-layout>
              <v-layout class="dialog-box-sub-container">
                <v-flex row wrap>
                  <v-flex xs12>
                    <v-flex class="opacity-value-container">
                      <h4 class="opacity-title">
                        Floodfill Tolerance <span>{{ tolerance }}</span>
                      </h4>
                    </v-flex>
                    <input
                      type="range"
                      v-model="tolerance"
                      max="10"
                      min="0"
                      step="0.01"
                      style="width: 100%"
                    />
                  </v-flex>
                </v-flex>
              </v-layout>
              <!-- <v-layout class="dialog-box-sub-container">
                <v-flex row wrap>
                  <v-flex xs12>
                    <v-flex class="opacity-value-container">
                      <h4 class="opacity-title">
                        Blur <span>{{ blurNum }}</span>
                      </h4>
                    </v-flex>
                    <input
                      type="range"
                      v-model="blurNum"
                      max="1"
                      min="0"
                      step="0.1"
                      style="width: 100%"
                      @change="createImage()"
                    />
                  </v-flex>
                </v-flex>
              </v-layout> -->
              <v-flex id="reset-btn-container">
                <span
                  class="reset-img-setting-label"
                  @click="
                    (grayscale = 0),
                      (brightness = 1),
                      (contrast = 1),
                      (tolerance = 1),
                      (blur = 0.2)
                  "
                  ><img
                    title="Reset Settings"
                    class="reset-opacity-btn"
                    id="reset-img-setting-btn"
                    src="../assets/icon/refresh.svg"
                  />Reset</span
                >
              </v-flex>
            </div>
          </v-flex>
        </hsc-window>
      </hsc-window-style-white>
    </div>

    <input
      type="file"
      accept="image/*"
      id="file"
      ref="file"
      name="myfile"
      v-on:change="nextImage()"
      style="display:none"
    />

    <div class="prev-img-container">
      <v-btn
        small
        class="prev-img"
        icon
        v-if="imageId > 0"
        @click="prevImage()"
        v-tooltip:right="{ html: 'Previous image' }"
      >
        <i class="fa fa-chevron-left frame-nav-arrow"></i>
      </v-btn>
    </div>
    <div class="next-img-container">
      <v-btn
        small
        class="next-img"
        icon
        v-if="imageId <= tolatImageCount - 2 && video_type == 0"
        @click="nextImage()"
        v-tooltip:left="{ html: 'Next image' }"
      >
        <i class="fa fa-chevron-right frame-nav-arrow"></i>
      </v-btn>
    </div>
    <div class="next-img-container">
      <v-btn
        small
        class="next-img"
        icon
        v-if="video_type == 1"
        @click="selectImage()"
        v-tooltip:left="{ html: 'Next image' }"
      >
        <i class="fa fa-chevron-right frame-nav-arrow"></i>
      </v-btn>
    </div>
    <div class="sidebar-icons">
      <v-flex class="sidebar-icons--list">
        <v-flex
          v-tooltip:right="{ html: 'Save' }"
          class="sidebar-icon-container save-btn-container"
          id="save-btn"
          @click="save(), (showCheck = true)"
          title="Save annotations"
          :class="[isAnychange == true ? 'notification-unsaved-work' : '']"
        >
          <img class="save-btn-icon" src="../assets/icon/save.svg" />
        </v-flex>
        <v-flex class="sidebar-icon-container no-hover">
          <div class="cust-divider"></div>
        </v-flex>
        <v-flex
          v-tooltip:right="{ html: 'Click Box' }"
          class="sidebar-icon-container annotation-tool"
          id="click-box-tool"
          @click="setExtremeClickMode()"
          title="Click box"
        >
          <img class="sidebar-icon" src="../assets/icon/click-box.svg" />
        </v-flex>
        <v-flex
          v-tooltip:right="{ html: 'Rectangle' }"
          class="sidebar-icon-container annotation-tool"
          id="rectangle-tool"
          @click="setDrawMode()"
          title="Rectangle"
        >
          <img class="sidebar-icon" src="../assets/icon/rectangle-box.svg" />
        </v-flex>
        <v-flex
          v-tooltip:right="{ html: 'Ratio Box' }"
          class="sidebar-icon-container annotation-tool"
          id="cube-tool"
          @click="setDrawRatioMode()"
          title="Rectangle Cube"
        >
          <img class="sidebar-icon" src="../assets/icon/cube-box.svg" />
        </v-flex>
        <v-flex
          v-tooltip:right="{ html: 'Polygon' }"
          class="sidebar-icon-container annotation-tool"
          id="polygon-tool"
          @click="setPolygonMode()"
          title="Polygon"
        >
          <img class="sidebar-icon" src="../assets/icon/polygon.svg" />
        </v-flex>
        <v-flex
          v-tooltip:right="{ html: 'Polyline' }"
          class="sidebar-icon-container annotation-tool"
          @click="setLineMode()"
          id="polyline-tool"
          title="Polyline"
        >
          <img class="sidebar-icon" src="../assets/icon/polyline.svg" />
        </v-flex>
        <v-flex
          v-tooltip:right="{ html: 'Point' }"
          class="sidebar-icon-container annotation-tool"
          @click="setDotMode()"
          id="point-tool"
          title="Point"
        >
          <img class="sidebar-icon" src="../assets/icon/point.svg" />
        </v-flex>
        <v-flex
          v-tooltip:right="{ html: 'Free Hand' }"
          class="sidebar-icon-container annotation-tool"
          @click="freeHand()"
          id="free-hand-tool"
          title="Free Hand"
        >
          <img class="sidebar-icon" src="../assets/icon/free-hand-lite.svg" />
        </v-flex>
        <v-flex
          v-tooltip:right="{ html: 'Flood Fill' }"
          class="sidebar-icon-container annotation-tool"
          @click="floodFill()"
          id="flood-fill-tool"
          title="Flood Fill"
        >
          <img class="sidebar-icon" src="../assets/icon/flood-fill.svg" />
        </v-flex>
        <v-flex
          v-tooltip:right="{ html: 'Free Text' }"
          class="sidebar-icon-container annotation-tool"
          @click="freeText()"
          id="free-text-tool"
          title="Free Text"
        >
          <img class="sidebar-icon" src="../assets/icon/free-text.svg" />
        </v-flex>
        <v-flex
          v-tooltip:right="{ html: 'Content Moderation' }"
          class="sidebar-icon-container annotation-tool"
          id="blur-tool"
          @click="createImage()"
          title="Blur"
        >
          <img class="sidebar-icon " src="../assets/icon/blur.svg" />
        </v-flex>
        <v-flex
          v-tooltip:right="{ html: 'Delete' }"
          class="sidebar-icon-container delete-btn-container annotation-tool"
          id="delete-tool"
          @click="deleteObject1()"
          title="Click box"
        >
          <img
            class="sidebar-icon delete-btn-icon"
            src="../assets/icon/trash.svg"
          />
        </v-flex>
        <v-flex class="sidebar-icon-container no-hover">
          <div class="cust-divider"></div>
        </v-flex>
        <!-- <v-flex class="toolbar-list-width"  title="Mask Annotation">
                <img src="../assets/icon/mask5.png">
              </v-flex> -->

        <v-flex
          v-tooltip:right="{ html: 'Zoom In' }"
          class="sidebar-icon-container"
          @click="setZoomMode(0, 0)"
          title="ZoomIn"
        >
          <img class="sidebar-icon" src="../assets/icon/zoom-in.svg" />
        </v-flex>
        <v-flex
          v-tooltip:right="{ html: 'Zoom Out' }"
          class="sidebar-icon-container"
          @click="zoomOut(0, 0)"
          title="ZoomOut"
        >
          <img class="sidebar-icon" src="../assets/icon/zoom-out.svg" />
        </v-flex>
        <v-flex
          v-tooltip:right="{ html: 'Reset Zoom' }"
          class="sidebar-icon-container"
          @click="uiresetZoom()"
          title="Reset"
        >
          <img class="sidebar-icon" src="../assets/icon/reset-zoom.svg" />
        </v-flex>
        <v-flex class="sidebar-icon-container no-hover">
          <div class="cust-divider"></div>
        </v-flex>

        <v-flex
          v-tooltip:right="{ html: 'Right Panel' }"
          @click="openRightPanel()"
          class="sidebar-icon-container dialog-toggler active-tool"
          id="right-panel-btn"
          title="Right Panel"
        >
          <img class="sidebar-icon" src="../assets/icon/right-toolbox.svg" />
        </v-flex>
        <v-flex
          v-tooltip:right="{ html: 'Label List' }"
          @click="openLabelList()"
          class="sidebar-icon-container dialog-toggle active-tool"
          id="label-list-btn"
          title="Label List"
        >
          <img class="sidebar-icon" src="../assets/icon/label-list.svg" />
        </v-flex>
        <v-flex
          v-tooltip:right="{ html: 'Image List' }"
          @click="openFrameList(), getFrameList()"
          class="sidebar-icon-container dialog-toggler"
          id="image-list-btn"
          title="Image List"
        >
          <img class="sidebar-icon" src="../assets/icon/image-list.svg" />
        </v-flex>
        <v-flex class="sidebar-icon-container no-hover">
          <div class="cust-divider"></div>
        </v-flex>
        <v-flex
          v-tooltip:right="{ html: 'Color Palette' }"
          @click="openColorWindow()"
          class="sidebar-icon-container dialog-toggler"
          id="color-palette-btn"
          title="Colour Palette"
        >
          <img class="sidebar-icon" src="../assets/icon/color-palette.svg" />
        </v-flex>
        <v-flex
          v-tooltip:right="{ html: 'Image Tool' }"
          @click="openImageWindow()"
          class="sidebar-icon-container dialog-toggler"
          id="image-tool-btn"
          title="Image Tool"
        >
          <img class="sidebar-icon" src="../assets/icon/image-tool.svg" />
        </v-flex>

        <v-flex
          v-tooltip:right="{ html: 'Shortcuts' }"
          class="toolbar-list-width sidebar-icon-container"
          id="keyboard-shortcut-btn"
          title="Shortcuts"
          style="cursor:pointer"
        >
          <v-bottom-sheet v-model="shortcutSheet" class="keyboard-sc-container">
            <img
              class="sidebar-icon"
              slot="activator"
              src="../assets/icon/keyboard.svg"
            />
            <v-layout row wrap class="keyboard-shortcut-container">
              <v-flex xs4 v-for="shortcut in shortcuts" :key="shortcut.key">
                <v-layout row wrap class="single-key-container">
                  <v-flex xs7 class="key-desc-container">
                    {{ shortcut.desc }}
                  </v-flex>
                  <v-flex xs5 class="key-group-container">
                    <div class="key-container" v-if="shortcut.key1 != ''">
                      <span class="shortcut-key" v-if="shortcut.key1 != ''">{{
                        shortcut.key1
                      }}</span>
                    </div>
                    <div class="key-container" v-if="shortcut.key2 != ''">
                      + <span class="shortcut-key"> {{ shortcut.key2 }} </span>
                    </div>
                    <div class="key-container" v-if="shortcut.key3 != ''">
                      + <span class="shortcut-key"> {{ shortcut.key3 }} </span>
                    </div>
                  </v-flex>
                </v-layout>
              </v-flex>
            </v-layout>
          </v-bottom-sheet>
        </v-flex>
      </v-flex>
    </div>

    <div
      id="scrollDiv"
      v-bind:style="{
        width: Math.floor(canvasWidth / 20) + 'px',
        height: Math.floor(canvasHeight / 20) + 'px',
        right: Math.floor(canvasWidth / 6) + 'px',
        top: Math.floor((canvasHeight / 10) * zoomFactor) + 'px',
      }"
    >
      <img
        :src="imageSource"
        height="100%"
        width="100%"
        style="position: absolute;filter: grayscale(0) brightness(1) contrast(1);"
      />
      <div
        id="scrollDivInner"
        v-bind:style="{
          width: Math.floor(screenWidth / 20) + 'px',
          height: Math.floor(screenHeight / 20) + 'px',
        }"
      ></div>
    </div>

    <v-layout class="annotation-setting-parameters">
      <v-card id="boxset" v-show="isFreeTextOpen" :isOpen.sync="isFreeTextOpen">
        <div class="freetext-card-parameters">
          <h3 class="free-text-heading">Add Free Text</h3>
          <img
            src="../assets/icon/close-cross.svg"
            @click="isFreeTextOpen = false"
            class="close-dialog-btn"
            alt=""
          />
          <v-layout row wrap>
            <v-flex class="free-text-input-container">
              <input
                type="text"
                placeholder="Enter Text Here"
                maxlength="512"
                v-model="imageText"
                class="freetext-card-input"
              />
            </v-flex>
            <v-flex
              class="free-text-input-container"
              v-for="(item, i) in imageTagObj"
              :key="i"
              v-if="item.selected === true"
            >
              <input
                type="text"
                placeholder="Free Text"
                maxlength="512"
                v-model="imageText"
                class="freetext-card-input"
              />
            </v-flex>
          </v-layout>
          <v-layout>
            <v-flex row wrap class="radio-input-container">
              <v-flex
                xs12
                v-for="(item, i) in imageTagObj"
                :key="i"
                v-if="item.selected === true"
              >
                <input
                  name="myfield"
                  type="checkbox"
                  :value="item.name"
                  v-model="imageTextSelect"
                />
                <span class="setting-lbl">{{ item.name }}</span>
              </v-flex>
            </v-flex>
          </v-layout>
          <v-flex class="btn-container">
            <v-btn
              small
              class="cust-btn cust-primary-btn"
              @click="saveImageText()"
              >OK</v-btn
            >
          </v-flex>
        </div>
      </v-card>

      <v-card
        id="set"
        v-show="isTagOpen"
        :isOpen.sync="isTagOpen"
        class="annotation-setting-parameters--height"
      >
        <v-card-actions class="setting-card-action">
          <v-layout row wrap class="setting-card-parameters">
            <v-flex class="class-list-container">
              <v-flex
                class="single-class-container close"
                v-for="(settingItem, i) in classObj"
                :key="i"
              >
                <p class="class-label" :title="settingItem.name">
                  {{ settingItem.name }}
                </p>

                <v-layout class="attributes-container">
                  <v-flex
                    class="single-attribute-outer-container"
                    v-if="settingItem.param && extractParam.subClass"
                    v-for="(extractParam, index) in settingItem.param"
                  >
                    <v-flex
                      class="single-attribute"
                      v-if="extractParam.subClass"
                    >
                      <p class="attribute-label" :title="extractParam.name">
                        {{ extractParam.name }}
                      </p>
                      <select
                        :title="parameterLabel[[i, index]]"
                        v-model="parameterLabel[[i, index]]"
                        :id="settingItem.name + index"
                        size="1"
                        onchange="this.blur()"
                        onblur="this.size=0;"
                      >
                        <option
                          class="select-option "
                          v-for="objects in extractParam.subClass"
                          :value="objects.name"
                          :key="objects.id"
                          >{{ objects.name }}</option
                        >
                      </select>
                    </v-flex>
                    <input
                      v-if="extractParam.paralength > 0"
                      :id="settingItem.name + index"
                      class="index setting-lbl-li setting-card--input-hidden"
                      v-model="parameterLabel[[i, index]]"
                      type="text"
                      v-bind:maxlength="extractParam.paralength"
                      v-on:keypress="isNumberKey"
                      v-bind:placeholder="extractParam.name"
                    />
                  </v-flex>
                </v-layout>
                <input
                  name="myfield"
                  type="radio"
                  v-bind:value="settingItem.name"
                  v-model="radioSelect"
                  v-on:click="isTagOpen = !isTagOpen"
                  @click="giveLabel(settingItem, i)"
                  @keydown.esc="isTagOpen = false"
                />
              </v-flex>
            </v-flex>
          </v-layout>
        </v-card-actions>
      </v-card>

      <div
        v-for="(tools, index) in annotationJson"
        :key="index"
        :id="index"
        v-if="tools.bbox && showtogglebbox[index]"
      >
        <div
          style="position:absolute;"
          v-bind:style="{
            left: Math.floor(tools.bbox.xmax * zoomFactor) + 10 + 'px',
            top: Math.floor(tools.bbox.ymin * zoomFactor) + 42 + 'px',
          }"
        >
          <img
            src="../assets/icon/details.png"
            alt="details"
            @click="showAnnoDetail(index)"
          />
        </div>
      </div>
      <div
        v-for="(tools, index) in annotationJson"
        :key="index"
        :id="index"
        v-if="
          tools.polygon &&
            tools.polygon.look != 'point' &&
            tools.polygon.look != 'line' &&
            showtogglepolygon[index]
        "
      >
        <div
          style="position:absolute;"
          v-bind:style="[
            tools.polygon.points[0].y < 20
              ? {
                  left:
                    Math.floor(tools.polygon.points[0].x * zoomFactor + 35) +
                    'px',
                  top:
                    Math.floor(tools.polygon.points[0].y * zoomFactor) +
                    56 +
                    'px',
                }
              : {
                  left:
                    Math.floor(tools.polygon.points[0].x * zoomFactor) +
                    35 +
                    'px',
                  top:
                    Math.floor(tools.polygon.points[0].y * zoomFactor) +
                    68 +
                    'px',
                },
          ]"
        >
          <img
            src="../assets/icon/details.png"
            alt="details"
            @click="showAnnoDetail(index)"
          />
        </div>
      </div>

      <div
        v-for="(annoItem, i) in annotationJson"
        :key="i"
        :id="annoItem.id"
        v-if="
          annoItem.bbox &&
            showtogglebbox[i] &&
            annotationTip == 'No' &&
            isDetailVisible[i]
        "
      >
        <v-card
          class="anno-item"
          v-bind:style="[
            annoItem.bbox.ymin < 20
              ? {
                  left: Math.floor(annoItem.bbox.xmin * zoomFactor) + 28 + 'px',
                  top: Math.floor(annoItem.bbox.ymin * zoomFactor) + 52 + 'px',
                }
              : {
                  left: Math.floor(annoItem.bbox.xmin * zoomFactor) + 28 + 'px',
                  top: Math.floor(annoItem.bbox.ymin * zoomFactor) + 23 + 'px',
                },
          ]"
        >
          <div class="anno-item--error">
            <span
              v-show="annoItem.bbox.score == 0.0"
              @click="setAnnoError(annoItem)"
            >
              <i class="fa fa-circle anno-item--score-green"></i>
            </span>
            <span
              v-show="annoItem.bbox.score == 1.0"
              @click="setAnnoError(annoItem)"
            >
              <i class="fa fa-circle anno-item--score-red"></i>
            </span>
            {{ annoItem.bbox.label }}
            <span
              v-if="annoItem.bbox.parameters.length > 0"
              @click="mytoggle(i)"
            >
              <i class="fa fa-caret-down anno-item-toggle"></i>
            </span>
          </div>
          <div v-bind:style="{ color: tipTextcolor }" v-if="showDetails[i]">
            <div
              v-for="(params, index) in annoItem.bbox.parameters"
              :key="index"
            >
              {{ params.nam }} : {{ params.val }}
            </div>
          </div>
        </v-card>
      </div>
      <div
        v-for="(annoItem, i) in annotationJson"
        :key="i"
        :id="annoItem.id"
        v-if="
          annoItem.polygon &&
            showtogglepolygon[i] &&
            annotationTip == 'No' &&
            isDetailVisible[i]
        "
      >
        <v-card
          class="anno-item"
          v-bind:style="[
            annoItem.polygon.points[0].y < 20
              ? {
                  left:
                    Math.floor(annoItem.polygon.points[0].x * zoomFactor + 35) +
                    'px',
                  top:
                    Math.floor(annoItem.polygon.points[0].y * zoomFactor) +
                    56 +
                    'px',
                }
              : {
                  left:
                    Math.floor(annoItem.polygon.points[0].x * zoomFactor) +
                    'px',
                  top:
                    Math.floor(annoItem.polygon.points[0].y * zoomFactor) +
                    28 +
                    'px',
                },
          ]"
        >
          <div class="anno-item--error">
            <span
              v-show="annoItem.polygon.score == 0.0"
              @click="setAnnoError(annoItem)"
            >
              <i class="fa fa-circle anno-item--score-green"></i>
            </span>
            <span
              v-show="annoItem.polygon.score == 1.0"
              @click="setAnnoError(annoItem)"
            >
              <i class="fa fa-circle anno-item--score-red"></i>
            </span>
            <span style="margin-bottom: 1px">{{ annoItem.polygon.label }}</span>
            <span
              v-if="annoItem.polygon.parameters.length > 0"
              @click="mytoggle(i)"
            >
              <i class="fa fa-caret-down anno-item-toggle"></i>
            </span>
          </div>
          <div v-bind:style="{ color: tipTextcolor }" v-if="showDetails[i]">
            <div
              v-for="(params, index) in annoItem.polygon.parameters"
              :key="index"
            >
              {{ params.nam }} : {{ params.val }}
            </div>
          </div>
        </v-card>
      </div>

      <div
        v-for="(annoItem, i) in annotationJson"
        :key="i"
        :id="annoItem.id"
        v-if="
          annoItem.bbox &&
            showtogglebbox[i] &&
            annotationTip == 'Yes' &&
            isDetailVisible[i]
        "
      >
        <v-card
          class="anno-item"
          v-bind:style="[
            annoItem.bbox.ymin < 20
              ? {
                  left: Math.floor(annoItem.bbox.xmin * zoomFactor) + 28 + 'px',
                  top: Math.floor(annoItem.bbox.ymin * zoomFactor) + 52 + 'px',
                }
              : {
                  left: Math.floor(annoItem.bbox.xmin * zoomFactor) + 28 + 'px',
                  top: Math.floor(annoItem.bbox.ymin * zoomFactor) + 23 + 'px',
                },
          ]"
        >
          <div class="anno-item--error">
            <span
              v-show="annoItem.bbox.score == 0.0"
              @click="setAnnoError(annoItem)"
            >
              <i class="fa fa-circle anno-item--score-green"></i>
            </span>
            <span
              v-show="annoItem.bbox.score == 1.0"
              @click="setAnnoError(annoItem)"
            >
              <i class="fa fa-circle anno-item--score-red"></i>
            </span>
            {{ annoItem.bbox.label }}
          </div>
          <div v-bind:style="{ color: tipTextcolor }">
            <div
              v-for="(params, index) in annoItem.bbox.parameters"
              :key="index"
            >
              {{ params.nam }} : {{ params.val }}
            </div>
          </div>
        </v-card>
      </div>

      <div
        v-for="(annoItem, i) in annotationJson"
        :key="i"
        :id="annoItem.id"
        v-if="
          annoItem.polygon &&
            showtogglepolygon[i] &&
            annotationTip == 'Yes' &&
            isDetailVisible[i]
        "
      >
        <v-card
          class="anno-item"
          v-bind:style="[
            annoItem.polygon.points[0].y < 20
              ? {
                  left:
                    Math.floor(annoItem.polygon.points[0].x * zoomFactor + 35) +
                    'px',
                  top:
                    Math.floor(annoItem.polygon.points[0].y * zoomFactor) +
                    56 +
                    'px',
                }
              : {
                  left:
                    Math.floor(annoItem.polygon.points[0].x * zoomFactor) +
                    'px',
                  top:
                    Math.floor(annoItem.polygon.points[0].y * zoomFactor) +
                    28 +
                    'px',
                },
          ]"
        >
          <div class="anno-item--error">
            <span
              v-show="annoItem.polygon.score == 0.0"
              @click="setAnnoError(annoItem)"
            >
              <i class="fa fa-circle anno-item--score-green"></i>
            </span>
            <span
              v-show="annoItem.polygon.score == 1.0"
              @click="setAnnoError(annoItem)"
            >
              <i class="fa fa-circle anno-item--score-red"></i>
            </span>
            {{ annoItem.polygon.label }}
          </div>
          <div v-bind:style="{ color: tipTextcolor }">
            <div
              v-for="(params, index) in annoItem.polygon.parameters"
              :key="index"
            >
              {{ params.nam }} : {{ params.val }}
            </div>
          </div>
        </v-card>
      </div>
      <v-dialog
        v-model="dotWarning"
        persistent
        width="auto"
        class="dialog-container"
        v-if="dotWarning == true"
      >
        <v-card>
          <v-card-title class="dialog-title">
            <v-layout row wrap>
              <v-flex>
                <v-subheader>
                  <p class="dialog-header">
                    You cannot draw two points on same location.
                  </p>
                </v-subheader>
              </v-flex>
            </v-layout>
          </v-card-title>

          <v-card-actions>
            <v-spacer></v-spacer>
            <v-btn
              small
              class="cust-btn cust-primary-btn"
              @click.native="dotWarning = false"
              >OK</v-btn
            >
          </v-card-actions>
        </v-card>
      </v-dialog>

      <!--   <v-dialog
        v-model="settingError"
        persistent
        width="auto"
        class="dialog-container"
        v-if="settingError==true"
      >
        <v-card>
          <v-card-title class="dialog-title">
            <v-layout row wrap>
              <v-flex>
                <v-subheader>
                  <p class="dialog-header">You have changed your settings, if you want to continue click on Yes?</p>
                </v-subheader>
              </v-flex>
            </v-layout>
          </v-card-title>

          <v-card-actions>
            <v-spacer></v-spacer>
            <v-btn small class="action-button" @click.native="settingError = false">Yes</v-btn>
            <v-btn small class="action-button" @click="callSettingScreen()" @click.native="settingError = false">No</v-btn>
          </v-card-actions>
        </v-card>
      </v-dialog>  -->

      <v-dialog
        v-model="lineError"
        persistent
        width="auto"
        class="dialog-container"
        v-if="lineError == true"
      >
        <v-card>
          <v-card-title class="dialog-title">
            <v-layout row wrap>
              <v-flex>
                <v-subheader>
                  <p class="dialog-header">
                    Polyline need atleast two connecting points.
                  </p>
                </v-subheader>
              </v-flex>
            </v-layout>
          </v-card-title>

          <v-card-actions>
            <v-spacer></v-spacer>
            <v-btn
              small
              class="cust-btn cust-primary-btn"
              @click.native="lineError = false"
              @click="deselectObject()"
              >OK</v-btn
            >
          </v-card-actions>
        </v-card>
      </v-dialog>

      <v-dialog
        v-model="polygonError"
        persistent
        width="auto"
        class="dialog-container"
        v-if="polygonError == true"
      >
        <v-card>
          <v-card-title class="dialog-title">
            <v-layout row wrap>
              <v-flex>
                <v-subheader>
                  <p class="dialog-header">
                    Polygon need more than two connecting points.
                  </p>
                </v-subheader>
              </v-flex>
            </v-layout>
          </v-card-title>

          <v-card-actions>
            <v-spacer></v-spacer>
            <v-btn
              small
              class="action-button cust-btn cust-primary-btn"
              @click.native="polygonError = false"
              >OK</v-btn
            >
          </v-card-actions>
        </v-card>
      </v-dialog>

      <v-dialog
        v-model="showDialog"
        width="auto"
        class="dialog-container"
        v-if="
          (isAnychange == true || unsavechange == true) && showDialog == true
        "
      >
        <v-card>
          <v-card-title class="dialog-title">
            <v-layout row wrap>
              <v-flex>
                <v-subheader>
                  <p class="dialog-header">Please save your changes first.</p>
                </v-subheader>
              </v-flex>
            </v-layout>
          </v-card-title>

          <v-card-actions>
            <v-spacer></v-spacer>
            <v-btn
              small
              class="cust-btn cust-primary-btn"
              @click.native="showDialog = false"
              @click="saveData()"
              >OK</v-btn
            >
            <v-btn
              small
              class="cust-btn danger-btn"
              @click.native="showDialog = false"
              @click="discardChanges()"
              >Cancel</v-btn
            >
            <v-spacer></v-spacer>
          </v-card-actions>
        </v-card>
      </v-dialog>
      <v-dialog
        v-model="showObjectClassMenu"
        width="auto"
        class="dialog-container"
        v-if="showObjectClassMenu == true && isTagOpen == true"
      >
        <v-card>
          <v-card-title class="dialog-title">
            <v-layout row wrap>
              <v-flex>
                <v-subheader>
                  <p class="dialog-header">
                    Please Select Object Class or Press Esc
                  </p>
                </v-subheader>
              </v-flex>
            </v-layout>
          </v-card-title>

          <v-card-actions>
            <v-spacer></v-spacer>
            <v-btn
              small
              class="cust-btn danger-btn"
              @click.native="showObjectClassMenu = false"
              >Cancel</v-btn
            >
            <v-spacer></v-spacer>
          </v-card-actions>
        </v-card>
      </v-dialog>

      <v-dialog
        v-model="showDownloadMsg"
        width="auto"
        class="dialog-container"
        v-if="showDownloadMsg == true"
      >
        <v-card>
          <v-card-title class="dialog-title">
            <v-layout row wrap>
              <v-flex>
                <v-subheader>
                  <p class="dialog-header">
                    If you want to save please click on SAVE or to download JSON
                    please click on DOWNLOAD.
                  </p>
                </v-subheader>
              </v-flex>
            </v-layout>
          </v-card-title>

          <v-card-actions>
            <v-spacer></v-spacer>
            <v-btn
              small
              class="cust-btn cust-primary-btn"
              @click.native="showDownloadMsg = false"
              @click="saveData()"
              >SAVE</v-btn
            >
            <v-btn
              small
              class="cust-btn cust-primary-btn"
              @click.native="showDownloadMsg = false"
              @click="downloadData()"
              >DOWNLOAD</v-btn
            >
            <v-spacer></v-spacer>
          </v-card-actions>
        </v-card>
      </v-dialog>

      <!-- ################################################################################# -->
      <v-dialog v-model="checkFlag" v-if="checkFlag && showCheck" width="500px">
        <v-card>
          <v-card-text>
            A attribute is changed, how do you want to change this attribute?
          </v-card-text>
          <v-card-actions>
            <v-btn
              class="cust-btn cust-primary-btn"
              @click="
                checkSave('forward'), (showCheck = false), (checkFlag = false)
              "
            >
              Forward copy
            </v-btn>
            <v-btn
              class="cust-btn cust-primary-btn"
              @click="
                checkSave('backward'), (showCheck = false), (checkFlag = false)
              "
            >
              Backward copy
            </v-btn>
            <v-btn
              class="cust-btn cust-primary-btn"
              @click="
                checkSave('all'), (showCheck = false), (checkFlag = false)
              "
            >
              Copy on all
            </v-btn>
            <v-btn
              class="cust-btn cust-primary-btn"
              @click="
                save(),
                  (showCheck = false),
                  (dialog = false),
                  (checkFlag = false)
              "
            >
              Current frame
            </v-btn>
          </v-card-actions>
        </v-card>
      </v-dialog>

      <!-- ################################################################################# -->

      <v-dialog
        v-model="duplicateObj"
        width="auto"
        class="dialog-container"
        :persistent="true"
        v-if="showDuplicateDialog == true && duplicateObj == true"
      >
        <v-card>
          <v-card-title class="dialog-title">
            <v-layout row wrap>
              <v-flex>
                <v-subheader>
                  <p class="dialog-header">
                    You cann't copy duplicate objects in a frame. The same have
                    been highlighted in red and your changes have been
                    discarded.
                  </p>
                </v-subheader>
              </v-flex>
            </v-layout>
          </v-card-title>

          <v-card-actions>
            <v-spacer></v-spacer>
            <v-btn
              small
              class="cust-btn cust-primary-btn"
              @click="
                discardChanges();
                lockUnlockFlag = false;
                copyAnnotationList = [];
              "
              >OK</v-btn
            >
            <v-spacer></v-spacer>
          </v-card-actions>
        </v-card>
      </v-dialog>

      <v-dialog
        v-model="showlockMessage"
        width="auto"
        class="dialog-container"
        v-if="showlockMessage == true"
      >
        <v-card>
          <v-card-title class="dialog-title">
            <v-layout row wrap>
              <v-flex>
                <v-subheader>
                  <p class="dialog-header">
                    Fast annotation mode will turn off when going to previous
                    image.
                  </p>
                </v-subheader>
              </v-flex>
            </v-layout>
          </v-card-title>

          <v-card-actions>
            <v-spacer></v-spacer>
            <v-btn
              small
              class="cust-btn cust-primary-btn"
              @click.native="showlockMessage = false"
              @click="prevImage()"
              >OK</v-btn
            >
            <v-btn
              small
              class="cust-btn danger-btn"
              @click.native="(showlockMessage = false), (lockUnlockFlag = true)"
              @click="requestImage(-1)"
              >Cancel</v-btn
            >
            <v-spacer></v-spacer>
          </v-card-actions>
        </v-card>
      </v-dialog>

      <div
        v-model="showDialogOnZoom"
        class="dialog-zoom"
        v-if="showDialogOnZoom == true"
      >
        <span class="dialog-header">Zoom {{ latestZoomValue }}%</span>
      </div>

      <v-dialog
        v-model="showNotification"
        width="auto"
        class="dialog-container"
        v-if="showNotification == true"
      >
        <v-card>
          <v-card-title class="dialog-title">
            <v-layout row wrap>
              <v-flex>
                <v-subheader>
                  <p class="dialog-header">
                    Your changes has been saved successfully.
                  </p>
                </v-subheader>
              </v-flex>
            </v-layout>
          </v-card-title>
        </v-card>
      </v-dialog>

      <v-dialog
        v-model="showdelNotification"
        width="auto"
        class="dialog-container"
        v-if="showdelNotification == true"
      >
        <v-card>
          <v-card-title class="dialog-title">
            <v-layout row wrap>
              <v-flex>
                <v-subheader>
                  <p class="dialog-header">
                    Your changes has been deleted successfully.
                  </p>
                </v-subheader>
              </v-flex>
            </v-layout>
          </v-card-title>
        </v-card>
      </v-dialog>

      <v-dialog
        v-model="showRotateMsg"
        width="auto"
        class="dialog-container"
        v-if="showRotateMsg == true"
      >
        <v-card>
          <v-card-title class="dialog-title">
            <v-layout row wrap>
              <v-flex>
                <v-subheader>
                  <p class="dialog-header">
                    Would you like to rotate the image?
                  </p>
                </v-subheader>
              </v-flex>
            </v-layout>
          </v-card-title>
          <v-card-actions>
            <v-spacer></v-spacer>
            <v-btn
              small
              class="cust-btn cust-primary-btn"
              @click.native="showRotateMsg = false"
              @click="changeOrientation()"
              >Yes</v-btn
            >
            <v-btn
              small
              class="cust-btn danger-btn"
              @click.native="showRotateMsg = false"
              >No</v-btn
            >
            <v-spacer></v-spacer>
          </v-card-actions>
        </v-card>
      </v-dialog>
      <v-dialog
        v-model="isQueryError"
        persistent
        width="auto"
        class="dialog-container"
        v-if="isQueryError == true"
      >
        <v-card>
          <v-card-title class="dialog-title">
            <v-layout row wrap>
              <v-flex>
                <v-subheader>
                  <p class="dialog-header">
                    <b>Something went wrong, please contact with admin.</b>
                    <br />
                    {{ "Error Message: " }} {{ this.queryErrorResult }}
                  </p>
                </v-subheader>
              </v-flex>
            </v-layout>
          </v-card-title>
          <v-card-actions>
            <v-spacer></v-spacer>
            <v-btn
              small
              class="cust-btn cust-primary-btn"
              flat
              to="/login"
              @click="sessionStorage.clear()"
              @click.native="isQueryError = false"
              >OK</v-btn
            >
          </v-card-actions>
        </v-card>
      </v-dialog>
    </v-layout>
    <main>
      <div fluid class="canvas-class">
        <canvas
          ref="canvas"
          id="c"
          v-bind:style="[filter, filters]"
          class="canvas-image"
        ></canvas>
        <canvas id="blurCanvas"></canvas>
      </div>
    </main>
    <template>
      <!-- <div id="footer">
    <v-footer class="darken-2 footer-section">
      <v-layout row wrap align-center>
        <v-flex xs7 class="footer-title">
          <div class="white--text">All Rights Reserved.</div>
        </v-flex>
      </v-layout>
    </v-footer>
  </div> -->
    </template>
  </v-app>
</template>
<script src="./ToolsJS/2D_js/editorScript.js"></script>
<!-- loading script from external file -->
<!-- Add "scoped" attribute to limit CSS to this component only -->
<style src="@/assets/css/main.css"></style>
<style scoped src="@/assets/css/editor.css"></style>
