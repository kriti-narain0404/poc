<template>
  <v-app :dark = "isDarkMode == true">
    <home-header />
    <input type="text" name :value="getUserId" style="display:none">
    <input type="text" name :value="getCounts" style="display:none">
    <input type="text" name :value="disableBack" style="display:none">
<main>
          <v-dialog v-model="isExecutionSuccessful" class="dialog-style" v-if="isExecutionSuccessful" >
            <v-card class="dialog-container">
              <v-card-title>
                <v-layout row wrap>
                  <v-flex>
                    <v-subheader>
                      <p class="dialog-header">Pipeline Successfully Executed.</p>
                    </v-subheader>
                  </v-flex>
                </v-layout>
              </v-card-title>
            </v-card>
          </v-dialog>
  <div class="project-container">
           <v-layout xs12 row wrap heading-row class="tab-btn-container">
             <v-btn-toggle v-model="selectedTab" mandatory>
                <v-btn value="project-structure">Project Structure</v-btn>
                <v-btn value="pipeline-settings">Pipeline Settings</v-btn>
             </v-btn-toggle>
            </v-layout>


    <v-container v-if="selectedTab=='project-structure'" fluid class="page-content-container  project-structure-container">
            <v-container fluid>
              <v-layout row wrap v-for="(userItem, i) in userList">
                <v-flex xs12 d-flex>
                  <v-layout row wrap justify-center >
                    <v-flex xs2 class="single-card" :id='userItem.username' @click="cardClicked(userItem.username)">
                      <v-layout row wrap>
                        <v-flex xs4 xl3 class="avatar-container">
                          <div class="avatar">A</div>
                           <div title="Active" class="status-indicator si-green"></div>                         
                        </v-flex>
                        <v-flex class="text-container">
                          <h3 class="username" :title="userItem.username"><span v-if="userItem.editmode ==false" @dblclick="editUser(i, userItem.username)">{{userItem.username}}</span>
                                      <span><input v-on:blur="saveUser(i, adminName)" class="project-edit-input" v-if="userItem.editmode ==true"
                                      name="adminfiled" v-model="adminName" type="text"></span></h3>
                          <h3 class="user-right">Admin</h3>
                        </v-flex>
                      </v-layout>
                    </v-flex>
                  </v-layout>
                </v-flex>
                <div class="card-container-divider"></div>
                <v-flex class="group-container" id="validator-group-container"  @scroll="scrollDiv()">
                  <v-btn v-if="(userItem.validators).length > 6" class="cust-btn scroll-btn left-scroll" @click="slide('left')"><img src="../assets/icon/scroll-arrow.svg"/></v-btn>
                  <v-btn v-if="(userItem.validators).length > 6" class="cust-btn scroll-btn right-scroll" @click="slide('right')"><img src="../assets/icon/scroll-arrow.svg"/></v-btn>
                <v-flex class="single-card-container" xs2 v-for="(userval, j) in userItem.validators">
                 <v-flex  d-flex>
                  <v-layout row wrap justify-left >
                    <v-flex xs12 class="single-card" >
                      <v-layout row wrap>
                        <v-flex xs4 xl3 class="avatar-container">
                          <div class="avatar">{{userval.username[0]}}</div>
                          <div title="Active" v-if="userval.status8hr == true" class="status-indicator si-green"></div>                         
                          <div title="Idle" v-if="userval.status8hr == false && userval.status24hr == true" class="status-indicator si-amber"></div>                         
                          <div title="Offline" v-if="userval.status8hr == false && userval.status24hr == false" class="status-indicator si-red"></div>                         
                        </v-flex>
                        <v-flex class="text-container">
                          <h3 class="username" :title="userval.username"><span class="project-edit-details" v-if="userval.editmode ==false" @dblclick="editValidator(i, j)">{{userval.username}}</span>
                                      <span><input @keydown.space.prevent v-on:blur="saveValidator(i, j, valName)" class="project-edit-input" v-if="userval.editmode ==true"
                                      name="valfiled" v-model="valName" type="text"></span></h3>
                          <h3 class="user-right">Validator</h3>
                        </v-flex>
                      </v-layout>
                    </v-flex>
                  </v-layout>
                 </v-flex>
                </v-flex>
                </v-flex>
                <div class="card-container-divider"></div>
                <v-flex class="group-container" id="annotator-group-container" >
                <v-flex xs2 class="single-card-container annotator-container" v-for="(userval, j) in userItem.validators">
                 <v-flex xs12 d-flex >
                  <v-layout row wrap justify-left>
                    <v-flex xs12 class="single-card" v-for="(useranno, k) in userval.annotators" >
                      <v-layout row wrap>
                        <v-flex xs4 xl3 class="avatar-container">
                          <div class="avatar">{{useranno.username[0]}}</div>
                          <div title="Active" v-if="useranno.status8hr == true" class="status-indicator si-green"></div>                         
                          <div title="Idle" v-if="useranno.status8hr == false && useranno.status24hr == true" class="status-indicator si-amber"></div>                         
                          <div title="Offline" v-if="useranno.status8hr == false && useranno.status24hr == false" class="status-indicator si-red"></div>                          </v-flex>
                        <v-flex class="text-container">
                          <h3 class="username" :title="useranno.username"><span class="project-edit-details" v-if="useranno.editmode ==false" @dblclick="editAnnotator(i, j, k)">{{useranno.username}}</span>
                                        <span><input @keydown.space.prevent v-on:blur="saveAnnotator(i, j, k, annoName)" class="project-edit-input" v-if="useranno.editmode ==true"
                                        name="anofiled" v-model="annoName" type="text"></span></h3>
                          <h3 class="user-right">Annotator</h3>
                        </v-flex>
                      </v-layout>
                    </v-flex>
                  </v-layout>
                </v-flex>
                </v-flex>
                </v-flex>
              </v-layout>
            </v-container>
          <v-flex xs12 class="button-style">
            <v-btn  @click="AddProjectDialog = true" class="cust-btn danger-btn add-btn"> Modify Structure</v-btn>            
            <v-btn  @click="saveAllUser()" class="cust-btn cust-submit-btn cust-primary-btn">Submit</v-btn>
          </v-flex>

            <v-dialog
              v-model="AddProjectDialog"
              class="dialog-style"
              v-if="AddProjectDialog==true"
              light
              persistent
            >

          <v-layout>
            <v-flex class="dialog-container form-container">
              <h3 class="dialog-title">Add New Project</h3>
              <v-flex class="dialog-form-container">
                            <v-flex class="input-container">
                                <v-flex class="flex-container">
                                <h3 class="input-label text-align--left">Project</h3>
                                </v-flex>
                                <input label="Project" v-model="projectName" class="field-settings cust-input-field" solo></input>
                              </v-flex>
                            <v-flex class="input-container">
                                <v-flex class="flex-container">
                                <h3 class="input-label text-align--left">Select Admin</h3>
                                </v-flex>
                                <input label="Select Admin"  v-model="adminName" class="field-settings cust-input-field" solo></input>
                              </v-flex>
                              <v-flex class="input-container">
                                <v-flex class="flex-container">
                                <h3 class="input-label text-align--left">Select Validator</h3>
                                </v-flex>
                                <input @keydown.space.prevent label="Validator" id="valName" v-model="valName" v-if="isValCategoryEdit ==true" @dblclick="editValCategory()"  class="field-settings cust-input-field" solo></input>
                                <v-select :items="valList" v-model="valName" label="Validator" v-if="isValCategoryEdit ==false" @dblclick="editValCategory()" @input="changeAnnoClass()" class="field-settings field-settings cust-input dropdown" solo></v-select>
                              </v-flex>
                              <v-flex class="input-container">
                                <v-flex class="flex-container">
                                <h3 class="input-label text-align--left">Select Annotator</h3>
                                </v-flex>
                                <input @keydown.space.prevent label="Annotator" id="annoName" v-model="annoName" v-if="isAnnoCategoryEdit ==true || isValCategoryEdit ==true" @dblclick="editAnnoCategory()" class="field-settings cust-input-field" solo></input>
                                <v-select :items="annoList" v-model="annoName" label="Annotator" v-if="isAnnoCategoryEdit ==false && isValCategoryEdit ==false" @dblclick="editAnnoCategory()" class="field-settings cust-input dropdown" solo></v-select>
                              </v-flex>
                                              

                      <div class="error-message" v-if="required==true">
                        <span>All fields are required.</span>
                      </div>
                      <div class="error-message" v-if="sameNameVerify==true">
                        <span>Same usernames are not allowed.</span>
                      </div>
                      <div class="error-message" v-if="isUserExist==true">
                        <span>{{ adminExistMessage }}</span>
                    </div>
                      <img class="close-btn" src="../assets/icon/close-cross.svg" @click="closeAddObjDialog()" alt="">
              </v-flex>
                    <v-flex class=" dialog-btn-container flex-container justify-cont--center">
                      <v-btn class="cust-btn cust-primary-btn submit-btn" @click="addValidUser(projectName, adminName, valName , annoName)">Create</v-btn>
                      <v-btn class="cust-btn danger-btn" @click="deleteUser(projectName, adminName, valName, annoName)">Delete</v-btn>
                      
                  </v-flex>
            </v-flex>
          </v-layout>
             </v-dialog>
          
          <v-dialog
          persistent          
              v-model="addUserNotification"
              width="auto"
              class="dialog-style"
              v-if="addUserNotification==true"
            >
              <v-card>
                <v-card-title add-user-notification-style>
                  <v-layout row wrap>
                    <v-flex>
                      <v-subheader>
                        <p class="dialog-header">Please add the user first</p>
                      </v-subheader>
                    </v-flex>
                  </v-layout>
                </v-card-title>
              </v-card>
          </v-dialog>


          <v-dialog
                  v-model="notifyReport"
                  width="500px"           
                  class="dialog-style"
                  v-if="notifyReport==true"
                >
                  <v-card>
                    <v-card-title>
                      <v-layout row wrap>
                        <v-flex>
                        <div class="report-header">
                        <h6>Report</h6>
                      </div>
                          <p class="report-details-header" v-html="reportDetails"></p>
                        </v-flex>
                      </v-layout>
                    </v-card-title>
                  </v-card>
          </v-dialog>

                  <v-dialog
                  persistent
                  v-model="deleteDialog"
                  class="dialog-style"
                  v-if="deleteDialog"
                >
                  <v-card class="dialog-container delete-dialog">
                    <v-card-title add-user-notification-style>
                      <v-layout row wrap>
                        <v-flex>
                          <v-subheader>
                            <p class="dialog-header">Are you sure you want to delete?</p>
                          </v-subheader>
                        </v-flex>
                      </v-layout>
                    </v-card-title>

                    <v-card-actions>
                      <v-flex class=" dialog-btn-container">
                      <v-btn small class="cust-btn submit-btn " @click.native="deleteDialog = false;deleteUser(projectName, adminName, valName, annoName)">OK</v-btn>
                      <v-btn small class="cust-btn danger-btn" @click.native="deleteDialog = false;">Cancel</v-btn>
                      </v-flex>

                    </v-card-actions>
                  </v-card>
          </v-dialog>
    </v-container>
    <v-container v-if="selectedTab=='pipeline-settings'" fluid class="page-content-container  objects-container">
              <v-layout row wrap>
                <v-flex xs3 class="outer-group-container script-field-container">
                <v-flex xs12 class="inner-group-container">
                  <h2 class="inner-group-container--title">Script Setting</h2>
                  <v-flex xs12 class="input-field-container">
                    <h3 class="input-label">Scheduler</h3>
                    <v-btn-toggle mandatory v-model="schedulerType" class="switch-btn-group">
                      <v-btn class="switch-btn left-btn" name="myfield_1" value="time"  v-model="schedulerType" title="Backward">Time</v-btn>
                      <v-btn class="switch-btn right-btn" name="myfield_1" value="frequency"  v-model="schedulerType" title="Forward">Frequency</v-btn>
                    </v-btn-toggle>   
                    <input v-if="schedulerType == 'time'" v-model="schedulerTime" type="time"  class="cust-input-field source-bkt-path-field"  placeholder="" />
                    {{schedulerTime}}
                    <v-select v-if="schedulerType == 'frequency'" class="form-group dropdown-field cust-input-field" v-model="schedulerTime" :items="frequencyList"  label="Select Frequency" solo>
                    </v-select>
                    <!-- <v-time-picker value="" format="24hr" landscape></v-time-picker> -->
                  </v-flex>
                  
                  <v-flex xs12 class="input-container">
                    <h3 class="input-label">Source Bucket Name</h3>
                      <input v-model="sourceBucketName"  class="cust-input-field source-bkt-path-field"  placeholder="" />
                  </v-flex>
                  <v-flex xs12 class="input-field-container">
                    <h3 class="input-label">Source Path</h3>
                      <input v-model="sourcePath"  class="cust-input-field source-bkt-path-field"  placeholder="" />
                  </v-flex>
                  <v-flex xs12 class="input-field-container">
                    <h3 class="input-label">Destination Bucket Name</h3>
                      <input v-model="destBucketName"  class="cust-input-field source-bkt-path-field"  placeholder="" />
                  </v-flex>
                  <v-flex xs12 class="input-field-container">
                    <h3 class="input-label">Destination Path</h3>
                      <input v-model="destPath"  class="cust-input-field source-bkt-path-field"  placeholder="" />
                  </v-flex>
                  <v-flex xs12 class="input-field-container">
                    <h3 class="input-label">File Type</h3>
                    <v-select multiple class="form-group  dropdown-field cust-input-field" v-model="fileTypeSelected" :items="fileTypeList" label="Select File Type" solo></v-select> 
                  </v-flex>
                </v-flex>
                <v-flex xs12 class="inner-group-container">
                  <v-flex xs12 class="input-field-container">
                    <h3 class="input-label">Select Project</h3>
                    <input class="form-group cust-input-field" disabled v-model="projectName" label="Select Project" solo></input>
                  </v-flex>
                  <v-flex xs12 class="input-field-container">
                    <h3 class="input-label">Division Type</h3>
                    <input class="form-group  dropdown-field cust-input-field" v-model="divisionType" :items="['Daywise','Annotationwise']" label="Select Division Type" solo></v-select>
                  </v-flex>
                  <v-flex xs12 class="input-field-container">
                    <h3 class="input-label">No. of Days Required</h3>
                      <input v-model="daysRequired" type="number" class="cust-input-field"  placeholder="Enter number of days required" />
                  </v-flex>
                  <v-flex xs12 class="input-field-container">
                    <h3 class="input-label">Avrage Object Per Frame</h3>
                      <input v-model="avgObject" type="number" class="cust-input-field"  placeholder="Enter average object per frame" />
                  </v-flex>
                  <v-flex xs12 class="input-field-container">
                    <h3 class="input-label">Number Of Annotators Available</h3>
                      <input v-model="annoAvailable" type="number" class="cust-input-field"  placeholder="Enter number of annotator available" />
                  </v-flex>
                  <v-flex xs12 class="input-field-container">
                    <h3 class="input-label">Ratio (Ann. vs Validator)</h3>
                      <input v-model="ratioAVV" type="number" class="cust-input-field"  placeholder="Enter ratio" />
                  </v-flex>
                  <v-flex xs12 class="input-field-container">
                    <h3 class="input-label">Number of Days Available</h3>
                      <input v-model="daysAvailable" type="number" class="cust-input-field"  placeholder="number of days available" />
                  </v-flex>
                  <v-flex xs12 class="input-field-container">
                    <h3 class="input-label">Productivity</h3>
                      <input v-model="productivityField" type="number" class="cust-input-field"  placeholder="Enter productivity" />
                  </v-flex>
                  <v-flex xs12 class="input-field-container">
                    <h3 class="input-label">Number of Frames</h3>
                      <input v-model="noOfFrames" type="number" class="cust-input-field"  placeholder="Enter number of frames" />
                  </v-flex>
                  <v-flex xs12 class="input-field-container">
                    <h3 class="input-label">Number of Annotator Required</h3>
                      <input v-model="annoRequired" type="number" class="cust-input-field"  placeholder="Enter number of annotator required" />
                  </v-flex>
                  <v-flex xs12 class="input-field-container">
                    <h3 class="input-label">Number of Validator Available</h3>
                      <input v-model="valAvaialable" type="number" class="cust-input-field"  placeholder="Enter number of validator available" />
                  </v-flex>
                  <v-flex xs12 class="input-field-container">
                    <h3 class="input-label">Conversion Script</h3>
                    <v-select class="form-group  dropdown-field cust-input-field" v-model="conversionScript" :items="['Script 1','Script 2']" label="Select " solo></v-select>
                  </v-flex>
                   <v-flex class=" dialog-btn-container flex-container justify-cont--center">
                      <v-btn v-if="role=='ADMIN'" class="cust-btn cust-primary-btn submit-btn">Submit</v-btn>
                      <v-btn class="cust-btn danger-btn">Reset</v-btn>
                    </v-flex>
                </v-flex>
                </v-flex>
                <v-flex xs6 class="outer-group-container">
                  <v-flex xs12 class="inner-group-container pipeline-container">
                    <v-flex class="pipeline-fields-container" id="pipeline-fields-container">
                   <v-flex xs12 class="input-field-container">
                    <v-select class="form-group  dropdown-field cust-input-field" item-text="Data Copier" item-value="Data Copier" :items="[...modelComponents, ...modelItems]" disabled value="Data Copier" label="Data Copier" solo></v-select>
                   </v-flex>
                   <v-flex v-for="(key, i) in componentLists" xs12 class="input-field-container">
                    <v-flex class="arrow-container">
                    <img src="../assets/icon/down-arrow.svg" alt=""> 
                    </v-flex>
                    <v-select class="form-group  dropdown-field cust-input-field"  v-model="componentName[i]" :items="[...modelComponents, ...modelItems]" @input="updateComponentField(i,componentName[i])" label="Select Pipeline Block" solo></v-select>
                   </v-flex>
                    </v-flex>
                   <v-flex class="add-component-container" @click="addComponentField()">
                     <img src="../assets/icon/Add-Plus.svg">Click here to add new model / Component 
                     </v-flex>
                      <v-flex class="dialog-btn-container flex-container justify-cont--center">
                      <v-btn class="cust-btn cust-primary-btn submit-btn" @click="executePipeline()" :disabled="isDisableExecution === true">Execute</v-btn>
                      <v-btn class="cust-btn danger-btn" @click="componentFields = []">Reset</v-btn>
                    </v-flex>
                  </v-flex>
                </v-flex>
                <v-flex xs3 class="outer-group-container">
                  <v-flex xs12 class="inner-group-container">
                    <v-flex xs12 class="search-container">
                     <div class="search-box">
                       <img class="search-icon" src="../assets/icon/search.svg"/>
                       <input class="input-field" id="search-component" type="text" v-model="searchComponent" placeholder="Search" />
                       <img @click="clearSearch()" v-if="search" class="close-icon" src="../assets/icon/close-cross.svg">
                     </div>
                    </v-flex>
                    <v-flex xs12 class="component-group-container models-group">
                      <h3 class="component-group-container--title">Models</h3>
                      <v-flex class="component-group-inner-container">
                      <v-flex v-for="key in modelItems" xs12 class="single-component-container">
                        {{key}}
                      </v-flex>
                      </v-flex>
                    </v-flex>
                    <v-flex xs12 class="component-group-container components-group">
                      <h3 class="component-group-container--title">Components</h3>
                      <v-flex class="component-group-inner-container">
                      <v-flex v-for="key in modelComponents" xs12 class="single-component-container">
                        {{key}}
                      </v-flex>
                      </v-flex>
                    </v-flex>
                  </v-flex>
                </v-flex>
              </v-layout>
          <v-dialog v-model="pipelineExecuteDialog" width="20vw" height="400px" class="dialog-style" v-if="pipelineExecuteDialog==true" >
            <v-card class="dialog-container">
              <v-card-title>
                <v-layout row wrap>
                  <v-flex>
                    <v-subheader>
                      <p class="dialog-header">Pipeline Execution Started</p>
                    </v-subheader>
                  </v-flex>
                </v-layout>
              </v-card-title>
            </v-card>
          </v-dialog> 
    </v-container>
  </div>
   </main>
  </v-app>
</template>

<script src="./ToolsJS/2D_js/userList.js"></script>
<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped src="@/assets/css/main.css"></style>
<style scoped src="@/assets/css/userlist.css"></style>
