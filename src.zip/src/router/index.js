import Vue from "vue";
import Router from "vue-router";
import Editor from "@/components/Editor";
import Home from "@/components/Home";
import Setting from "@/components/Setting";
import UserList from "@/components/userList";
import Login from "@/components/Login";
import Dashboard from "@/components/Dashboard";
import Signup from "@/components/Signup";
import Forget from "@/components/Forget";
import authPin from "@/components/authPin";
import Mask from "@/components/Mask";
import Editor_3d from "@/components/editor_3d";
import TextEditor from "@/components/TextEditor";

Vue.use(Router);

export default new Router({
  routes: [
    {
      path: "/project/:project",
      name: "editor",
      component: Editor,
      props: true,
    },
    {
      path: "/home",
      name: "home",
      component: Home,
    },
    {
      path: "/setting",
      name: "setting",
      component: Setting,
      props: true,
    },
    {
      path: "/userList",
      name: "userList",
      component: UserList,
      props: true,
    },
    {
      path: "/dashboard",
      name: "dashboard",
      component: Dashboard,
      props: true,
    },
    {
      path: "/textEditor",
      name: "textEditor",
      component: TextEditor,
      props: true,
    },
    {
      path: "/signup",
      name: "signup",
      component: Signup,
      props: true,
    },
    {
      path: "/forget",
      name: "forget",
      component: Forget,
      props: true,
    },
    {
      path: "/authPin",
      name: "authPin",
      component: authPin,
      props: true,
    },
    {
      path: "/mask",
      name: "mask",
      component: Mask,
      props: true,
    },
    {
      path: "/editor_3d",
      name: "editor_3d",
      component: Editor_3d,
      props: true,
    },
    {
      path: "/login",
      name: "login",
      component: Login,
      props: true,
    },
    {
      path: "/",
      redirect: "/login",
    },
  ],
});
