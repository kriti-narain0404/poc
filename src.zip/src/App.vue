<template>
<div id="app">
  <head></head>
  <router-view></router-view>
</div>
</template>

<script>
import Vue from "vue";

export default {
  name: "app"
};
</script>

<style src="@/main.css"></style>
