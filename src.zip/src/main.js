// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from "vue";
import App from "./App";
import router from "./router";
import VueApollo from "vue-apollo";
import Vuetify from "vuetify";
import VueEditor from "vue2-editor";
import * as VueWindow from "@hscmap/vue-window";
import "expose-loader?$!expose-loader?jQuery!jquery";
import "jquery-ui-dist/jquery-ui";
import "material-design-icons-iconfont";

var config = require("../config");
import("../node_modules/vuetify/dist/vuetify.min.css"),
  import("../node_modules/vue-swatches/dist/vue-swatches.min.css");
// add css
import "@fortawesome/fontawesome-free/css/all.css";
import "@fortawesome/fontawesome-free/js/all.js";
// add js for apolloclient details
import { apolloClient, networkInterface } from "./client_apollo.js";

const EventBus = new Vue();
console.log(process.env.NODE_ENV, process.env.NODE_ENV === "development");
Vue.config.productionTip = false;

//Vue.prototype.$hostname = 'http://13.232.109.172:5000';
Vue.prototype.$hostname = "http://localhost:5000";

networkInterface.use([
  {
    applyMiddleware(req, next) {
      if (!req.options.headers) {
        req.options.headers = {};
      }
      req.options.headers["Authorization"] = `Bearer ${sessionStorage.getItem(
        "accessToken"
      )}`;
      req.options.headers["X-XSS-Protection"] = `1; mode=block`;
      req.options.headers["X-Content-Type-Options"] = `nosniff`;
      req.options.headers["Cache-Control"] = `no-store,no-cache`;
      next();
    },
  },
]);

Vue.use(VueApollo, {
  apolloClient,
});
Vue.use(Vuetify);
Vue.use(VueWindow);
Vue.use(VueEditor);

const apolloProvider = new VueApollo({
  defaultClient: apolloClient,
  defaultOptions: {
    $loadingKey: "loading",
  },
});

/* eslint-disable no-new */
new Vue({
  el: "#app",
  apolloProvider,
  router,
  template: "<App/>",
  components: { App },
});
