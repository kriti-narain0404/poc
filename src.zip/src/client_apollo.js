// This js is used to expose the apollo client outside vue component

import ApolloClient, { createNetworkInterface } from 'apollo-client';

if (process.env.NODE_ENV === 'development') {
  //var ENDPOINT = 'http://13.232.109.172:5000';
  var ENDPOINT = 'http://localhost:5000';
} else {
  //var ENDPOINT = 'http://13.232.109.172:5000';
  var ENDPOINT = 'http://localhost:5000';
}

export const networkInterface = createNetworkInterface({
  uri: `${ENDPOINT}/graphql`,
  transportBatching: true,
  mode: 'no-cors',
});

export const apolloClient = new ApolloClient({networkInterface});

//https://stackoverflow.com/questions/45461745/how-can-i-re-run-vue-js-apolloclient-middleware



