from PIL.Image import NONE
from jwt.exceptions import DecodeError, ExpiredSignatureError
from commons import constants as cfg
from graphql import (GraphQLError)
from utils.errors_utils import Error
from flask import Flask, request, jsonify, make_response
import jwt
import sys
import time
from functools import wraps
import datetime
from utils.logger import Logger
logger = Logger.get_logger()


def create_access_token(payload):
    '''
     This function to create JWT token and pass to login method
    '''
    encoded_jwt = None
    try:
        payload['exp'] = datetime.datetime.utcnow() + datetime.timedelta(minutes=1500)
        encoded_jwt = jwt.encode(payload, cfg.SECRET_KEY, algorithm="HS256")
        return encoded_jwt.decode('utf-8')
    except Exception as e:
        logger.info("Authorization Token is generated %s",e)
        pass
    return encoded_jwt


def auth(func):
    '''
     decorator to valid jwt token
    '''
    def authenicate(*args, **kwargs):
        auth_value = validate_jwt()
        if auth_value is None:
            return None
        else:
            return func(*args, **kwargs)
    return authenicate

# def auth_validator(func):
#     '''
#      decorator to valid jwt token
#     '''
#     fun = getattr(func, '__inds_static_hack__', func)
#     def authenicate(*args, **kwargs):
#         validate_jwt()
#         return fun(*args, **kwargs)
#     authenicate.__name__ = fun.__name__
#     return authenicate

# # Ref---https://github.com/cython/cython/issues/1434


def validate_jwt():
    '''
     This function to validate JWT token
    '''
    token = None
    token_validation_val = None
    # jwt is passed in the request header in Authorization
    if 'Authorization' in request.headers:
        token = request.headers['Authorization']
        token = (lambda token : token.split()[1] if len(token.split()) >= 2 else None)(token)
    if not token:
        logger.info("Authorization Token is missing")
        return token_validation_val
    else:    
        try:
            # decoding the payload to fetch the stored details
            token_validation_val = jwt.decode(token, cfg.SECRET_KEY, algorithms=["HS256"])
        except (DecodeError, ExpiredSignatureError) as e :
            logger.info("Authorization Token is not valid or expired %s",e)
            raise GraphQLError(Error.get_error_object(sys.exc_info()[0].__name__))

            pass
        except Exception as exc:
            logger.info("Authorization Token is not valid or expired %s",exc)
            raise GraphQLError(Error.get_error_object(sys.exc_info()[0].__name__))

            pass

    return token_validation_val
