"""
Author:Kush
File usage: This file is used to load the configuration 
Created-Date: 17/11/2021
Updated-Date: 30/11/2021
NoesisAutoTagAI Copyright @HCL-2021
"""

import json
import os
import traceback
from utils.logger import Logger
from commons.constants import JsonLoadConfig3DConstanst as c
from nat_3D_Backend.structures.data_structures_3D import ObjConfig
from nat_3D_Backend.dao.JsonLoadConfig_dao import JsonLoadConfigDao
from nat_3D_Backend.exception.JsonLoadConfig_exception import JsonLoadConfig3DException
from nat_3D_Backend.commons.getfolderpath import FetchFolderPath
from nat_3D_Backend.commons.getVideoName import fetchVideoName

logger = Logger.get_logger()

class LoadConfig3D:
    """
    Description: This Class is used to read the config file of specific project and used to forward its content .
    """

    def __init__(self,video_id):
        """
        Description    : This is used to intialize the class loadConfig
        :param video_name: type: Int value. eg: 32
        """
        self.video_id = video_id

    def getVideoName(self):
        """
        Description    : returns the video name for a particular video id
        """
        return fetchVideoName(self.video_id).FetchVideoName()

    def setVideoName(self):
        """
        Description : It fetch the VideoName and set its value to video_name variable
        """
        self.video_name = self.getVideoName()

    def __get_json_load_config_dao_obj(self):
        """
        Description : This method is used to initialize the object of JsonLoadConfifDao class
        return: Obj of JsonLoadConfigDao class 
        Raises:
            JsonLoadConfig3DException: [description]
        """
        obj_config_dao = None
        try:
            obj_config_dao = JsonLoadConfigDao(self.video_name)
        except Exception as e:
            raise JsonLoadConfig3DException("Unable to create Object of JsonLoadConfig Dao Class , - {0}, Traceback: {1}".format(e, traceback.format_exc(limit=1)))
        if obj_config_dao is None:
            raise JsonLoadConfig3DException("JsonLoadConfigDao Object is None, please check intialization of JsonLoadConfig_Dao - {0} ".format(traceback.extract_stack(limit=1)))

        return obj_config_dao

    def __get_project(self,configDao_obj):
        """
        Description : This function is used fetch the project name from db using video_name
        :return: String of project name [Example : "Magna"]
        Raises:
            JsonLoadConfig3DException: [description]
        """
        prj_name = None
        
        prj_name = configDao_obj.fetch_project_name_dao().get("project_name")
        return prj_name

    def __get_folder_path_obj(self):
        """
        Description : This method is used to initialize the object of FetchFolderPath class
        :return: Obj of FetchFolderPath
        Raises:
            JsonLoadConfig3DException: [description]
        """
        fetch_path_obj = None
        try:
            fetch_path_obj = FetchFolderPath(self.video_id)
        except Exception as e:
            raise JsonLoadConfig3DException("Unable to create Object of FetchFolderPath Class , - {0}, Traceback: {1}".format(e, traceback.format_exc(limit=1)))
        if fetch_path_obj is None:
            raise JsonLoadConfig3DException("FetchFolderPath Object is None, please check intialization of FetchFolderPath Class - {0} ".format(traceback.extract_stack(limit=1)))
        return fetch_path_obj

    def __findConfig(self):
        """
        Description : This function is used to search and locate the config file inside the data directory.
        :return: Configuration File Path
        Raises:
            JsonLoadConfig3DException: [description]
        """
        configFilePath = None
        folder_path_obj = None
        obj_JsonLoadConfig_dao = None
        self.project_name = None

        #Creating an obj of fetchfolderpath class and constructing the folder path which contains the projects_config json's    
        folder_path_obj = self.__get_folder_path_obj()
        dataPath = folder_path_obj.fetch_folder_path()

        #Creating the DAO Object for fetching project_name from db
        obj_JsonLoadConfig_dao = self.__get_json_load_config_dao_obj()
        
        #Fetching the project name from db using the video_name
        self.project_name = self.__get_project(obj_JsonLoadConfig_dao)

        #Constructing the Config JSON's File Path 
        if os.path.exists(os.path.join(dataPath,c.FOLDER_NAME,self.project_name.replace(" ","_")+".json")):
            configFilePath = os.path.join(dataPath,c.FOLDER_NAME,self.project_name.replace(" ","_")+".json") 
        else:
            raise JsonLoadConfig3DException("Error finding the config JSON file , Kindly check configFilePath , - Traceback: {0}".format(traceback.extract_stack(limit=1)))
        
        if configFilePath is None:
                raise JsonLoadConfig3DException("confgFilePath is None , Kindly check the same .{0}".format(traceback.extract_stack(limit=1)))


        return configFilePath
    
    def readConfig(self):
        """
        Description : This Function is used to read the config file and return its contents
        :return: Config JSON Data
        Raises:
            JsonLoadConfig3DException: [description]
        """
        logger.info("[INFO]: Inside readConfig Function")
        response = None

        #Setting the video_name variable to its fetched value using video_id
        self.setVideoName()

        # Getting the config file path
        configPath = self.__findConfig()
        # Reading the config json file
        with open(configPath) as cfg:
            try:
                jsonData = json.load(cfg)
            except Exception as e:
                raise JsonLoadConfig3DException("Unable to extract the data from JSON File , Kindly check jsonData var -{0}, Traceback: {1}".format(e, traceback.format_exc(limit=1)))
        response = ObjConfig(
            jsonData=json.dumps(jsonData)
        )
        return response
    
        

