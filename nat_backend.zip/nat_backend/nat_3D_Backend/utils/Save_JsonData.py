"""
Author:Shanam Afzal
File usage: This file saves the json data into json file.
Created-Date: 25/11/2021
Updated-Date: 30/11/2021
NoesisAutoTagAI Copyright @HCL-2021
"""

from utils.logger import Logger
logger = Logger.get_logger()
import json
import os
from datetime import datetime
import random
import string
from nat_3D_Backend.utils.UIviewer_util import UIviewer
from commons.constants import Json_Constants as jc
from nat_3D_Backend.exception.saveJsonException import SaveJsonFileException
from structures.data_structures import ObjResponse
import traceback
from nat_3D_Backend.commons.getfolderpath import FetchFolderPath
from nat_3D_Backend.commons.getVideoName import fetchVideoName


class SaveJsonFile:
    """
    Description              : This class loads image, pcd, json data for video with specific image id.
    """
    def __init__(self, v_id, im_id, json_data, proj_id, auto_anno):
        """
        Description            : Initializes the object for SaveJsonFile class
        parameter v_id         : id of the video of interest
        parameter im_id        : image number
        parameter json_data    : data to be stored in json file
        """
        self.video_id = v_id
        self.image_id = im_id
        self.jsonData = json_data
        self.project_id = proj_id
        self.auto_annotations = auto_anno
        #self.config_type = config_flag
        
    def getVideoName(self):
        """
        Description    : returns the video name for a particular video id
        """
        return fetchVideoName(self.video_id).FetchVideoName()

    def fetchSaveDirPath(self):
        """
        Description          : This method fetches directory path for json file to be saved
        Return               : Returns directory path where json file is to be saved
                               Example :
        Raises               : SaveJsonFileException: [description]
                               
        """
        obj_FetchFolderPath = FetchFolderPath(self.video_id)
        self.data_3D_path = obj_FetchFolderPath.fetch_folder_path()
        json_path = os.path.join(self.data_3D_path, self.video_name, 'json')
        if not os.path.exists(json_path):
            logger.info("[INFO]: The json directory {0} doesnot exists...Making Directory".format(json_path))
            if not os.path.isdir(json_path):
                os.mkdir(json_path)
        return json_path


    def saveJsonAnnotation(self):
        """
        Description          : This method created json file and save the json data into that json file                       
        Raises               : SaveJsonFileException: [description]
                               
        """
        status = False
        logger.info("[INFO]: Inside save Json Annotation")
        self.annotations = json.loads(self.jsonData.replace("'",'"'))
        self.video_name = self.getVideoName()
        self.save_dir = self.fetchSaveDirPath()
        json_file = self.save_dir +'/'+self.getImageName().split('.')[0]+".json"
        self.annotations = self.getNatJsonStructure()
        try:
            with open(json_file, 'w') as json_handle:
                json.dump(self.annotations, json_handle,indent=4,sort_keys=True)
                status = True
        except Exception as e:
            raise SaveJsonFileException("Json file doesnt exist, -{0}, Traceback: {1}".format(e, traceback.format_exc(limit=1)))
        response = ObjResponse(
            status=status,
            )
        return response

    def getNatJsonStructure(self):
        """
        Description : This methods converts the 3D Bat Json structure to NAT Json structure
        Raises : SaveJsonFileException: [description]
        Return : Nat_Json_Format
        """
        logger.info("[INFO]: Inside getNatJsonStructure")
        track = False
        current = datetime.now()
        date_time = current.strftime("%d/%m/%Y %H:%M:%S")   
        updated_imageName = os.path.splitext(self.getImageName())[0]
        nat_json_format = {"created": date_time,"height":"900","img":{updated_imageName:{"annotations":[]}}}

        #Velocity Parameter Value (to be changed to dynamic when it gets implemented)
        velocity_parameter_value = "79m/s"
        #Fill Color Value (will be dynamic as per implementation)
        fill_value = "#e8867c"
        #Opacity Value (will be dynamic as per implementation)
        opacity_value = "0.5"
        
        for j in range(len(self.annotations[jc.KEY_LABELS])):
            # random_id = ''.join(random.choices(string.ascii_uppercase + string.digits, k = 10)) 
            annos_entry = {
                "bbox":None,
                "id":self.annotations[jc.KEY_LABELS][j]["id"],
                "imageTag":None,
                "label":self.annotations[jc.KEY_LABELS][j]["category"],
                "polygon":None,
                "bbox3d":""
                }
            nat_json_format[jc.KEY_IMG][updated_imageName][jc.KEY_ANNOTATIONS].append(annos_entry)

            locked_objects = self.get_locked_objects()
            if j in locked_objects:
                track = True
            else:
                track = False
            bbox3d = {
                "annoId":self.annotations[jc.KEY_LABELS][j]["id"],
                "fill":fill_value,
                "label":self.annotations[jc.KEY_LABELS][j]["category"],
                "opacity":opacity_value,
                "velocity":velocity_parameter_value,
                "parameters":[],
                "points":[],
                "score":0.0,
                "track":track,
                "dimension":self.annotations[jc.KEY_LABELS][j]["box3d"][jc.KEY_DIMENSIONS],
                "location":self.annotations[jc.KEY_LABELS][j]["box3d"][jc.KEY_LOCATION],
                "orientation":self.annotations[jc.KEY_LABELS][j]["box3d"][jc.KEY_ORIENTATION]
                }
            
            for param_count in range(len(self.annotations[jc.KEY_LABELS][j]["box3d"][jc.KEY_PARAMETERS])):
                param_format = {
                    "nam":self.annotations[jc.KEY_LABELS][j]["box3d"][jc.KEY_PARAMETERS][param_count]["nam"],
                    "val":self.annotations[jc.KEY_LABELS][j]["box3d"][jc.KEY_PARAMETERS][param_count]["val"]
                    }
                bbox3d[jc.KEY_PARAMETERS].append(param_format)
            nat_json_format[jc.KEY_IMG][updated_imageName][jc.KEY_ANNOTATIONS][j][jc.KEY_BBOX3D] = bbox3d
        return nat_json_format

    def getImageName(self):
        """
        Description          : This method fetches image_name for given image_id
        Return               : Returns image_name path for given image_id
        Raises               : SaveJsonFileException: [description]
                               
        """
        try:
            signal = 2
            empty_list = []
            obj_UIViewer = UIviewer(self.video_id, self.image_id,signal, self.project_id, empty_list, 2, "")
        except Exception as e:
            raise SaveJsonFileException("Couldnt create UIViewer class object, -{0}, Traceback: {1}".format(e, traceback.format_exc(limit=1)))
        image_name = obj_UIViewer.image_name_extractor(os.path.join(self.data_3D_path, self.video_name))
        return image_name


    def get_locked_objects(self):
        """
        Description          : This method fetches ids of locked objects
        Return               : Returns list of id of objects
        
                               
        """
        logger.info("[Entry]: get_locked_objects")
        
        listLabelID = []
        json_file = self.save_dir +'/'+self.getImageName().split('.')[0]+".json"
        if os.path.isfile(json_file):
            bbox = 'bbox3d'
            class_name = 'label'
        else:
            bbox = 'bbox'
            class_name = 'class'
        auto_anno = json.loads(self.auto_annotations)       
        for i in auto_anno:
            for id, dict_ in i.items():
                if id == bbox:
                    label = i[bbox][class_name]
                    uniqueID = i[bbox]['parameters'][0]['val']
                    listLabelID.append(uniqueID)
        
        logger.info("[Exit]: get_locked_objects")
        return sorted(listLabelID)
