"""
Author:Pushap
File usage: This file is to be used to get the json, pcd, image data from the folders.
Created-Date: 22/11/2021
Updated-Date: 30/11/2021
NoesisAutoTagAI Copyright @HCL-2021
"""
import json
from nat_3D_Backend.structures.data_structures_3D import ObjUiViewer

from utils.logger import Logger
from dao.data import Data
from dao.settings_dao import SettingsDao
from commons.constants import PossibleExtensions as c
from commons.constants import Json_Constants as jc
from dao.data import Data as d
from nat_3D_Backend.exception.uiviewer_exception import UIViewerUtilsException
import traceback
import fnmatch
import os
from nat_3D_Backend.commons.getfolderpath import FetchFolderPath
from nat_3D_Backend.commons.getVideoName import fetchVideoName

logger = Logger.get_logger()

class UIviewer:
    """
    Description              : This class loads image, pcd, json data for video with specific image id.
    """
    def __init__(self, v_id, im_id, signal, proj_id, auto_anno, config_flag, copydir):
        """
        Description          : Initializes the object for UIviewer class
        parameter v_id       : video_id for the data fetch
        parameter im_id      : image number
        parameter signal     : 0 for previous, 1 for next image
        """
        self.video_id = v_id
        self.signal = signal
        self.image_id = im_id 
        self.project_id = proj_id
        self.auto_annotations = auto_anno
        self.config_type = config_flag
        self.direction = copydir

    def getImageId(self):
        
        if self.signal == 1:
            self.image_id = self.image_id + 1
        elif self.signal == 0:
            self.image_id = self.image_id - 1

    def getVideoName(self):
        """
        Description    : returns the video name for a particular video id
        """
        return fetchVideoName(self.video_id).FetchVideoName()

    def path_to_search(self):
        """
        Description          : This method return folder path to be searched for item of interest
        Return               : a string containing the absolute folder path.
                               Example: /home/user/noesis_data/video_name
        """
        logger.info("[INFO]: Inside path_to_search")
        path_to_search = FetchFolderPath(self.video_id).fetch_folder_path() + self.video_name
        return path_to_search

    def check_img_names(self, info):
        """

        """
        logger.info("[INFO]: Inside check_img_images")
        values_cam_channels = list(info.values())
        new_list = []
        for i in values_cam_channels:
            new_list.append(i.split("/")[-1])
        unique_images = list(set([new_list[0]]).union(set(new_list[1:])))
        if len(unique_images)>1:
            raise UIViewerUtilsException("The images with image id {1} are not unique, kindly check the uploaded data, Traceback: {0}".
                                                 format(traceback.extract_stack(limit=1), self.image_id))
        self.image_name_with_ext = unique_images[0]
        self.image_name = self.image_name_with_ext.split('.')[0]



    def files_finder(self, possible_extensions, path_to_walk):
        """
        Description                 : This method finds files with particular extension on a root dir: path_to_walk
        :param possible_extensions  : The possible extension of the file to be found.
        :param path_to_walk         : The root path where files are to be found.
        Return                      : a dict containing key as absolute path to directory and value as file of interest.
                               Example: {'CAM_FRONT_LEFT': '/home/pushap/Music/productivity_dashboard_v2/noesis_data/NuScenes/ONE/images/CAM_FRONT_LEFT/000049.jpg'}
        Raises:
            UIViewerUtilsException: [description]
        """
        
        logger.info("[INFO]: Inside files_finder")
        info = {}
        for root, _, filenames in os.walk(path_to_walk):
            matches = []
            for extensions in possible_extensions:
                for filename in fnmatch.filter(filenames, extensions):
                    matches.append(os.path.join(root, filename))
            if matches and possible_extensions != c.JSON_EXT_3D:
                try:
                    info[str(root.split("/")[-1])] = d.natural_sort(matches)[self.image_id]
                except Exception as e:
                    raise UIViewerUtilsException("Couldn't find the file with id {2}, -{0}, Traceback: {1}".
                                                     format(e, traceback.format_exc(limit=1), self.image_id))
            elif possible_extensions == c.JSON_EXT_3D and matches:
                if matches[0].split('/')[-2] == c.JSON_EXT_3D[0].replace('*.',''):
                    json_match = [a for a in matches if self.image_name == (a.split('/')[-1]).split('.')[0]]
                    if json_match:
                        if len(json_match) > 1:
                            raise UIViewerUtilsException("There are more than one json with same name {0}, Traceback: {1}".
                                                            format(self.image_name, traceback.extract_stack(limit=1)))
                        info['json'] = json_match[0]
                   
                

        if not info and possible_extensions != c.JSON_EXT_3D:
            raise UIViewerUtilsException("info dict is empty, No file with the possible extensions {1} found in {2},"
                                         " {0}".format(traceback.extract_stack(limit=1), possible_extensions,
                                                       path_to_walk))
        if possible_extensions == c.POSSIBLE_IMAGE_EXTENSIONS_3D:
            self.check_img_names(info)
        return info

    def load_json(self, path_to_walk):
        """
        Description          : This method reads a json file.
        :param path_to_walk  : the root directory to find json in.
        Return               : json data.
                               Example: {'name': '000049', 'timestamp': 0, 'index': 49, 'labels': [{
        'id': 1, 'category': 'vehicle', 'box3d': {'dimension': {'width': 2.34, 'length': 3.96, 'height': 2.05},
        'location': {'x': -14.380017865419294, 'y': 6.719285438786099, 'z': -0.7749999999999999}, 'orientation': {
        'rotationYaw': 1.956696734867944, 'rotationPitch': 0, 'rotationRoll': 0}}}, {'id': 15, 'category': 'vehicle',
        'box3d': {'dimension': {'width': 5.6692216322180276, 'length': 2.08, 'height': 2.2}, 'location': {'x':
        -4.582306836200669, 'y': -25.6519216839421, 'z': -0.52}, 'orientation': {'rotationYaw': -0.33,
        'rotationPitch': 0, 'rotationRoll': 0}}}
        Raises:
            UIViewerUtilsException: [description]
        """
        json_data = None
        try:
            json_data = json.load(open(self.files_finder(possible_extensions=c.JSON_EXT_3D, path_to_walk=path_to_walk)
                                        .get('json')))
        except Exception as e:
            pass

        if json_data is None:
            logger.info("[INFO]: there is no data in the json or the json doesnot exist with id : {0}, traceback: {1}"
                        .format(self.image_id, traceback.extract_stack(limit=1)))
        
        return json_data


    def image_name_extractor(self, path_to_walk):
        """
        Description          : This method extract the image name from video name.
        
        Return               : image name.
                               Example: image_00001.jpg
        Raises:
            UIViewerUtilsException: [description]
        """
        logger.info("[INFO]: Inside image_name_extractor")
        image_name = None
        data_images = self.files_finder(possible_extensions=c.POSSIBLE_IMAGE_EXTENSIONS_3D, path_to_walk=path_to_walk)
        try:
            image_name = data_images.get(list(data_images.keys())[0]).split('/')[-1]
        except Exception as e:
            raise UIViewerUtilsException("Could not fetch image name,{0}, traceback: {1}".format(e, traceback.format_exc(limit=1)))
        if image_name is None:
            raise UIViewerUtilsException("Image name is None, kindly check, traceback: {0}".format(traceback.extract_stack(limit=1)))
        return image_name

    def generate_path(self, data):
        """

        """
        data_modified = {}
        for k, v in data.items():
            path_splitted = v.split("/")
            folder_path_relative = "/".join(path_splitted[path_splitted.index("noesis_data")+1:-1])
            name_of_file = path_splitted[-1]
            data_modified[k] = Data.make_url(folder_path_relative, name_of_file)
        return data_modified

    def convert_nat_json_to_3d(self,natJsonData):
        """
        Description : this method is used to convert nat json format to 3d_json format
        :param natJsonData : Its a string of nat json data from which we will extract values and will convert 
                            it into 3d-structured json format
        return : 3d_json data
        """
        if natJsonData != None:
            
            
            imageName = list(natJsonData[jc.KEY_IMG].keys())[0]
            
            json_data_3D = {
                "name": imageName,
                "timestamp": 0,
                "index": int(self.image_id),
                "labels": [],
            }
            for annos_count in range(len(natJsonData[jc.KEY_IMG][imageName][jc.KEY_ANNOTATIONS])):
                labels_dict = {
                    "id":natJsonData[jc.KEY_IMG][imageName][jc.KEY_ANNOTATIONS][annos_count]["id"],
                    "category": natJsonData[jc.KEY_IMG][imageName][jc.KEY_ANNOTATIONS][annos_count]["label"],
                    "box3d": None,
                }
                
                box3d_format = {
                    "dimension": {
                        "width": natJsonData[jc.KEY_IMG][imageName][jc.KEY_ANNOTATIONS][annos_count][jc.KEY_BBOX3D][jc.KEY_DIMENSIONS]["width"],
                        "length": natJsonData[jc.KEY_IMG][imageName][jc.KEY_ANNOTATIONS][annos_count][jc.KEY_BBOX3D][jc.KEY_DIMENSIONS]["length"],
                        "height": natJsonData[jc.KEY_IMG][imageName][jc.KEY_ANNOTATIONS][annos_count][jc.KEY_BBOX3D][jc.KEY_DIMENSIONS]["height"]
                    },
                    "location": {
                        "x": natJsonData[jc.KEY_IMG][imageName][jc.KEY_ANNOTATIONS][annos_count][jc.KEY_BBOX3D][jc.KEY_LOCATION]["x"],
                        "y": natJsonData[jc.KEY_IMG][imageName][jc.KEY_ANNOTATIONS][annos_count][jc.KEY_BBOX3D][jc.KEY_LOCATION]["y"],
                        "z": natJsonData[jc.KEY_IMG][imageName][jc.KEY_ANNOTATIONS][annos_count][jc.KEY_BBOX3D][jc.KEY_LOCATION]["z"]
                    },
                    "orientation": {
                        "rotationYaw": natJsonData[jc.KEY_IMG][imageName][jc.KEY_ANNOTATIONS][annos_count][jc.KEY_BBOX3D][jc.KEY_ORIENTATION]["rotationYaw"],
                        "rotationPitch": natJsonData[jc.KEY_IMG][imageName][jc.KEY_ANNOTATIONS][annos_count][jc.KEY_BBOX3D][jc.KEY_ORIENTATION]["rotationPitch"],
                        "rotationRoll": natJsonData[jc.KEY_IMG][imageName][jc.KEY_ANNOTATIONS][annos_count][jc.KEY_BBOX3D][jc.KEY_ORIENTATION]["rotationRoll"]
                    },
                    "parameters": [],
                    "track": natJsonData[jc.KEY_IMG][imageName][jc.KEY_ANNOTATIONS][annos_count][jc.KEY_BBOX3D][jc.KEY_TRACK]
                }
                for param_count in range(len(natJsonData[jc.KEY_IMG][imageName][jc.KEY_ANNOTATIONS][annos_count][jc.KEY_BBOX3D][jc.KEY_PARAMETERS])):
                    paramater_format = {
                        "nam":natJsonData[jc.KEY_IMG][imageName][jc.KEY_ANNOTATIONS][annos_count][jc.KEY_BBOX3D][jc.KEY_PARAMETERS][param_count]["nam"],
                        "val":natJsonData[jc.KEY_IMG][imageName][jc.KEY_ANNOTATIONS][annos_count][jc.KEY_BBOX3D][jc.KEY_PARAMETERS][param_count]["val"]
                    }
                    box3d_format[jc.KEY_PARAMETERS].append(paramater_format)
                labels_dict["box3d"] = box3d_format
                json_data_3D[jc.KEY_LABELS].append(labels_dict) 
            return json_data_3D
        else:
            return None

    def files_counter(self, possible_extensions, path_to_walk):
        """
        Description                 : This method counts files with particular extension on a root dir: path_to_walk
        :param possible_extensions  : The possible extension of the file to be found.
        :param path_to_walk         : The root path where files are to be found.
        Return                      : a dict containing key as absolute path to directory and value as count of files.
                               Example: {'CAM_FRONT_LEFT': 50}
        Raises:
            UIViewerUtilsException: [description]
        """
        
        logger.info("[INFO]: Inside files_finder")
        info = {}
        for root, _, filenames in os.walk(path_to_walk):
            matches = []
            for extensions in possible_extensions:
                for filename in fnmatch.filter(filenames, extensions):
                    matches.append(os.path.join(root, filename))
            
            if matches and possible_extensions != c.JSON_EXT_3D:
                try:
                    info[str(root.split("/")[-1])] = len(d.natural_sort(matches))
                    
                except Exception as e:
                    raise UIViewerUtilsException("Couldn't find the file with id {2}, -{0}, Traceback: {1}".
                                                     format(e, traceback.format_exc(limit=1), self.image_id))
           
            elif possible_extensions == c.JSON_EXT_3D and matches:
                
                info['json'] = len(matches)
       
        if not info and possible_extensions != c.JSON_EXT_3D:
            raise UIViewerUtilsException("info dict is empty, No file with the possible extensions {1} found in {2},"
                                         " {0}".format(traceback.extract_stack(limit=1), possible_extensions,
                                                       path_to_walk))
        
        
        
                
        
        max_count = max(list(info.values()))

        return max_count  


    def generate_data(self, image_id):
        """
        Description       : this method is used to fetch all the data and is to be called to get the data described for the class.
        Return            : ObjUiViewer
        """
        logger.info("[INFO]: Inside extract_images")
        
        self.video_name = self.getVideoName()
        #self.getImageId()
        self.image_id = image_id
        
        path_to_walk = self.path_to_search()
        
        data_images_absolute_path = self.files_finder(possible_extensions=c.POSSIBLE_IMAGE_EXTENSIONS_3D, path_to_walk=path_to_walk)
        
        data_images = self.generate_path(data_images_absolute_path)
        data_pcd_absolute_path = self.files_finder(possible_extensions=c.PCD_EXT_3D, path_to_walk=path_to_walk)
        
        json_file = self.files_finder(possible_extensions=c.JSON_EXT_3D, path_to_walk=path_to_walk).get('json')
        
        data_pcd = self.generate_path(data_pcd_absolute_path)
        loadedJson = self.load_json(path_to_walk=path_to_walk)
        
        annos_json = self.convert_nat_json_to_3d(loadedJson)
        
        return(data_images, annos_json, data_pcd, loadedJson, json_file, data_images_absolute_path)

    
    
    def get_label_and_uniqueID(self, count, i, j, annotation_type, json):
      label = json['img'][i][j][count][annotation_type]['label']
      uniqueID = json['img'][i][j][count][annotation_type]['parameters'][0]['val']
      annotation_type_flag = True  
      return label, uniqueID, annotation_type_flag    

    
    def get_curr_obj_and_copy(self,json_flag, current_json, labelIDList, current_annotation_dict, current_bbox_list):
      
      for i in current_json['img']:
            for j in current_json['img'][i]:
                count = 0
                for k in current_json['img'][i][j]:
                    c_bbox = False
                    c_poly = False
                   
                    if current_json['img'][i][j][count]['bbox3d']:
                      c_label, c_uniqueID, c_bbox = self.get_label_and_uniqueID(count, i, j, 'bbox3d', current_json)
                      
                    elif current_json['img'][i][j][count]['polygon']:
                      c_label, c_uniqueID, c_poly = self.get_label_and_uniqueID(count, i, j, 'polygon', current_json)                      
                    else:
                      count += 1
                      continue
                   
                    for IDLabel in labelIDList:
                      if c_bbox == True:
                        annotation_type = "bbox3d"  
                      elif c_poly == True:
                        annotation_type = "poly"

                      if IDLabel[0] == c_label and IDLabel[1] == c_uniqueID:
                          
                          key = str(c_label)+str(c_uniqueID)+annotation_type
                          if json_flag == 0:
                            current_annotation_dict[key] = current_json['img'][i][j][count]
                          elif json_flag == 1:
                            current_json['img'][i][j][count] = current_annotation_dict[key]
                            del current_annotation_dict[key]
                          else:
                            key = str(c_label)+str(c_uniqueID)
                            
                            current_bbox_list.append(current_json['img'][i][j][count])

                    count += 1
      return current_annotation_dict, i, j, current_bbox_list

    
    def compare_json(self, current_json_path, next_json_path, labelIDList):
      logger.info("Inside compare JSON copy mode Manual")
      
      current_bbox_list = []
      current_annotation_dict = {}
      if os.path.isfile(next_json_path):
        with open(current_json_path, encoding='utf-8', errors='ignore') as f:
          current_json = json.load(f)
        f.close()
        with open(next_json_path, encoding='utf-8', errors='ignore') as g:
          next_json = json.load(g)
        g.close()
        
        json_flag = 0
        current_annotation_dict, i, j, current_bbox_list=self.get_curr_obj_and_copy(json_flag, current_json, labelIDList, current_annotation_dict, current_bbox_list)
        json_flag = 1
        current_annotation_dict, i, j, current_bbox_list=self.get_curr_obj_and_copy(json_flag, next_json, labelIDList, current_annotation_dict, current_bbox_list)

        
        if current_annotation_dict:
          for key,value in current_annotation_dict.items():
            next_json['img'][i][j].append(value)

        with open(next_json_path, 'w') as fp:
            json.dump(next_json, fp, indent=4)
            
        
        
            
      else:
        with open(current_json_path, encoding='utf-8', errors='ignore') as f:
          current_json = json.load(f)
          json_flag = 2
          f.close()
        next_jsonname = os.path.splitext(os.path.basename(next_json_path))[0]
        current_jsonname = os.path.splitext(os.path.basename(current_json_path))[0]
        current_annotation_dict, i, j, current_bbox_list=self.get_curr_obj_and_copy(json_flag, current_json, labelIDList, current_annotation_dict, current_bbox_list)
        current_json['img'][i][j] = current_bbox_list
        current_json['img'][next_jsonname] = current_json['img'].pop(current_jsonname)
        with open(next_json_path, 'w') as fp:
          json.dump(current_json, fp, indent=4)
    
    def get_labelIDlist_from_json(self, object_list):
        logger.info("[Start]: get_labelIDlist_from_json")
        
        listLabelID = []
        for i in object_list:
            for id, dict_ in i.items():
                if id == 'bbox3d':
                    label = i['bbox3d']['label']
                    uniqueID = i['bbox3d']['parameters'][0]['val']
                    listLabelID.append([label, uniqueID])
            logger.info("[Exit]: get_labelIDlist_from_json")
        return listLabelID
    
    def check_json_and_compare(self, config_type, signal, image_id, jsoncount,  copy_mode, flag, auto_annotations,  json_path,  json_path_to_interpolate):
        
        if jsoncount:
            if copy_mode == 'manual' and auto_annotations:
    
                listLabelID = self.get_labelIDlist_from_json(auto_annotations)
                
                if flag:
        
                    self.compare_json( json_path_to_interpolate, json_path, listLabelID,)
            
                
        
        return image_id   

    def extract_data(self):
        """
        Description       : this method is used to fetch all the data and is to be called to get the data described for the class.
        Return            : ObjUiViewer
        """
        logger.info("[INFO]: Inside extract_images")
        
        if self.signal == 2:
            data_images,annos_json, data_pcd, loadedJson, json_file, data_images_absolute_path = self.generate_data(self.image_id)
            
        else:
            auto_annotations = json.loads(self.auto_annotations)
            if self.config_type == 3 or self.config_type == 4:
                frames_to_interpolate = SettingsDao.get_frames_to_interpolate(self.project_id)
            else:
                frames_to_interpolate = 1
            
            self.video_name = self.getVideoName()
            path_to_walk = self.path_to_search()
            image_counter = self.files_counter(possible_extensions=c.POSSIBLE_IMAGE_EXTENSIONS_3D, path_to_walk=path_to_walk)
            json_counter = self.files_counter(possible_extensions=c.JSON_EXT_3D, path_to_walk=path_to_walk)
    
            if  self.signal:
                for i in range(frames_to_interpolate):
                    if  self.image_id == image_counter-1:
                        break 
            
                    data_images,annos_json, data_pcd, loadedJson, json_file, data_images_absolute_path = self.generate_data(self.image_id+1)
                    if self.direction == "Forward":
                        if json_file == None:
                            image_name = self.image_name_extractor(path_to_walk=path_to_walk)
                            json_file = os.path.join(path_to_walk, "json", image_name.split('.')[0]+".json")

                        prev_data_images,prev_annos_json, prev_data_pcd, prev_loadedJson, prev_json_file, prev_data_images_absolute_path = self.generate_data(self.image_id-1)
                        if prev_json_file != None:
                            flag = os.path.exists(prev_json_file)
                            self.image_id = self.check_json_and_compare(self.config_type, self.signal, self.image_id+1, json_counter,  "manual", flag, auto_annotations,  json_file,  prev_json_file)
                        else:
                            self.image_id += 1
                    
                    
            else:
                for i in range(frames_to_interpolate, 0 , -1):
                    if self.image_id < 0:
                        self.image_id = 0
                        break 
                    data_images,annos_json, data_pcd, loadedJson, json_file, data_images_absolute_path = self.generate_data(self.image_id-1)
                    if self.direction == "Backward":
                        if json_file == None:
                            image_name = self.image_name_extractor(path_to_walk=path_to_walk)
                            json_file = os.path.join(path_to_walk, "json", image_name.split('.')[0]+".json")
                            
                        next_data_images,next_annos_json, next_data_pcd, next_loadedJson, next_json_file, next_data_images_absolute_path = self.generate_data(self.image_id+1)
                        if next_json_file != None:
                            flag = os.path.exists(next_json_file)
                            self.image_id = self.check_json_and_compare(self.config_type, self.signal, self.image_id-1, json_counter,  "manual", flag, auto_annotations,  json_file,  next_json_file)
                        else:
                            self.image_id -= 1
                    


        data_images,annos_json, data_pcd, loadedJson, json_file, data_images_absolute_path = self.generate_data(self.image_id)
        response = ObjUiViewer(
            images_data=json.dumps(data_images),
            annos_json=json.dumps(annos_json),
            pcd_data=json.dumps(data_pcd),
            image_id=self.image_id,
            image_name=self.image_name
        )
        
        return response



