"""
Author:Kush
File usage: This file is used to create db connection 
Created-Date: 18/11/2021
Updated-Date: 22/11/2021
NoesisAutoTagAI Copyright @HCL-2021
"""
import os
import mysql.connector
import traceback
from utils.logger import Logger
from controller.nat_config_controller import NATConfigController
from nat_3D_Backend.exception.dbconfig_exception import DbConfigException
from utils.ops_encrypt import EncryptDecrypt


logger = Logger.get_logger()
class DbConfig3D:
    """
    Description: This Class create the database connections.
    """

    def __init__(self):
        """
        Description    : This is used to intialize the class loadConfig
        """
        pass   

    def configObj(self):
        """
        Description    : This is used to read the database configuration file
        :return: It returns an object of NATConfigController class [Example : Obj NatConfig]
        """
        return NATConfigController.read_config()
    
    def hostName(self):
        """
        Description    : This is used to extract and decrypt the hostname from database configuration file
        :return: It returns a Decoded String of DB_Hostname extracted from nat properties  
        """
        return EncryptDecrypt.decrypt_incoming(self.config_var.get(os.environ.get('ENV'), 'MYSQL_DATABASE_HOST'))

    def username(self):
        """
        Description    : This is used to extract and decrypt the username from database configuration file
        :return: It returns a Decoded String of DB_Username extracted from nat properties
        """
        return EncryptDecrypt.decrypt_incoming(self.config_var.get(os.environ.get('ENV'), 'MYSQL_DATABASE_USER'))
    
    def password(self):
        """
        Description    : This is used to extract and decrypt the password from database configuration file
        :return: It returns a Decoded String of DB_Password extracted from nat properties
        """
        return EncryptDecrypt.decrypt_incoming(self.config_var.get(os.environ.get('ENV'), 'MYSQL_DATABASE_PASSWORD'))

    def db_name(self):
        """
        Description    : This is used to extract and decrypt the db_name from database configuration file
        :return: It returns a Decoded String of DB_Name extracted from nat properties
        """
        return EncryptDecrypt.decrypt_incoming(self.config_var.get(os.environ.get('ENV'), 'MYSQL_DATABASE_DB'))

    def connect_to_DB(self):
        """
        Description    : This is used to create a mysql database connection and cursor for db operations
        :return: It Return a DB Connection and a Cursor Obj [Example : [db_conn,db_cur]]
        Raises:
            DbConfigException: [description]
        """
        logger.info("[INFO]: Inside connect_to_Db")
        config = None
        self.config_var = self.configObj()
        #Extracting/constructing a dict. containing db credentials
        try:
            config = {'host': self.hostName(), 'user': self.username(),
                    'password': self.password(), 'database': self.db_name(), 'auth_plugin': 'mysql_native_password'}
        except Exception as e:
            raise DbConfigException("Unable to fetch hostname,username,password or db_name , kindly check their impl.- -{0}, Traceback: {1}".format(e, traceback.format_exc(limit=1)))
        if config is None:
            raise DbConfigException("config dict. is None , kindly check its var. - .{0}".format(traceback.extract_stack(limit=1)))

        #Connecting to db using the db credentials (config)
        try:
            self.conn = mysql.connector.connect(**config)
        except Exception as e:
            raise DbConfigException("Unable to connect to db , kindly check the connection Obj. --{0}, Traceback: {1}".format(e, traceback.format_exc(limit=1)))
        
        return [self.conn,self.conn.cursor(dictionary=True)]
        