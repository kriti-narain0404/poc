from nat_3D_Backend.exception.base_exception import NATToolexception

Error_Name = "FetchFolderPathError"

class FetchFolderPathException(NATToolexception):
    def __init__(self, message):
        super(FetchFolderPathException,self).__init__(message+"$"+Error_Name)

class FetchFolderPathDAOException(NATToolexception):
    def __init__(self, message):
        super(FetchFolderPathDAOException,self).__init__(message+"$"+Error_Name)

