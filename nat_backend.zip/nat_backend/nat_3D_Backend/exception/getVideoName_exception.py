from nat_3D_Backend.exception.base_exception import NATToolexception

Error_Name = "GetVideoNameError"

class getVideoNameException(NATToolexception):
    def __init__(self, message):
        super(getVideoNameException,self).__init__(message+"$"+Error_Name)

class getVideoNameDAOException(NATToolexception):
    def __init__(self, message):
        super(getVideoNameDAOException,self).__init__(message+"$"+Error_Name)

