from nat_3D_Backend.exception.base_exception import NATToolexception

Error_Name = "UIViewerUtilsError"

class UIViewerUtilsException(NATToolexception):
    def __init__(self, message):
        super(UIViewerUtilsException, self).__init__(message+"$"+Error_Name)