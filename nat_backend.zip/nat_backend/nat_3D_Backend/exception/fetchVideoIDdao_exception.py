from nat_3D_Backend.exception.base_exception import NATToolexception


class FetchVideoIDDAOException(NATToolexception):
    def __init__(self, message):
        super(FetchVideoIDDAOException, self).__init__(message)


