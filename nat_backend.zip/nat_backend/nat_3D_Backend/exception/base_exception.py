from utils.logger import Logger
from graphql import GraphQLError
from utils.errors_utils import Error

logger = Logger.get_logger()

class NATToolexception(Exception):
    """
    This class is responsible for custom exception handling
    """
    message = ''

    def __init__(self, message):
        self.message = message.split("$")
        logger.error(self.message[0])
        raise GraphQLError(Error.get_error_object(self.message[1]))



