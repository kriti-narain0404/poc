from nat_3D_Backend.exception.base_exception import NATToolexception

Error_Name = "JsonLoadConfigError"

class JsonLoadConfigDAOException(NATToolexception):
    def __init__(self, message):
        super(JsonLoadConfigDAOException,self).__init__(message+"$"+Error_Name)

class JsonLoadConfig3DException(NATToolexception):
    def __init__(self, message):
        super(JsonLoadConfig3DException,self).__init__(message+"$"+Error_Name)