"""
Author:
File usage: This file is to be used fetch video name from video id
Created-Date: 30/11/2021
Updated-Date: 30/11/2021
NoesisAutoTagAI Copyright @HCL-2021
"""
import json

from utils.logger import Logger
from nat_3D_Backend.dao.FetchVideoName_dao import GetVideoNameDAO
from nat_3D_Backend.exception.getVideoName_exception import getVideoNameException
logger = Logger.get_logger()
import traceback


class fetchVideoName:
    """
    Description              : This class fetches the folder path based upon the video name
    """
    def __init__(self, v_id=32):
        """
        Description          : Initializes the object for FetchFolderPath class
        parameter v_id       : id of the video of interest
        """
        self.video_id = v_id

    def dao_obj(self):
        """
        Description          : This method intializes the dao object
        Return               : DAO object
        Raises:
            FetchFolderPathException: [description]
        """
        logger.info("[INFO]: Inside dao_obj")
        obj_dao = None

        try:
            obj_dao = GetVideoNameDAO()
        except Exception as e:
            raise getVideoNameException("Couldn't create DAO object, -{0}, Traceback: {1}".
                                         format(e, traceback.format_exc(limit=1)))

        if obj_dao is None:
            raise getVideoNameException("GetVideoNameDAO Object is None, please check intialization,"
                                         " {0}".format(traceback.extract_stack(limit=1)))

        return obj_dao


    def FetchVideoName(self):
        """
        Description          : This method return video name for a particular video_id
        Return               : a string containing the video_name.
                               Example: NuScenes
        """
        logger.info("[INFO]: Inside FetchVideoName")
        obj_dao = self.dao_obj()
        self.v_name = obj_dao.fetchVideoName(self.video_id)
        return self.v_name
