"""
Author:
File usage: This file creates the db connection for use.
Created-Date: 24/11/2021
Updated-Date: 24/11/2021
NoesisAutoTagAI Copyright @HCL-2021
"""

from utils.logger import Logger
from nat_3D_Backend.utils.dbConfig_3D import DbConfig3D as dbconnect
from nat_3D_Backend.exception.getdb_exception import DBConnectException
import traceback

logger = Logger.get_logger()

class DBConnect:
    """
    Description           : This class can be used to get connection and cursor for the DB.
    """
    def __init__(self):
        pass

    def db_obj_creation(self):
        """
        Description          : This method intializes the db object
        Return               : DB object
        Raises:
            DBConnectException: [description]
        """
        logger.info("Inside db_obj_creation")
        db_obj = None

        try:
            db_obj = dbconnect()
        except Exception as e:
            raise DBConnectException("Couldn't create database object, -{0}, Traceback: {1}".
                                       format(e, traceback.format_exc(limit=1)))

        if db_obj is None:
            raise DBConnectException("Database Connection Object is None, please check DB connection,"
                                       " {0}".format(traceback.extract_stack(limit=1)))

        return db_obj

    def get_db_cursor(self):
        """
        Description          : This method gets the connection and cursor from db object
        Return               : connection and cursor object
        """
        logger.info("Inside get_db_cursor")
        conn, cursor = None, None
        db_obj = self.db_obj_creation()
        
        conn, cursor = db_obj.connect_to_DB()        
        return [conn, cursor]