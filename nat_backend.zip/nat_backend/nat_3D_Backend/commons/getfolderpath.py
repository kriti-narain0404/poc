"""
Author:
File usage: This file is to be used to get the json, pcd, image data from the folders.
Created-Date: 24/11/2021
Updated-Date: 30/11/2021
NoesisAutoTagAI Copyright @HCL-2021
"""
import json

from utils.logger import Logger
from nat_3D_Backend.dao.FetchFolderPath_dao import FetchFolderPathDAO
from nat_3D_Backend.exception.getfolderpath_exception import FetchFolderPathException
logger = Logger.get_logger()
import traceback


class FetchFolderPath:
    """
    Description              : This class fetches the folder path based upon the video name
    """
    def __init__(self, v_id=32):
        """
        Description          : Initializes the object for FetchFolderPath class
        parameter v_id       : id of the video of interest
        """
        self.video_id = v_id

    def dao_obj(self):
        """
        Description          : This method intializes the dao object
        Return               : DAO object
        Raises:
            FetchFolderPathException: [description]
        """
        logger.info("[INFO]: Inside dao_obj")
        obj_dao = None

        try:
            obj_dao = FetchFolderPathDAO()
        except Exception as e:
            raise FetchFolderPathException("Couldn't create DAO object, -{0}, Traceback: {1}".
                                         format(e, traceback.format_exc(limit=1)))

        if obj_dao is None:
            raise FetchFolderPathException("FetchFolderPathDAO Object is None, please check intialization of UIviewer_dao,"
                                         " {0}".format(traceback.extract_stack(limit=1)))

        return obj_dao


    def fetch_folder_path(self):
        """
        Description          : This method return folder path for a particular video_name
        Return               : a string containing the folder path.
                               Example: /home/user/noesis_data
        """
        logger.info("[INFO]: Inside fetch_folder_path")
        obj_dao = self.dao_obj()
        self.folder_path = None
        self.folder_path = obj_dao.folder_path(self.video_id)
        return self.folder_path
