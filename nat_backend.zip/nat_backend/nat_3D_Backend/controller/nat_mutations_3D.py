"""
Author:
File usage: This file is used for defining the Backend API and calling their respective Implementation functions 
Created-Date: 22/11/2021
Updated-Date: 22/11/2021
NoesisAutoTagAI Copyright @HCL-2021
"""

from utils.logger import Logger
from nat_3D_Backend.utils.JsonLoadConfig_3D import LoadConfig3D
from nat_3D_Backend.utils.Save_JsonData import SaveJsonFile
from nat_3D_Backend.utils.UIviewer_util import UIviewer

logger = Logger.get_logger()

class NatMutation3D:
    """
    Description: This Class is used for defining the backend APIs and consists of the their respective calling functions.
    """
    # def __init__(self):

    @staticmethod
    def jsonConfigLoader(video_id):
        """
        Description : This Function is used for fetching config json data
        :param video_name : A String containing the video name 
        :return: Config JSON Data [Example : configJson={{json_data}}]
        """
        logger.info("[INFO]: Inside Config Loader")
        configJson = LoadConfig3D(video_id).readConfig()
        return configJson

    @staticmethod
    def saveJsonData(video_id,img_id,jsonData, proj_id, auto_annotations):
        """
        Description : This Function returns the status of saving json files
        :param v_name       : name of the video of interest
        :param img_id       : image number
        :param json_data    : data to be stored in json file
        :return: Save Status [Example : status=True/False]
        """
        logger.info("[INFO]: Inside Save Json Data ")
        obj_saveStatus = SaveJsonFile(video_id,img_id,jsonData, proj_id, auto_annotations).saveJsonAnnotation()
        return obj_saveStatus

    @staticmethod
    def uiViewerLoader(video_id,img_id,signal, project_id, auto_annotations, config_type, copy_direction):
        """
        Description :
        :param v_name
        :param img_id
        :param signal 
        :return:
        """
        logger.info("[INFO]: Inside Ui Viewer Loader")
        logger.info("inside uiViewerLoader")
        return UIviewer(video_id,img_id,signal, project_id, auto_annotations, config_type, copy_direction).extract_data()

