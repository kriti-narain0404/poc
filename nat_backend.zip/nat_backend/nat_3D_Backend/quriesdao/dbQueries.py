"""
Author:
File usage: This file contains all the database queries.
Created-Date: 23/11/2021
Updated-Date: 30/11/2021
NoesisAutoTagAI Copyright @HCL-2021
"""

class DbQueries(object):
    """
    Description : This class contains all the DB_Queries which will be executed 
    """

    UIVIEWER_FILEPATH = "SELECT folder_path from nat_user_setting where user_id IN (select assigned_user_id FROM video" \
                        " WHERE id='{video_id}') and project_id IN (select project_id FROM video WHERE id='{video_id}')"

    JSON_CONFIG_PROJECT_NAME = "SELECT project_name from nat_project where id IN (select project_id from video where video_name='{video_name}')"

    VIDEO_NAME = "SELECT video_name FROM video WHERE id={video_id}"

    VIDEO_ID = "SELECT id FROM video WHERE video_name='{v_name}'"
