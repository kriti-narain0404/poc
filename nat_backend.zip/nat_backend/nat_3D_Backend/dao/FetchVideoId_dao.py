"""
Author:Pushap
File usage: This file is to be used to get the json, pcd, image data from the folders.
Created-Date: 6/12/2021
Updated-Date: 6/12/2021
NoesisAutoTagAI Copyright @HCL-2021
"""
from utils.logger import Logger
from nat_3D_Backend.exception.fetchVideoIDdao_exception import FetchVideoIDDAOException
from nat_3D_Backend.quriesdao.dbQueries import DbQueries
from nat_3D_Backend.commons.getdb_conn import DBConnect
import traceback

logger = Logger.get_logger()

class FetchVideoIDDAO:
    """
    Description           : This class is to be used to fetch details from DB.
    """
    def __init__(self, video_name):
        self.v_name = video_name

    def fetch_video(self):
        """
        Description     : This method is used to get id of the video using the video name.
        return          : A dict containing the video id.
                          Example: [{"id": "32"]
        Raises:
            FetchVideoIDDAOException: [description]
        """
        logger.info("[INFO]: Inside fetch_video")
        conn, cursor = DBConnect().get_db_cursor()
        query = DbQueries.VIDEO_ID.format(v_name=self.v_name)

        video_id = None
        try:
            cursor.execute(query)
        except Exception as e:
            raise FetchVideoIDDAOException(
                "Not able to execute the query, kindly check it -{0}, Traceback: {1}".format(e, traceback.format_exc(
                    limit=1)))
        try:
            video_id = cursor.fetchall()
        except Exception as e:
            raise FetchVideoIDDAOException(
                "Not able to fetch the video_id, kindly check it -{0}, Traceback: {1}".format(e,traceback.format_exc(limit=1)))
        conn.close()
        if len(video_id)>1:
            raise FetchVideoIDDAOException("there are more than one video with same name : {0}, Traceback:{1}".format(self.v_name, traceback.extract_stack(limit=1)))
        if not video_id:
            raise FetchVideoIDDAOException(
                "there is no video with name : {0}, Traceback:{1}".format(self.v_name, traceback.extract_stack(limit=1)))
        return video_id

    def video_name(self):
        """

        """
        video_list = self.fetch_video()
        return video_list[0].get("id")
