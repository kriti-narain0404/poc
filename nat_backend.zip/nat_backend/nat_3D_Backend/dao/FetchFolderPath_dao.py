"""
Author:Pushap
File usage: This file is to be used to get the json, pcd, image data from the folders.
Created-Date: 22/11/2021
Updated-Date: 22/11/2021
NoesisAutoTagAI Copyright @HCL-2021
"""

from utils.logger import Logger
logger = Logger.get_logger()
from utils.ops_encrypt import EncryptDecrypt as ed
from nat_3D_Backend.exception.getfolderpath_exception import FetchFolderPathDAOException
from nat_3D_Backend.quriesdao.dbQueries import DbQueries
from nat_3D_Backend.commons.getdb_conn import DBConnect
import traceback


class FetchFolderPathDAO:
    """
    Description           : This class is to be used to fetch details from DB.
    """
    def __init__(self):
        pass

    def folder_path_dict_fetch(self, query, cursor):
        """

        """
        try:
            cursor.execute(query)
        except Exception as e:
            raise FetchFolderPathDAOException(
                "Not able to execute the query, kindly check it -{0}, Traceback: {1}".format(e, traceback.format_exc(
                    limit=1)))

        path_dict = None
        try:
            path_dict = cursor.fetchall()
        except Exception as e:
            raise FetchFolderPathDAOException(
                "Not able to fetch the path dictionary, kindly check it -{0}, Traceback: {1}".format(e,
                                                                                                     traceback.format_exc(
                                                                                                         limit=1)))
        return path_dict

    def fetch_folder_path_dao(self):
        """
        Description     : This method is used to get the folder path for a particular video name.
        return          : A dict containing folder path base64encoded.
                          Example: {"folder_path": "L2hvbWUvbWFuYXY1MDAyL25vZXNpc19kYXRhLw=="}
        Raises:
            FetchFolderPathDAOException: [description]
        """
        logger.info("[INFO]: Inside fetch_folder_path_dao")
        conn, cursor = DBConnect().get_db_cursor()
        query = DbQueries.UIVIEWER_FILEPATH.format(video_id=self.v_id)

        path_dict = None
        path_dict = self.folder_path_dict_fetch(query, cursor)
        if not path_dict:
            path_dict = self.folder_path_dict_fetch(query.replace("assigned_user_id", "validator_assign_id"), cursor)
            if not path_dict:
                raise FetchFolderPathDAOException("path dictionary is None, Kindly check, {0}".format(traceback.extract_stack(limit=1)))
        if len(path_dict) > 1:
            raise FetchFolderPathDAOException(
                "There are more than one videos with same id {0}, Traceback: {1}".format(self.v_id,
                                                                                         traceback.extract_stack(
                                                                                             limit=1)))
        conn.close()
        return path_dict

    def folder_path(self, v_id):
        """
        Description     : This method is used to get the folder path decoded for a particular video name.
        return          : A string containing the folder path.
                          Example: "/home/nat/noesis_data"
        """
        logger.info("[INFO]: Inside folder_path")
        self.v_id = v_id
        folder_path = ed.decrypt_incoming(self.fetch_folder_path_dao()[0].get("folder_path"))
        return folder_path
