"""
Author:Kush
File usage: This file is to be used to get project details 
Created-Date: 24/11/2021
Updated-Date: 24/11/2021
NoesisAutoTagAI Copyright @HCL-2021
"""

from nat_3D_Backend.quriesdao.dbQueries import DbQueries
from nat_3D_Backend.exception.JsonLoadConfig_exception import JsonLoadConfigDAOException
from nat_3D_Backend.commons.getdb_conn import DBConnect
import traceback
from utils.logger import Logger

logger = Logger.get_logger()

class JsonLoadConfigDao:
    """
    Description : This class is to be used to fetch project details from DB for JsonLoadConfig Util
    """

    def __init__(self,v_nm):
        self.video_name = v_nm
        pass

    def fetch_project_name_dao(self):
        """
        Description     : This method is used to get the project name for a particular video name.
        return          : A String of Project Name of which that video belongs to.
                          Example: {"project_name"="Magna"}
        Raises:
            JsonLoadConfigDAOException: [description]
        """
        logger.info("[INFO]: Inside fetch_project_name_dao")
        prj_name_dict = None

        #Creating an Object of DbConnect class
        db_obj = DBConnect()

        #Getting the DB connection and cursor obj 
        conn,cur = db_obj.get_db_cursor()

        #Db query to execute
        query = DbQueries.JSON_CONFIG_PROJECT_NAME.format(video_name=self.video_name)

        #Executing the DB Query
        try:
            cur.execute(query)
        except Exception as e:
            raise JsonLoadConfigDAOException("Unable to execute db query, kindly check it - {0}, Traceback: {1}".format(e, traceback.format_exc(limit=1)))
        
        #Extracting the Project Name from DB Cursor
        try:
            prj_name_dict = cur.fetchone()
        except Exception as e:
            raise JsonLoadConfigDAOException("Unable to fetch data from database cursor ,- {0}, Traceback: {1}".format(e, traceback.format_exc(limit=1)))
        
        if prj_name_dict is None:
            raise JsonLoadConfigDAOException("Project Dict. is None , kindly check the same {0}".format(traceback.extract_stack(limit=1)))

        #Closing DB Connection
        try:
            conn.close()
        except:
            raise JsonLoadConfigDAOException("Unable to close db connection ,- {0} ".format(traceback.extract_stack(limit=1)))
        return prj_name_dict

