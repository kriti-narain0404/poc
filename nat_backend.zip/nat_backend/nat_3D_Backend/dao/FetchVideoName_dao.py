"""
Author:Pushap
File usage: This file is to be used to get the video name using video id from DB.
Created-Date: 30/11/2021
Updated-Date: 30/11/2021
NoesisAutoTagAI Copyright @HCL-2021
"""

from utils.logger import Logger
logger = Logger.get_logger()
from nat_3D_Backend.exception.getVideoName_exception import getVideoNameDAOException
from nat_3D_Backend.quriesdao.dbQueries import DbQueries
from nat_3D_Backend.commons.getdb_conn import DBConnect
import traceback


class GetVideoNameDAO:
    """
    Description           : This class is to be used to fetch details from DB.
    """
    def __init__(self):
        pass


    def fetchVideoName_dao(self):
        """
        Description     : This method is used to get the folder path for a particular video name.
        return          : A dict containing folder path base64encoded.
                          Example: {"video_name":"Nuscenes"}
        Raises:
           getVideoNameDAOException: [description]
        """
        logger.info("[INFO]: Inside fetchVideoName_dao")
        conn, cursor = DBConnect().get_db_cursor()
        query = DbQueries.VIDEO_NAME.format(video_id=self.v_id)
        try:
            cursor.execute(query)
        except Exception as e:
            raise getVideoNameDAOException("Not able to execute the query, kindly check it -{0}, Traceback: {1}".format(e, traceback.format_exc(limit=1)))

        videoName_dict = None
        try:
            videoName_dict = cursor.fetchall()
        except Exception as e:
            raise getVideoNameDAOException("Not able to fetch the  dictionary, kindly check it -{0}, Traceback: {1}".format(e, traceback.format_exc(limit=1)))

        conn.close()
        if len(videoName_dict) > 1:
            raise getVideoNameDAOException("There are more than one videos with same id {0}, Traceback: {1}".format(self.v_id, traceback.extract_stack(limit=1)))
        if not videoName_dict:
            raise getVideoNameDAOException("VideoName dictionary is None, Kindly check, {0}".format(traceback.extract_stack(limit=1)))
        return videoName_dict


    def fetchVideoName(self, v_id):
        """
        Description     : This method is used to get the video name for video id.
        return          : A string containing the video name.
                          Example: ""
        """
        logger.info("[INFO]: Inside fetchVideoName")
        self.v_id = v_id
        video_name = self.fetchVideoName_dao()[0].get("video_name")
        return video_name
