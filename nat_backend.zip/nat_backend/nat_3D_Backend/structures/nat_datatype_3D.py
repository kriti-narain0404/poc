"""
Author:
File usage: This is used for defining the Graphql Datatypes 
Created-Date: 22/11/2021
Updated-Date: 22/11/2021
NoesisAutoTagAI Copyright @HCL-2021
"""

from graphql import (
    GraphQLField, GraphQLNonNull, GraphQLArgument,
    GraphQLObjectType, GraphQLList, GraphQLBoolean, GraphQLString,
    GraphQLSchema, GraphQLInt, GraphQLFloat, GraphQLInputObjectType,
    GraphQLInputObjectField
)
from graphql.type.definition import GraphQLInputObjectField

class NatDataTypes3d:
    """
    Description: This Class contains graphql definations
    """

    ObjConfigType = GraphQLObjectType(
        name='ObjConfig',
        fields={
            'jsonData': GraphQLField(
                GraphQLNonNull(GraphQLString),
            )
        }
    )

    ObjUiViewerType = GraphQLObjectType(
        name = 'ObjUiViewer',
        fields={
            'images_data':GraphQLField(
                GraphQLNonNull(GraphQLString)
            ),
            'annos_json':GraphQLField(
                GraphQLNonNull(GraphQLString)
            ),
            'pcd_data': GraphQLField(
                GraphQLNonNull(GraphQLString)
            ),
            'image_id': GraphQLField(
                GraphQLNonNull(GraphQLInt)
            ),
            'image_name': GraphQLField(
                GraphQLNonNull(GraphQLString)
            )
        }
    )
