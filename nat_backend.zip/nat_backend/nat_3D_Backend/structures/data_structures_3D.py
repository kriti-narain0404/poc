"""
Author:Kush
File usage: This is used for defining the data structures  
Created-Date: 22/11/2021
Updated-Date: 22/11/2021
NoesisAutoTagAI Copyright @HCL-2021
"""

from collections import namedtuple

ObjConfig = namedtuple('ObjConfig','jsonData')
ObjUiViewer = namedtuple('ObjUiViewer','images_data annos_json pcd_data image_id image_name')