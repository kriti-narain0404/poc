
class GlobalData:
    """
    This class will handle the global data for the application
    """
    ENVIRONMENT_DETAILS = None
    PROJECT_ID = None
    DB_CONNECTION = None
    DB_CURSOR = None
    PROJECT_PATH = None


