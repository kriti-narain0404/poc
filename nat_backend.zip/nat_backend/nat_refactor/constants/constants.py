from math import e
import os
#from unittest.mock import DEFAULT


class Constants:

    CONFIG_FILE_PATH = 'nat_refactor/configuration/config.ini'

    ROOT_DIR_PATH = os.path.abspath(os.curdir)

    MAX_BYTES = 10000000
    BACKUP_COUNT = 99
    ALL_PERMISSION = 0o777

    LOG_FILE_NAME = 'data_copy_log-{}.txt'
    LOGGER_ROOT_FOLDER_NAME = 'log'

    DEFAULT_ENVIRONMENT = "DEFAULT"

    EXECUTION_ENVIRONMENT_SOURCE = 'AWS CLOUD DATA PROVIDER'
    EXECUTION_ENVIRONMENT_DESTINATION = 'AWS CLOUD DATA CONSUMER'
    EXECUTION_ENVIRONMENT = 'ExecutionEnvironment'

    
    API_BASE_URL = "APIs URL"

    BASE_URL = "BASE_URL"

    MYSQL_DATABASE_USER = 'MYSQL_DATABASE_USER'
    MYSQL_DATABASE_PASSWORD = 'MYSQL_DATABASE_PASSWORD'
    MYSQL_DATABASE_DB = 'MYSQL_DATABASE_DB'
    MYSQL_DATABASE_HOST = 'MYSQL_DATABASE_HOST'

    AWS_KEY = 'AWS_KEY'
    AWS_KEY_ID = 'AWS_KEY_ID'
    AWS_RESOURCE = 'AWS_RESOURCE'

    AWS_SOURCE_BUCKET_KEY = "sourceBucket"
    AWS_DESTINATION_BUCKET_KEY = "destBucket"

    AWS_SOURCE_PATH_KEY = "sourcePath"
    AWS_DESTINATION_PATH_KEY = "destPath"
    APIs = "pipelineSequence"
    FILETYPE = "fileType"
    PROJECT_ID_KEY = "PID"

    TRACE_LIMIT = 1

    STATUS_KEY = "status"

    STATUS_TRUE = {"status": "success"}
    STATUS_FALSE = {"status": "failure"}



    BYTES_TO_MB = 1024**2
    EXTENSION_SEPERATOR = "."
    COMMA_SEP = ", "
    PATH_SEPERATOR = "/"

    STATUS_COMPLETED = "COMPLETED"
    STATUS_ERROR = "ERROR"

    TABLE_NAME = "dp_component_state_manager"
    TABLE_AVAILABILITY = "DPComponent_Availability"
    COLUMNS = ["FileName", "Copier", "ProjId"]
    COLUMN_VIDEONAME = COLUMNS[0]
    COLUMN_STATUS = COLUMNS[1]
    COLUMN_PROJECTID = COLUMNS[2]

    SCHEDULER_TYPES = ["SPECIFIC_TIME", "HOURS"]


    API_SPLITTER = "_"

    EXTRACTOR_KEY = "extract"
    NAT_JSON_KEY = "json"

    TABLE_NAME_STATE_MANAGER = "data_pipeline_component_state"
    COLUMNS_STATE_MANAGER = ["project_id", "copier"]
    COLUMN_PROJECTID_STATE_MANAGER = COLUMNS_STATE_MANAGER[0]
    COLUMN_STATUS_STATE_MANAGER = COLUMNS_STATE_MANAGER[1]

    COMPONENT_STATE_RUNNING = "RUNNING"
    COMPONENT_STATE_ERROR = "ERROR"

    EXTRACTOR = "extractor"
    COPY = "copy"
    PORT = "PORT"


    TABLE_NAME_DATAPIPELINE_SETTINGS = "pipeline_settings"


    API_INITIALIZE = "API INITIALIZE"

    # these are for other API in the pipeline.
    API = "API INITIATOR"
    API_STOP = "API STOP"


    WORKERS = "WORKERS"
    HOSTNAME = "HOSTNAME"
    NONE = None

    API_PORT = "API PORT"

    AVAILABLE_STATUS = "AVAILABLE"

    #for the pipeline components
    AVG_OBJ_PER_FRAME = "avgObjectPerFrame"
    AVG_PROD = "productivity"
    COPIER_KEY = "copier"
    COMPONENT_DB_MAP = {
        "copier": "copier",
        "extractor": "DataExtractor",
        "model": "model",
        "attributes": "attribute_extractor",
        "nat": "json_creator",
        "distributor": "Distributor"
    }
    #Common constants

    ALL_DATA = "*"
    PROJECT_ID = "projectId"
    PROJECT_ID_AVAILABLE = "project_id"
    TRUE_CONDITION = True
    FALSE_CONDITION = False
    FILE_TYPE_KEY = "fileType"
    STRING_PLACEHOLDER = '%s'
    LAST_ELEMENT = -1
    EQUAL_SIGN = "="
    SECOND_LAST_ELEMENT = -2
    IP_ADDRESS_KEY = "IP_ADDRESS"
    IMG_KEY = "img"

    #Validation constants
    PIPELINE_SETTING_TABLE_NAME = "pipeline_settings"
    DATE_COLUMN = "Date"
    ORDER_DATE = "DESC"
    BUCKETS_KEYS = ["sourceBucket", "destBucket"]
    PATH_KEYS_AWS = ["sourcePath", "destPath"]
    #UNIT TESTING CONSTANTS
    #Files Table
    TABLE_NAME_FILES = "dp_file_state_manager"
    FILES_TABLE_KEYS = ["project_id", "source_path", "file_size_MB"]
    SOURCE_PATH_KEY = "source_path"

    #General Constants
    FIRST_ELEMENT = 0
    LABEL_JSON_SUFFIX = '_label.json'
    EMPTY_STRING = ''
    EMPTY_LIST = []
    WRITE_MODE = "w"
    EMPTY_DICT = {}


    #scheduler constants
    SCHEDULER_TYPE = "schedulerType"
    SPECIFIC_TIME = "SPECIFIC_TIME"
    HOURS_TIME = "HOURS"
    TIME = "time"
    #CONFIG MANAGER
    EXECUTION_ENVIRONMENTS = ["LOCAL", "DEV", "PROD", "TEST", "UAT"]

    #signup constants
    USER_ID_COLUMN = 'id'
    USERNAME_COLUMN = "login"
    TABLE_NAME_USERS = "nat_user"


    #insert_columns
    FIRST_NAME_COLUMN = "first_name"
    LAST_NAME_COLUMN = "last_name"
    PASSWORD_HASH_COLUMN = "password_hash"
    SECURITY_COLUMN = "security"
    MOBILE_NUMBER_COLUMN = "mobile_number"

    #Next_img
    TABLE_NAME_USER_SETTING = "nat_user_setting"
    FOLDER_PATH = 'folder_path'
    IMAGES = 'images'
    DOT = '.'
    JSON_FOLDER = 'json'
    HEIGHT = 'height'
    WIDTH = 'width'
    BLUR_ACTIVE = 'is_blur_mode_active'
    JSON_ANNOTATION_FIRST_KEY = 'img'
    JSON_ANNOTATION_THIRD_KEY = 'annotations'

    #SaveAnnotations

    JSON_SCHEMA = {"created": None, "height": None, "img": None, "inputs_dir": None, "width": None}
    CREATED_KEY = "created"
    INPUT_DIR_KEY = "inputs_dir"
    ANNOTATIONS_SCHEMA = {"bbox": None, "imageTag": None, "polygon": None, "id": None, "label": None}

    # SaveSettings
    USER_ID = 'user_id'
    LAST_MODIFIED_DATE = 'last_modified_date'
    CREATED_DATE = 'created_date'

    # GetSettings
    NAT_ADMIN = 'nat_admin'
    SETTINGS_COLUMNS =['user_id', 'setting_data', 'model_type', 'pred_type',
                       'output_format', 'anno_tip', 'min_width', 'min_height',
                       'folder_path', "frames_to_interpolate"]
    SETTING_DATA_KEY = "setting_data"
    PARAMETERS_KEY = "parameters"
    NAME_KEY = 'name'
    ID_VALUE = 'Id'
    SUBCLASS_KEY = 'subClass'
    SELECTED = "selected"

    # User Role
    TABLE_NAME_USER_AUTHORITY = 'nat_user_authority'
    ROLE_COLUMN = 'authority_name'

    # Annotation Class
    TABLE_NAME_ANNOTATION_CLASSES = 'annotation_classes'
    ClASS_COLUMN = 'Class_Name'
    TABLE_ANNOTATION_CLASSES_ID_NAME = ["ID", "Class_Name"]

    # TABLE_VIDEO = 'video'
    TABLE_VIDEO_COLUMNS = ["model_date", "process_for_transaction_table", "automation_class_Data"]
    TABLE_VIDEO_MODEL_DATE = "model_date"
    TABLE_VIDEO_PROCESSED_FLAG = "process_for_transaction_table"
    TABLE_VIDEO_AUTOMATION_RESULTS = "automation_class_Data"

    TABLE_TRANSACTION_DASHBOARD = 'transaction_table_dashboard'
    DASHBOARD_KEYS = ["editlabel_m", "editcoord_m", "editparam_m", "editlabel_a", "editcoord_a", "editparam_a",
                      "interpolated", "added_m", "added_a", "deleted_a", "deleted_m", "class_id"]

    #ImagePreview
    TABLE_NAME_VIDEO = "video"
    ID_COLUMN = 'id'
    ASSIGNED_USER_ID_KEY = "assigned_user_id"
    PROJECT_ID_KEY_IMGPRV = "project_id"
    VIDEO_NAME_KEY = "video_name"
    PREVIEW_FOLDER = "preview"
    BBOX_KEY = "bbox"
    POLYGON_KEY = "polygon"
    X_MIN = "xmin"
    X_MAX = "xmax"
    Y_MIN = "ymin"
    Y_MAX = "ymax"

    WIDTH_LINE = 2
    CIRCLE_RADIUS = 3
    CIRCLE_THICKNESS = 2
    TOTAL_LENGTH = 8
    IMAGE_EXTENSION = ".png"

    COLOR_SCHEME = {
        "bbox": (255, 0, 255),
        "polygon": (255, 0, 0),
        "line": (255, 255, 0),
        "point": (0, 255, 0)
    }
    ANNOTATION_LOOK_KEY = "look"
    POINTS_KEY = "points"
    X_KEY = "x"
    Y_KEY = "y"
    POLYGON_LOOK = "polygon"
    LINE_LOOK = "line"
    POINT_LOOK = "point"
    VIDEOPATH_KEY = 'video_path'

    # Archive dashboard transactions
    TABLE_ARCHIVE_TRANSACTION_DASHBOARD = 'archived_transaction_table_dashboard'
    TABLE_ARCHIVE_TRANSACTION_DASHBOARD_COLUMNS = ['editlabel_m', 'editcoord_m', 'editparam_m', 'editlabel_a',
                                                   'editcoord_a', 'editparam_a', 'added_m', 'deleted_a', 'interpolated',
                                                   'deleted_m', 'added_a', 'class_id', 'project_id', 'date', 'user_id',
                                                   'video_id', 'model_date']

