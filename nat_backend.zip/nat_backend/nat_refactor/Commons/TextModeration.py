import os
import json
from nat_refactor.utils.database_ops import DQL, DbConfig
from nat_refactor.constants.constants import Constants
from nat_refactor.Commons.Next_img import NextImage


class TextModeration(object):

    def __init__(self, uid, pid):
        self.userid = uid
        self.project_id = pid

        self._db = None
        self._cur = None
        self._project_path = None
        self.text_folder_name = 'text'
        self.json_folder_name = 'json'

    @property
    def db(self):
        if self._db is None:
            self._db = DbConfig.get_instance().pool.get_connection()
        return self._db

    @property
    def cur(self):
        if self._cur is None:
            self._cur = self.db.cursor(dictionary=True)
        return self._cur

    @property
    def project_path(self):
        if self._project_path is None:
            self._project_path = NextImage.base_folder_path(self.userid, self.project_id)
        return self._project_path

    def get_video_name(self, video_id):
        with DQL() as obj_dql:
            video_data = obj_dql.select_from_table(
                table_name=Constants.TABLE_NAME_VIDEO,
                columns=Constants.ALL_DATA,
                condition={Constants.ID_COLUMN: video_id},
                dictionary=True,
                cursor=self.cur
            )
        return video_data[Constants.FIRST_ELEMENT][Constants.VIDEO_NAME_KEY]

    def get_dir_paths(self, video_name):
        text_file_dir = os.path.join(self.project_path, video_name, self.text_folder_name)
        json_save_dir = os.path.join(self.project_path, video_name, self.json_folder_name)
        return text_file_dir, json_save_dir

    @classmethod
    def parse_text(cls, text, annos):
        import re
        add_pos = 0
        for a in annos:
            s_pos = add_pos + a['pos'][0]
            e_pos = add_pos + a['pos'][1]
            prefix_tag = f'<span id="{a["id"]}" title="{a["intent"]}" style="background-color: orange;">'
            postfix_tag = '</span>'
            text = text[:s_pos] + prefix_tag + text[s_pos:e_pos] + postfix_tag + text[e_pos:]
            add_pos += len(prefix_tag) + len(postfix_tag)
        return "<p>" + re.sub(r'\\r\\n|\\r|\\n', "</br>", text) + "</p>"

    def get_new(self, videoid, f):
        video_name = self.get_video_name(videoid)
        text_file_dir, json_save_dir = self.get_dir_paths(video_name)
        file_without_ext = os.path.splitext(f)

        file_path = os.path.join(text_file_dir, f)
        with open(file_path, 'r') as file:
            data = file.read()

        json_file_path = os.path.join(json_save_dir, f'{file_without_ext[0]}.json')
        if os.path.exists(json_file_path):
            print(f'reading from file: [{json_file_path}]')
            with open(json_file_path, 'r') as file:
                annos = file.read()
        else:
            annos = '[]'
        
        def _d(a):
            a["text"] = data[a["pos"][0]:a["pos"][1]]
            return a

        annos_lst = sorted(json.loads(annos), key=lambda a: a['pos'][0])
        return {
            "video_name": video_name,
            "file_path": file_path,
            "text": self.parse_text(data, annos_lst),
            "annos": json.dumps([_d(a) for a in annos_lst])
        }

    def set_new(self, videoid, f, annos):
        video_name = self.get_video_name(videoid)
        text_file_dir, json_save_dir = self.get_dir_paths(video_name)
        file_path = os.path.join(self.project_path + video_name, self.text_folder_name, f)
        with open(file_path, 'r') as file:
            data = file.read()
        file_without_ext = os.path.splitext(f)

        if not os.path.exists(json_save_dir):
            os.mkdir(json_save_dir)

        annos_lst = sorted(json.loads(annos), key=lambda a: a['pos'][0])
        json_file_path = os.path.join(json_save_dir, f'{file_without_ext[0]}.json')
        with open(json_file_path, 'w') as file:
            file.write(annos)

        return {
            "video_name": video_name,
            "file_path": file_path,
            "text": self.parse_text(data, annos_lst),
            "annos": annos
        }

    def get(self, videoid, f):
        with DQL() as obj_dql:
            video_data = obj_dql.select_from_table(
                table_name=Constants.TABLE_NAME_VIDEO,
                columns=Constants.ALL_DATA,
                condition={Constants.ID_COLUMN: videoid},
                dictionary=True,
                cursor=self.cur
            )
        video_name = video_data[Constants.FIRST_ELEMENT][Constants.VIDEO_NAME_KEY]
        file_path = os.path.join(self.project_path + video_name, self.text_folder_name, f)
        with open(file_path, 'r') as file:
            data = file.read()

        file_without_ext = os.path.splitext(f)
        json_save_dir = os.path.join(self.project_path + video_name, self.json_folder_name)
        json_file_path = os.path.join(json_save_dir, f'{file_without_ext[0]}.json')
        if os.path.exists(json_file_path):
            print(f'reading from file: [{json_file_path}]')
            with open(json_file_path, 'r') as file:
                annos = file.read()
        else:
            annos = '{"intent": []}'

        return {
            "video_name": video_name,
            "file_path": file_path,
            "text": data,
            "annos": annos
        }

    def set(self, videoid, f, text, annos):
        with DQL() as obj_dql:
            video_data = obj_dql.select_from_table(
                table_name=Constants.TABLE_NAME_VIDEO,
                columns=Constants.ALL_DATA,
                condition={Constants.ID_COLUMN: videoid},
                dictionary=True,
                cursor=self.cur
            )
        video_name = video_data[Constants.FIRST_ELEMENT][Constants.VIDEO_NAME_KEY]
        file_path = os.path.join(self.project_path + video_name, self.text_folder_name, f)
        with open(file_path, 'w') as file:
            file.write(text)

        file_without_ext = os.path.splitext(f)
        json_save_dir = os.path.join(self.project_path + video_name, self.json_folder_name)
        if not os.path.exists(json_save_dir):
            os.mkdir(json_save_dir)
        json_file_path = os.path.join(json_save_dir,  f'{file_without_ext[0]}.json')
        with open(json_file_path, 'w') as file:
            file.write(annos)
        return {
            "video_name": video_name,
            "file_path": file_path,
            "text": text,
            "annos": annos
        }

    def close(self):
        if self._cur is not None:
            self._cur.close()
            self._cur = None
        if self._db is not None:
            self._db.close()
            self._db = None
