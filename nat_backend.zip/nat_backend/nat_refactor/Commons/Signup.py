from nat_refactor.constants.constants import Constants
from nat_refactor.utils.database_ops import DQL, DML, DbBase
from nat_refactor.utils.logger import Logger
from nat_refactor.exceptions.signup_exceptions import *
from nat_refactor.exceptions.parameter_exception import *
from typing import List
from traceback import extract_stack, format_exc

logger = Logger.get_logger()


class SignUp:

    @classmethod
    def find_user(cls, username) -> List:
        """
        Description        : This method find existed users from the table
        :param: username   : This is a username where we check it is existing or not in database.
        :param: db_obj     : This is the object of db connection.
        """
        if not username:
            raise ParameterNotFound("Username parameter is not found")
        with DQL() as obj_dql:
            data = obj_dql.select_from_table(
                table_name=Constants.TABLE_NAME_USERS,
                columns=Constants.USERNAME_COLUMN,
                condition="login='{}'".format(username))
            return data[0] if data else None

    @classmethod
    def user_signup(cls, entry_data):
        """
        Description        : This method find existed users from the table.
        :param: entry_data  : This is used for data entry in existing columns in the table.
        :param: columns_names : Name of the columns from which the info for a user is required.
        """
        try:
            existing_user_data = cls.find_user(entry_data[Constants.USERNAME_COLUMN])
            if existing_user_data:
                return False
            insert_data = list(entry_data.values())
            column_info = ", ".join(list(entry_data.keys()))
            with DML() as obj_dml:
                obj_dml.insert_into_table(
                    table_name=Constants.TABLE_NAME_USERS,
                    column_info_data=column_info,
                    insert_data=insert_data,
                    placeholders_length=len(list(entry_data.values())),
                    executemany=0
                )
            return True
        except Exception as err:
            logger.error(format_exc())
            raise SignUpException("Signup failed")
        finally:
            DbBase.clean()
