# from .Next_img import NextImage
# from .Signup import SignUp
# from .config_manager import *
#
# next_img = NextImage.next_img
