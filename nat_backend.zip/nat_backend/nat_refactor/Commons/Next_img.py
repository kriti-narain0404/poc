import json
import os
from typing import AnyStr, Tuple

import PIL
from PIL.ExifTags import TAGS

from commons import constants as cfg
from dao.data import Data
from nat_refactor.constants.constants import Constants
from nat_refactor.exceptions.next_img_exception import *
from nat_refactor.utils.database_ops import DQL
from nat_refactor.utils.encrypt_decrypt import *
from nat_refactor.utils.logger import Logger
from structures.data_structures import *
from nat_refactor.constants.global_data import GlobalData
logger = Logger.get_logger()


class NextImage:

    @classmethod
    def base_folder_path(cls, userid: int, project_id: int) -> AnyStr:
        '''
        Description : This function gives the absolute path of the directory by using userid and project_id
        userid : This is the user id eg : userid = 19
        project_id : This is the project id eg: project_id = 24
        exception raised : An exception is raised if this method is enabled to fetch the data.
        return : absolute path of the directory where all the folder containing images. eg : /home/user/noesis_data/
        '''

        with DQL() as obj_dql:
            data = obj_dql.select_from_table(
                table_name=Constants.TABLE_NAME_USER_SETTING,
                columns=Constants.FOLDER_PATH,
                condition=f"user_id='{userid}' and project_id = '{project_id}'")

            if not data:
                raise Exception("Folder path not found in DB")

            return decrypt(str(data[Constants.FIRST_ELEMENT][Constants.FIRST_ELEMENT]))

    @classmethod
    def next_img(cls, userid: int, project_id: int, image_id: int, video_name: AnyStr,
                 vid: int, video_type: int) -> Tuple[ObjVideoImage, AnyStr]:
        '''
        Description: This function returns a name tuple which is be consumed by the frontend for image display.
        userid: This is the user id eg : userid = 19
        project_id: This is the project id eg: project_id = 24
        image_id: This is the image number image sorted list which needs to be diaplayed eg image_id = 10
        video_name: This is the folder whose images are to be displayed on the UI eg: Traffic light
        vid: This is the id of the videoname in the database eg : vid = 20
        video_type: This tells whether the video folder contains 2D data or 3D data. eg : 0 for 2D and 1 for 3D.

        '''

        folder_path = cls.base_folder_path(userid, project_id)
        GlobalData.PROJECT_PATH = folder_path
        absolute_video_folder_path = os.path.join(folder_path, video_name)
        image_folder_absolute_path = os.path.join(absolute_video_folder_path, Constants.IMAGES)
        images_in_folder = os.listdir(image_folder_absolute_path)
        total_images_in_folder = len(images_in_folder)
        if not total_images_in_folder:
            raise NoImagesFound("The folder {} does not contain images".format(image_folder_absolute_path))
        image_filename = Data.natural_sort(images_in_folder)[image_id]
        image_name_without_extension = os.path.splitext(os.path.basename(image_filename))[0]
        json_filename = image_name_without_extension + Constants.LABEL_JSON_SUFFIX
        json_absolute_path = os.path.join(absolute_video_folder_path, Constants.JSON_FOLDER, json_filename)

        # get the orientation and the height width of the image
        try:
            image_data = PIL.Image.open(os.path.join(image_folder_absolute_path, image_filename))
            width_of_image, height_of_image = image_data.size
        except Exception as e:
            raise ImageFileError("There was an issue while extracting the information from the image file"
                                 "|| error {}".format(str(e)))

        exif_data = image_data.getexif()
        labeled = {}
        for (key, val) in exif_data.items():
            labeled[TAGS.get(key)] = val
        orientation = labeled.get('Orientation', 1)
        if 'Orientation' not in labeled:
            logger.error("error while fetching the orientation")

        if os.path.exists(json_absolute_path):
            json_data = json.load(open(json_absolute_path))
            is_blur_mode_active = json_data[Constants.BLUR_ACTIVE] if Constants.BLUR_ACTIVE in json_data else False
            annotation_data = json_data[Constants.JSON_ANNOTATION_FIRST_KEY][image_name_without_extension][Constants.JSON_ANNOTATION_THIRD_KEY]
        else:
            annotation_data = Constants.EMPTY_LIST.copy()
            is_blur_mode_active = False
        video_data_folder = folder_path.split(os.path.sep)[Constants.SECOND_LAST_ELEMENT]
        image_url = os.path.join(cfg.IMG_ENDPOINT, video_data_folder, video_name, image_filename)
        return ObjVideoImage(
            id=image_filename,
            is_blur_mode_active=is_blur_mode_active,
            project=video_data_folder,
            videoname=video_name,
            src=encode_incoming(image_url),
            imageId=image_id,
            videoId=vid,
            videopath=encode_incoming(absolute_video_folder_path),
            imagecount=total_images_in_folder,
            annotations=[],  # AnnotationUtils.make_annotations(annos),
            labels=None,  # NatInterface.get_obj_detect_label_opts(project)
            orientation=int(orientation),
            annos_json=json.dumps(annotation_data),
            video_type=video_type,
            width=width_of_image,
            height=height_of_image
        ), folder_path
