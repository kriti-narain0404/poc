import os
from nat_refactor.constants.global_data import GlobalData
from nat_refactor.constants.constants import Constants
from dao.data import Data
from nat_refactor.exceptions.next_img_exception import NoImagesFound


class ImageJsonList:


    def image_json_data(self,videoname):
        

        absolute_video_folder_path = os.path.join(GlobalData.PROJECT_PATH, videoname)
        image_folder_absolute_path = os.path.join(absolute_video_folder_path, Constants.IMAGES)
        images_in_folder = os.listdir(image_folder_absolute_path)
        if not images_in_folder:
            raise NoImagesFound("The folder {} does not contain images".format(image_folder_absolute_path))
        images_in_folder_sorted = Data.natural_sort(images_in_folder)
        image_name_without_extension = [os.path.splitext(os.path.basename(image_filename))[Constants.FIRST_ELEMENT]
                                        for image_filename in
                                        images_in_folder_sorted]

        json_folder_absolute_path = os.path.join(absolute_video_folder_path, Constants.JSON_FOLDER)
        json_in_folder = os.listdir(json_folder_absolute_path)
        json_name_without_extension = Constants.EMPTY_LIST.copy()
        if json_in_folder:
            json_in_folder_sorted = Data.natural_sort(json_in_folder)
            json_name_without_extension = [(os.path.splitext(os.path.basename(json_filename))[Constants.FIRST_ELEMENT])
                                           .replace('_label',Constants.EMPTY_STRING)
                                           for json_filename in json_in_folder_sorted]

        return image_name_without_extension, json_name_without_extension


