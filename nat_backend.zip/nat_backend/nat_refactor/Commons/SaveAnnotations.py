import os
from time import strftime, localtime

from nat_refactor.utils.json_ops import JSONHandler
from nat_refactor.constants.constants import Constants

class SaveAnnotations:
    """
    Description : This class is responsible for making entry of the annotation data when Save is hit on the NAT-UI.
    """
    def __init__(self, folder_path):
        """
        folder_path: The path of the folder where images and json folders are present
        """
        self.json_save = None
        self.image_name_without_extension = None
        self.folder_path = folder_path

    def save_annotations(self, annotations, image_name, is_blur_mode_active, width=None, height=None):
        """
        Description: This method will save the JSON corresponding to the image name provided at json folder path
        annotations: list of dicts which contains the annotations done by the annotator.
        image_name: the name of the image corresponding to which annotations are to be saved.
        width: width of the image.
        height: the height of the image.
        """
        # initializing the json which is to be saved
        json_save_dir = os.path.join(self.folder_path, Constants.JSON_FOLDER)
        self.image_name_without_extension = os.path.splitext(os.path.basename(image_name))\
            [Constants.FIRST_ELEMENT]
        json_file_abs_path = os.path.join(json_save_dir,
                                          self.image_name_without_extension+Constants.LABEL_JSON_SUFFIX)
        json_file_existance = os.path.exists(json_file_abs_path)
        json_folder_existance = os.path.exists(json_save_dir)
        if annotations and json_folder_existance:
            self.create_annotations_dict(annotations, is_blur_mode_active, width, height)
            json_obj = JSONHandler(filepath=json_file_abs_path)
            json_obj.writer(self.json_save)
        elif annotations and not json_folder_existance:
            os.mkdir(json_save_dir)
            self.create_annotations_dict(annotations, is_blur_mode_active, width, height)
            json_obj = JSONHandler(filepath=json_file_abs_path)
            json_obj.writer(self.json_save)
        elif not annotations and json_file_existance:
            os.remove(json_file_abs_path)


    def create_annotations_dict(self, annotations, is_blur_mode_active, width, height):
        """
        Description: This method will create the data for the img key inside the json
        annotations: list of dicts which contains the annotations done by the annotator.
        width: width of the image.
        height: the height of the image.
        """
        self.json_save = Constants.JSON_SCHEMA.copy()
        self.json_save[Constants.CREATED_KEY] = strftime("%m/%d/%Y %H:%M:%S", localtime())
        self.json_save[Constants.HEIGHT] = height
        self.json_save[Constants.WIDTH] = width
        self.json_save[Constants.BLUR_ACTIVE] = is_blur_mode_active
        self.json_save[Constants.JSON_ANNOTATION_FIRST_KEY] = Constants.EMPTY_DICT.copy()
        self.json_save[Constants.JSON_ANNOTATION_FIRST_KEY][self.image_name_without_extension]\
            = Constants.EMPTY_DICT.copy()
        self.json_save[Constants.JSON_ANNOTATION_FIRST_KEY][self.image_name_without_extension]\
            [Constants.JSON_ANNOTATION_THIRD_KEY] = None
        annotations_list = Constants.EMPTY_LIST.copy()
        for anno in annotations:
            anno_data = Constants.ANNOTATIONS_SCHEMA.copy()
            for k, v in anno.items():
                anno_data[k] = v
            annotations_list.append(anno_data)
        self.json_save[Constants.JSON_ANNOTATION_FIRST_KEY][self.image_name_without_extension]\
            [Constants.JSON_ANNOTATION_THIRD_KEY] = annotations_list
        