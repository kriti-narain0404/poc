from nat_refactor.utils.database_ops import DQL, DML, DbBase
from nat_refactor.constants.constants import Constants
from nat_refactor.exceptions.SaveSettings_exceptions import *


class SaveSettings:
    """
    Description: This class will save the settings on Setting screen of the NAT in the DB
    """
    def __init__(self, uid, pid, logger):
        self.current_datetime = None
        self.userid = uid
        self.project_id = pid
        self.logger = logger

        self._db = None
        self._cur = None
        self._update_flag = None

    @property
    def db(self):
        if self._db is None:
            self._db = DbBase()
        return self._db

    @property
    def cur(self):
        if self._cur is None:
            self._cur = self.db.db_conn.cursor()
        return self._cur

    @property
    def update_flag(self):
        """
        Description: This method will check and update the flag if data for the user with particular
                     project exists or not
        """
        if self._update_flag is None:
            try:
                with DQL() as obj_dql:
                    data = obj_dql.select_from_table(
                        table_name=Constants.TABLE_NAME_USER_SETTING,
                        columns=Constants.FOLDER_PATH,
                        condition={
                            "user_id": self.userid,
                            "project_id": self.project_id
                        })

                # Update a flag which will tell whether the data needs to be updated or inserted
                self._update_flag = True if data else False
            except Exception as err:
                raise FlagUpdateException("Couldn't update the flag which will decide whether to update settings or"
                                          " insert the settings || error {}".format(str(err)))
        return self._update_flag

    def save_settings(self, data):
        """
        Description: This method will be entrypoint for the settings insert or update.
        uid: This is the userid for which the settings need to be updated
        pid: This is the projectid for which the settings need to be updated, combined with userid these form a unique
             key for updation.
        data: the settings data which needs to updated or inserted into the table.
        """
        if self.update_flag:
            data_to_be_updated = self.curate_data(data)

            with DML() as obj_dml:
                obj_dml.update_into_table(Constants.TABLE_NAME_USER_SETTING,
                                          data_to_be_updated,
                                          f"{Constants.USER_ID}='{self.userid}' and {Constants.PROJECT_ID_AVAILABLE} = '{self.project_id}'")

        else:
            data[Constants.USER_ID] = self.userid
            data[Constants.PROJECT_ID_AVAILABLE] = self.project_id
            data[Constants.CREATED_DATE] = data[Constants.LAST_MODIFIED_DATE]
            with DML() as obj_dml:
                obj_dml.insert_into_table(Constants.TABLE_NAME_USER_SETTING, ", ".join(list(data.keys())),
                                          ['{}'.format(i) for i in list(data.values())],
                                          placeholders_length=len(list(data.keys())), executemany=0)

    def insert_class_data(self, classes):
        query = f"SELECT {Constants.ClASS_COLUMN} from {Constants.TABLE_NAME_ANNOTATION_CLASSES} " \
                f"WHERE Project_ID = %s"
        self.cur.execute(query, (self.project_id,))
        data = self.cur.fetchall()
        existing_classes = set([r[0] for r in data])

        new_classes = [c for c in classes if c not in existing_classes]
        insert_query = f"INSERT INTO {Constants.TABLE_NAME_ANNOTATION_CLASSES} " \
                       "(Class_Name, Project_ID) VALUES (%s, %s)"
        self.cur.executemany(insert_query, [(c, self.project_id,) for c in new_classes])
        self.db.db_conn.commit()

    def curate_data(self, data):
        """
        Description: This method will reformat the data to be used for updating the user settings table
        data: The data which needs to curated for updation of the table
        """
        return ", ".join(["{} = '{}'".format(column_name, value) for column_name, value in data.items()])

    def close(self):
        if self._cur is not None:
            self._cur.close()
            self._cur = None
