import os
import json
import pandas as pd
from copy import deepcopy
from graphql import GraphQLError
from datetime import datetime, date
from nat_refactor.constants.constants import Constants
from nat_refactor.utils.database_ops import DQL, DML, DbBase, DbConfig


class Dashboard(object):
    """
    Description: This class will handle the dashboard functionalities
    """

    def __init__(self, uid, pid, logger):
        self.userid = uid
        self.project_id = pid
        self.logger = logger

        self._db = None
        self._cur = None

    @property
    def db(self):
        if self._db is None:
            # self._db = DbBase()
            self._db = DbConfig.get_instance().pool.get_connection()
        return self._db

    @property
    def cur(self):
        if self._cur is None:
            self._cur = self.db.cursor()
        return self._cur

    @classmethod
    def fetch_automation_data(cls, video_id):
        with DQL() as obj_dql:
            data = obj_dql.select_from_table(
                table_name=Constants.TABLE_NAME_VIDEO,
                columns=", ".join(Constants.TABLE_VIDEO_COLUMNS),
                condition={
                    'id': video_id
                },
                dictionary=True
            )
        return data[Constants.FIRST_ELEMENT]

    def fetch_class_names(self):
        with DQL() as obj_dql:
            cols = Constants.TABLE_ANNOTATION_CLASSES_ID_NAME
            data = obj_dql.select_from_table(
                table_name=Constants.TABLE_NAME_ANNOTATION_CLASSES,
                columns=", ".join(cols),
                condition={
                    'Project_ID': self.project_id
                },
                dictionary=True
            )
        return {d[cols[0]]: d[cols[1]] for d in data}, {d[cols[1]]: d[cols[0]] for d in data}

    def get_user_dashboard_transaction(self, dt):
        with DQL() as obj_dql:
            cols = Constants.DASHBOARD_KEYS
            data = obj_dql.select_from_table(
                table_name=Constants.TABLE_TRANSACTION_DASHBOARD,
                columns=", ".join(cols),
                condition={
                    'user_id': self.userid,
                    'project_id': self.project_id,
                    'date': str(dt)
                },
                dictionary=True
            )
        return data

    def insert_user_dashboard_transaction(self, class_info, video_id, automation_data, date_of_model):
        """
        Description  : This method inserts the value for the user in the transaction table.
        class_info   : The classids which are not present in the db
        """
        insert_data_template = {k: 0 for k in Constants.DASHBOARD_KEYS[:-1]}
        insert_data_template.update({
            'class_id': None,
            'user_id': self.userid,
            'video_id': video_id,
            'project_id': self.project_id,
            'date': date.today(),
            'model_date': None
        })

        def generate_insert_data(cls_id, added_a=0, m_dt=None):
            insert_row = deepcopy(insert_data_template)
            insert_row.update({
                'class_id': cls_id,
                'added_a': added_a,
                'model_date': m_dt
            })
            return insert_row

        if date_of_model and automation_data:
            insert_rows = [generate_insert_data(cls_id, added_a=automation_data[cls_id], m_dt=date_of_model) for cls_id in class_info]
        elif date_of_model:
            insert_rows = [generate_insert_data(cls_id, m_dt=date_of_model) for cls_id in class_info]
        else:
            insert_rows = [generate_insert_data(cls_id) for cls_id in class_info]

        # print(insert_rows)
        with DML() as obj_dml:
            obj_dml.insert_into_table_dict(Constants.TABLE_TRANSACTION_DASHBOARD, insert_rows)

    def update_processed_flag(self, video_id):
        with DML() as obj_dml:
            obj_dml.update_into_table(
                Constants.TABLE_NAME_VIDEO, Constants.TABLE_VIDEO_PROCESSED_FLAG + "=1", f"id={video_id}")

    def insert_data_for_user(self, classes_to_be_entered, video_id):
        """
        Description         : This method inserts the data for user on a particular day when he's annotating.
        classes_to_be_added : A list containing the classes needed by the user for annotation
        """
        self.logger.info("[START]: Inside insert_data_for_user")
        if not self.project_id:
            return None

        automated_data = self.fetch_automation_data(video_id)
        class_names_by_id, class_id_by_name = self.fetch_class_names()
        date_of_model = automated_data[Constants.TABLE_VIDEO_MODEL_DATE]
        automation_results_modified = None

        if not class_names_by_id:
            raise GraphQLError("There are no classes defined for this project")

        if automated_data \
                and automated_data[Constants.TABLE_VIDEO_MODEL_DATE] \
                and not automated_data[Constants.TABLE_VIDEO_PROCESSED_FLAG]:
            automation_results = json.loads(automated_data[Constants.TABLE_VIDEO_AUTOMATION_RESULTS])
            automation_results_modified = {class_id_by_name[k]: v for k, v in automation_results.items()}

        current_date = date.today()
        user_dashboard_transaction_data = self.get_user_dashboard_transaction(current_date)
        response = {}
        class_data_for_insertion = []
        class_parameters = {k: 0 for k in Constants.DASHBOARD_KEYS[:-1]}

        if user_dashboard_transaction_data:
            class_exists = set()
            for data in user_dashboard_transaction_data:
                d = deepcopy(data)
                class_name = class_names_by_id[d.pop("class_id")]
                response[class_name] = d
                class_exists.add(class_name)
            classes_to_be_inserted = [class_nm for class_nm in classes_to_be_entered if class_nm not in class_exists]
            if classes_to_be_inserted:
                response.update({
                    class_: class_parameters for class_ in classes_to_be_inserted
                })
                class_data_for_insertion = [
                    class_id_by_name[class_nm] for class_nm in classes_to_be_inserted if class_nm in class_id_by_name]
        else:
            response = {class_nm: class_parameters for class_nm in classes_to_be_entered}
            class_data_for_insertion = [
                class_id_by_name[class_nm] for class_nm in classes_to_be_entered if class_nm in class_id_by_name]

        if class_data_for_insertion:
            self.insert_user_dashboard_transaction(
                class_data_for_insertion, video_id, automation_results_modified, date_of_model)
            if automated_data.get(Constants.TABLE_VIDEO_PROCESSED_FLAG) is not None and not automated_data.get(
                    Constants.TABLE_VIDEO_PROCESSED_FLAG):
                self.update_processed_flag(video_id)

        return response

    def update_data_for_user(self, data):
        """
        Description  : This method updates the data for user on a particular day when he's annotating.
        data         : The user ID for which the data is to be fetched.
        """
        self.logger.info("[START]: Inside update_data_for_user")
        if not data:
            return None
        data = json.loads(data)
        current_date = date.today()
        class_names_by_id, class_id_by_name = self.fetch_class_names()
        update_cols = Constants.DASHBOARD_KEYS[:-1]
        where_cols = ['class_id', 'user_id', 'project_id', 'date']
        query = f"UPDATE {Constants.TABLE_TRANSACTION_DASHBOARD} " \
                f"SET {', '.join([f'`{c}` = %s' for c in update_cols])} " \
                f"WHERE {' AND '.join([f'`{c}` = %s' for c in where_cols])}"
        update_rows = []
        for class_name, dashboard_data in data.items():
            row = [dashboard_data.get(col) for col in update_cols] + [
                class_id_by_name[class_name], self.userid, self.project_id, current_date]
            update_rows.append(row)

        self.logger.debug(query)
        self.logger.debug(update_rows)
        self.cur.executemany(query, update_rows)
        self.db.commit()

    def get_productivity_details(self, start_date, end_date):
        """
        Description      : This method gets data for productivity tab of the dashboard.
        start_date       : date from which the data is to be fetched for the project.
        end_date         : the date till which the data is to be fetched
        """
        query = \
            "SELECT " \
                "CAST(sum(a.editlabel_m)+sum(a.editcoord_m)+sum(a.editparam_m)+sum(editlabel_a)+sum(editcoord_a)+sum(editparam_a) as SIGNED) AS modify, " \
                "CAST(sum(deleted_a)+sum(deleted_m) as SIGNED) as deleted, " \
                "CAST(sum(added_m) as SIGNED) as added, " \
                "CAST(a.date as CHAR) as date, " \
                "u.login as username " \
            "FROM archived_transaction_table_dashboard a " \
            "LEFT JOIN nat_user u on u.id = a.user_id " \
            "WHERE project_id = %s AND date BETWEEN %s AND %s " \
            "GROUP BY date, user_id"
        self.cur.execute(query, (self.project_id, start_date, end_date,))
        h = ['modify', 'deleted', 'added', 'date', 'username']
        data = self.cur.fetchall()
        return [dict(zip(h, d)) for d in data] if data else None

    def get_accuracy_details(self, start_date, end_date):
        """
        Description      : This method gets data for accuracy tab of the dashboard.
        start_date       : date from which the data is to be fetched for the project.
        end_date         : the date till which the data is to be fetched
        """
        query = \
            "SELECT " \
                "CAST(sum(a.editlabel_a) + sum(a.deleted_a) as SIGNED) as wrong_classifications, " \
                "CAST(sum(a.editcoord_a) as SIGNED) as wrong_coordinates, " \
                "CAST(sum(a.added_a) as SIGNED) as total_detections, " \
                "CAST(a.model_date as CHAR) as date, " \
                "c.Class_Name as class_name " \
            "FROM archived_transaction_table_dashboard a " \
            "LEFT JOIN annotation_classes c on c.ID = a.class_id " \
            "WHERE " \
                "a.video_id IN (Select id from video where project_id = %s AND submitted=1) " \
                "AND model_date BETWEEN %s AND %s " \
                "AND model_date IS NOT NULL " \
            "GROUP BY model_date, class_id"
        self.cur.execute(query, (self.project_id, start_date, end_date,))
        h = ['wrong_classifications', 'wrong_coordinates', 'total_detections', 'date', 'class_name']
        data = [dict(zip(h, r)) for r in self.cur.fetchall()]

        class_model_data = {}
        if data:
            dataframe = pd.DataFrame(data)
            class_model_data = {
                'class_data': data,
                'model_data': dataframe.groupby(by='date', as_index=True).sum().to_dict("index")
            }
        return class_model_data

    def close(self):
        if self._cur is not None:
            self._cur.close()
            self._cur = None
        if self._db is not None:
            self._db.close()
            self._db = None
