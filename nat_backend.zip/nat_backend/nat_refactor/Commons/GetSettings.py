import json
from copy import deepcopy
from typing import List, Dict

from nat_refactor.utils.database_ops import DQL, DbConfig
from utils.ops_encrypt import EncryptDecrypt as ed
from nat_refactor.constants.constants import Constants


class GetSettings:
    """
    Description: This class will get the settings for admin only or admin+validator or admin+annotator
    """
    def __init__(self, uid, pid):
        self.userid = uid
        self.project_id = pid
        self.admin_only = False

        self._admin_user_id = None
        self._db = None
        self._cur = None

    @property
    def db(self):
        if self._db is None:
            # self._db = DbBase()
            self._db = DbConfig.get_instance().pool.get_connection()
        return self._db

    @property
    def cur(self):
        if self._cur is None:
            self._cur = self.db.cursor(dictionary=True)
        return self._cur

    @property
    def admin_user_id(self):
        """
        Description: This method will fetch the admin user id from the admin table for the project id.
        """
        if self._admin_user_id is None:
            with DQL() as obj_dql:
                data = obj_dql.select_from_table(
                    table_name=Constants.NAT_ADMIN,
                    columns=Constants.USER_ID,
                    condition={"project_id": self.project_id},
                    dictionary=True,
                    cursor=self.cur
                )
            self._admin_user_id = data[0][Constants.USER_ID]
        return self._admin_user_id

    def get_user_settings_data(self, condition, is_mandatory=False):
        with DQL() as obj_dql:
            data = obj_dql.select_from_table(
                table_name=Constants.TABLE_NAME_USER_SETTING,
                columns=Constants.COMMA_SEP.join(Constants.SETTINGS_COLUMNS),
                condition=condition,
                dictionary=True,
                cursor=self.cur
            )
        if is_mandatory:
            assert len(data) == 1, "There is error while fetching the data for userid:{}, expected length is 1," \
                                   "got {}".format(condition['user_id'], len(data))
        return data

    def clean_settings_data(self, data):
        settings_data = json.loads(data.get(Constants.SETTING_DATA_KEY))

        # The following loop takes care of the parameter selected flag
        # condition to be true: if there is subclass inside parameter
        for setting_data in settings_data:
            if setting_data[Constants.PARAMETERS_KEY]:
                parameters = setting_data[Constants.PARAMETERS_KEY]
                for param in parameters:
                    if Constants.SUBCLASS_KEY in param and \
                            param[Constants.NAME_KEY] != Constants.ID_VALUE and \
                            not param[Constants.SUBCLASS_KEY] \
                            and param[Constants.SELECTED]:
                        param[Constants.SELECTED] = Constants.FALSE_CONDITION
        # settings_data = json.dumps(settings_data)
        data[Constants.SETTING_DATA_KEY] = settings_data
        return data

    def get_setting_dict(self, setting_data: List):
        setting_dict = {}
        for d in setting_data:
            if 'parameters' in d:
                p_dict = {}
                for p in d['parameters']:
                    if 'subClass' in p:
                        sub_class_dict = {}
                        for c in p['subClass']:
                            sub_class_dict[c['name']] = c
                        p['subClass'] = sub_class_dict
                    p_dict[p['name']] = p
                d['parameters'] = p_dict
            setting_dict[d['name']] = d
        return setting_dict

    def get_setting_values(self, setting_dict: Dict):
        final_list = deepcopy(setting_dict)
        for s_name, s in setting_dict.items():
            if 'parameters' in s:
                for p_name, p in s['parameters'].items():
                    if 'subClass' in p:
                        final_list[s_name]['parameters'][p_name]['subClass'] = list(p['subClass'].values())
                final_list[s_name]['parameters'] = list(final_list[s_name]['parameters'].values())
        return list(final_list.values())

    def get_settings(self):
        classes_to_be_entered = []
        admin_data = self.get_user_settings_data(
            {"user_id": self.admin_user_id, "project_id": self.project_id}, is_mandatory=True)[Constants.FIRST_ELEMENT]

        if self.admin_user_id == self.userid:
            admin_only = True
            final_data = self.clean_settings_data(admin_data)
        else:
            # here the data for user : validator and annotator must be matched with admin data
            admin_only = False
            # print('User Id: ', self.userid)
            # print('Admin Id: ', self.admin_user_id)
            data = self.get_user_settings_data(
                {"user_id": self.userid, "project_id": self.project_id}, is_mandatory=False)
            admin_data = self.clean_settings_data(admin_data)
            final_data = admin_data
            if data:
                user_data = self.clean_settings_data(data[Constants.FIRST_ELEMENT])
                final_data['anno_tip'] = user_data['anno_tip']
                user_setting_dict = self.get_setting_dict(user_data['setting_data'])
                admin_setting_dict = self.get_setting_dict(admin_data['setting_data'])
                for s_name, s in admin_setting_dict.items():
                    if s_name in user_setting_dict:
                        user_s = user_setting_dict[s_name]
                        s['selected'] = user_s['selected']
                        if s['selected']:
                            classes_to_be_entered.append(s_name)
                        if 'parameters' in s and 'parameters' in user_s:
                            for p_name, p in s['parameters'].items():
                                if p_name in user_s['parameters']:
                                    user_p = user_s['parameters'][p_name]
                                    p['selected'] = user_p['selected']
                                    if 'subClass' in p and 'subClass' in user_p:
                                        for sub_cls_name, sub_cls in p['subClass'].items():
                                            if sub_cls_name in user_p['subClass']:
                                                user_sub_cls = user_p['subClass'][sub_cls_name]
                                                sub_cls['selected'] = user_sub_cls['selected']
                        # print(json.dumps(admin_setting_dict, indent=4))
                        admin_data['setting_data'] = self.get_setting_values(admin_setting_dict)

                final_data = admin_data

        return [
            final_data.get('anno_tip'),
            ed.decrypt_incoming(final_data.get('folder_path')),
            final_data.get('min_height'),
            final_data.get('min_width'),
            final_data.get('model_type'),
            final_data.get('output_format'),
            final_data.get('pred_type'),
            json.dumps(final_data.get("setting_data")),
            final_data.get("frames_to_interpolate")], classes_to_be_entered, admin_only
    
    def close(self):
        if self._cur is not None:
            self._cur.close()
            self._cur = None
        if self._db is not None:
            self._db.close()
            self._db = None
