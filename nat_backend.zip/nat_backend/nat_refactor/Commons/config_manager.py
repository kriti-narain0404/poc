"""
File : config_manager.py
Description : Reads configuration file and create getter functions for each
              parameter in config.
Created on : 17-03-2022
Author :
E-mail :
"""

import configparser
import os
from nat_refactor.constants.constants import Constants as c
from nat_refactor.exceptions.FileNotFound_exception import FileNotFoundException


class ConfigManager:
    """
    This class opens the configuration file and
    reads all the configuration provided inside it
    """

    def __new__(self):
        if not hasattr(self, 'instance'):
            file_name = c.CONFIG_FILE_PATH
            self.parser = configparser.ConfigParser()
            self.parser.optionxform = str
            self.config = self.parser

            if os.path.exists(file_name):
                self.config.read(file_name, encoding='utf-8')
            else:
                raise FileNotFoundException('No Config file found!')

            self.instance = super(ConfigManager, self).__new__(self)

        return self.config


class ReadConfigFile:
    """
    This class reads specific configurations based on user requirement
    """

    objConfig = ''

    def __init__(self):
        self.obj_config = ConfigManager()

    def get_environment_config_source(self, param):
        env_config = self.obj_config[c.EXECUTION_ENVIRONMENT_SOURCE]
        return env_config[param]

    def get_environment_config_destination(self, param):
        env_config = self.obj_config[c.EXECUTION_ENVIRONMENT_DESTINATION]
        return env_config[param]

    def get_env_config(self, param):
        env_config = self.obj_config[c.DEFAULT_ENVIRONMENT]
        return env_config[param]

    def get_env_parameters(self, param, env_name):
        return self.obj_config[env_name][param]

    def get_base_url(self, param):
        env_config = self.obj_config[c.API_BASE_URL]
        return env_config[param]

    def get_api_intiator_suffix(self, param):
        env_config = self.obj_config[c.API]
        return env_config[param]

    def get_api_port(self, param):
        env_config = self.obj_config[c.API_PORT]
        return env_config[param]

    def get_api_config(self,param):
        env_config = self.obj_config[c.API_INITIALIZE]
        return env_config[param]

    def get_api_stop_config(self,param):
        env_config = self.obj_config[c.API_STOP]
        return env_config[param]


# Create an instance of ReadConfigFile to be used throughout the program
cfg = ReadConfigFile()

if __name__ == '__main__':
    execution_env = cfg.get_env_config(c.EXECUTION_ENVIRONMENT)
    db_details = cfg.get_env_parameters("MYSQL_DATABASE_USER", execution_env)
    print(db_details)
