import os
import json
import cv2
import numpy as np
import string
import random

from nat_refactor.utils.database_ops import DQL
from nat_refactor.constants.constants import Constants
from nat_refactor.utils.encrypt_decrypt import *
from nat_refactor.exceptions.next_img_exception import NoImagesFound
from nat_refactor.utils.logger import Logger
from nat_refactor.Commons.config_manager import cfg

from dao.data import Data
from structures.data_structures import *

logger = Logger().get_logger()


class ImagePreview:
    """
    This class will handle the functionality for image preview option
    """

    def __init__(self, imageid, vid):
        """
        image_id: Id of the image requested.
        vid: the id of the video in the table video
        """

        self.image_id = imageid
        self.video_id = vid
        self._video_data = None
        self._folder_path = None
        self.preview_folder = None
        self.image_path_preview_abs = None

    @property
    def video_data(self):
        """
        Description: This method will fetch data for the video from video table
        """
        if self._video_data is None:
            with DQL() as obj_dql:
                self._video_data = obj_dql.select_from_table(
                    table_name=Constants.TABLE_NAME_VIDEO,
                    columns=Constants.ALL_DATA,
                    condition={Constants.ID_COLUMN: self.video_id},
                    dictionary=True)
        return self._video_data

    @property
    def folder_path(self):
        """
        Description: This method will fetch the folder path from the db for the user
        """
        if self._folder_path is None:
            with DQL() as obj_dql:
                self._folder_path = obj_dql.select_from_table(
                    table_name=Constants.TABLE_NAME_USER_SETTING,
                    columns=Constants.FOLDER_PATH,
                    condition={
                        Constants.USER_ID: (self.video_data[Constants.FIRST_ELEMENT]).get(Constants.ASSIGNED_USER_ID_KEY),
                        Constants.PROJECT_ID_KEY_IMGPRV: (self.video_data[Constants.FIRST_ELEMENT]).get(Constants.PROJECT_ID_KEY_IMGPRV)},
                    dictionary=True)
        return self._folder_path

    def make(self):
        folder_path = decrypt((self.folder_path[Constants.FIRST_ELEMENT]).get(Constants.FOLDER_PATH))

        videoname = (self.video_data[Constants.FIRST_ELEMENT]).get(Constants.VIDEO_NAME_KEY)
        absolute_video_folder_path = os.path.join(folder_path, videoname)
        self.preview_folder = os.path.join(absolute_video_folder_path, Constants.PREVIEW_FOLDER)

        if not os.path.exists(self.preview_folder):
            os.mkdir(self.preview_folder)
        else:
            os.system("rm -rf {}/*".format(self.preview_folder))

        image_folder_absolute_path = os.path.join(absolute_video_folder_path, Constants.IMAGES)
        images_in_folder = os.listdir(image_folder_absolute_path)

        total_images_in_folder = len(images_in_folder)

        if not total_images_in_folder:
            raise NoImagesFound("The folder {} does not contain images".format(image_folder_absolute_path))

        image_filename = Data.natural_sort(images_in_folder)[self.image_id]
        image_name_without_extension = os.path.splitext(os.path.basename(image_filename))[Constants.FIRST_ELEMENT]

        json_filename = image_name_without_extension + Constants.LABEL_JSON_SUFFIX
        json_absolute_path = os.path.join(absolute_video_folder_path, Constants.JSON_FOLDER, json_filename)

        if os.path.exists(json_absolute_path):
            annotation_data = json.load(open(json_absolute_path))[Constants.JSON_ANNOTATION_FIRST_KEY][image_name_without_extension][Constants.JSON_ANNOTATION_THIRD_KEY]
            image_preview_file = self.__generate_image_with_annotations(image_folder_absolute_path, image_filename, annotation_data)

            url = os.path.join(cfg.get_env_parameters(Constants.IP_ADDRESS_KEY,
                                                      cfg.get_env_parameters(Constants.EXECUTION_ENVIRONMENT,
                                                                             Constants.DEFAULT_ENVIRONMENT)),
                               Constants.IMG_KEY,
                               folder_path.split(Constants.PATH_SEPERATOR)[Constants.SECOND_LAST_ELEMENT],
                               videoname,
                               Constants.PREVIEW_FOLDER,
                               image_preview_file)
        else:
            url = os.path.join(cfg.get_env_parameters(Constants.IP_ADDRESS_KEY,
                                                      cfg.get_env_parameters(Constants.EXECUTION_ENVIRONMENT,
                                                                             Constants.DEFAULT_ENVIRONMENT)),
                               Constants.IMG_KEY,
                               folder_path.split(Constants.PATH_SEPERATOR)[Constants.SECOND_LAST_ELEMENT],
                               videoname,
                               Constants.IMAGES,
                               image_filename)
        return ObjVideoDetails(videoid=self.video_id,
                               videoname=videoname,
                               videourl=url,
                               videopath=(self.video_data[Constants.FIRST_ELEMENT]).get(Constants.VIDEOPATH_KEY),
                               imageid=self.image_id,
                               imagecount=total_images_in_folder)

    def __generate_image_with_annotations(self, image_folder, image_filename, annotation_data):
        """
        Description : This method generates a preview image
        image_folder: The absolute path the folder where images are present
        image_filename: name of the image file
        annotation_data: the annotations done by the user
        """
        imageread = cv2.imread(os.path.join(image_folder, image_filename))
        for annotation in annotation_data:
            if annotation[Constants.BBOX_KEY]:
                start = (int((annotation[Constants.BBOX_KEY]).get(Constants.X_MIN)),
                         int((annotation[Constants.BBOX_KEY]).get(Constants.Y_MIN)))
                end = (int((annotation[Constants.BBOX_KEY]).get(Constants.X_MAX)),
                         int((annotation[Constants.BBOX_KEY]).get(Constants.Y_MAX)))
                cv2.rectangle(imageread, start, end,
                              Constants.COLOR_SCHEME.get(Constants.BBOX_KEY), Constants.WIDTH_LINE)

            elif annotation[Constants.POLYGON_KEY]:
                annotation_type = (annotation[Constants.POLYGON_KEY]).get(Constants.ANNOTATION_LOOK_KEY)
                points = (annotation[Constants.POLYGON_KEY]).get(Constants.POINTS_KEY)
                pair_points = [(int(data.get(Constants.X_KEY)), int(data.get(Constants.Y_KEY)))
                               for data in points]
                if annotation_type == Constants.POLYGON_LOOK:
                    cv2.polylines(imageread, [np.asarray(pair_points, np.int32)], Constants.TRUE_CONDITION,
                                  Constants.COLOR_SCHEME.get(Constants.POLYGON_LOOK), Constants.WIDTH_LINE)

                elif annotation_type == Constants.LINE_LOOK:
                    cv2.line(imageread, pair_points[Constants.FIRST_ELEMENT], pair_points[Constants.LAST_ELEMENT],
                             Constants.COLOR_SCHEME.get(Constants.LINE_LOOK), Constants.WIDTH_LINE)

                elif annotation_type == Constants.POINT_LOOK:
                    cv2.circle(imageread, (points[Constants.FIRST_ELEMENT]), Constants.CIRCLE_RADIUS,
                               Constants.COLOR_SCHEME.get(Constants.POINT_LOOK), Constants.CIRCLE_THICKNESS)

                else:
                    logger.warn("This look type has no implementation, expected polygon, line, point"
                                " got {}".format(annotation_type))
            else:
                logger.warn("The method for this annotation to be shown on the image preview functionality"
                                          "is not implemented, expected bbox and polygon only")
        # image save
        filename = ''.join(random.choices(string.ascii_uppercase +
                               string.digits, k=Constants.TOTAL_LENGTH))
        self.image_path_preview_abs = os.path.join(self.preview_folder, filename+Constants.IMAGE_EXTENSION)
        cv2.imwrite(self.image_path_preview_abs, imageread)
        return filename+Constants.IMAGE_EXTENSION



