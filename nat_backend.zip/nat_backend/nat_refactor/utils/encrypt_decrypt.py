from nat_refactor.exceptions.decrypt_exception import DecryptException
import base64


def decrypt(data):
    """
    Description: This function decrypts the encoded data.
    :return: decoded string
    """
    try:
        return (base64.b64decode(data)).decode('UTF-8')
    except Exception as e:
        raise DecryptException("the data sent couldn't be decrypted exception occured {}".format(e)) from e


def encode_incoming(message):
    """
    Description       : this method is used to encrypt the incoming message
    :param message    : this is the input to be encrypted
    """
    if type(message) is not str:
        message = str(message)
    return base64.b64encode(bytes(message, 'utf-8')).decode('utf-8')