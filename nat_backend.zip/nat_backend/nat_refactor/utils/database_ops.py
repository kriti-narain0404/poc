"""
Author:Kush
File usage: This file is used to create db connection
Created-Date: 30/03/2022
Updated-Date:
NoesisAutoTagAI Copyright @HCL-2022
"""

import mysql.connector
from mysql.connector import pooling
# import sqlalchemy.pool as pool
from typing import Dict, List, Union
from nat_refactor.utils.logger import Logger
from nat_refactor.constants.constants import Constants
from nat_refactor.utils.encrypt_decrypt import decrypt
from nat_refactor.exceptions.dbconfig_exception import *
from nat_refactor.Commons.config_manager import cfg
from nat_refactor.queries.queries import DBQueries
from nat_refactor.constants.global_data import GlobalData

logger = Logger().get_logger()


class DbConfig:
    """
    Description: This Class create the database connections.
    """

    handler = None

    def __init__(self):
        """
        virtual private constructor
        """
        if DbConfig.handler is not None:
            raise Exception('This class is a singleton class')
        else:
            DbConfig.handler = self
        self.__pool = None
        self.fetch_env()

    @property
    def pool(self):
        if self.__pool is None:
            print('Creating pooled connections')
            self.__pool = self.__get_pooled_connection(max_overflow=10, pool_size=5)
        return self.__pool

    def __get_pooled_connection(self, **kwargs):
        config = {
            'host': self.hostName(),
            'user': self.username(),
            'password': self.password(),
            'database': self.db_name(),
            'auth_plugin': 'mysql_native_password'
        }

        # def get_conn():
        #     c = mysql.connector.connect(**config)
        #     c.autocommit = False
        #     return c
        #
        # return pool.QueuePool(get_conn, **kwargs)
        return pooling.MySQLConnectionPool(
            pool_name="pynative_pool",
            pool_size=kwargs['pool_size'],
            pool_reset_session=True,
            **config)

    @classmethod
    def get_instance(cls):
        if cls.handler is None:
            cls.handler = cls()
        return cls.handler

    def fetch_env(self):
        """
        Description    : This method will fetch the environment to be used while execution
        """
        GlobalData.ENVIRONMENT_DETAILS = cfg.get_env_config(Constants.EXECUTION_ENVIRONMENT)

    def hostName(self):
        """
        Description    : This is used to extract and decrypt the hostname from database configuration file
        :return: It returns a Decoded String of DB_Hostname extracted from nat properties
        """
        return decrypt(cfg.get_env_parameters(Constants.MYSQL_DATABASE_HOST, GlobalData.ENVIRONMENT_DETAILS))

    def username(self):
        """
        Description    : This is used to extract and decrypt the username from database configuration file
        :return: It returns a Decoded String of DB_Username extracted from nat properties
        """
        return decrypt(cfg.get_env_parameters(Constants.MYSQL_DATABASE_USER, GlobalData.ENVIRONMENT_DETAILS))

    def password(self):
        """
        Description    : This is used to extract and decrypt the password from database configuration file
        :return: It returns a Decoded String of DB_Password extracted from nat properties
        """
        return decrypt(cfg.get_env_parameters(Constants.MYSQL_DATABASE_PASSWORD, GlobalData.ENVIRONMENT_DETAILS))

    def db_name(self):
        """
        Description    : This is used to extract and decrypt the db_name from database configuration file
        :return: It returns a Decoded String of DB_Name extracted from nat properties
        """
        return decrypt(cfg.get_env_parameters(Constants.MYSQL_DATABASE_DB, GlobalData.ENVIRONMENT_DETAILS))

    def connect_to_DB(self):
        """
        Description    : This is used to create a mysql database connection and cursor for db operations
        :return: It Return a DB Connection and a Cursor Obj [Example : [db_conn,db_cur]]
        Raises:
            DbConfigException: [description]
        """
        logger.info("[INFO]: Inside connect_to_Db")
        # Extracting/constructing a dict. containing db credentials
        try:
            self.fetch_env()
            config = {'host': self.hostName(), 'user': self.username(),
                      'password': self.password(), 'database': self.db_name()}
        except Exception as e:
            raise DBConfigException("Unable to fetch hostname,username,password or db_name || Error: {}".format(e))
        # Connecting to db using the db credentials (config)
        try:
            if GlobalData.DB_CONNECTION is not None:
                if GlobalData.DB_CONNECTION.is_connected():
                    return GlobalData.DB_CURSOR, GlobalData.DB_CONNECTION
                else:
                    GlobalData.DB_CONNECTION = mysql.connector.connect(**config)
                    GlobalData.DB_CURSOR = GlobalData.DB_CONNECTION.cursor(
                        dictionary=Constants.TRUE_CONDITION)
                    return GlobalData.DB_CURSOR, GlobalData.DB_CONNECTION
            else:
                GlobalData.DB_CONNECTION = mysql.connector.connect(**config)
                GlobalData.DB_CURSOR = GlobalData.DB_CONNECTION.cursor(
                    dictionary=Constants.TRUE_CONDITION)
                return GlobalData.DB_CURSOR, GlobalData.DB_CONNECTION
        except Exception as e:
            raise DBConfigException("Unable to connect to db , kindly check the connection Obj || Error {}".format(e))


class DbBase(object):
    __db_conn = None

    def __init__(self):
        pass

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, exc_traceback):
        # self.clean()
        pass

    @property
    def db_conn(self):
        if DbBase.__db_conn is None:
            try:
                print("opening polled connection")
                # db_conf = DbConfig.get_instance()
                DbBase.__db_conn = DbConfig.get_instance().pool.get_connection()
            except Exception as e:
                print(e)
                raise e
        return DbBase.__db_conn

    @classmethod
    def clean(cls):
        if cls.__db_conn is not None:
            print("closing polled connection")
            cls.__db_conn.close()
            cls.__db_conn = None


class DML(DbBase):
    """
    This class holds the data manipulative commands for the application
    """
    def insert_into_table_dict(self, table_name, insert_data: Union[List[Dict], Dict]):
        """
        Description                : This method will insert into a column/columns with dict data.
        :param: table_name         : This the table name in which insert is to be made.
        :param: insert_data        : data to be inserted into the table in dict format.
        :param: executemany        : This value is int and tells whether only one row is to be inserted or multiple.
        """
        if not insert_data:
            return False

        columns = []
        placeholders_length = 0
        insert_rows = []
        if isinstance(insert_data, dict):
            insert_data = [insert_data]
        for row in insert_data:
            if not columns:
                columns = row.keys()
                placeholders_length = len(columns)
            insert_rows.append(list(row.values()))

        query = f"INSERT INTO {table_name} (`{'`, `'.join(columns)}`) " \
                f"VALUES ({', '.join([Constants.STRING_PLACEHOLDER] * placeholders_length)})"
        cur = None
        try:
            cur = self.db_conn.cursor()
            cur.executemany(query, insert_rows)
            self.db_conn.commit()
        except Exception as e:
            raise InsertTableException("Couldn't enter the data into the table {} || error : {}".format(table_name, e))
        finally:
            if cur is not None:
                cur.close()

    def insert_into_table(self, table_name, column_info_data, insert_data, placeholders_length=1, executemany=1):
        """
        Description                : This method will insert into a column/columns with data.
        :param: table_name         : This the table name in which insert is to be made.
        :param: column_info_data   : The data which is to be entered.
        :param: insert_data        : data to be inserted into the table.
        :param: placeholders_lenght: The length of the columns which are to be entered.
        :param: executemany        : This value is int and tells whether only one row is to be inserted or multiple.
        """
        cur = None
        try:
            cur = self.db_conn.cursor()
            placeholders = ", ".join([Constants.STRING_PLACEHOLDER] * placeholders_length)
            query = DBQueries.INSERT_PLACEHOLDER % (table_name, column_info_data, placeholders)
            if executemany:
                cur.executemany(query, insert_data)
            else:
                cur.execute(query, insert_data)
            self.db_conn.commit()
        except Exception as e:
            raise InsertTableException("Couldn't enter the data into the table {} || error : {}".format(table_name, e))
        finally:
            if cur is not None:
                cur.close()

    def update_into_table(self, table_name, column_info_data, condition):
        """
        Description        : This method updates a row in the given table
        :param: table_name : the name of the table whose data needs to be updated.
        :param: columns_info_data : The columns which are required to be updated.
        :param: condition : determines a particular row which needs to be updated.
        """
        cur = None
        try:
            cur = self.db_conn.cursor()
            query = DBQueries.UPDATE.format(table_name, column_info_data, condition)
            cur.execute(query)
            self.db_conn.commit()
        except Exception as e:
            raise UpdateTableException("Couldn't Update the data in the table {} || error : {}".format(table_name, e))
        finally:
            if cur is not None:
                cur.close()


class DQL(DbBase):
    """
    This class holds all of the data query statements used in the application.
    """

    def select_from_table(self, table_name, columns, condition=None, dictionary=None, cursor=None):
        """
        Description        : This method selects particular column from the table
        :param: table_name : the name of the table from where you want the data to be fetched.
        :param: columns    : The columns which are required.
        """
        cur = None
        if condition:
            try:
                cur = self.db_conn.cursor(dictionary=dictionary) if cursor is None else cursor
                if isinstance(condition, dict):
                    where = []
                    where_values = []
                    for con_col, con_val in condition.items():
                        where.append(f"{con_col} = %s")
                        where_values.append(con_val)
                    query = DBQueries.SELECT_CONDITIONAL.format(
                        columns, table_name, " AND ".join(where))
                    cur.execute(query, tuple(where_values))
                else:
                    query = DBQueries.SELECT_CONDITIONAL.format(columns, table_name, condition)
                    cur.execute(query)
                return cur.fetchall()
            except Exception as e:
                raise SelectTableException("couldn't fetch data from the table|| error: {}".format(e))
            finally:
                if cur is not cursor and cur is not None:
                    cur.close()
        else:
            try:
                cur = self.db_conn.cursor(dictionary=dictionary) if cursor is None else cursor
                query = DBQueries.SELECT.format(columns, table_name)
                cur.execute(query)
                return cur.fetchall()
            except Exception as e:
                raise SelectTableException("couldn't fetch data from the table|| error: {}".format(e))
            finally:
                if cur is not cursor and cur is not None:
                    cur.close()