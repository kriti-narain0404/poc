import json

from nat_refactor.constants.constants import Constants
from nat_refactor.exceptions.json_ops_exceptions import *


class JSONHandler:
    """
    Description: This class will handle all json related operations
    """
    def __init__(self, filepath):
        """
        filepath: the path of the file which is to be taken care off.
        """
        self.filepath = filepath

    def writer(self, data: dict, indent=4):
        """
        Description: This method will write a json file
        data: The data which is to be written inside json file
        indent: The indent option of json writer, default is 4.
        """
        if not isinstance(data, dict):
            raise TypeError("The data which is sent to be written doesnot have the correct type, Expected type 'dict',"
                            " got {}".format(type(data)))

        try:
            with open(self.filepath, Constants.WRITE_MODE) as file:
                json.dump(data, file, indent=indent)
        except Exception as err:
            raise JSONFileWriteException("Error while writing the json file {} || Error {}".format(self.filepath,
                                                                                                   str(err)))

