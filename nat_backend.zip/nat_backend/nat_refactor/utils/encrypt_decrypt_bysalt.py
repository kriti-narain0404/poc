import os
import hashlib
from nat_refactor.utils.logger import Logger
from nat_refactor.exceptions.encrypt_decrypt_exception import *

logger = Logger.get_logger()


class EncryptionUtils:
    """
    Description          : This class has method for encrypting the data.
    """

    @classmethod
    def generate_hash(cls, value):
        """
        Description        : This method find existed users from the table
        :param: Value      : This is the value for which hash needs to be generated..
        """
        if not value:
            raise InvalidValue("Invalid Value")
        try:
            salt = os.urandom(16)
            key = hashlib.pbkdf2_hmac('sha256', value.encode('utf-8'), salt, 100000)
            response = salt + key
            return response.hex()
        except Exception as error_obj:
            raise EncryptException("Error has occured while encrypting the password || error{}".format(error_obj))
