from traceback import extract_tb, StackSummary
from sys import stderr
from nat_refactor.utils.logger import Logger

def print_traceback(traceback_obj, file=None):
    """Print the list of tuples as returned by extract_tb() or
        extract_stack() as a formatted stack trace to the given file."""
    if file is None:
        file = stderr
    traceback_str = 'Traceback: \n'
    for item in StackSummary.from_list(extract_tb(traceback_obj, limit=None)).format():
        print(item, file=file, end="")
        traceback_str += str(item)
    (Logger().get_logger()).error(traceback_str)
