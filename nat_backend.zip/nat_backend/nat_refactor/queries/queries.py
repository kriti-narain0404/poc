
class DBQueries:
    """
    Description     : This class will maintain all the queries used in the application.
    """
    SELECT_BY_DATE = "SELECT {column_name} FROM {table_name} WHERE {condition} ORDER BY {date_column_name}" \
                     " {ASC_or_DESC}"
    INSERT_PLACEHOLDER = "INSERT INTO %s ( %s ) VALUES ( %s )"
    SELECT_CONDITIONAL = "SELECT {} FROM {} WHERE {}"
    SELECT = "SELECT {} FROM {}"
    UPDATE = "UPDATE {} SET {} WHERE {}"