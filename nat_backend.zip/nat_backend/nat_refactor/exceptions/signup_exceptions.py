from nat_refactor.exceptions.base_exception import NAT


class UserFindException(NAT):
    def __init__(self, message):
        super(UserFindException, self).__init__(message)


class UserExistanceException(NAT):
    def __init__(self,message):
        super(UserExistanceException, self).__init__(message)

class SignUpException(NAT):
    def __init__(self, message):
        super(SignUpException, self).__init__(message)