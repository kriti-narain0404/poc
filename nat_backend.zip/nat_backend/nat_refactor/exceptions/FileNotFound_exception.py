from nat_refactor.exceptions.base_exception import NAT


class FileNotFoundException(NAT):
    def __init__(self, message):
        super(FileNotFoundException, self).__init__(message)


class UserSignupException(NAT):
    def __init__(self, message):
        super(UserSignupException, self).__init__(message)



