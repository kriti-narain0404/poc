from nat_refactor.exceptions.base_exception import NAT


class DBConfigException(NAT):
    def __init__(self, message):
        super(DBConfigException, self).__init__(message)

class InsertTableException(NAT):
    def __init__(self, message):
        super(InsertTableException, self).__init__(message)

class SelectTableException(NAT):
    def __init__(self, message):
        super(SelectTableException, self).__init__(message)

class UpdateTableException(NAT):
    def __init__(self, message):
        super(UpdateTableException, self).__init__(message)