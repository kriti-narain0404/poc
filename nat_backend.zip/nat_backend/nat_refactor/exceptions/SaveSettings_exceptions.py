from nat_refactor.exceptions.base_exception import NAT


class FlagUpdateException(NAT):
    def __init__(self, message):
        super(FlagUpdateException, self).__init__(message)

