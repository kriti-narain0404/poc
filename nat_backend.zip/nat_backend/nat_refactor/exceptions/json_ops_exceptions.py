from nat_refactor.exceptions.base_exception import NAT


class JSONFileWriteException(NAT):
    def __init__(self, message):
        super(JSONFileWriteException, self).__init__(message)
