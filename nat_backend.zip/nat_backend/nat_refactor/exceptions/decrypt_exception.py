from nat_refactor.exceptions.base_exception import NAT


class DecryptException(NAT):
    def __init__(self, message):
        super(DecryptException, self).__init__(message)