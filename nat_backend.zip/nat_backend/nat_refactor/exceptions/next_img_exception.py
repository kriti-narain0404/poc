from nat_refactor.exceptions.base_exception import NAT


class NoImagesFound(NAT):
    def __init__(self, message):
        super(NoImagesFound, self).__init__(message)


class ImageFileError(NAT):
    def __init__(self, message):
        super(ImageFileError, self).__init__(message)



