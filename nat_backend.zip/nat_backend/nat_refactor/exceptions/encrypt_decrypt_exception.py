from nat_refactor.exceptions.base_exception import NAT


class InvalidValue(NAT):
    def __init__(self, message):
        super(InvalidValue, self).__init__(message)


class EncryptException(NAT):
    def __init__(self, message):
        super(EncryptException, self).__init__(message)