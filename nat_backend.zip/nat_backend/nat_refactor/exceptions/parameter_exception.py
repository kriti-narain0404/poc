from nat_refactor.exceptions.base_exception import NAT

class ParameterNotFound(NAT):
    def __init__(self, message):
        super(ParameterNotFound, self).__init__(message)