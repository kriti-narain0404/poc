"""
Author:
File usage: This file contains all the database queries.
Created-Date: 20/01/2022
Updated-Date: 
NoesisAutoTagAI Copyright @HCL-2021
"""


class DbQueries(object):
    """
    Description : This class contains all the DB_Queries which will be executed 
    """

    DASHBOARD_FETCH_DATA = "SELECT {required_feilds} FROM transaction_table_dashboard"\
     " WHERE user_id='{uid}' AND project_id='{pid}' AND date='{today_date}'"
    PROJECT_ID = "SELECT project_id FROM video WHERE id='{vid}'"
    CLASS_NAMES_WITH_ID = "SELECT ID, Class_Name FROM annotation_classes where Project_ID='{pid}'"
    INSERT = "INSERT INTO {table_name}{table_columns} VALUES "
    UPDATE = "Update {table_name} set {data} where {condition}"
    SELECT_QUERY = "SELECT {0} from {1} where {2}"
