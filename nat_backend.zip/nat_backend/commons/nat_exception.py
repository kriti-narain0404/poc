'''
 Custom Exception class
'''

from utils.logger import Logger
logger = Logger.get_logger()


class NatException(BaseException):
    def __init__():
        pass

class Authentication(NatException):
    pass

class NatMutationTokenError(NatException):
     logger.error('Token is not valid or expired...')
     pass
