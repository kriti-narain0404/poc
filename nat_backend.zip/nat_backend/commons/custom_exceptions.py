import commons.constants as cons

exception_errors = {
    'VideoFileNotFoundError': cons.ERROR_VIDEO_FILE_NOT_FOUND,
    'ImageFileNotFoundError': cons.ERROR_IMG_FILE_NOT_FOUND,
    'FileNotFoundError': cons.ERROR_FILE_NOT_FOUND,
    'InvalidFileError': cons.ERROR_INVALID_FILE,

    'ApplicationConfigError': cons.ERROR_APPLICATION_CONFIG,

    'NatServerBadRequestError': cons.ERROR_NAT_SERVER_BAD_REQUEST,
    'NatInternalServerError': cons.ERROR_NAT_INTERNAL_SERVER,
    'NatServiceUnavailableError': cons.ERROR_NAT_SERVICE_UNAVAILABLE,
    'DependentModelNotFoundError': cons.ERROR_DEPENDENT_MODEL_NOT_FOUND,
    'LoadModelNotFoundError': cons.ERROR_LOAD_MODEL_NOT_FOUND,
    'CreateObjectLabelDetection': cons.ERROR_CREATE_OBJECT_LABEL_DETECTION,
    'ObjectDetectionLabelError':  cons.ERROR_OBJECT_LABEL_DETECTION,
    'UserNotFoundError': cons.ERROR_USER_NOT_EXIST,
    'NatInfoNotFoundError': cons.ERROR_NAT_INFO_NOT_FOUND,
    'NatDatabaseError': cons.ERROR_NAT_DATABASE,
    'NatError': cons.ERROR_NAT

}


class CustomException(Exception):

    def __init__(self, msg=None, status=None):
        classname = self.__class__.__name__
        if msg is None:
            msg = exception_errors[classname]['message']
        if status is None:
            status = exception_errors[classname]['status']
        self.status_message = msg
        self.status_code = status
        Exception.__init__(self)


class VideoFileNotFoundError(CustomException):
    """It is custom exception to notify if Video File not found """
    pass


class ImageFileNotFoundError(CustomException):
    """It is custom exception to notify if Image File not found"""
    pass


class FileNotFoundError(CustomException):
    """It is custom exception to notify if File not found"""
    pass


class InvalidFileError(CustomException):
    """It is custom exception to notify if Invalid file"""
    pass


class ApplicationConfigError(CustomException):
    """It is custom exception to notify if Config file has error"""
    pass


class NatServerBadRequestError(CustomException):
    """It is custom exception to notify if Nat Server Bad request error"""
    pass


class NatInternalServerError(CustomException):
    """It is custom exception to notify if Nat Internal server Error"""
    pass


class NatServiceUnavailableError(CustomException):
    """It is custom exception to notify if Nat service unavailable Error"""
    pass


class DependentModelNotFoundError(CustomException):
    """It is custom exception to notify if Dependent Model not found"""
    pass


class LoadModelNotFoundError(CustomException):
    """It is custom exception to notify if Load model not found"""
    pass

class CreateObjectLabelDetectionError(CustomException):
    """It creates an exception while creating the object detection label"""
    pass

class ObjectDetectionLabelError(CustomException):
    """It creates an exception while detecting the """
    pass

class UserNotFoundError(CustomException):
  """ User does not exist"""
  pass

class NatInfoNotFoundError(CustomException):
  """ Nat File Not Found"""
  pass

class NatDatabaseError(CustomException):
  """ Nat Database Error"""
  pass

class NatError(CustomException):
  """ This is the custom exception for every function where there is no other id found. """
  pass



