import os
import json
from controller.nat_config_controller import NATConfigController
from utils.settings_utils import SettingsUtils

config_obj = NATConfigController.read_config()

class Config(object):
    BASE_DIR = os.path.abspath(os.path.dirname(__file__))

#CONSTANTS VARIABLES

BASE_PATH =''
PROJECT_PATH =''
AUTOMATION_PATH = ''
MEDIA_PATH = ''
JSON_PATH = ''
PROJECT_NAME = 'noesis_data'

project_path = SettingsUtils.get_value_by_key(SettingsUtils.KEY_DATAPATH)

# TODO: TEMPORARY FIX
if project_path is None:
    project_path = '/opt/NAT/upload/noesis_data/'
BASE_PATH = os.path.dirname(os.path.abspath(project_path))

PROJECT_PATH = os.path.join(BASE_PATH, PROJECT_NAME)
AUTOMATION_PATH = os.path.join(BASE_PATH, PROJECT_NAME)
MEDIA_PATH = os.path.join(project_path, 'images')
JSON_PATH = os.path.join(BASE_PATH, PROJECT_NAME, 'test_video', 'json')

mysql_db = None 

PROJECT_LABELS = []
filter = "JSON file (*.json)|*.json|All Files (*.*)|*.*||"

imageIdConfig = ""

METRICS_FNAME = 'metrics.json'
FOLD_FNAME = 'labels.json'
PREDS_FNAME = 'predictions.json'
RANKINGS_FNAME = 'rankings.csv'
LABEL_FNAME = 'automation.json'

TRAIN = 'trn'
VAL = 'val'
TEST = 'tst'
UNLABELED = 'unlabeled'
IMG_EXT = '.jpg'
IMG = 'img'

IMG_EXT_JPG = '.jpg'
IMG_EXT_PNG = '.png'
IMG_EXT_JPG1 = '.JPG'
IMG_EXT_PNG1 = '.PNG'
IMG_EXT_jpeg = '.jpeg'
IMG_EXT_JPEG = '.JPEG'

DEFAULT_WIDTH = 300
DEFAULT_HEIGHT = 300
BATCH_SIZE = 12
VAL_FOLD_RATIO = 0.2

ROLE_ADMIN = 'ADMIN'
ROLE_VALIDATOR = 'VALIDATOR'
ROLE_ANNOTATOR = 'ANNOTATOR'

os.environ['ENV']=config_obj.get('DEFAULT','ENVIRONMENT')             

IMG_ENDPOINT = config_obj.get(os.environ.get('ENV'),'IP_ADDRESS') + '/img'
VIDEO_ENDPOINT = config_obj.get(os.environ.get('ENV'),'IP_ADDRESS') + '/video'

SECRET_KEY = 'jIL7dg!%As</ZQ/`Nvk=@.uG550%)m'
BURNDOWN_FOLDER = 'data_burndown'
BURNDOWN_CSV_DATA = ['date', 'count1', 'count2']

class PossibleExtensions:
    POSSIBLE_IMAGE_EXTENSIONS = [IMG_EXT_PNG, IMG_EXT_PNG1, IMG_EXT_JPEG, IMG_EXT_jpeg, IMG_EXT_JPG1, IMG_EXT_JPG]
    POSSIBLE_IMAGE_EXTENSIONS_3D = ["*.jpg", "*.jpeg", "*.JPG", "*.JPEG", "*.png", "*.PNG"]
    JSON_EXT = ['.json']
    JSON_EXT_3D = ['*.json']
    PCD_EXT_3D = ['*.pcd']

class JsonLoadConfig3DConstanst:
    FOLDER_NAME = "3D_Data"

class ErrorCodes():
     FILE_NOT_FOUND = -4001
     INVALID_FILE = -4002

     MODEL_FILES_NOT_FOUND = -5001
     MODEL_LODING = -5002
    
class Errors():
    ERROR_FILE_NOT_FOUND = {'message': 'FILE NOT FOUND','status': ErrorCodes.FILE_NOT_FOUND}
    ERROR_INVALID_FILE = {'message': 'INVALID FIEL','status': ErrorCodes.INVALID_FILE}

    ERROR_MODEL_FILE_NOT_FOUND = {'message': 'MODEL FILES NOT FOUND',\
                                'status': ErrorCodes.MODEL_FILES_NOT_FOUND}
    ERROR_MODEL_LODING = {'message': 'ERROR IN MODEL LOADING',\
                                'status': ErrorCodes.MODEL_LODING} 
class ConstantsDashboard:
    key_for_annotation_dict = ['label', 'bbox', 'parameters']
    csv_header = ["Created_datetime(YYYYMMDD-HHMMSS)", "Modified_datetime(YYYYMMDD-HHMMSS)",
                  "Json_Name", "Edit_count", "Count_of_annotations", "Count_of_annotation_added",
                  "Count_of_annotation_deleted", "Count_of_coord/points_updated", "Count_of_label_updated",
                  "Count_of_parameter_updated", "Annotation","Pre-annotated"]
    project_csv_header = ["Created_datetime(YYYYMMDD-HHMMSS)", "Modified_datetime(YYYYMMDD-HHMMSS)", "Video_Name",	"Video_Id",	"Assigned_User_Id",	"Assigned_User_Name", "Edit_count", "Count_of_annotations", "Count_of_annotation_added", "Count_of_annotation_deleted", "Count_of_coord/points_updated", "Count_of_label_updated", "Count_of_parameter_updated", "Validator_name"]
    accuracy_csv_header = ["video_name", "object_detection_accuracy", "object_edited_count", "object_deletion_count", "object_loc_accuracy"]
    JSON_FOLDER_NAME = "/json"
    CSV_FOLDER_NAME = "/csv"
    NP_DUMP_NAME = "/np_dump"
    CSV_NAME = "/data.csv"
    PROJ_CSV_NAME = "/compiled_proj.csv"
    DATA_ACCURACY_FOLDER = "data_accuracy"
    DATA_PRODUCTIVITY_FOLDER = "data_productivity"
    DASHBOARD_KEYS = ["editlabel_m", "editcoord_m", "editparam_m", "editlabel_a", "editcoord_a", "editparam_a", "interpolated", "added_m", "added_a", "deleted_a", "deleted_m", "class_id"]
    FETCH_CONDITION_1 = "CAST(sum(a.editlabel_m)+sum(a.editcoord_m)+sum(a.editparam_m)+sum(editlabel_a)+sum(editcoord_a)+sum(editparam_a) as SIGNED) AS modify, CAST(sum(deleted_a)+sum(deleted_m) as SIGNED) as deleted, CAST(sum(added_m) as SIGNED) as added, CAST(a.date as CHAR) as date, u.login as username"
    FETCH_CONDITION_2 = "archived_transaction_table_dashboard a left join nat_user u on u.id=a.user_id"
    FETCH_CONDITION_3 = "project_id='{0}' AND date BETWEEN '{1}' AND '{2}' group by date, user_id"
    CLASS_DATA_COLUMNS = "model_date, process_for_transaction_table, automation_class_Data"
    VIDEO_PROCESSED_FLAG = "process_for_transaction_table"
    AUTOMATION_RESULTS = "automation_class_Data"
    DATE_OF_MODEL = "model_date"
    PROCESSED_VIDEO_FLAG = 1
    ACC_FETCH_0 = "CAST(sum(a.editlabel_a) + sum(a.deleted_a) as SIGNED) as wrong_classifications, CAST(sum(a.editcoord_a) as SIGNED) as wrong_coordinates, CAST(sum(a.added_a) as SIGNED) as total_detections, CAST(a.model_date as CHAR) as date, c.Class_Name as class_name"
    ACC_FETCH_1 = "transaction_table_dashboard a left join annotation_classes c on c.ID=a.class_id"
    ACC_FETCH_2 = "a.video_id IN(Select id from video where project_id='{}' AND submitted=1) AND model_date BETWEEN '{}' AND '{}' AND model_date IS NOT NULL group by model_date, class_id"
    GROUPBY = "date"
    DISPLAY_DATA_CLASS_KEY = "class_data"
    DISPLAY_DATA_MODEL_KEY = "model_data"
# Status Code
STATUS_200 = 200 # OK
STATUS_400 = 400 # BAD REQUEST
STATUS_404 = 404 # NOT FOUND
STATUS_415 = 415 # UNSUPPORTED MEDIA TYPE
STATUS_500 = 500 # INTERNAL SERVER ERROR
STATUS_503 = 503 # SERVICE UNAVAILABLE
STATUS_401 = 401 # USER DOES NOT EXIST AUTHENTICATION ERROR

# Custom error messages

ERROR_VIDEO_FILE_NOT_FOUND = { "message": "VIDEO FILE NOT FOUND",
                              "status": STATUS_404 }
ERROR_IMG_FILE_NOT_FOUND = { "message": "IMG FILE NOT FOUND",
                            "status": STATUS_404 }
ERROR_FILE_NOT_FOUND = {"message": "FILE NOT FOUND",
                        "status": STATUS_404}

ERROR_INVALID_FILE = { "message": "INVALID FILE TYPE ERROR",
                      "status": STATUS_415}

ERROR_APPLICATION_CONFIG = { "message": "APPLICATION CONFIG ERROR",
                            "status": STATUS_500}

ERROR_NAT_SERVER_BAD_REQUEST = { "message": "NAT SERVER BAD REQUEST",
                                "status": STATUS_400}
ERROR_NAT_INTERNAL_SERVER = { "message": "NAT INTERNAL SERVER",
                             "status": STATUS_500}
ERROR_NAT_SERVICE_UNAVAILABLE = { "message": "NAT SERVICE UNAVAILABLE",
                                 "status": STATUS_503}

ERROR_DEPENDENT_MODEL_NOT_FOUND = { "message": "DEPENDENT MODEL NOT FOUND",
                                   "status": STATUS_404}
ERROR_LOAD_MODEL_NOT_FOUND = { "message": "LOAD MODEL NOT FOUND",
                              "status": STATUS_404}

ERROR_CREATE_OBJECT_LABEL_DETECTION = {"message": "ERROR WHILE CREATING OBJECT LABEL DETECTION",
                                       "status":STATUS_500}

ERROR_OBJECT_LABEL_DETECTION = {"message": "ERROR WHILE  OBJECT LABEL DETECTION",
                                       "status":STATUS_500}

ERROR_USER_NOT_EXIST = {"message": "USER DOES NOT EXIST", "status": STATUS_401}

ERROR_NAT_INFO_NOT_FOUND = {'message': 'NAT INFORMATION NOT FOUND',
                        'status': STATUS_400}

ERROR_IMAGE_ID_NOT_FOUND = 'IMAGE ID NOT FOUND'
ERROR_VIDEO_ID_NOT_FOUND = 'VIDEO ID NOT FOUND'
ERROR_NAT_DATABASE = {"message" : "DATABASE ERROR", 'status': STATUS_500}
ERROR_NAT = {"message" : "nat error" , 'status' : STATUS_500}

ERROR_LIST = ["FileNotFoundError", "TypeError", "AttributeError", 
"FileExistsError", "InterruptedError", "PermissionError", "ProcessLookupError", 
"TimeoutError", "SystemError", "MemoryError", "ExpiredSignatureError", 
"DecodeError", "UnboundLocalError","DbConfigError","DBConnectError","FetchFolderPathError",
"GetVideoNameError","JsonLoadConfigError","SaveJsonFileError","UIViewerUtilsError"]

#Login activity HOURS
TIME_DIFFERENCE_1 = 24
TIME_DIFFERENCE_2 = 8

#3D-2D Json Structure Constants
class Json_Constants:
    KEY_IMG = "img"
    KEY_ANNOTATIONS = "annotations"
    KEY_BBOX3D = "bbox3d"
    KEY_DIMENSIONS = "dimension"
    KEY_ORIENTATION = "orientation"
    KEY_LOCATION = "location"
    KEY_LABELS = "labels"
    KEY_PARAMETERS = "parameters"
    KEY_TRACK = "track"

SELECT_ALL = "*"
class PipelineSettings:
    TABLENAME = "pipeline_settings"
    CONDITION = "projectId = {} ORDER BY date DESC LIMIT 1"
    NOT_REQUIRED_KEYS = ["Date", "id"]
    FIRST_ELEMENT = 0
    USER_ID = 'userId'
    PROJECT_ID = 'projectId'
    SCHEDULER_TYPE = 'schedulerType'
    SOURCE_BUCKET= 'sourceBucket'
    SOURCE_PATH = 'sourcePath'
    DESTINATION_BUCKET = 'destBucket'
    DESTINATION_PATH = 'destPath'
    PROJECT_NAME = 'projectName'
    DIVISON_TYPE = 'divisonType'
    DAYS_REQUIRED = 'daysRequired'
    AVGOBJPERFRAME = 'avgObjectPerFrame'
    ANNO_AVAIL = 'annotatorsAvailable'
    RATIO = 'ratio'
    DAYS_AVAIL = 'daysAvailable'
    PRODUCTIVITY = 'productivity'
    FRAME_COUNT = 'frameCount'
    ANNO_REQ = 'annotatorRequired'
    VAL_AVAIL = 'validatorAvailable'
    CONVERSIONSCRIPT = 'conversionScript'
    TIME = 'time'
    FREQUENCY = 'frequency'
    FILETYPE = 'fileType'
    PIPELINE_SEQ = 'pipelineSequence'
    STATUS = 'status'

# Constants for data pipeline acknowledgement
class Ack_data_pipeline_constants:
    PROJECT_ID = "project_id"
    AVAILABLE_STATUS = "AVAILABLE"
    DP_COMPONENT_STATUS = "data_pipeline_component_state"
    NOT_RUNNING_STATUS = "NR"
    RUNNING_STATUS = "RUNNING"
    DP_COMPONENT_AVAILABILITY = "DPComponent_Availability"
    COMPONENT_RUNNING_STATUS = "components_running_status"
    SELECT_ALL_SYMBOL = "*"
    SELECT_QUERY_CONDITION = " = {3}"
    TRUE_STATUS = True
    FALSE_STATUS = False
    INITIALIZE_NONE = None
