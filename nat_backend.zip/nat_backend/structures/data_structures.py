from collections import namedtuple, OrderedDict

Image = namedtuple('Image', 'id project src thumbnail thumbnailWidth thumbnailHeight \
                            tags caption modelTags modelProbs')
Metrics = namedtuple('Metrics', 'accuracy loss counts')
Counts = namedtuple('Counts', 'trn val tst unlabeled')
ImageList = namedtuple('ImageList', 'images')
Point = namedtuple('Point', 'id x y')
Param = namedtuple('Param', 'nam val')
Annotation = namedtuple('Annotation', 'id label bbox polygon')
BoundingBox = namedtuple(
    'BoundingBox', 'id annoId track label fill opacity score ratio xmin ymin xmax ymax points parameters')
Polygon = namedtuple('Polygon', 'id annoId track label fill opacity score look points parameters')
ObjDetectImage = namedtuple(
    'ObjDetectImage', 'id project videopath videoid annos_json')
Annotator = namedtuple('Annotator', 'status_1 status_2 username editmode role')
Validator = namedtuple('Validator', 'status_1 status_2 username editmode role annotators')
UserList = namedtuple('UserList', 'project project_id projectEditmode username editmode role validators changed')
WorkDiv = namedtuple('WorkDiv', 'userid projectid sourcebucket sourcepath'
                                ' destBucket destpath projectType divisionType'
                                ' requiredays avgFrame availannotator annoratio'
                                ' availdays productivity totalFrame requireannotator'
                                ' availvalidator conversionScript time frequency filetype pipelineseq status')
ObjUserList = namedtuple('ObjUserList', 'userList workDiv')
ObjDetectLabelOpts = namedtuple('ObjDetectLabelOpts', 'labels')
ColorLabel = namedtuple('ColorLabel', 'value text color')
SettingData = namedtuple('SettingData', 'id name selected type color length')
SettingDataInput = namedtuple(
    'SettingDataInput', 'id name selected type color length')
SettingObject = namedtuple(
    'SettingObject', 'settingObject predType modelType outputFormat folderPath minHeight minWidth annoTip classData interpolate_data')
ObjVideoImage = namedtuple(
    'ObjVideoImage', 'id is_blur_mode_active project videoname src imageId videoId videopath imagecount annotations labels orientation annos_json video_type width height')
ObjTextModeration = namedtuple('ObjTextModeration', 'id videoname annos text fileId videoId video_type')

FloodFillPoint = namedtuple('FloodFillPoint', 'x y')
StartTime = namedtuple('StartTime', 'hh mm ss')
EndTime = namedtuple('EndTime', 'hh mm ss')

TimeStamp = namedtuple('TimeStamp', 'eventtype starttime endtime')

ImgProc = namedtuple('ImgProc', 'points')

ObjUploadVideo = namedtuple('ObjUploadVideo', 'videoname videopath lastfolder')
ObjVideoAssigne = namedtuple(
    'ObjVideoAssigne', 'videoid assignuserid videoname')
ObjVideoProcessed = namedtuple('ObjVideoProcessed', 'videoid')

ObjVideoDelete = namedtuple('ObjVideoDelete', 'videoid')
UserId = namedtuple('UserId', 'userId')
ObjLoginUser = namedtuple('ObjLoginUser', 'username role userid activated last_project access_token auth_pin')
ObjSecret = namedtuple('ObjSecret', 'secret qr')
ObjUser = namedtuple('ObjLoginUser', 'username role userid first_name last_name mobile_number newuser auto_captcha user_captcha')
ObjAssignList = namedtuple('ObjAssignList', 'username role userid activated last_project')
Video = namedtuple(
    'Video', 'videoid videoname assigneuserid assigned processed submitted videodate validatorassignid annotatorusername'
             ' validatorusername no_frames no_labeljsons video_type')
ObjVideo = namedtuple('ObjVideo', 'last_project videos')

ObjVideoDetails = namedtuple(
    'ObjVideoDetails', 'videoid videoname videourl videopath imageid imagecount')

ObjPreviewVideoDetails = namedtuple(
    'ObjPreviewVideoDetails', 'videoid videoname videourl total_duration timestamp')

ObjImage = namedtuple('ObjImage', 'images jsons')

ObjImageDetails = namedtuple(
    'ObjImageDetails', 'imageid imagename videoid metricspath')

ObjMetrics = namedtuple('ObjMetrics', 'videoid metricspath')

ObjImageId = namedtuple(
    'ObjImageId', 'videoid metricspath imagename accuracyval editval updatedval locaccval')

ObjNotification = namedtuple('ObjNotification', 'count msg')
ObjModifiedFilesCount = namedtuple('ObjModifiedFilesCount', 'videopath')
ObjVideoPush = namedtuple('ObjVideoPush', 'videoids count')
MetricsParameterObject = namedtuple('MetricsParameterObject', 'label value')
MetricsParameter = namedtuple(
    'MetricsParameter', 'object_detection_accuracy object_deletion_count object_edited_count object_loc_accuracy')
MetricsParameterFrames = namedtuple('MetricsParameterFrames', 'metrics label')
MetricsParameterVideo = namedtuple(
    'MetricsParameterVideo', 'metrics label frames')
MetricsData = namedtuple('MetricsData', 'metrics videos')
ObjUserAssignationList = namedtuple('ObjUserAssignationList', 'users')
ScriptList = namedtuple('ScriptList', ' scriptname flag')
ObjScriptList = namedtuple('ObjScriptList', 'scriptList')
ObjReport = namedtuple('ObjReport', 'text')
NotificationCount = namedtuple('NotificationCount', 'notificationcount')
ObjFramesDetails = namedtuple('ObjFramesDetails', 'path frames_count json_count scripts_list conversion_scripts')
ObjResponse = namedtuple('ObjResponse', 'status')
ProductivityResponse = namedtuple('ProductivityResponse', 'productivity_data')
ObjAnnotation = namedtuple('ObjAnnotation', 'annos_json')
ObjMaskImage = namedtuple('ObjMaskImage', 'imageId imagename videoname src encoded_string imagecount')
Project = namedtuple('Project', 'project_id project_name')
ObjProject = namedtuple('ObjProject', 'projects')
ObjUserQue = namedtuple('ObjUserQue','question answer')
ObjAcknowledge = namedtuple('ObjAcknowledge', 'acknowledge')
ObjPipelineSettings = namedtuple('PipelineData', 'pipeline_data')
