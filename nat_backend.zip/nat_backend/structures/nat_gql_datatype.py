from graphql import (
    GraphQLField, GraphQLNonNull, GraphQLArgument,
    GraphQLObjectType, GraphQLList, GraphQLBoolean, GraphQLString,
    GraphQLSchema, GraphQLInt, GraphQLFloat, GraphQLInputObjectType,
    GraphQLInputObjectField
)
from graphql.type.definition import GraphQLInputObjectField


class NatGQLDataTypes(object):
    PointType = GraphQLObjectType(
        name='Point',
        fields={
            'id': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),
            'x': GraphQLField(
                GraphQLNonNull(GraphQLFloat),
            ),
            'y': GraphQLField(
                GraphQLNonNull(GraphQLFloat),
            )
        }
    )

    ObjImageIdType = GraphQLObjectType(
        name='ObjImageId',
        fields={
            'videoid': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),
            'metricspath': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),
            'imagename': GraphQLField(
                GraphQLList(GraphQLString),
            ),
            'accuracyval': GraphQLField(
                GraphQLList(GraphQLInt),
            ),
            'editval': GraphQLField(
                GraphQLList(GraphQLInt),
            ),
            'updatedval': GraphQLField(
                GraphQLList(GraphQLInt),
            ),
            'locaccval': GraphQLField(
                GraphQLList(GraphQLInt),
            )

        }
    )

    MetricsParameterObjectType = GraphQLObjectType(
        name='MetricsParameterObject',
        fields={
            'label': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),
            'value': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),
        }
    )

    MetricsParameterType = GraphQLObjectType(
        name='MetricsParameter',
        fields={
            'object_detection_accuracy': GraphQLField(
                GraphQLList(MetricsParameterObjectType),
            ),
            'object_deletion_count': GraphQLField(
                GraphQLList(MetricsParameterObjectType),
            ),
            'object_edited_count': GraphQLField(
                GraphQLList(MetricsParameterObjectType),
            ),
            'object_loc_accuracy': GraphQLField(
                GraphQLList(MetricsParameterObjectType),
            ),
        }
    )

    MetricsParameterFramesType = GraphQLObjectType(
        name='MetricsParameterFrames',
        fields={
            'metrics': GraphQLField(
                GraphQLNonNull(MetricsParameterType),
            ),
            'label': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),
        }
    )

    MetricsParameterVideoType = GraphQLObjectType(
        name='MetricsParameterVideo',
        fields={
            'metrics': GraphQLField(
                GraphQLNonNull(MetricsParameterType),
            ),
            'label': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),
            'frames': GraphQLField(
                GraphQLList(MetricsParameterFramesType),
            ),
        }
    )

    MetricsDataType = GraphQLObjectType(
        name='MetricsData',
        fields={
            'metrics': GraphQLField(
                GraphQLNonNull(MetricsParameterType),
            ),
            'videos': GraphQLField(
                GraphQLList(MetricsParameterVideoType),
            ),
        }
    )

    ParamType = GraphQLObjectType(
        name='Param',
        fields={
            'nam': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),
            'val': GraphQLField(GraphQLInt)
        }
    )
    ParamInputType = GraphQLInputObjectType(
        name='ParamInput',
        fields={
            'nam': GraphQLInputObjectField(
                GraphQLNonNull(GraphQLString),
            ),
            'val': GraphQLInputObjectField(GraphQLString
                                           )
        }
    )

    PointInputType = GraphQLInputObjectType(
        name='PointInput',
        fields={
            'id': GraphQLInputObjectField(
                GraphQLNonNull(GraphQLString),
            ),
            'x': GraphQLInputObjectField(
                GraphQLNonNull(GraphQLFloat),
            ),
            'y': GraphQLInputObjectField(
                GraphQLNonNull(GraphQLFloat),
            )
        }
    )

    StartTimeInputType = GraphQLInputObjectType(
        name='StartTimeInput',
        fields={
            'hh':GraphQLInputObjectField(GraphQLInt),
            'mm': GraphQLInputObjectField(GraphQLInt),
            'ss':GraphQLInputObjectField(GraphQLInt),
    })
    EndTimeInputType = GraphQLInputObjectType(
        name='EndTimeInput',
        fields={
            'hh':GraphQLInputObjectField(GraphQLInt),
            'mm': GraphQLInputObjectField(GraphQLInt),
            'ss': GraphQLInputObjectField(GraphQLInt),
    })
    ColorLabelType = GraphQLObjectType(
        name='ColorLabel',
        fields={
            'value': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),
            'text': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),
            'color': GraphQLField(
                GraphQLNonNull(GraphQLString),
            )
        }
    )

    BoundingBoxType = GraphQLObjectType(
        name='BoundingBox',
        fields={
            'id': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),
            'annoId': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),
            'track': GraphQLField(
                GraphQLNonNull(GraphQLBoolean),
            ),
            'label': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),
            'score': GraphQLField(
                GraphQLNonNull(GraphQLFloat),
            ),
            'ratio': GraphQLField(
                GraphQLNonNull(GraphQLFloat),
            ),
            'xmin': GraphQLField(
                GraphQLNonNull(GraphQLInt),
            ),
            'ymin': GraphQLField(
                GraphQLNonNull(GraphQLInt),
            ),
            'xmax': GraphQLField(
                GraphQLNonNull(GraphQLInt),
            ),
            'ymax': GraphQLField(
                GraphQLNonNull(GraphQLInt),
            ),
            'points': GraphQLField(
                GraphQLList(PointType),
            ),
            'parameters': GraphQLField(
                GraphQLList(ParamType),
            ),

        }
    )

    PolygonType = GraphQLObjectType(
        name='Polygon',
        fields={
            'id': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),
            'annoId': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),
            'track': GraphQLField(
                GraphQLNonNull(GraphQLBoolean),
            ),
            'label': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),
            'score': GraphQLField(
                GraphQLNonNull(GraphQLFloat),
            ),
            'look': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),
            'points': GraphQLField(
                GraphQLList(PointType),
            ),
            'parameters': GraphQLField(
                GraphQLList(ParamType),
            ),
        }
    )

    AnnotationType = GraphQLObjectType(
        name='Annotation',
        fields={
            'id': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),
            'label': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),
            'bbox': GraphQLField(
                BoundingBoxType
            ),
            'polygon': GraphQLField(
                PolygonType
            ),
        }
    )
    SubclassInputDataType = GraphQLInputObjectType(
        name='SubclassDataInput',
        fields={
            'color': GraphQLInputObjectField(
                GraphQLString,
            ),
            'id': GraphQLInputObjectField(
                GraphQLInt,
            ),
            'length': GraphQLInputObjectField(
                GraphQLInt,
            ),
            'name': GraphQLInputObjectField(
                GraphQLString,
            ),
            'selected': GraphQLInputObjectField(
                GraphQLBoolean,
            ),
            'type': GraphQLInputObjectField(
                GraphQLString,
            ),

        }
    )

    ParametersInputDataType = GraphQLInputObjectType(
        name='ParametersDataInput',
        fields={
            'color': GraphQLInputObjectField(
                GraphQLString,
            ),
            'id': GraphQLInputObjectField(
                GraphQLInt,
            ),
            'length': GraphQLInputObjectField(
                GraphQLInt,
            ),
            'name': GraphQLInputObjectField(
                GraphQLString,
            ),
            'subClass': GraphQLInputObjectField(
                GraphQLList(SubclassInputDataType),
            ),
            'selected': GraphQLInputObjectField(
                GraphQLBoolean,
            ),
            'type': GraphQLInputObjectField(
                GraphQLString,
            ),

        }
    )

    ClassAddedInputType = GraphQLInputObjectType(
        name='ClassAddedDataInput',
        fields={
            'name': GraphQLInputObjectField(
                GraphQLString)
        }
    )

    SettingDataInputType = GraphQLInputObjectType(
        name='SettingDataInput',
        fields={
            'id': GraphQLInputObjectField(
                GraphQLNonNull(GraphQLInt),
            ),
            'name': GraphQLInputObjectField(
                GraphQLNonNull(GraphQLString),
            ),
            'selected': GraphQLInputObjectField(
                GraphQLBoolean
            ),
            'type': GraphQLInputObjectField(
                GraphQLNonNull(GraphQLString)
            ),
            'color': GraphQLInputObjectField(
                GraphQLNonNull(GraphQLString)
              ),
            'length': GraphQLInputObjectField(
              GraphQLNonNull(GraphQLInt)
            ),
            'parameters': GraphQLInputObjectField(
                GraphQLList(ParametersInputDataType),
            )
        }
    )

    TimeStampInputType = GraphQLInputObjectType(
        name='TimeStampInput',
        fields={
            'eventtype': GraphQLInputObjectField(
                GraphQLNonNull(GraphQLString),
            ),
            'starttime': GraphQLInputObjectField(StartTimeInputType),
            'endtime': GraphQLInputObjectField(EndTimeInputType),
        }
    )
    SettingDataType = GraphQLObjectType(
        name='SettingData',
        fields={
            'id': GraphQLField(
                GraphQLNonNull(GraphQLInt),
            ),
            'name': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),
            'selected': GraphQLField(
                GraphQLBoolean
            ),
            'type': GraphQLField(
                GraphQLNonNull(GraphQLString)
            ),
            'color': GraphQLField(
                GraphQLNonNull(GraphQLString)
            ),
          'length': GraphQLField(
            GraphQLNonNull(GraphQLInt),
          ),
        }
    )
    SettingObjectType = GraphQLObjectType(
        name='SettingObject',
        fields={
            'predType': GraphQLField(
             (GraphQLString),
            ),
            'modelType': GraphQLField(
                (GraphQLString),
            ),
            'outputFormat': GraphQLField(
                (GraphQLString),
            ),
            'folderPath': GraphQLField(
                (GraphQLString),
            ),
            'minHeight': GraphQLField(
                (GraphQLInt),
            ),
            'minWidth': GraphQLField(
                (GraphQLInt),
            ),
            'annoTip': GraphQLField(
                (GraphQLString),
            ),
            'settingObject': GraphQLField(
                (GraphQLString)
            ),
            'classData': GraphQLField(
                GraphQLString
            ),
            'interpolate_data': GraphQLField(
                (GraphQLInt),
            ),
        }
    )

    BoundingBoxInputType = GraphQLInputObjectType(
        name='BoundingBoxInput',
        fields={
            'id': GraphQLInputObjectField(
             GraphQLNonNull(GraphQLString),
            ),
            'annoId': GraphQLInputObjectField(
                GraphQLNonNull(GraphQLString),
            ),
            'track': GraphQLInputObjectField(
                GraphQLNonNull(GraphQLBoolean),
            ),
            'label': GraphQLInputObjectField(
                GraphQLNonNull(GraphQLString),
            ),
            'fill': GraphQLInputObjectField(
                GraphQLNonNull(GraphQLString),
            ),
            'opacity': GraphQLInputObjectField(
                GraphQLNonNull(GraphQLString),
            ),
            'score': GraphQLInputObjectField(
                GraphQLNonNull(GraphQLFloat),
            ),
            'ratio': GraphQLInputObjectField(
                GraphQLNonNull(GraphQLFloat),
            ),
            'xmin': GraphQLInputObjectField(
                GraphQLNonNull(GraphQLInt),
            ),
            'ymin': GraphQLInputObjectField(
                GraphQLNonNull(GraphQLInt),
            ),
            'xmax': GraphQLInputObjectField(
                GraphQLNonNull(GraphQLInt),
            ),
            'ymax': GraphQLInputObjectField(
                GraphQLNonNull(GraphQLInt),
            ),
            'points': GraphQLInputObjectField(
                GraphQLList(PointInputType),
            ),
            'parameters': GraphQLInputObjectField(
                GraphQLList(ParamInputType),
            ),
        }
    )

    PolygonInputType = GraphQLInputObjectType(
        name='PolygonInput',
        fields={
            'id': GraphQLInputObjectField(
                GraphQLNonNull(GraphQLString),
            ),
            'annoId': GraphQLInputObjectField(
                GraphQLNonNull(GraphQLString),
            ),
            'track': GraphQLInputObjectField(
                GraphQLNonNull(GraphQLBoolean),
            ),
            'label': GraphQLInputObjectField(
                GraphQLNonNull(GraphQLString),
            ),
            'fill': GraphQLInputObjectField(
                GraphQLNonNull(GraphQLString),
            ),
            'opacity': GraphQLInputObjectField(
                GraphQLNonNull(GraphQLString),
            ),
            'score': GraphQLInputObjectField(
                GraphQLNonNull(GraphQLFloat),
            ),
            'look': GraphQLInputObjectField(
                GraphQLNonNull(GraphQLString),
            ),
            'points': GraphQLInputObjectField(
                GraphQLList(PointInputType),
            ),
            'parameters': GraphQLInputObjectField(
                GraphQLList(ParamInputType),
            ),
        }
    )

    ImageTagInputType = GraphQLInputObjectType(
        name='ImageTagInput',
        fields={
            'id': GraphQLInputObjectField(
             GraphQLNonNull(GraphQLString),
            ),
            'annoId': GraphQLInputObjectField(
                GraphQLNonNull(GraphQLString),
            ),
            'label': GraphQLInputObjectField(
                GraphQLNonNull(GraphQLString),
            ),
            'fill': GraphQLInputObjectField(
                GraphQLNonNull(GraphQLString),
            ),
            'opacity': GraphQLInputObjectField(
                GraphQLNonNull(GraphQLString),
            ),
            'x': GraphQLInputObjectField(
                GraphQLNonNull(GraphQLInt),
            ),
            'y': GraphQLInputObjectField(
                GraphQLNonNull(GraphQLInt),
            ),
            'parameters': GraphQLInputObjectField(
                GraphQLList(ParamInputType),
            ),
        }
    )

    AnnotationInputType = GraphQLInputObjectType(
        name='AnnotationInput',
        fields={
            'id': GraphQLInputObjectField(
                GraphQLNonNull(GraphQLString),
            ),
            'label': GraphQLInputObjectField(
                GraphQLNonNull(GraphQLString),
            ),
            'bbox': GraphQLInputObjectField(
                BoundingBoxInputType
            ),
            'polygon': GraphQLInputObjectField(
                PolygonInputType
            ),

            'imageTag': GraphQLInputObjectField(
                ImageTagInputType
            ),
        }
    )
    FloodFillPointType = GraphQLObjectType(
        name='FloodFillPoint',
        fields={
            'x': GraphQLField(
                GraphQLInt
            ),
            'y': GraphQLField(
                GraphQLInt
            )
        }
    )
    StartTimeType = GraphQLObjectType(
        name='StartTime',
        fields={
            'hh':GraphQLField(GraphQLInt),
            'mm': GraphQLField(GraphQLInt),
            'ss':GraphQLField(GraphQLInt),
    })
    EndTimeType = GraphQLObjectType(
        name='EndTime',
        fields={
            'hh':GraphQLField(GraphQLInt),
            'mm': GraphQLField(GraphQLInt),
            'ss': GraphQLField(GraphQLInt),
    })

    TimeStampType = GraphQLObjectType(
        name='TimeStamp',
        fields={
            'eventtype': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),
            'starttime': GraphQLField(StartTimeType),
            'endtime': GraphQLField(EndTimeType),
        }
    )

    ImgProcType = GraphQLObjectType(
        name='ImgProc',
        fields={
            'points': GraphQLField(
                GraphQLList(FloodFillPointType)
            )
        }
    )

    ObjVideoImageType = GraphQLObjectType(
        name='ObjVideoImage',
        fields={
            'id': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),
            'is_blur_mode_active': GraphQLField(
                GraphQLNonNull(GraphQLBoolean),
            ),
            'copy_mode': GraphQLField(
                GraphQLNonNull(GraphQLString)
            ),
            'project': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),
            'videoname': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),
            'src': GraphQLField(
                GraphQLString
            ),
            'imageId': GraphQLField(
                GraphQLInt
            ),
            'videoId': GraphQLField(
                GraphQLInt
            ),
            'videopath': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),
            'imagecount': GraphQLField(
                GraphQLInt
            ),
            'annotations': GraphQLField(
                GraphQLList(AnnotationType)
            ),
            'labels': GraphQLField(
                GraphQLList(ColorLabelType)
            ),
            'orientation': GraphQLField(
                GraphQLInt
            ),
            'annos_json': GraphQLField(
                GraphQLString
            ),
            'video_type': GraphQLField(
                GraphQLInt
            ),
            'width': GraphQLField(
                GraphQLInt
            ),
            'height': GraphQLField(
                GraphQLInt
            ),
        }
    )

    ObjTextModerationType = GraphQLObjectType(
        name='ObjTextModeration',
        fields={
            'id': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),
            'videoname': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),
            'text': GraphQLField(
                GraphQLString
            ),
            'annos': GraphQLField(
                GraphQLString
            ),
            'fileId': GraphQLField(
                GraphQLInt
            ),
            'videoId': GraphQLField(
                GraphQLInt
            ),
            'video_type': GraphQLField(
                GraphQLInt
            ),
        }
    )


    ObjDetectImageType = GraphQLObjectType(
        name='ObjDetectImage',
        fields={
            'id': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),
            'project': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),
            'videopath': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),
            'videoid': GraphQLField(
                GraphQLNonNull(GraphQLInt),
            ),
            'annos_json': GraphQLField(
                GraphQLString
            ),
        }
    )

    PolygonType = GraphQLObjectType(
        name='Polygon',
        fields={
            'id': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),
            'annoId': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),
            'label': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),
            'fill': GraphQLInputObjectField(
                GraphQLNonNull(GraphQLString),
            ),
            'score': GraphQLField(
                GraphQLNonNull(GraphQLFloat),
            ),
            'look': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),
            'points': GraphQLField(
                GraphQLList(PointType),
            ),
        }
    )

    annotatorType = GraphQLObjectType(
        name='Annotator',
        fields={
            'status_1': GraphQLField(GraphQLBoolean),
            'status_2': GraphQLField(GraphQLBoolean),
            'username': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),
            'editmode': GraphQLField(
                GraphQLBoolean
            ),
            'role': GraphQLField(
                GraphQLNonNull(GraphQLString),
            )
        }
    )

    ValidatorType = GraphQLObjectType(
        name='Validator',
        fields={
            'status_1': GraphQLField(GraphQLBoolean),
            'status_2': GraphQLField(GraphQLBoolean),
            'username': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),
            'editmode': GraphQLField(
                GraphQLBoolean
            ),
            'role': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),
            'annotators': GraphQLField(
                GraphQLList(annotatorType)
            )
        }
    )

    ScriptListType = GraphQLObjectType(
        name='ScriptList',
        fields={
            'scriptname': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),
            'flag': GraphQLField(
                GraphQLBoolean
            ),
        }
    )

    PipelineType = GraphQLObjectType(
        name='PipelineData',
        fields = {
            'pipeline_data': GraphQLField(GraphQLString)
        }
    )

    WorkDivType = GraphQLObjectType(
        name='WorkDiv',
        fields = {
            "userid": GraphQLField(GraphQLInt,),
            "projectid": GraphQLField(GraphQLInt,),
            "sourcebucket":GraphQLField(GraphQLString,),
            "sourcepath": GraphQLField(GraphQLString, ),
            "destBucket": GraphQLField(GraphQLString, ),
            "destpath": GraphQLField(GraphQLString, ),
            "projectType": GraphQLField(GraphQLString, ),
            "divisionType": GraphQLField(GraphQLString, ),
            "requiredays": GraphQLField(GraphQLInt, ),
            "avgFrame": GraphQLField(GraphQLInt, ),
            "availannotator": GraphQLField(GraphQLInt, ),
            "annoratio": GraphQLField(GraphQLInt, ),
            "availdays": GraphQLField(GraphQLInt, ),
            "productivity": GraphQLField(GraphQLInt, ),
            "totalFrame": GraphQLField(GraphQLInt, ),
            "requireannotator": GraphQLField(GraphQLInt, ),
            "availvalidator": GraphQLField(GraphQLInt, ),
            "conversionScript": GraphQLField(GraphQLString, ),
            "time": GraphQLField(GraphQLString, ),
            "frequency": GraphQLField(GraphQLString, ),
            "filetype": GraphQLField(GraphQLString, ),
            "pipelineseq": GraphQLField(GraphQLString, ),
            "status": GraphQLField(GraphQLString, ),
        }
    )
    UserListType = GraphQLObjectType(
        name='UserList',
        fields={
            'project': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),
            'project_id': GraphQLField(
                GraphQLNonNull(GraphQLInt),
            ),
            'projectEditmode': GraphQLField(
                GraphQLBoolean
            ),
            'username': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),
            'editmode': GraphQLField(
                GraphQLBoolean
            ),
             'role': GraphQLField(
               GraphQLNonNull(GraphQLString),
              ),

            'validators': GraphQLField(
                GraphQLList(ValidatorType)
            ),
            'changed': GraphQLField(
                GraphQLBoolean
            ),
        }
    )


    annotatorInputType = GraphQLInputObjectType(
        name='annotatorInput',
        fields={
            'username': GraphQLInputObjectField(
                GraphQLNonNull(GraphQLString),
            ),
            'editmode': GraphQLInputObjectField(
                GraphQLNonNull(GraphQLBoolean),
            ),
            'role': GraphQLInputObjectField(
                GraphQLNonNull(GraphQLString),
            ),
            'status24hr': GraphQLInputObjectField(GraphQLBoolean),
            'status8hr': GraphQLInputObjectField(GraphQLBoolean),
        }
    )

    ValidatorInputType = GraphQLInputObjectType(
        name='ValidatorInput',
        fields={
            'username': GraphQLInputObjectField(
                GraphQLNonNull(GraphQLString),
            ),
            'editmode': GraphQLInputObjectField(
                GraphQLNonNull(GraphQLBoolean),
            ),
            'role': GraphQLInputObjectField(
                GraphQLNonNull(GraphQLString),
            ),
            'annotators': GraphQLInputObjectField(
                GraphQLList(annotatorInputType)
            ),
            'status24hr': GraphQLInputObjectField(GraphQLBoolean),
            'status8hr': GraphQLInputObjectField(GraphQLBoolean),
        }
    )
    UserListInputType = GraphQLInputObjectType(
        name='UserListInput',
        fields={
            'project': GraphQLInputObjectField(
                GraphQLNonNull(GraphQLString),
            ),
            'project_id': GraphQLInputObjectField(
                GraphQLNonNull(GraphQLInt),
            ),
            'projectEditmode': GraphQLInputObjectField(
                GraphQLNonNull(GraphQLBoolean),
            ),
            'username': GraphQLInputObjectField(
                GraphQLNonNull(GraphQLString),
            ),
            'editmode': GraphQLInputObjectField(
                GraphQLNonNull(GraphQLBoolean),
            ),
            'validators': GraphQLInputObjectField(
                GraphQLList(ValidatorInputType)
            ),
            'role': GraphQLInputObjectField(
                GraphQLNonNull(GraphQLString),
            ),
            'changed': GraphQLInputObjectField(
                GraphQLNonNull(GraphQLBoolean),
            ),
        }
    )

    ObjUserListType = GraphQLObjectType(
        name='ObjUserList',
        fields={
            'userList': GraphQLField(
                GraphQLList(UserListType)
            ),
            'workDiv': GraphQLField(
              WorkDivType
            ),
            # 'id': GraphQLField(
            #   GraphQLNonNull(GraphQLInt)
            # ),
        }
    )

    UserIdType = GraphQLObjectType(
        name='UserId',
        fields={
            'userId': GraphQLField(
                GraphQLNonNull(GraphQLInt),
            ),
        }
    )
    ObjVideoAssigneType = GraphQLObjectType(
        name='ObjVideoAssigne',
        fields={
            'videoid': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),
            'assignuserid': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),
            'videoname': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),
        }
    )

    ObjVideoProcessedType = GraphQLObjectType(
        name='ObjVideoProcessed',
        fields={
            'videoid': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),

        }
    )

    ObjVideoDeleteType = GraphQLObjectType(
        name='ObjVideoDelete',
        fields={
            'videoid': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),

        }
    )

    ObjUploadVideoType = GraphQLObjectType(
        name='ObjUploadVideo',
        fields={

            'videopath': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),
        }
    )
    ObjNotificationType = GraphQLObjectType(
        name='ObjNotification',
        fields={
            'count': GraphQLField(
                GraphQLNonNull(GraphQLInt),
            ),
            'msg': GraphQLField(
                GraphQLString
            ),
            'status_code': GraphQLField(
                GraphQLInt
            ),
        }
    )

    ObjVideoPushType = GraphQLObjectType(
        name='ObjVideoPush',
        fields={
            'videoids': GraphQLField(
                GraphQLList(GraphQLInt),
            ),
            'count': GraphQLField(
                GraphQLNonNull(GraphQLInt),
            ),
        }
    )

    ObjModifiedFilesCountType = GraphQLObjectType(
        name='ObjModifiedFilesCount',
        fields={
            #TODO: remove this arg
            'videopath': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),
        }
    )
    UserInputType = GraphQLInputObjectType(
        name='UserInput',
        fields={
            'name': GraphQLInputObjectField(
                GraphQLNonNull(GraphQLString),
            ),
            'email': GraphQLInputObjectField(
                GraphQLNonNull(GraphQLString),
            ),
            'password': GraphQLInputObjectField(
                GraphQLNonNull(GraphQLString),
            ),
        }
    )


    CreateUserType = GraphQLObjectType(
        name='CreateUser',
        fields={
            'name': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),
            'email': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),
            'password': GraphQLField(
                GraphQLString
            ),
        }
    )

    ObjLoginUserType = GraphQLObjectType(
        name='ObjLoginUser',
        fields={
            'username': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),
            'userid': GraphQLField(
                GraphQLNonNull(GraphQLInt),
            ),
            'role': GraphQLField(
                GraphQLNonNull(GraphQLString)
            ),
            'activated': GraphQLField(
                GraphQLInt
            ),
            'last_project': GraphQLField(
                GraphQLInt
            ),
            'access_token': GraphQLField(
                GraphQLNonNull(GraphQLString)
            ),
            'auth_pin': GraphQLField(
                GraphQLString,
            ),
            'otp' : GraphQLField(
                GraphQLString,
            ),
            'secret' : GraphQLField(
                GraphQLInt,
            ),
        }
    )
    ObjSecretType = GraphQLObjectType(
        name='ObjSecret',
        fields={
            # 'username': GraphQLField(GraphQLString),
            'secret': GraphQLField(GraphQLString),
            'qr': GraphQLField(GraphQLString),
        }
    )
    ObjAssignListType = GraphQLObjectType(
        name='ObjAssignList',
        fields={
            'username': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),
            'userid': GraphQLField(
                GraphQLNonNull(GraphQLInt),
            ),
            'role': GraphQLField(
                GraphQLNonNull(GraphQLString)
            ),
            'activated': GraphQLField(
                GraphQLInt
            ),
            'last_project': GraphQLField(
                GraphQLInt
            ),
        }
    )

    ObjUserType = GraphQLObjectType(
        name='ObjUser',
        fields={
            'username': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),
            'userid': GraphQLField(
                GraphQLNonNull(GraphQLInt),
            ),
            'first_name': GraphQLField(
                GraphQLString,
            ),
            'last_name': GraphQLField(
                GraphQLString,
            ),
            'mobile_number': GraphQLField(
                GraphQLString,
            ),
            'role': GraphQLField(
                GraphQLNonNull(GraphQLString)
            ),
            'newuser': GraphQLField(
                GraphQLBoolean,
            ),
            'auto_captcha': GraphQLField(
                GraphQLInt,
            ),
            'user_captcha': GraphQLField(
                GraphQLInt,
            ),
        }
    )
    ObjUserTypeQue = GraphQLObjectType(
        name='ObjUserQue',
        fields={
            'question': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),
            'answer': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),
        }
    )
    ObjAcknowledgeType = GraphQLObjectType(
        name = 'ObjAcknowledge',
        fields = {
            'acknowledge':GraphQLField(
                GraphQLNonNull(GraphQLString),
            ), 
        }
    )
    ObjUserAssignationListType = GraphQLObjectType(
        name='ObjUserAssignationList',
        fields={
            'users': GraphQLField(
                GraphQLList(ObjAssignListType)
            )
        }
    )
    ImageType = GraphQLObjectType(
        name='Image',
        fields={
            'id': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),
            'project': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),
            'src': GraphQLField(
                GraphQLString
            ),
            'thumbnail': GraphQLField(
                GraphQLString
            ),
            'thumbnailWidth': GraphQLField(
                GraphQLInt
            ),
            'thumbnailHeight': GraphQLField(
                GraphQLInt
            ),
            'caption': GraphQLField(
                GraphQLString
            ),
            'tags': GraphQLField(
                GraphQLList(GraphQLString)
            ),
            'modelTags': GraphQLField(
                GraphQLList(GraphQLString)
            ),
            'modelProbs': GraphQLField(
                GraphQLList(GraphQLFloat)
            )
        }
    )

    CountsType = GraphQLObjectType(
        name='Counts',
        fields={
            'trn': GraphQLField(
                GraphQLNonNull(GraphQLInt),
            ),
            'val': GraphQLField(
                GraphQLNonNull(GraphQLInt),
            ),
            'tst': GraphQLField(
                GraphQLInt,
            ),
            'unlabeled': GraphQLField(
                GraphQLNonNull(GraphQLInt),
            )
        }
    )

    MetricsType = GraphQLObjectType(
        name='Metrics',
        fields={
            'accuracy': GraphQLField(
                GraphQLNonNull(GraphQLFloat),
            ),
            'loss': GraphQLField(
                GraphQLNonNull(GraphQLFloat),
            ),
            'counts': GraphQLField(
                CountsType
            ),
        }
    )

    ImageListType = GraphQLObjectType(
        name='ImageList',
        fields={
            'images': GraphQLField(
                GraphQLList(ImageType)
            ),
        }
    )

    ObjDetectLabelOptsType = GraphQLObjectType(
        name='ObjDetectLabelOpts',
        fields={
            'labels': GraphQLField(
                GraphQLList(ColorLabelType)
            ),
        }
    )

#############################################    

    ProjectType = GraphQLObjectType(
        name='Project',
        fields={
            'project_id': GraphQLField(
                GraphQLInt
            ),
            'project_name': GraphQLField(
                GraphQLString
            )
        }
    )

############################################
    VideoType = GraphQLObjectType(
        name='Video',
        fields={
            'videoid': GraphQLField(
                GraphQLInt
            ),
            'videoname': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),
            'assigneuserid': GraphQLField(
                GraphQLInt
            ),
            'assigned': GraphQLField(
                GraphQLBoolean
            ),
            'processed': GraphQLField(
                GraphQLBoolean
            ),
            'submitted': GraphQLField(
                GraphQLBoolean
            ),
            'videodate': GraphQLField(
                GraphQLString
            ),
            'validatorassignid': GraphQLField(
                GraphQLInt
            ),
            'annotatorusername': GraphQLField(
                GraphQLString
            ),
            'validatorusername': GraphQLField(
                GraphQLString
            ),
            'no_frames': GraphQLField(
                GraphQLInt
            ),
            'no_labeljsons': GraphQLField(
                GraphQLInt
            ),
            'video_type': GraphQLField(
                GraphQLInt
            ),
        }
    )
    ObjVideoType = GraphQLObjectType(
        name='ObjVideo',
        fields={
            'last_project': GraphQLField(
                GraphQLInt
            ),
            'videos': GraphQLField(
                GraphQLList(VideoType),
            ),

        }
    )
#################################

    ObjProjectType = GraphQLObjectType(
        name='ObjProject',
        fields={
            'projects': GraphQLField(
                GraphQLList(ProjectType),
            ),
        }
    )

#################################
    ObjVideoDetailsType = GraphQLObjectType(
        name='ObjVideoDetails',
        fields={

            'videoid': GraphQLField(
                GraphQLInt
            ),
            'videoname': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),
            'videourl': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),
            'videopath': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),
            'imageid': GraphQLField(
                GraphQLInt
            ),
            'imagecount': GraphQLField(
                GraphQLInt
            ),
        }
    )
    ObjPreviewVideoDetailsType = GraphQLObjectType(
        name='ObjPreviewVideoDetails',
        fields={

            'videoid': GraphQLField(
                GraphQLInt
            ),
            'videoname': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),
            'videourl': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),
            'total_duration': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),
            'timestamp': GraphQLField(
                GraphQLList(TimeStampType)
            ),
        }
    )

    ObjImageDetailsType = GraphQLObjectType(
        name='ObjImageDetails',
        fields={

            'imageid': GraphQLField(
                GraphQLInt
            ),
            'imagename': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),
            'videoid': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),
            'metricspath': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),
        }
    )

    ObjImageType = GraphQLObjectType(
        name='ObjImage',
        fields={
            'images': GraphQLField(
                GraphQLList(GraphQLString),
            ),
            'jsons': GraphQLField(
                GraphQLList(GraphQLString),
            ),

        }
    )

    ObjMetricsType = GraphQLObjectType(
        name='ObjMetrics',
        fields={

            'videoid': GraphQLField(
                GraphQLInt
            ),
            'metricspath': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),
        }
    )

    ImageMetricsType = GraphQLObjectType(
        name='ObjMetrics',
        fields={

            'created': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),
            'updated': GraphQLField(GraphQLFloat
                                    ),
            'accuracy': GraphQLField(GraphQLFloat
                                     ),
            'name': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),
            'edit': GraphQLField(GraphQLInt
                                 ),
            'videoid': GraphQLField(
                GraphQLInt
            )
        }
    )

    ScriptListInputType = GraphQLInputObjectType(
        name='ScriptDataInput',
        fields={
            'scriptname': GraphQLInputObjectField(
                GraphQLNonNull(GraphQLString),
            ),
            'flag': GraphQLInputObjectField(
                GraphQLNonNull(GraphQLBoolean),
            ),

        }
    )

    ObjscriptListType = GraphQLObjectType(
        name='ObjScriptList',
        fields={
            'scriptList': GraphQLField(
                GraphQLList(ScriptListType)
            ),
        }
    )
    # ObjReportType = GraphQLObjectType(
    # name='ObjReport',
    # fields={
    #     'text': GraphQLField(
    #       GraphQLString,
    #     )
    # }
    # )


    ObjReportType = GraphQLObjectType(
    name='ObjReport',
    fields={
        'text': GraphQLField(
          GraphQLString,
        )
    }
    )
    NotificationCountType = GraphQLObjectType(
    name='NotificationCount',
    fields={
        'notificationcount': GraphQLField(
          GraphQLString,
        )
    }
    )

    AcceptRejectVideoType = GraphQLObjectType(
    name='AccpetRejectVideo',
    fields={
        'userid': GraphQLField(
          GraphQLInt,
        ),
        'submitted': GraphQLField(
          GraphQLInt,
        ),
      'videoid': GraphQLField(
        GraphQLInt,
      )
    }
    )
    ObjFramesDetailsType = GraphQLObjectType(
    name='ObjFramesDetails',
    fields={
        'path': GraphQLField(
          GraphQLString,
        ),
        'frames_count': GraphQLField(
          GraphQLInt,
        ),
        'json_count': GraphQLField(
          GraphQLInt,
        ),
        'scripts_list': GraphQLField(
          GraphQLList(GraphQLString),
        ),
        'conversion_scripts': GraphQLField(
          GraphQLList(GraphQLString),
        )
      }
    )
    ObjResponseType = GraphQLObjectType(
    name='ObjResponse',
    fields={
        'status': GraphQLField(
          GraphQLBoolean,
        )
      }
    )

    ProductivityResponseType = GraphQLObjectType(
    name='ProductivityResponse',
    fields={
        'productivity_data': GraphQLField(
          GraphQLString,
        )
      }
    )

    ObjAnnotationType = GraphQLObjectType(
        name='ObjAnnotation',
        fields={

            'annos_json': GraphQLField(
                GraphQLString
            ),
        }
    )
    ObjMaskImageType = GraphQLObjectType(
        name='ObjMaskImage',
        fields={

            'imageId': GraphQLField(
                GraphQLNonNull(GraphQLInt)
            ),
            'imagename': GraphQLField(
                GraphQLString,
            ),
            'videoname': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),
            'src': GraphQLField(
                GraphQLString
            ),
            'encoded_string': GraphQLField(
                GraphQLNonNull(GraphQLString),
            ),
            'imagecount': GraphQLField(
                GraphQLInt
            ),
        }
    )
