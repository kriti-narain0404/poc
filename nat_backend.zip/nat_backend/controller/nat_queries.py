import os
import random

#from config.config import DatabaseConfig
from utils.image_utils import ImageUtils
from controller.nat_interface import NatInterface
from utils.metrics_utils import MetricsUtils
from utils.settings_utils import SettingsUtils
from structures.data_structures import *
from commons import constants as cfg
from dao.data import *
from utils.logger import Logger
from auth import (
    create_access_token,
    auth)
logger = Logger.get_logger()
from utils.dashboard import DashboardUtils
from graphql import GraphQLError
from utils.errors_utils import Error
from traceback import format_exc
from sys import exc_info
from nat_refactor.utils.database_ops import DbBase
from nat_refactor.Commons.Dashboard import Dashboard


class NatQuery(object):

    @staticmethod
    @auth
    def get_image_single(project, id_, dset=cfg.UNLABELED):
        logger.info("[Start]: get_image_single")
        try:
            fpath = Data.get_fpath(project, cfg.FOLD_FNAME)
            fold = Data.load_fold(fpath,'')
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: get_image_single")
        return ImageUtils.make_image(id_, fold, dset)

    @staticmethod
    @auth
    def get_default_obj_video_img(project, videoid, imageid,
                           dset=cfg.UNLABELED, include_preds=True):
        logger.info("[Start]: get_default_obj_video_img")
        videoPath= None
        imagecount = None
        files = None
        imageId = img= None

        try:

            cur = cfg.mysql_db.get_db().cursor()
            video_id = videoid
            image_id = imageid
            totalquery = ("SELECT * FROM demo_image where  video_id = %s")
            cur.execute(totalquery, video_id)
            result = list(cur.fetchall())
            imagecount = len(result)
            query = ("SELECT * FROM demo_image where  video_id = %s limit 1")
            cur.execute(query, video_id)
            result = list(cur.fetchone())
            imageId = result[0]
            path = cfg.BASE_PATH+'/'
            jsonFolder = "json";
            videoPath = result[5]
            fileName = result[2]
            files = os.path.splitext(fileName)[0]
            videoFolder = os.path.relpath(videoPath, path)
            mainPath = path + videoFolder + "/" + jsonFolder + "/"
            jsonfileName = files+".json"
            labeljsonfileName = files + "_label" + ".json"
            jsonfile = mainPath+files+".json"
            Data.init_dataset(cfg.PROJECT_NAME, videoPath, cfg.IMG_EXT, labeljsonfileName, imageid)
            img = Data.load_obj_detect_img(files, videoPath, jsonfileName,labeljsonfileName, include_preds)
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: get_default_obj_video_img")
        return NatInterface.make_obj_detect_image(files, project, img, imageId, video_id, videoPath,imagecount)



    @staticmethod
    @auth
    def get_next_obj_detect_img(project, currentId=None, dset=cfg.UNLABELED,
                            include_preds=True):
        logger.info("[Start]: get_next_obj_detect_img")
        image_name = None
        imagecount = None
        video_id = videoPath = img  = None
        ids= []
        try:

            annotate = []
            fold = Data.load_fold(project,'')
            ids = list(fold[dset].keys())
            random.shuffle(ids)
            img = Data.load_obj_detect_img(ids[0], project, include_preds)
            cur = cfg.mysql_db.get_db().cursor()

            video_id =0
            image_name = 1
            query = ("SELECT * FROM demo_image where video_id = %s limit 1")
            cur.execute(query, image_name)
            result = list(cur.fetchall())
            videoPath = ''
            totalquery = ("SELECT * FROM demo_image where  video_id = %s")
            cur.execute(totalquery, video_id)
            result = list(cur.fetchall())
            imagecount = 0
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: get_next_obj_detect_img")
        return NatInterface.make_obj_detect_image(ids[0], project, img,image_name,video_id,videoPath,imagecount)

    @staticmethod
    @auth
    def get_image_list(proj_name, dset=cfg.UNLABELED):
        logger.info("[Start]: get_image_list")
        image_data = None
        try:
            if os.path.exists(Data.get_fpath(proj_name, cfg.RANKINGS_FNAME)):
                image_data = NatInterface.get_ranked_batch(proj_name, dset)
            else:
                image_data = NatInterface.get_random_batch(
                proj_name, dset, shuffle=True)
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: get_image_list")
        return ImageList(images=image_data)

    @staticmethod
    @auth
    def get_obj_detect_label_opts(project):
        logger.info("[Start]: get_obj_detect_label_opts")
        logger.info("[Exit]: get_obj_detect_label_opts")
        return NatInterface.get_obj_detect_label_opts(project)

    @staticmethod
    @auth
    def get_setting_object(userid, projectid, fromFile, video_id):
        logger.info("[Start]: get_setting_object")
        response = None
        try:
            print("Starting for response")
            response_data, classes_to_be_entered, admin_only = SettingsUtils.get_response_updated(userid=userid, projectid=projectid)
            # classes_to_be_entered = ["lane", "car"]
            class_data = None
            if not admin_only and video_id > -1:
                try:
                    dashboard = Dashboard(userid, projectid, logger)
                    class_data = dashboard.insert_data_for_user(classes_to_be_entered, video_id)
                except Exception as e:
                    logger.error("Unable to update data for the user, traceback: {0}, \n error: {1}".format(format_exc(limit=1), e))
                    raise GraphQLError(f'Unable to update data for the user, {str(e)}')
            response = SettingObject(
                    annoTip=response_data[0],
                    folderPath=response_data[1],
                    minHeight=response_data[2],
                    minWidth=response_data[3],
                    modelType=response_data[4],
                    outputFormat=response_data[5],
                    predType=response_data[6],
                    settingObject=response_data[7],
                    classData=json.dumps(class_data),
                    interpolate_data=response_data[8]
                )
            # print("response",response)
        except Exception as error_obj:
            logger.error(error_obj)
        finally:
            DbBase.clean()
        logger.info("[Exit]: get_setting_object")
        return response


    @staticmethod
    @auth
    def get_modified_files_count():
        logger.info("[Start]: get_modified_files_count")
        response = None
        try:
            response = GitUtils.get_untracked_count()
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("Exit get_modified_files_count")
        return response

    @staticmethod
    @auth
    def get_metrics_details(videoid):
        response = True
        logger.info("[Start]: get_metrics_details")
        response = ObjResponse(
            status = response
        )
        logger.info("[Exit]: get_metrics_details")
        return response
