"""
Created on Wed Jun 18 17:30:40 2018
@author: HCL Technologies Ltd
"""
import os
from sys import platform
import configparser
from configparser import NoOptionError
from configparser import NoSectionError


class NATConfigController(object):
    """
    NATConfig is responsible for implementing to load the configuration file.
    """
    @staticmethod
    def read_config():
        """
            This method is responsible for creating a config object based upon
            config-parser and reading the configuration
        Return:
            Returns a configuration object based upon configparser.
        """
        config_obj = None
        try:
            config_obj = configparser.ConfigParser()
            if platform == "linux" or platform == "linux2":
              #config_obj.read(os.environ.get('NAT_CONFIG_PATH'))
              config_obj.read('config/nat_config.properties')
            elif platform == "win32":
              config_obj.read('config/nat_config_win.properties')
        except (NoSectionError, NoOptionError):
            raise NoSectionError
        return config_obj
