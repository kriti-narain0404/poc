import time
from cmath import pi
from traceback import extract_stack, format_exc
import os
import datetime
import requests
import json
from nat_refactor.Commons.AllImageJsonData import ImageJsonList
from nat_refactor.utils.database_ops import DbBase, DbConfig
from nat_refactor.Commons.Signup import SignUp
from nat_refactor.Commons.Next_img import NextImage
from nat_refactor.constants.global_data import GlobalData
from nat_refactor.Commons.Dashboard import Dashboard
from nat_refactor.Commons.SaveAnnotations import SaveAnnotations
from nat_refactor.Commons.TextModeration import TextModeration
# from nat_refactor.utils.database_ops import DbConfig
# from nat_refactor.constants.global_data import GlobalData
from nat_refactor.Commons.ImagePreview import ImagePreview
from dao.settings_dao import SettingsDao
import pyotp
from utils.image_utils import ImageUtils
from controller.nat_interface import NatInterface
from utils.video_utils import VideoUtils
from utils.eval_utils import EvalUtils
from utils.settings_utils import SettingsUtils
from utils.ops_encrypt import EncryptDecrypt  
from utils.common_utils import CommonUtils
from graphql import GraphQLError
from utils.errors_utils import Error
import sys
from dao.login_activity_dao import LoginActiveInactive
from commons import constants as cfg
from dao.data import Data
from utils.floodfill import FloodFill
from structures.data_structures import *
from structures.nat_gql_datatype import *
from utils.user_utils import UserUtils
from dao.user_dao import UserDAO
from utils.logger import Logger
from controller.nat_config_controller import NATConfigController
from dao.workdiv_dao import WorkdivDao
from dao.notifications_dao import NotificationsDao
from utils.metrics_utils import MetricsUtils
from dao.video_dao import VideoDao
# from utils.preview import Preview
from dao.project_dao import ProjectDAO
from utils.auto_tracking import AutoTracking
import PIL.Image
import base64
import pyqrcode
from pyqrcode import QRCode
from utils.dashboard import DashboardUtils
from nat_refactor.utils.encrypt_decrypt_bysalt import EncryptionUtils
from nat_refactor.utils.traceback_utils import print_traceback
from auth import (
    create_access_token,
    auth
)

logger = Logger.get_logger()
config_obj = NATConfigController.read_config()


class NatMutation(object):
    @staticmethod
    def update_tags(id_, project, tags):
        logger.info("[Start]: update_tags")
        try:
            if len(tags) > 0:
                fold = Data.load_fold(project, '')
                ImageUtils.save_image_data(fold, id_, tags)
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: update_tags")


    @staticmethod
    def get_curr_img_and_json_path(image_folder, json_folder, image_dir_path, image_id):
        image_path = os.path.join(image_folder, Data.get_image_name(Data.sort_dir_image_list(image_dir_path), image_id))
        json_path = os.path.join(json_folder, os.path.splitext(Data.get_image_name(Data.sort_dir_image_list(image_dir_path), image_id))[0] + "_label" + ".json")
        im = PIL.Image.open(image_path)
        width, height = im.size  
                    
        return image_path, json_path, im, width, height
    
    @staticmethod           
    def get_info_for_image_to_interpolate(image_dir_path,image_id, image_folder, json_folder, img_index_to_interpolate):
        image_name_to_interpolate = Data.get_image_name(Data.sort_dir_image_list(image_dir_path),img_index_to_interpolate)
        image_path_to_interpolate = os.path.join(image_folder, image_name_to_interpolate)
        img_name_without_extension_to_interpolate = os.path.splitext(image_name_to_interpolate)[0]
        labeljsonfileName_to_interpolate = img_name_without_extension_to_interpolate + "_label" + ".json"
        json_path_to_interpolate = os.path.join(json_folder, labeljsonfileName_to_interpolate)
        return  image_path_to_interpolate, json_path_to_interpolate 

    @staticmethod
    def check_json_and_compare(configure_flag, signal, image_id, jsoncount,  copy_mode, flag, auto_annotations, image_path, json_path, image_path_to_interpolate, json_path_to_interpolate, img_name_without_extension, video_path, jsonfileName, labeljsonfileName, include_preds):
        if jsoncount:
            if copy_mode == 'automatic' and auto_annotations:
                listLabelID = AutoTracking.get_labelIDlist_from_json(auto_annotations)
                
                if flag:
                    AutoTracking.update_bbox_using_tracking(image_path, image_path_to_interpolate,  json_path_to_interpolate, listLabelID,

                                                        json_path ,  )
                
            elif copy_mode == 'manual' and auto_annotations:
                listLabelID = AutoTracking.get_labelIDlist_from_json(auto_annotations)
                if flag:
                    Data.compare_json(image_path_to_interpolate, image_path, json_path_to_interpolate, json_path, listLabelID, )
            if not signal:
                if configure_flag == 0:
                    image_id = image_id + 1 
            else:
                if configure_flag == 1:
                    image_id = image_id - 1
                
            img = Data.load_obj_detect_img(
                    img_name_without_extension, video_path, jsonfileName, labeljsonfileName, include_preds)
            
        else:
            img = None    

        return image_id, img       
    
    @staticmethod
    @auth
    def get_next_obj_video_img(signal, project, videoname, video_id, image_id, video_type, imagename, base64Image,
                               auto_annotations, copy_mode, configure_flag, project_id, userid,
                               dset=cfg.UNLABELED, include_preds=True):
        # 0 for next, 1 for previous
        logger.info("[Start]: get_next_obj_video_img")
        folder_assign = videoname
        # dir_path = ''
        # dir_files = None
        # next_image = None
        # images_list = []
        # image_name = None
        jsonFolderName = "json"
        imageFolderName = "images"
        # width = 0
        # height = 0

        # frames_to_interpolate = None

        try:
            if video_type == 1 and base64Image != "":
                NatMutation.nextImageUpload(video_id, image_id, imagename, videoname,
                                            base64Image)  # Self assigned image upload
            # project_folder_path = NextImage.base_folder_path(userid, project_id)
            project_folder_path = NextImage.base_folder_path(userid, project_id)
            project_path = project_folder_path

            image_dir_path = os.path.join(project_path + folder_assign, imageFolderName,'')
            sorted_image_files = Data.sort_dir_image_list(image_dir_path)
            image_name = Data.get_image_name(sorted_image_files, image_id)
            img_name_without_extension = os.path.splitext(image_name)[0]
            jsonfileName = img_name_without_extension + ".json"
            labeljsonfileName = img_name_without_extension + "_label" + ".json"
            
            video_path = os.path.join(project_path, folder_assign)
            image_folder = os.path.join(video_path, imageFolderName, '')
            json_folder = os.path.join(video_path, jsonFolderName, '')
            
            
            if not os.path.exists(json_folder):
                os.mkdir(json_folder)
            
            Data.annotate = []
            imagecount = len([name for name in os.listdir(image_folder)])
           
            jsoncount = len([name for name in os.listdir(json_folder)])
            predType = SettingsUtils.get_value_by_key(SettingsUtils.KEY_PREDTYPE)
            if configure_flag == 0:
                signal = 0
                frames_to_interpolate = SettingsDao.get_frames_to_interpolate(project_id)
            elif configure_flag == 1:
                signal = 1 
                frames_to_interpolate = SettingsDao.get_frames_to_interpolate(project_id)
            else:
                frames_to_interpolate = 1
            
            if not signal:
                for i in range(frames_to_interpolate):
                    if image_id == imagecount:
                        break 
                    
                    image_path, json_path, im, width, height = NatMutation.get_curr_img_and_json_path(image_folder, json_folder, image_dir_path, image_id)

                    prev_img_index = image_id - 1
                    prev_image_path, prev_json_path = NatMutation.get_info_for_image_to_interpolate(image_dir_path,image_id, image_folder, json_folder, prev_img_index)
                    flag = os.path.exists(prev_json_path)
                    image_id, img = NatMutation.check_json_and_compare(configure_flag, signal, image_id, jsoncount,  copy_mode, flag, auto_annotations, image_path, json_path, prev_image_path, prev_json_path, img_name_without_extension, video_path, jsonfileName, labeljsonfileName, include_preds)
                if configure_flag == 0:
                    image_id -= 1  
            else:
                for i in range(frames_to_interpolate, 0 , -1):
                    
                    image_path, json_path, im, width, height = NatMutation.get_curr_img_and_json_path(image_folder, json_folder, image_dir_path, image_id) 
                    if image_id < 0:
                        break 
                    
                    next_img_index = image_id + 1
                    next_image_path, next_json_path = NatMutation.get_info_for_image_to_interpolate(image_dir_path,image_id, image_folder, json_folder, next_img_index)
                    flag = os.path.exists(next_json_path)
    
                    image_id, img = NatMutation.check_json_and_compare(configure_flag, signal, image_id, jsoncount,  copy_mode, flag, auto_annotations, image_path, json_path, next_image_path, next_json_path, img_name_without_extension, video_path, jsonfileName, labeljsonfileName, include_preds)
                if configure_flag == 1:
                    image_id += 1  

            response, project_folder_path = NextImage.next_img(
                userid, project_id, image_id, videoname, video_id, video_type)
        except Exception as error_obj:
            logger.error(error_obj)
            raise GraphQLError(error_obj)
        finally:
            DbBase.clean()
        logger.info("[Exit]: get_next_obj_video_img")
        return response


    @staticmethod
    @auth
    def get_next_obj_mask_img(image_id, video_name):
        logger.info("[Start]: get_next_obj_mask_img")
        project_path = SettingsUtils.get_value_by_key(SettingsUtils.KEY_DATAPATH)
        folder_assign = video_name
        image_name = None
        response = None
        try:
            dir_path = os.path.join(project_path + folder_assign, os.path.join('images', ''))
            sorted_files = Data.sort_dir_image_list(dir_path)
            image_name = Data.get_image_name(sorted_files, image_id)
            video_path = os.path.join(project_path, folder_assign)
            main_path = os.path.join(video_path, '')
            image_folder = os.path.join(main_path, 'images', '')
            image_path = os.path.join(image_folder, image_name)
            mask_image_path = os.path.join(video_path, 'mask', image_name)
            with open(mask_image_path, "rb") as image_file:
                encoded_string = base64.b64encode(image_file.read()).decode('utf-8')
            path = os.path.split(video_path)
            lastfolder = path[1]
            cfg.LAST_PATH = lastfolder
            project_path = os.path.join(cfg.BASE_PATH, cfg.PROJECT_NAME, cfg.LAST_PATH)
            cfg.MEDIA_PATH = os.path.join(project_path, 'images')
            src = Data.make_url(lastfolder, image_name)
            imagecount = len([name for name in os.listdir(image_folder)])
            response =  ObjMaskImage(
                imageId=image_id,
                imagename=image_name,
                videoname=video_name,
                src=src,
                encoded_string=encoded_string,
                imagecount=imagecount
            )
        except Exception as error_obj:
            logger.error(error_obj)
            raise GraphQLError(Error.get_error_object(sys.exc_info()[0].__name__))
            logger.info("[Exit]: get_next_obj_mask_img")
        return response


    @staticmethod
    @auth
    def imageUploadCloud(user_id, image_name, imagepath, base64Image):
        logger.info("[Start]: imageUploadCloud")
        response = None
        try:
            project_path = SettingsUtils.get_value_by_key(SettingsUtils.KEY_DATAPATH)
            folder_path = os.path.split(imagepath)[0]
            video_name = os.path.split(folder_path)[1]
            video_path = project_path  + video_name
            image_folder = video_path + '/' + "images"
            json_folder = video_path + '/' + "json"
            image_path = image_folder +'/' +image_name
            filename = image_folder + "/" + image_name
            try:
                if os.path.exists(video_path):
                    response = ObjResponse(
                        status=False
                    )
                else:
                    os.makedirs(video_path)
                    os.makedirs(image_folder)
                    os.makedirs(json_folder)
                    VideoUtils.save_image_cloud(base64Image, filename)
                    VideoUtils.save_upload_video(image_path, image_name, video_name, video_path, user_id)
                    response = ObjResponse(
                        status=True
                    )
            except OSError as error:
                logger.error(error)
        except Exception as error_obj:
            logger.error(error_obj)
            raise GraphQLError(Error.get_error_object(sys.exc_info()[0].__name__))
        logger.info("[Exit]: imageUploadCloud")
        return response
        

    @staticmethod
    def nextImageUpload(video_id, image_id, image_name, video_name, base64Image):
        logger.info("[Start]: nextImageUpload")
        images_list = []
        try:
            cur = cfg.mysql_db.get_db().cursor()
            query = "SELECT COUNT(*) FROM image where video_id = %s "
            cur.execute(query, video_id)
            query = "SELECT image_name FROM image where video_id = %s "
            cur.execute(query, video_id)
            image_name_list = list(cur.fetchall())
            for image in image_name_list:
                images_list.append(image[0])
            if  image_name in images_list:
                pass
            else:
                NatMutation.imageUpload(video_id, image_name, video_name, base64Image)

        except Exception as error_obj:
            logger.error(error_obj)
            raise GraphQLError(Error.get_error_object(sys.exc_info()[0].__name__))
        logger.info("[Exit]: nextImageUpload")


    @staticmethod
    @auth
    def imageUpload(video_id, image_name, video_name, base64Image):
        logger.info("[Start]: imageUpload")
        try:
            project_path = SettingsUtils.get_value_by_key(SettingsUtils.KEY_DATAPATH)
            video_path = project_path +  video_name
            image_folder = video_path + '/' + "images"
            image_path = image_folder +'/' +image_name
            VideoUtils.save_image_cloud(base64Image, image_path)
            VideoUtils.save_video_image(video_path, video_name, video_id, image_path, image_name)
        except Exception as error_obj:
            logger.error(error_obj)
            raise GraphQLError(Error.get_error_object(sys.exc_info()[0].__name__))
        logger.info("[Exit]: imageUpload")


    @staticmethod
    @auth
    def fileDownloadCloud(image_id, video_id, image_name, image_url):
        logger.info("[Start]: fileDownloadCloud")
        annos_json = None

        try:
            project_path = SettingsUtils.get_value_by_key(SettingsUtils.KEY_DATAPATH)
            files = os.path.splitext(image_name)[0]
            folder_path = os.path.split(image_url)[0]
            last_folder = os.path.split(folder_path)[1]
            labeljsonfileName = files + '_' + "label.json"
            jsonfileName = files + ".json"
            video_path = os.path.join(project_path, last_folder)

            project = os.path.join(video_path, 'json')
            fold = Data.load_fold(project, labeljsonfileName)
            annos_json = json.dumps(fold)
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: fileDownloadCloud")
        return ObjAnnotation(
            annos_json=annos_json
        )

    @staticmethod
    def getMaskMaskImage(image_id, video_id, image_name, image_url):
        logger.info("[Start]: getMaskMaskImage")
        annos_json = None
        try:
            project_path = SettingsUtils.get_value_by_key(SettingsUtils.KEY_DATAPATH)
            folder_path = os.path.split(image_url)[0]
            last_folder = os.path.split(folder_path)[1]
            video_path = os.path.join(project_path, last_folder)
            project = os.path.join(video_path, 'mask')
            image_path = os.path.join(project, image_name)
            with open(image_path, "rb") as img_file:
                encoded_string = base64.b64encode(img_file.read()).decode('utf-8')
        except Exception as error_obj:
            logger.error(error_obj)
            raise GraphQLError(Error.get_error_object(sys.exc_info()[0].__name__))
        logger.info("[Exit]: getMaskMaskImage")
        return ObjAnnotation(
            annos_json=encoded_string
        )


    @staticmethod
    @auth
    def saveMask(image_id, video_id, image_name, imagepath, base64Image):
        logger.info("[Start]: saveMask")
        annos_json = None
        try:
            project_path = SettingsUtils.get_value_by_key(SettingsUtils.KEY_DATAPATH)
            folder_path = os.path.split(imagepath)[0]
            video_name = os.path.split(folder_path)[1]
            video_path = project_path  + video_name
            mask_folder = video_path + '/' + "mask"
            mask_path = mask_folder +'/' +image_name
            os.remove(mask_path)
            VideoUtils.save_image_cloud(base64Image, mask_path)
            annos_json = NatMutation.getMaskMaskImage(1, 1, image_name, imagepath)
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: saveMask")
        return annos_json


    @staticmethod
    @auth
    def save_obj_detect_image(id_, project, annos, classwise_data, videopath, videoid,
                              width, height, uid, pid, is_blur_mode_active, dset=None):
        logger.info("[Start]: save_obj_detect_image")
        response = None
        dashboard = Dashboard(uid, pid, logger)
        try:
            dashboard.update_data_for_user(classwise_data)
        except Exception as e:
            logger.error("Cannot update data for the user, traceback: {0}, \n error: {1}".format(format_exc(limit=1), e))
            raise GraphQLError(f'Cannot update data for the user, error: {str(e)}')
        finally:
            dashboard.close()
        try:
            save_obj = SaveAnnotations(folder_path=videopath)
            save_obj.save_annotations(annos, id_, is_blur_mode_active)
            response = ObjDetectImage(
                id = id_,
                project=project,
                videopath=videopath,
                videoid=videoid,
                annos_json=json.dumps(annos),
            )
            
        except Exception as error_obj:
            logger.error(error_obj)
            raise GraphQLError(Error.get_error_object(sys.exc_info()[0].__name__))
        logger.info("[Exit]: save_obj_detect_image")
        return response
    
    @staticmethod
    @auth
    def check_save_obj_detect_image(id_, project, annos, videopath, videoid, dset=None):
        logger.info("[Start]: check_save_obj_detect_image")
        response = None
        try:
            id_ = os.path.splitext(id_)[0]
            dset = ImageUtils.get_random_dset() if dset is None else dset
            entry = Data.make_obj_detect_entry(annos)
            videoPath = videopath
            videopath = os.path.join(videopath, 'json')
            labeljsonfileName = id_ + '_label.json'
            parameters = {}
            required_ids = []
            anno_types = ['bbox','polygon']
            for anno in annos:
                try:
                    parameters[anno['polygon']['annoId']] = []
                    required_ids.append(anno['polygon']['annoId'])
                    for i in range(len(anno['polygon']['parameters'])):
                        if i!=0:
                            parameters[anno['polygon']['annoId']].append(anno['polygon']['parameters'][i]['val'])
                except:
                    parameters[anno['bbox']['annoId']] = []
                    required_ids.append(anno['bbox']['annoId'])
                    for i in range(len(anno['bbox']['parameters'])):
                        if i!=0:
                            parameters[anno['bbox']['annoId']].append(anno['bbox']['parameters'][i]['val'])
            json_file_names = os.listdir(videopath)
            for filename in sorted(json_file_names):
                j_filename = os.path.join(videopath, filename)
                data = open(j_filename,)
                data = json.load(data)
                temp = data['img'][filename.replace('_label.json','')]['annotations']
                for element_count in range(len(temp)):
                    try:
                        if temp[element_count]['bbox']['parameters'][0]['val'] in required_ids:
                            count = 1
                            for i in range(len(temp[element_count]['bbox']['parameters'])):
                                if i!=0:
                                    for j in range(len(parameters[temp[element_count]['bbox']['parameters'][0]['val']])):
                                        if count < len(temp[element_count]['bbox']['parameters']):
                                            if data['img'][filename.replace('_label.json','')]['annotations'][element_count]['bbox']['track'] == True:
                                                    data['img'][filename.replace('_label.json','')]['annotations'][element_count]['bbox']['parameters'][count]['val'] = parameters[temp[element_count]['bbox']['parameters'][0]['val']][j] 
                                                    count+=1
                    except:
                        if temp[element_count]['polygon']['parameters'][0]['val'] in required_ids:
                            count = 1
                            for i in range(len(temp[element_count]['polygon']['parameters'])):
                                if i!=0:
                                    for j in range(len(parameters[temp[element_count]['polygon']['parameters'][0]['val']])):
                                        if count < len(temp[element_count]['polygon']['parameters']):
                                            if data['img'][filename.replace('_label.json','')]['annotations'][element_count]['polygon']['track'] == True:
                                                    data['img'][filename.replace('_label.json','')]['annotations'][element_count]['polygon']['parameters'][count]['val'] = parameters[temp[element_count]['polygon']['parameters'][0]['val']][j]
                                                    count+=1 
                json_object = json.dumps(data, indent = 4)
                with open(j_filename, "w") as outfile:
                    outfile.write(json_object)
        except Exception as error_obj:
            logger.error(error_obj)
            raise GraphQLError(Error.get_error_object(sys.exc_info()[0].__name__))
        logger.info("[Exit]: check_save_obj_detect_image")
        return response
    
    @staticmethod
    @auth
    def check_save_obj_detect_image_forward(id_, project, annos, videopath, videoid, dset=None):
        logger.info("[Start]: check_save_obj_detect_image")
        response = None
        try:
            id_ = os.path.splitext(id_)[0]
            dset = ImageUtils.get_random_dset() if dset is None else dset
            entry = Data.make_obj_detect_entry(annos)
            videoPath = videopath
            videopath = os.path.join(videopath, 'json')
            labeljsonfileName = id_ + '_label.json'
            parameters = {}
            required_ids = []
            anno_types = ['bbox','polygon']
            for anno in annos:
                try:
                    parameters[anno['polygon']['annoId']] = []
                    required_ids.append(anno['polygon']['annoId'])
                    for i in range(len(anno['polygon']['parameters'])):
                        if i!=0:
                            parameters[anno['polygon']['annoId']].append(anno['polygon']['parameters'][i]['val'])
                except:
                    parameters[anno['bbox']['annoId']] = []
                    required_ids.append(anno['bbox']['annoId'])
                    for i in range(len(anno['bbox']['parameters'])):
                        if i!=0:
                            parameters[anno['bbox']['annoId']].append(anno['bbox']['parameters'][i]['val'])
            json_file_names = os.listdir(videopath)
            image_ids = list(range(1,1+len(sorted(json_file_names))))
            comparison_value = sorted(json_file_names).index(id_ + '_label.json')
            for filename,image_id in zip(sorted(json_file_names),image_ids):
                if image_id > comparison_value:
                    j_filename = os.path.join(videopath, filename)
                    data = open(j_filename,)
                    data = json.load(data)
                    temp = data['img'][filename.replace('_label.json','')]['annotations']
                    for element_count in range(len(temp)):
                        try:
                            if temp[element_count]['bbox']['parameters'][0]['val'] in required_ids:
                                count = 1
                                for i in range(len(temp[element_count]['bbox']['parameters'])):
                                    if i!=0:
                                        for j in range(len(parameters[temp[element_count]['bbox']['parameters'][0]['val']])):
                                            if count < len(temp[element_count]['bbox']['parameters']):
                                                if data['img'][filename.replace('_label.json','')]['annotations'][element_count]['bbox']['track'] == True:
                                                    data['img'][filename.replace('_label.json','')]['annotations'][element_count]['bbox']['parameters'][count]['val'] = parameters[temp[element_count]['bbox']['parameters'][0]['val']][j] 
                                                    count+=1
                        except:
                            if temp[element_count]['polygon']['parameters'][0]['val'] in required_ids:
                                count = 1
                                for i in range(len(temp[element_count]['polygon']['parameters'])):
                                    if i!=0:
                                        for j in range(len(parameters[temp[element_count]['polygon']['parameters'][0]['val']])):
                                            if count < len(temp[element_count]['polygon']['parameters']):
                                                if data['img'][filename.replace('_label.json','')]['annotations'][element_count]['polygon']['track'] == True:
                                                    data['img'][filename.replace('_label.json','')]['annotations'][element_count]['polygon']['parameters'][count]['val'] = parameters[temp[element_count]['polygon']['parameters'][0]['val']][j]
                                                    count+=1 
                    json_object = json.dumps(data, indent = 4)
                    with open(j_filename, "w") as outfile:
                        outfile.write(json_object)
        except Exception as error_obj:
            logger.error(error_obj)
            raise GraphQLError(Error.get_error_object(sys.exc_info()[0].__name__))
        logger.info("[Exit]: check_save_obj_detect_image")
        return response
    
    @staticmethod
    @auth
    def check_save_obj_detect_image_backward(id_, project, annos, videopath, videoid, dset=None):
        logger.info("[Start]: check_save_obj_detect_image")
        response = None
        try:
            id_ = os.path.splitext(id_)[0]
            dset = ImageUtils.get_random_dset() if dset is None else dset
            entry = Data.make_obj_detect_entry(annos)
            videoPath = videopath
            videopath = os.path.join(videopath, 'json')
            labeljsonfileName = id_ + '_label.json'
            parameters = {}
            required_ids = []
            anno_types = ['bbox','polygon']
            for anno in annos:
                try:
                    parameters[anno['polygon']['annoId']] = []
                    required_ids.append(anno['polygon']['annoId'])
                    for i in range(len(anno['polygon']['parameters'])):
                        if i!=0:
                            parameters[anno['polygon']['annoId']].append(anno['polygon']['parameters'][i]['val'])
                except:
                    parameters[anno['bbox']['annoId']] = []
                    required_ids.append(anno['bbox']['annoId'])
                    for i in range(len(anno['bbox']['parameters'])):
                        if i!=0:
                            parameters[anno['bbox']['annoId']].append(anno['bbox']['parameters'][i]['val'])
            json_file_names = os.listdir(videopath)
            image_ids = list(range(len(sorted(json_file_names))-1))
            comparison_value = sorted(json_file_names).index(id_ + '_label.json')
            for filename,image_id in zip(sorted(json_file_names),image_ids):
                if image_id < comparison_value:
                    j_filename = os.path.join(videopath, filename)
                    data = open(j_filename,)
                    data = json.load(data)
                    temp = data['img'][filename.replace('_label.json','')]['annotations']
                    for element_count in range(len(temp)):
                        try:
                            if temp[element_count]['bbox']['parameters'][0]['val'] in required_ids:
                                count = 1
                                for i in range(len(temp[element_count]['bbox']['parameters'])):
                                    if i!=0:
                                        for j in range(len(parameters[temp[element_count]['bbox']['parameters'][0]['val']])):
                                            if count < len(temp[element_count]['bbox']['parameters']):
                                                if data['img'][filename.replace('_label.json','')]['annotations'][element_count]['bbox']['track'] == True:
                                                    data['img'][filename.replace('_label.json','')]['annotations'][element_count]['bbox']['parameters'][count]['val'] = parameters[temp[element_count]['bbox']['parameters'][0]['val']][j] 
                                                    count+=1
                        except:
                            if temp[element_count]['polygon']['parameters'][0]['val'] in required_ids:
                                count = 1
                                for i in range(len(temp[element_count]['polygon']['parameters'])):
                                    if i!=0:
                                        for j in range(len(parameters[temp[element_count]['polygon']['parameters'][0]['val']])):
                                            if count < len(temp[element_count]['polygon']['parameters']):
                                                 if data['img'][filename.replace('_label.json','')]['annotations'][element_count]['polygon']['track'] == True:
                                                    data['img'][filename.replace('_label.json','')]['annotations'][element_count]['polygon']['parameters'][count]['val'] = parameters[temp[element_count]['polygon']['parameters'][0]['val']][j]
                                                    count+=1  
                    json_object = json.dumps(data, indent = 4)
                    with open(j_filename, "w") as outfile:
                        outfile.write(json_object)
        except Exception as error_obj:
            logger.error(error_obj)
            raise GraphQLError(Error.get_error_object(sys.exc_info()[0].__name__))
        logger.info("[Exit]: check_save_obj_detect_image")
        return response

    @staticmethod
    @auth
    def after_save_frame(videoid, videoname):
        logger.info("[Start]: after_save_frame")
        response = None
        try:
            VideoUtils.after_save_frame(videoid, videoname)
            response = ObjResponse(
                status = True
            )
        except Exception as error_obj:
            logger.error(error_obj)
            response = ObjResponse(
                status = False
            )
        logger.info("[Exit]: after_save_frame")
        return response

   
    @staticmethod
    @auth
    def save_setting_object(userid, project_id, settingObject, predType, modelType, outputFormat, folderPath, minHeight, minWidth, annoTip, class_added, frames_to_interpolate):
        logger.info("[Start]: save_setting_object")
        response = ObjResponse(
            status = False
        )
        try:
            SettingsUtils.save_json(userid, project_id, settingObject, predType, modelType,
                                    outputFormat, folderPath, minHeight, minWidth, annoTip, class_added, frames_to_interpolate)
            response = ObjResponse(
                status = True
            )
        except Exception as error_obj:
            logger.error(error_obj)
            raise GraphQLError(Error.get_error_object(sys.exc_info()[0].__name__))
        finally:
            DbBase.clean()
        logger.info("[Exit]: save_setting_object")
        return response

    @staticmethod
    @auth
    def save_preview_video_details(videoid, videoname,takName, total_duration, timestamp):
        logger.info("[Start]: save_preview_video_details")
        response = ObjResponse(
            status = False
        )
        try:
            SettingsUtils.save_preview_video_json(videoid, videoname, takName,
                                    total_duration, timestamp)
            response = ObjResponse(
                status = True
            )
        except Exception as error_obj:
            logger.error(error_obj)
            raise GraphQLError(Error.get_error_object(sys.exc_info()[0].__name__))
        logger.info("[Exit]: save_preview_video_details")
        return response

    @staticmethod
    @auth
    def save_upload_video(videopath):
        logger.info("[Start]: save_upload_video")
        root_dir = []
        try:
            project_path = SettingsUtils.get_value_by_key('folderPath')
            root_dir = videopath.split('/')
            lastfolder = os.path.split(videopath)[0]
            path = project_path
            filepath = path + '/' + root_dir[0]
            dir_list = Data.sort_dir_image_list(project_path)
            cur = cfg.mysql_db.get_db().cursor()
            for folder_name in dir_list:
                if cfg.FOLD_NAME_GIT != folder_name:
                    video_date = str(datetime.datetime.now())
                    query = "INSERT INTO video (`video_date` ,`video_name` ,`video_path`,`assigned`,`processed`) " \
                        "VALUES ('" + video_date + "', '" + folder_name + \
                        "', '" + filepath + "', False,False)"
                    cur.execute(query)
        except Exception as error_obj:
            logger.error(error_obj)
            raise GraphQLError(Error.get_error_object(sys.exc_info()[0].__name__))
        logger.info("[Exit]: save_upload_video")


    @staticmethod
    @auth
    def update_video_assigned(videoid, assignuserid, userid):
        logger.info("[Start]: update_video_assigned")
        response = ObjResponse(
            status = False
        )
        try:
            cur = cfg.mysql_db.get_db().cursor()
            videoids = videoid
            assignuser_id = str(assignuserid)
            an_to = UserDAO.get_login_by_userid(assignuser_id, cur=cur)

            assignees = {}

            for videoid in videoids:
                query = """ SELECT * FROM video WHERE id=%s """
                data = (videoid)
                cur.execute(query, data)
                rows = cur.fetchone()
                
                videoname = rows[1]
                an_from_id = rows[7]
                if an_from_id is None:
                    an_from_id = rows[12]       # copy from validator branch if annotator is blank
                if videoname:
                    an_from = UserDAO.get_login_by_userid(an_from_id, cur=cur)
                    try:
                        assignees[an_from].append(videoname)
                    except:
                        assignees[an_from] = [videoname]
                    NotificationsDao.create_notifications(videoid, assignuserid, userid, cur=cur)

            query = """ UPDATE video SET assigned_user_id =%s, assigned=True WHERE id IN (%s) """ %(
                assignuser_id,
                ','.join([str(i) for i in videoids])
            )
            cur.execute(query)
            logger.info("Assigned in db successfully")
            response = ObjResponse(
                status = True
            )

        except Exception as error_obj:
            logger.error(error_obj)
            raise GraphQLError(Error.get_error_object(sys.exc_info()[0].__name__))
        logger.info("[Exit]: update_video_assigned")

    @staticmethod
    @auth
    def update_video_assigned_validator(videoid, assignuserid, userid):
        logger.info("[Start]: update_video_assigned_validator")
        response = ObjResponse(
            status = False
        )
        try:
            cur = cfg.mysql_db.get_db().cursor()
            videoids = videoid
            assignuser_id = str(assignuserid)
            # userid        = str(userid)
            new_validator_name = UserDAO.get_login_by_userid(assignuser_id, cur=cur)

            assignees = {}

            for video_id in videoids:
                video_details = VideoDao.get_video_details_by_id(video_id)
                video_name = video_details.get("video_name")
                validator_id = video_details.get("validator_assign_id")
                if video_name and validator_id!=assignuser_id:
                    old_validator_name = 'master'
                    if validator_id is not None:
                        old_validator_name = UserDAO.get_login_by_userid(validator_id, cur=cur)
                    try:
                        assignees[old_validator_name].append(video_name)
                    except:
                        assignees[old_validator_name] = [video_name]
                NotificationsDao.create_notifications(video_id, assignuserid, userid)

            query = """ UPDATE video 
                        SET validator_assign_id =%s , assigned=False, processed=False, submitted=False, assigned_user_id=null 
                        WHERE id IN (%s)""" % (
                assignuser_id,
                ','.join([str(i) for i in videoid])
            )
            cur.execute(query)
            logger.debug("Assigned in db successfully")
            response = ObjResponse(
                status = True
            )

        except Exception as error_obj:
            logger.error(error_obj)
            raise GraphQLError(Error.get_error_object(sys.exc_info()[0].__name__))
        logger.info("[Exit]: update_video_assigned_validator")

    @staticmethod
    @auth
    def get_all_images_detail(videoid):
        logger.info("[Start]: get_all_images_detail")
        all_images_detail = None
        try:

            cur = cfg.mysql_db.get_db().cursor()
            video_id = str(videoid)
            query = ("SELECT * FROM demo_image where video_id=%s")
            cur.execute(query, video_id)
            result = list(cur.fetchall())
            all_images_detail = ImageUtils.make_images_list(result) # This is erroneous, not modified because not in use
        except Exception as error_obj:
            logger.error(error_obj)
            raise GraphQLError(Error.get_error_object(sys.exc_info()[0].__name__))
        logger.info("[Exit]: get_all_images_detail")
        return all_images_detail

    @staticmethod
    @auth
    def get_all_images_details(videoid):
        logger.info("[Start]: get_all_images_details")

        try:
            data = ImageJsonList().image_json_data(videoid)

        except Exception as error_obj:
            logger.error(error_obj)
            raise GraphQLError(Error.get_error_object(sys.exc_info()[0].__name__))
        logger.info("[Exit]: get_all_images_details")
        return ObjImage(images=data[0], jsons=data[1])

    @staticmethod
    @auth
    def get_image_metrics(videoid, imagename):
        image_metrics = None
        logger.info("[Start]: get_all_images_detail")
        try:
            cur = cfg.mysql_db.get_db().cursor()
            video_id = str(videoid)
            query = ("SELECT * FROM video where id=%s")
            cur.execute(query, video_id)
            result = list(cur.fetchone())
            jsonpath = result[2] + '/json'
            image_metrics = EvalUtils.images_metrics_details(
                jsonpath, imagename)
        except Exception as error_obj:
            logger.error(error_obj)
            raise GraphQLError(Error.get_error_object(sys.exc_info()[0].__name__))
        logger.info("[Exit]: get_all_images_detail")
        return image_metrics

    @staticmethod
    @auth
    def update_video_processed(videoid):
        logger.info("[Start]: update_video_processed")
        try:
            Data.consldt_mtx = {'name_cnl': [], 'accuracy_cnl': [
            ], 'edit_cnl': [], 'updated_cnl': [], 'locacc_cnl': []}
            cur = cfg.mysql_db.get_db().cursor()
            video_id = str(videoid)
            query = """ UPDATE video SET  processed=True WHERE id =%s """
            cur.execute(query, video_id)
        except Exception as error_obj:
            logger.error(error_obj)
            raise GraphQLError(Error.get_error_object(sys.exc_info()[0].__name__))
        logger.info("[Exit]: update_video_processed")

    @staticmethod
    @auth
    def delete_video(videoid):
        logger.info("[Start]: delete_video")
        try:
            cur = cfg.mysql_db.get_db().cursor()
            videoids = videoid
            delstatmt = """DELETE FROM nat_user_notifications WHERE video_id IN (%s)"""%(','.join(str(x) for x in videoids))
            query = """DELETE FROM video WHERE id IN (%s)"""%(','.join(str(x) for x in videoids))
            cur.execute(delstatmt)
            cur.execute(query)
        except Exception as error_obj:
            logger.error(error_obj)
            raise GraphQLError(Error.get_error_object(sys.exc_info()[0].__name__))
        logger.info("[Start]: delete_video")

    @staticmethod
    @auth
    def get_video_details(videoid, imageid):
        try:
            return ImagePreview(imageid, videoid).make()
        except Exception as error_obj:
            logger.error(error_obj)
            raise GraphQLError(Error.get_error_object(sys.exc_info()[0].__name__))

    @staticmethod
    @auth
    def get_preview_video_details(videoid, videoname):
        video_details = None
        logger.info("[Start]: get_preview_video_details")
        try:
            video_details = VideoUtils.make_preview_video_details(videoid, videoname)
        except Exception as error_obj:
            logger.error(error_obj)
            raise GraphQLError(Error.get_error_object(sys.exc_info()[0].__name__))
        logger.info("[Exit]: get_preview_video_details")
        return video_details


    @staticmethod
    @auth
    def start_flood_fill(videoid, imageid, videoname, clickPointX, clickPointY,tolerance):
        logger.info("[Start]: start_flood_fill")
        ff_points = []
        project_path = SettingsUtils.get_value_by_key(
            SettingsUtils.KEY_DATAPATH)
        folder_assign = videoname
        try:
            dir_path = project_path + folder_assign + "/" + 'images' + "/"
            sorted_files = Data.sort_dir_image_list(dir_path)
            image_name = Data.get_image_name(sorted_files, imageid)
            imagePath = dir_path + '/' + image_name
            points = FloodFill.floodfill_working(
                imagePath, clickPointX, clickPointY, tolerance)
            logger.info("start_flood_fill  points received ")
            for counter in range(len(points['x'])):
                x_ = points['x'][counter]
                y_ = points['y'][counter]
                pt = FloodFillPoint(
                    x=x_,
                    y=y_
                )
                ff_points.append(pt)
        except Exception as error_obj:
            logger.error(error_obj)
            raise GraphQLError(Error.get_error_object(sys.exc_info()[0].__name__))

        logger.info("[Exit]: start_flood_fill")
        return ImgProc(
            points=ff_points
        )

    @staticmethod
    @auth
    def get_all_videos(userid, project_id):
        '''
        Function for displaying videos data on the home page for Annotater
        args -
            userid - (Int) User ID of current session user
        return -
            (LIST) Details of video extracted from database 
        '''
        logger.info("[Start]: get_all_videos")
        result = None
        response = None
        users_dict = {}
        try:
            
            cur = cfg.mysql_db.get_db().cursor()
            user_id = int(userid) 
            query_param = (project_id,user_id)
            last_prj = 0
            if user_id == 1:
                query = ("SELECT * FROM video ORDER BY no_labeljsons/no_frames")
                cur.execute(query)
            else:
                if project_id == -1:
                    query = ("SELECT last_selected from nat_annotator where user_id=%s")
                    cur.execute(query,user_id)
                    last_prj = cur.fetchone()[0]
                    if last_prj is not 0:
                        query_param = (last_prj,user_id)
                        query = ("SELECT * FROM video where project_id=%s and assigned_user_id=%s ORDER BY no_labeljsons/no_frames")
                        cur.execute(query,query_param)  
                        result = list(cur.fetchall())
                else:
                    query1 = ("update nat_annotator set last_selected=%s where user_id=%s ")
                    cur.execute(query1,query_param)
                    last_prj = project_id
                    query_param = (last_prj,user_id)
                    query = ("select * from video where project_id=%s and assigned_user_id=%s ORDER BY no_labeljsons/no_frames")
                    cur.execute(query,query_param)  
                    result = list(cur.fetchall())
            users_dict = UserDAO.get_users_dict(cur)
            videos = VideoUtils.make_video_list(result, users_dict)
            response = ObjVideo(
                last_project=last_prj,
                videos=videos
            )
        except Exception as error_obj:
            logger.error(error_obj)
            raise GraphQLError(Error.get_error_object(sys.exc_info()[0].__name__))
        logger.info("[Exit]: get_all_videos")
        return response

    @staticmethod
    @auth
    def get_all_videos_validator(userid, user_role, project_id):
        '''
        Function for displaying videos data on the home page for users(ADMIN/VALIDATOR)
        args -
            userid - (Int) User ID of current session user
            user_role - (String) Role of the user (ADMIN/VALIDATOR)
        return -
            (LIST) Details of video and last project selected by the user  
        '''
        logger.info("[Start]: get_all_videos_validator")
        result = None
        response = None
        users_dict = {}
        try:
            cur = cfg.mysql_db.get_db().cursor()
            user_id = int(userid)
            query_param = (project_id,user_id)
            last_prj = 0
            if project_id == -1:
                if user_role == cfg.ROLE_ADMIN or user_role == "ADMIN":
                    query = ("select last_selected from nat_admin where user_id=%s")
                    cur.execute(query,user_id)
                    last_prj = cur.fetchone()[0]
                    if last_prj is not 0:
                        query2 = ("SELECT * FROM video where project_id=%s ORDER BY no_labeljsons/no_frames")
                        cur.execute(query2,last_prj)
                        result = list(cur.fetchall())
                else:
                    query = ("select last_selected from nat_validator where user_id=%s")
                    cur.execute(query,user_id)
                    last_prj = cur.fetchone()[0]
                    if last_prj is not 0:
                        query_param = (last_prj,user_id)
                        query = ("select * from video where project_id=%s and validator_assign_id=%s ORDER BY no_labeljsons/no_frames")
                        cur.execute(query,query_param)  
                        result = list(cur.fetchall())
            else:
                if user_role == cfg.ROLE_ADMIN or user_role == "ADMIN":
                    query1 = ("update nat_admin set last_selected=%s where user_id=%s")
                    cur.execute(query1,query_param)
                    last_prj = project_id
                    query2 = ("SELECT * FROM video where project_id=%s ORDER BY no_labeljsons/no_frames")
                    cur.execute(query2,project_id)
                    result = list(cur.fetchall())
                else:
                    query1 = ("update nat_validator set last_selected=%s where user_id=%s")
                    cur.execute(query1,query_param)
                    last_prj = project_id
                    query_param = (last_prj,user_id)
                    query = ("select * from video where project_id=%s and validator_assign_id=%s ORDER BY no_labeljsons/no_frames")
                    cur.execute(query,query_param)  
                    result = list(cur.fetchall())
            users_dict = UserDAO.get_users_dict(cur)
        except Exception as error_obj:
            logger.error(error_obj)
            raise GraphQLError(Error.get_error_object(sys.exc_info()[0].__name__))
        logger.info("[Exit]: get_all_videos_validator")
        videos = VideoUtils.make_video_list(result, users_dict)

        response = ObjVideo(
            last_project=last_prj,
            videos=videos
        )
        return response

    @staticmethod
    @auth
    def user_projects(userid,user_role):
        logger.info("[Start]: user_projects")
        response = None
        try:
            response = ProjectDAO.get_all_projects(userid,user_role)
        except Exception as error_obj:
            logger.error(error_obj)
            raise GraphQLError(Error.get_error_object(sys.exc_info()[0].__name__))
        logger.info("[Exit]: user_projects")
        return response

    @staticmethod
    def create_user(name, email, password):
        pass

    @staticmethod
    def login_user(username, password):
        logger.info("[Start]: login_user")
        response = None
        try:
            identity = UserUtils.login(username, password)
            # GitUtils.reset_static_vars()
            #identity['exp'] = 3600
            if identity:
                LoginActiveInactive(identity['userid']).update_last_login()
            access_token = create_access_token(identity)
            response = ObjLoginUser(
                userid=identity['userid'],
                username=identity['username'],
                role=identity['role'],
                activated=identity['activated'],
                last_project=identity['last_project'],
                access_token=access_token,
                auth_pin=identity['auth_pin']
            )
        except Exception as error_obj:
            logger.error(error_obj)
            #raise GraphQLError(Error.get_error_object(sys.exc_info()[0].__name__))
        logger.info("[Exit]: login_user")
        return response

    
        

    @staticmethod
    def login_by_tfa(username, otp, secret, cur=None):
        logger.info("[Start]: login_by_tfa - %d" % (otp))
        response = None
        match = 0
        key = None
        try:
            if secret == "":
                if cur is None:
                    cur = cfg.mysql_db.get_db().cursor()

                query = "SELECT tfa_secret, locked FROM nat_user WHERE login='%s'" % (username)
                cur.execute(query)
                tfa_info = list(cur.fetchone())
                key = tfa_info[0]
                locked = tfa_info[1]
                if locked < 3:
                    if key:
                        if CommonUtils.verify_otp(otp, key):
                            match = 1
                            query = "UPDATE nat_user SET locked = 0 WHERE login='%s'" %(username)
                            cur.execute(query)
                        else:
                            query = "UPDATE nat_user SET locked = locked + 1 WHERE login='%s'" %(username)
                            cur.execute(query)
                            # logger.info("locked: %d" %(locked+1))
                else:
                    match = 2
                    # logger.info("Account locked")
                # if cur is None:
                #     cur = cfg.mysql_db.get_db().cursor()
                
                # query = "SELECT tfa_secret FROM nat_user WHERE login='%s'" % (username)
                # cur.execute(query)
                # key = cur.fetchone()[0]
                # if key :
                #     if CommonUtils.verify_otp(otp, key):
                #         match = 1
            else:
                if CommonUtils.verify_otp(otp, secret):
                    UserDAO.save_tfa_secret(username, secret)
                    match = 1
            response = ObjLoginUser(
                userid=None,
                username=None,
                role=None,
                activated=match,
                last_project=None,
                access_token=None,
                auth_pin=None
            )
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: login_by_tfa  %s" %(match))
        return response
        
    

    @staticmethod
    def generate_tfa_secret(username):
        logger.info("[Start] : generate_tfa_secret")
        secret=pyotp.random_base32()
        uri = "otpauth://totp/%s?secret=%s" % (username, secret)
        qr = pyqrcode.create(uri).text()
        print(qr)
        response =  ObjSecret(
            secret = secret,
            qr = qr
        )
        return response
        '''logger.info("[Start] : generate_tfa_secret")
        response =  ObjLoginUser(
            userid=None,
            username=None,
            role=None,
            activated=None,
            last_project=None,
            access_token=None,
            auth_pin=pyotp.random_base32()
        )
        return response'''

    @staticmethod
    @auth
    def reset_notifications(userid, username):
        logger.info("[Start]: reset_notifications")
        count = 0
        try:
            NotificationsDao.reset_unread_count(userid)
            logger.info("New dirs inserted in database")
        except Exception as error_obj:
            logger.error(error_obj)
            raise GraphQLError(Error.get_error_object(sys.exc_info()[0].__name__))
        logger.info("[Exit]: reset_notifications")
        return ObjNotification(
            count=count,
            msg=""
        )

    @staticmethod
    @auth
    def push_video(userid, username, interim_ids, final_ids):
        logger.info("[Start]: push_video")
        videoids = []
        count = len(final_ids)
        response = False
        try:
            cur = cfg.mysql_db.get_db().cursor()
            if len(final_ids)==0:
                NotificationsDao.reset_unread_count(userid)
            else:
                query = """ SELECT id, video_name, no_frames, assigned_user_id, validator_assign_id FROM video WHERE id IN (%s) """%(','.join(str(x) for x in final_ids))
                cur.execute(query)
                results = cur.fetchall()
                videonames = []
                for result in results:
                    videonames.append(result[1])
                NotificationsDao.reset_unread_count(userid)
                if True:
                    logger.debug("Pushed %s files", str(count))
                    anno_name = UserDAO.get_login_by_userid(userid)
                    validator_ids = []
                    vali_names = {}
                    for result in results:
                        try:
                            is_processed = VideoUtils.set_video_processed_if(result)
                            videoid = result[0]
                            videoname = result[1]
                            frames_count = result[2]
                            validator_id = result[4]
                            if is_processed:
                                videoids.append(int(videoid))
                                
                                if validator_id not in validator_ids:
                                    validator_ids.append(validator_id)
                                    vali_name = UserDAO.get_login_by_userid(validator_id)
                                    vali_names[validator_id] = vali_name
                                    logger.debug("Merging branch %s into branch %s" % (anno_name, vali_name))
                                    # if anno_name and vali_name:
                                    #     ScriptUtils.merge(anno_name, vali_name)
				
                                MetricsUtils.create_or_update_productivity(videoid, videoname, vali_name, anno_name,
                                                                           frames_count=frames_count)
                                MetricsUtils.create_or_update_accuracy(videoname)
                                
                                NotificationsDao.create_notifications(videoid, validator_id, userid)
                            #Removing because it is slowing down the API
                            # VideoUtils.after_submit(videoid, videoname)
                        except Exception as error_obj:
                            logger.error("Error in processing video %s - %s"%(str(videoid), error_obj))
           
        except Exception as error_obj:
            logger.error(error_obj)
            raise GraphQLError(Error.get_error_object(sys.exc_info()[0].__name__))
        logger.info("[Exit]: push_video")
        return ObjVideoPush(
            videoids=videoids,
            count=count
        )

    @staticmethod
    @auth
    def users_assignation_list(userid, role, projectId):
        logger.info("[Start]: users_assignation_list")
        response = []
        try:
            users = UserUtils.get_users_assignation_list(userid, role, projectId)
            users_obj = []
            for user in users:
                users_obj.append(ObjAssignList(
                    userid=user['userid'],
                    username=user['username'],
                    role=user['role'],
                    activated=user['activated'],
                    last_project = projectId,
                ))

            response = ObjUserAssignationList(
                users=users_obj
            )
        except Exception as error_obj:
            logger.error(error_obj)
            raise GraphQLError(Error.get_error_object(sys.exc_info()[0].__name__))
        logger.info("[Exit]: users_assignation_list")
        return response

    @staticmethod
    @auth
    def save_user_list_obj(jsondata, userid=1):
        
    
        logger.info("[Start]: save_user_list_obj")
        response = ObjResponse(status=False)
        try:
            UserUtils.save_project_team(jsondata, userid)
            response = ObjResponse(status=True)
        except Exception as error_obj:
            logger.error(error_obj)
            raise GraphQLError(Error.get_error_object(sys.exc_info()[0].__name__))
        logger.info("[Exit]: save_user_list_obj")
        return response

    @staticmethod
    @auth
    def get_user_list_obj(userid,proId):
        logger.info("[Start]: get_user_list_obj")
        response = []
        try:
            # TODO: Add project_id here
            response = UserUtils.get_team(userid,proId)
        except Exception as error_obj:
            logger.error(error_obj)
            raise GraphQLError(Error.get_error_object(sys.exc_info()[0].__name__))
        logger.info("[Exit]: get_user_list_obj")
        return response

    @staticmethod
    @auth
    def save_script_list_obj(scriptList):
        logger.info("[Start]: save_script_list_obj")
        response = []
        try:
            # TODO: Add project_id here
            #response = UserUtils.get_project_team()
            print("save_script_list_obj: ", scriptList)
        except Exception as error_obj:
            logger.error(error_obj)
            raise GraphQLError(Error.get_error_object(sys.exc_info()[0].__name__))
        logger.info("[Exit]: save_script_list_obj")
        return response

    @staticmethod
    @auth
    def init_project(userid, folderpath, projectType, divisionType, availdays, requiredays, productivity, avgFrame, totalFrame, availannotator, requireannotator, annoratio, availvalidator, scriptList, conversionScript, conversionScripts):
        logger.info("[Start]: init_project")
        response = ObjNotification(
            count = 0,
            msg = ""
        )
        try:
            go = True
            work_id = None
            r = WorkdivDao.get_workdiv_by_folderpath(folderpath)
            if r:
                work_id = r[0]
                d = WorkdivDao.get_latest_details(r[0])
                if d:
                    WorkdivDao.update_workdiv(userid, work_id, scriptList, conversionScript)
                    if d[3] >= 1:
                        response = ObjNotification(
                            count = 0,
                            msg = "Updated."
                        )
                        logger.debug("Updated. %s folder already exists in active status"%(folderpath))
                        go = False
            if go:
                if not work_id:
                    logger.debug("Creating new work")
                    project_id = ProjectDAO.find_by_name(projectType)
                    work_id = WorkdivDao.save_workdiv(userid, folderpath, divisionType, availdays, requiredays, productivity, avgFrame, totalFrame, availannotator, requireannotator, annoratio, availvalidator, scriptList, project_id, conversionScript, conversionScripts)
                if work_id:
                    api_url_base = EncryptDecrypt.decrypt_incoming(config_obj.get(os.environ.get('ENV'),'API_URL_BASE'))
                    api_url = '{0}v1/init-project'.format(api_url_base)

                    headers = {'Content-Type': 'application/json'}
                    params = {'work_id': work_id}

                    logger.debug("Requesting url {0}".format(api_url))
                    resp = requests.post(api_url, headers=headers, params=params)
                    logger.debug("Status code: {0}".format(resp.status_code))

                    if resp.status_code == 200:
                        response = ObjNotification(
                            count = 1,
                            msg = ""
                        )
        except Exception as error_obj:
            logger.error(error_obj)
            raise GraphQLError(Error.get_error_object(sys.exc_info()[0].__name__))
        logger.info("[Exit]: init_project")
        return response

    @staticmethod
    @auth
    def init_project_report():
        logger.info("[Start]: init_project_response")
        response = None
        try:
          api_url_base = EncryptDecrypt.decrypt_incoming(config_obj.get(os.environ.get('ENV'),'API_URL_BASE'))
          api_url = '{0}v1/report'.format(api_url_base)

          headers = {'Content-Type': 'application/json'}

          logger.debug("Requesting url {0}".format(api_url))
          resp = requests.get(api_url, headers=headers)
          logger.debug("Status code: {0}".format(resp.status_code))

          if resp.status_code == 200:
              response = ObjReport(
                  text = resp.text
              )
        except Exception as error_obj:
            logger.error(error_obj)
            raise GraphQLError(Error.get_error_object(sys.exc_info()[0].__name__))
        logger.info("[Exit]: init_project_response")
        return response

    @staticmethod
    @auth
    def video_to_frames(folderpath):
        logger.info("[Start]: init_project_response")
        response = None
        try:
            api_url_base = EncryptDecrypt.decrypt_incoming(config_obj.get(os.environ.get('ENV'),'API_URL_BASE'))
            api_url = '{0}v1/video-to-frames'.format(api_url_base)

            headers = {'Content-Type': 'application/json'}
            params = {'folderpath': folderpath}

            logger.debug("Requesting url {0}".format(api_url))
            resp = requests.post(api_url, headers=headers, params=params)
            logger.debug("Status code: {0}".format(resp.status_code))

            if resp.status_code == 200:
                data = resp.json()
                if data:
                    response = ObjFramesDetails(
                        path = data.get('path'),
                        frames_count = data.get('frames_count'),
                        json_count = data.get('json_count'),
                        scripts_list = data.get('scripts_list'),
                        conversion_scripts = data.get('conversion_scripts')
                    )
        except Exception as error_obj:
            logger.error(error_obj)
            raise GraphQLError(Error.get_error_object(sys.exc_info()[0].__name__))
        logger.info("[Exit]: init_project_response")
        return response

    @staticmethod
    @auth
    def get_all_user_notifications(userid):
        logger.info("[Start]: get_all_user_notifications")
        response = []
        try:
            c = NotificationsDao.get_unread_count(userid)
            response = NotificationCount(notificationcount=c)
        except Exception as error_obj:
            logger.error(error_obj)
            raise GraphQLError(Error.get_error_object(sys.exc_info()[0].__name__))
        logger.info("[Exit]: get_all_user_notifications")
        return response


    @staticmethod
    @auth
    def accept_reject_video(userid, submitted, videoid):
        logger.info("[Start]: accept_reject_video")
        response = []
        try:
            video_details = VideoDao.get_video_details_by_id(videoid)
            videoname = video_details.get("video_name")
            user_from = UserDAO.get_login_by_userid(userid)
            user_to = UserDAO.get_login_by_userid(video_details.get('assigned_user_id'))
            if submitted:
                count = 1
                VideoDao.accept_video(videoid)
                #ScriptUtils.merge(user_from, 'master')
            else:
                count = 0
                VideoDao.reject_video(videoid)
                NotificationsDao.reset_unread_count(userid)
                # if count > 1:
                #     #ScriptUtils.merge(user_from, user_to, videoname)
                NotificationsDao.create_notifications(videoid, video_details.get('assigned_user_id'), userid)
            MetricsUtils.create_or_update_productivity(videoid, videoname, user_from, user_to, True)
            MetricsUtils.create_or_update_accuracy(videoname, True)
        except Exception as error_obj:
            logger.error(error_obj)
            raise GraphQLError(Error.get_error_object(sys.exc_info()[0].__name__))
        logger.info("[Exit]: accept_reject_video")
        return count

    @staticmethod
    @auth
    def get_productivity_metrics_updated(userid, username, userrole, from_date, to_date, pid, active_tab):
        logger.info("[Start]: get_productivity_metrics_updated")
        dashboard = Dashboard(userid, pid, logger)
        print(pid, from_date, to_date, active_tab)
        try:
            data = None
            if active_tab == "Productivity":
                data = dashboard.get_productivity_details(from_date, to_date)
                # data = DashboardUtils().get_users_data(pid, from_date, to_date)
            elif active_tab == "Accuracy":
                data = dashboard.get_accuracy_details(from_date, to_date)
                # data = DashboardUtils().get_accuracy_data(pid, from_date, to_date)
            else:
                logger.error("the active_tab is unknown, traceback:{}".format(extract_stack(limit=1)))
        except Exception as e:
            print(format_exc())
            logger.error(str(e))
            raise GraphQLError(str(e))
        finally:
            dashboard.close()
            DbBase.clean()
        response = ProductivityResponse(
            productivity_data = json.dumps(data)
        )
        logger.info("[Exit]: get_productivity_metrics_updated")
        return response

    @staticmethod
    @auth
    def get_productivity_metrics(userid, username, userrole, from_date, to_date, pid):
        response = True
        logger.info("[Start]: get_productivity_metrics")
        try:
            r = MetricsUtils.generate_productivity_csv(userid, username, userrole, from_date, to_date)
            response = ObjResponse(
                status = r
            )
        except Exception as error_obj:
            response = False
            response = ObjResponse(
                status = False
            )
        logger.info("[Exit]: get_productivity_metrics")
        return response

    @staticmethod
    @auth
    def reopen_video(videoid):
        logger.info("[Start]: reopen_video")
        response = True
        try:
            r = VideoDao.reopen(videoid)
            response = ObjResponse(
                status = r
            )
        except Exception as error_obj:
            logger.error(error_obj)
            response = ObjResponse(
                status = False
            )
        logger.info("[Exit]: reopen_video")
        return response

    @staticmethod
    @auth
    def get_performance_chart(userid, username, userrole, pid):
        logger.info("[Start]: get_performance_chart")
        response = True
        try:
            r = MetricsUtils.generate_performance_chart_csv(userid, username, userrole, pid)
            response = ObjResponse(
                status = r
            )
        except Exception as error_obj:
            response = False
            response = ObjResponse(
                status = False
            )
        logger.info("[Exit]: get_performance_chart")
        return response

    @staticmethod
    @auth
    def change_orientation(videoname, filename, orientation):
        response = True
        logger.info("[Start]: change_orientation")
        try:
            project_path = SettingsUtils.get_value_by_key(SettingsUtils.KEY_DATAPATH)
            filepath = os.path.join(project_path, videoname, 'images', filename)
            r = ImageUtils.change_orientation(filepath, orientation)
            response = ObjResponse(
                status=r
            )
        except Exception as error_obj:
            logger.error(error_obj)
            response = ObjResponse(
                status = False
            )
        logger.info("[Exit]: change_orientation")
        return response

    @staticmethod
    def get_pipeline_config(projectid):
        """
        Description : This method will call the dao function to fetch data from db.
        :param projectid  : the id of the project for which data is required.
        :return    : A dict containing all the relevant data.
        """
        response = ObjPipelineSettings(
                pipeline_data=''
            )
        try:
            data = ProjectDAO.get_pipeline_settings(projectid)
            print(data)
            response = ObjPipelineSettings(
                pipeline_data=json.dumps(data)
            )
        except Exception as e:
            logger.error("error occured while fetching data for project with id {}".format(projectid))
        return response

    @staticmethod
    @auth
    def get_project_config(projectid):
        logger.info("[Start]: get_project_config")
        response = []
        try:
            response = WorkdivDao.make_workdiv_obj(projectid)
        except Exception as error_obj:
            logger.error(error_obj)
            raise GraphQLError(Error.get_error_object(sys.exc_info()[0].__name__))
        logger.info("[Exit]: get_project_config")
        return response

    @staticmethod
    def user_signup(username, password, first_name, last_name, mobile_number,
                    role, security_question, security_answer,
                    auto_captcha, user_captcha):
        security = {}
        logger.info("[Start]: user_signup")
        response = []
        # isValidCaptcha = None
        isValidCaptcha = UserDAO.validate_captcha(user_captcha, auto_captcha)
        if not isValidCaptcha:
            logger.error("Captcha doesn't match.")
            print("[INFO]:Captcha doesn't match.")
            raise GraphQLError(Error.get_error_object(sys.exc_info()[0].__name__))
        try:
            new_user = SignUp.user_signup({
                'login': username,
                "password_hash": EncryptionUtils.generate_hash(password),
                "first_name": first_name,
                "last_name": last_name,
                "activated": 0,
                "mobile_number": mobile_number,
                "security": EncryptionUtils.generate_hash(security_question + '@' + security_answer)
            })
        except Exception as err:
            raise GraphQLError(Error.get_error_object(sys.exc_info()[0].__name__))
        logger.info("[Start]: user_signup")
        response = ObjUser(
            username=username,
            role=role,
            userid=2,
            first_name=first_name,
            last_name=last_name,
            mobile_number=mobile_number,
            newuser=new_user,
            auto_captcha=auto_captcha,
            user_captcha=user_captcha
        )
        return response

    @staticmethod
    def get_question(username):
        '''
        Input: username
        Return: Object containing security question and answer
        '''
        logger.info("[Start]: get_question")
        response = []
        try:
            response = UserDAO.getquestion(username)
        except Exception as error_obj:
            logger.error(error_obj)
            #raise GraphQLError(Error.get_error_object(sys.exc_info()[0].__name__))
        logger.info("[Exit]: get_question")
        return response
    
    @staticmethod
    def reset_password(username,newPass):
        '''
        Input: username, newPass (new password)
        Return: Status of reset operation (True or False)
        '''
        logger.info("[Start]: reset_password")
        try:
            response = UserDAO.resetpassword(username,newPass)
            
        except Exception as error_obj:
            logger.error(error_obj)
            raise GraphQLError(Error.get_error_object(sys.exc_info()[0].__name__))
        logger.info("[Exit]: reset_password")
        return response

    @staticmethod
    @auth
    def load_settings_to_json(userid):
        logger.info("[Start]: load_settings_to_json")
        response = ObjResponse(
            status = False
        )
        try:
            SettingsUtils.update_json()
            response = ObjResponse(
                status = True
            )
        except Exception as error_obj:
            logger.error(error_obj)
            raise GraphQLError(Error.get_error_object(sys.exc_info()[0].__name__))
        logger.info("[Exit]: load_settings_to_json")
        return response


    @staticmethod
    @auth
    def lastSelectedProject(userid,role,projectid):
        logger.info("[Start]: lastSelectedProject")
        response = None
        try:
            response = ProjectDAO.update_last_project(userid,role,projectid)
        except Exception as error_obj:
            logger.error(error_obj)
            raise GraphQLError(Error.get_error_object(sys.exc_info()[0].__name__))
        logger.info("[Exit]: lastSelectedProject")
        return response

    @staticmethod
    def acknowledge_data_pipeline(projectid):
        logger.info("[Start]: acknowledge_data_pipeline")
        response = None
        try:
            response = ProjectDAO.get_acknowledgement_data(projectid) 
        except Exception as error_obj:
            logger.error(error_obj)
            raise GraphQLError(Error.get_error_object(sys.exc_info()[0].__name__))
        logger.info("[Exit]: acknowledge_data_pipeline")
        return response

    @staticmethod
    @auth
    def get_text_moderation_obj(project_id, userid, videoid, video_type, f):
        tm = TextModeration(userid, project_id)
        try:
            tm_data = tm.get_new(videoid, f)
            return ObjTextModeration(
                id=f,
                videoname=tm_data['video_name'],
                text=tm_data['text'],
                annos=tm_data['annos'],
                # text=file_path,
                fileId=0,
                videoId=videoid,
                video_type=video_type
            )
        finally:
            tm.close()

    @staticmethod
    @auth
    def save_text_moderation_obj(project_id, userid, videoid, annos, video_type, f):
        tm = TextModeration(userid, project_id)
        try:
            tm_data = tm.set_new(videoid, f, annos)
            return ObjTextModeration(
                id=f,
                videoname=tm_data['video_name'],
                text=tm_data['text'],
                annos=tm_data['annos'],
                fileId=0,
                videoId=videoid,
                video_type=video_type
            )
        finally:
            tm.close()
