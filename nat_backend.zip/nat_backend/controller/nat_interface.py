import os
import random
import json

# Custom packages
from structures.data_structures import *
from dao.data import Data
from utils.image_utils import ImageUtils
from commons import constants as cfg
from utils.ops_encrypt import EncryptDecrypt as ed
from utils.logger import Logger
from auth import (
    create_access_token,
    auth)
logger = Logger.get_logger()

class NatInterface(object):
    @staticmethod
    @auth
    def make_obj_detect_label_opt(label):
        logger.info("[Start]: get_obj_detect_label_opts")
        color_label = None
        try:
          color_label = ColorLabel(
            value=label['value'],
            text=label['text'],
            color=label['color']
          )

        except Exception as error_obj:
          logger.error(error_obj)
        return color_label

    @staticmethod
    @auth
    def get_obj_detect_label_opts(project):
        logger.info("[Start]: get_obj_detect_label_opts")
        opts = []
        try:

          labels = Data.get_obj_detect_label_opts(cfg.AUTOMATION_PATH)

          for label in labels:
              opts.append(NatInterface.make_obj_detect_label_opt(label))
        except Exception as error_obj:
          logger.error(error_obj)
        logger.info("[Exit]: get_obj_detect_label_opts")
        return opts

    @staticmethod
    @auth
    def make_obj_detect_image(id_, project, img,imageId,videoId,videoPath,imagecounts,videoname,image_name, video_type,
                              width, height, orientation=1):
        logger.info("[Start]: make_obj_detect_image")
        try:
          path =os.path.split(videoPath)
          mainpath = path[0]
          lastfolder = path[1]
          print("*************", lastfolder)
          perviosfolder=os.path.split(path[0])
          projectPath =perviosfolder[1]+'/'+lastfolder
          cfg.LAST_PATH = lastfolder
          project_path = os.path.join(cfg.BASE_PATH, cfg.PROJECT_NAME,cfg.LAST_PATH)
          cfg.MEDIA_PATH = os.path.join(project_path,'images')
          cfg.JSON_PATH = os.path.join(project_path,'json')
          print(Data.make_url(lastfolder, image_name))
          src = ed.encode_incoming(Data.make_url(lastfolder, image_name))
          annos = [] if img is None else img['annotations']
          logger.debug("[Start]: json_dumps")
          annos_json = json.dumps(annos)
          logger.debug("[Exit]: json_dumps")
          orientation = orientation if orientation is not None else 1
        except Exception as error_obj:
          logger.error(error_obj)
        logger.info("[Exit]: make_obj_detect_image")
        return ObjVideoImage(
          id=image_name,
          project=project,
          videoname=videoname,
          src=src,
          imageId=imageId,
          videoId=videoId,
          videopath=ed.encode_incoming(videoPath),
          imagecount=imagecounts,
          annotations=[], #AnnotationUtils.make_annotations(annos),
          labels=None, #NatInterface.get_obj_detect_label_opts(project)
          orientation=int(orientation),
          annos_json=annos_json,
          video_type= video_type,
          width = width,
          height = height
        )

    @staticmethod
    @auth
    def get_random_batch(proj_name, dset, shuffle=False, limit=20):
        logger.info("[Start]: get_random_batch")
        image_data = []
        try:
          fold = Data.load_fold(proj_name,'')
          ids = list(fold[dset].keys())
          if shuffle:
              random.shuffle(ids)
          for id_ in ids[:limit]:
              image_data.append(ImageUtils.make_image(id_, fold, dset))
        except Exception as error_obj:
          logger.error(error_obj)
        return image_data

    @staticmethod
    @auth
    def get_ranked_batch(proj_name, dset, limit=cfg.BATCH_SIZE):
        logger.info("[Start]: get_ranked_batch")
        image_data = []
        try:
          fold = Data.load_fold(proj_name,'')
          preds_df = pd.read_csv(
              Data.get_fpath(proj_name, cfg.RANKINGS_FNAME),
              index_col=0)
          i = 0
          for id_, row in preds_df.iterrows():
              if i > limit:
                  return image_data
              if id_ in fold[dset]:
                  image_data.append(ImageUtils.make_image(
                      id_, fold, dset))
                  i += 1
        except Exception as error_obj:
          logger.error(error_obj)
        return image_data
