import os
from flask import Flask
from flask_cors import CORS
from flask_graphql import GraphQLView
from schema import *
from flask import Response, request, abort, send_from_directory
from io import StringIO
from flask import Blueprint

from flaskext.mysql import MySQL
import json
from commons import constants as cfg
from nat_3D_Backend.dao.FetchVideoId_dao import FetchVideoIDDAO
from nat_3D_Backend.commons.getfolderpath import FetchFolderPath
from utils.settings_utils import SettingsUtils
from dao.data import Data
from utils.logger import Logger
logger = Logger.get_logger()


class localFlask(Flask):
    def process_response(self, response):
        response.headers['server'] = None
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['X-XSS-Protection'] = '1; mode=block'
        response.headers['Cache-Control'] = 'no-store,no-cache'
        response.headers['Content-Security-Policy'] = 'default-src \'self\''


        super(localFlask, self).process_response(response)
        return(response)



def create_app(**kwargs):
    app = localFlask(__name__)
    CORS(app, supports_credentials=True, resources={r'/*': {'origins': [ '*' ]}})
    logger.info("inside create_app")
    app.add_url_rule(
        '/graphql',
        view_func=GraphQLView.as_view('graphql', schema=Schema, **kwargs)
    )
    logger.info("Exit create_app")
    return app

application = create_app(graphiql=True)
app = application

@app.route('/img/noesis_data/<source>')
def image(source, filename):
    logger.info("[Start]: image")
    project_path = SettingsUtils.get_value_by_key(SettingsUtils.KEY_DATAPATH)
    img_dir = os.path.join(project_path, os.path.join(source, 'images'))
    logger.info("Inside image path Expose ")
    MEDIA_FOLDER = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(filename)))), img_dir)
    logger.info("Exit image path Expose MEDIA_FOLDER %s ",MEDIA_FOLDER)
    logger.info("[Exit]: image")
    return send_from_directory(MEDIA_FOLDER, filename)

@app.route('/img/noesis_data/<source>/<filename>')
def video(source, filename):
    logger.info("[Start]: video")
    # project_path = SettingsUtils.get_value_by_key(SettingsUtils.KEY_DATAPATH)
    # img_dir = os.path.join(project_path, os.path.join(source, 'images'))
    img_dir = cfg.MEDIA_PATH
    MEDIA_FOLDER = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(filename)))), img_dir)
    logger.info("[Exit]: video")
    return send_from_directory(MEDIA_FOLDER, filename)

@app.route('/img_path/noesis_data/<source>/<filename>')
def get_image(source, filename):
    '''
        Sample URL: http://localhost:5000/img_path/noesis_data/demo_data_d2c1/0.jpg
    '''
    logger.info("[Start]: get_image")
    try:
        image_id = int(filename.replace(".jpg", ""))
        project_path = SettingsUtils.get_value_by_key(SettingsUtils.KEY_DATAPATH)
        img_dir = os.path.join(project_path, os.path.join(source, 'images'))
        sorted_files = Data.sort_dir_image_list(img_dir)
        image_name = Data.get_image_name(sorted_files, image_id)
        MEDIA_FOLDER = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(image_name)))), img_dir)
    except Exception as error_obj:
        logger.error(error_obj)
    logger.info("[Exit]: get_image")
    return send_from_directory(MEDIA_FOLDER, image_name)

@app.route('/img/noesis_data/<vid_name>/<folder_name>/<cam_channel>/<filename>')
def get_image_3D(vid_name, folder_name, cam_channel, filename):
    """
       Sample URL: http://localhost:5000/img/noesis_data/NuScenes/images/CAM_FRONT_LEFT/000048.jpg
    """
    logger.info("[INFO]: Inside get_images_3D")
    try:
        video_id = FetchVideoIDDAO(vid_name).video_name()
    except Exception as e:
        logger.error(e)
    try:
        folder_path = FetchFolderPath(video_id).fetch_folder_path()
    except Exception as e:
        logger.error(e)
    abs_p = os.path.join(folder_path, vid_name, folder_name, cam_channel)
    return send_from_directory(abs_p, filename)

@app.route('/img/noesis_data/<vid_name>/<folder_name>/<filename>')
def get_pcd_3D(vid_name, folder_name, filename):
    """
       Sample URL: "http://localhost:5000/img/noesis_data/NuScenes/pointclouds/000048.pcd"
    """
    logger.info("[INFO]: Inside get_pcd_3D")
    try:
        video_id = FetchVideoIDDAO(vid_name).video_name()
    except Exception as e:
        logger.error(e)
    try:
        folder_path = FetchFolderPath(video_id).fetch_folder_path()
    except Exception as e:
        logger.error(e)
    abs_p = os.path.join(folder_path, vid_name, folder_name)
    return send_from_directory(abs_p, filename)

if __name__ == '__main__':
    application.run(host='0.0.0.0', threaded=True)
