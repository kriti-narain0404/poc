from xml.etree.ElementTree import Element, SubElement, Comment, tostring
import xml.dom.minidom
import json
import sys
import os
from PIL import Image

def convert(fold, videopath, imagename, target_filename, params_vals):
    response = None
    try:
        im = Image.open(os.path.join(videopath, 'images', imagename + '.jpg'))
        width, height = im.size

        data = Element('annotation')
        child_filename = SubElement(data, 'filename')
        child_filename.text = imagename

        child_source = SubElement(data, 'source')
        child = SubElement(child_source, 'database')
        child.text = "The VOC2007 Database"
        child = SubElement(child_source, 'annotation')
        child.text = "PASCAL VOC2007"
        child = SubElement(child_source, 'image')
        child.text = "dummy"
        child = SubElement(child_source, 'flickrid')
        child.text = "000000000"

        child_owner = SubElement(data, 'owner')
        child = SubElement(child_owner, 'flickrid')
        child.text = "Panasonic"
        child = SubElement(child_owner, 'name')
        child.text = "dummy"

        child_pre = SubElement(data, 'pre')
        child_size = SubElement(child_pre, 'size')
        child = SubElement(child_size, 'width')
        child.text = str(width)
        child = SubElement(child_size, 'height')
        child.text = str(height)
        child = SubElement(child_size, 'depth')
        child.text = "3"

        child_segmented = SubElement(data, 'segmented')
        child_segmented.text = 0

        fail = 0

        for obj in fold['img'][imagename]['annotations']:
            try:
                if obj['bbox'] is not None:
                    annotation = obj['bbox']
                elif obj['polygon'] is not None:
                    annotation = obj['polygon']
                child_object = SubElement(data, 'object')
                child = SubElement(child_object, 'name')
                child.text = annotation['label']
                child = SubElement(child_object, 'id')
                child.text = annotation['id']
                for param in annotation['parameters']:
                    child = SubElement(child_object, param['nam'])
                    try:
                        child.text = str(params_vals.get(param['nam']).get(param['val']))
                    except:
                        child.text = str(param['val'])
                child = SubElement(child_object, 'bndbox')
                child2 = SubElement(child, 'xmin')
                child2.text = str(annotation['xmin'])
                child2 = SubElement(child, 'ymin')
                child2.text = str(annotation['ymin'])
                child2 = SubElement(child, 'xmax')
                child2.text = str(annotation['xmax'])
                child2 = SubElement(child, 'ymax')
                child2.text = str(annotation['ymax'])
            except Exception as error_obj:
                fail += 1

        dom = xml.dom.minidom.parseString(tostring(data))
        pretty_xml_as_string = dom.toprettyxml()

        filepath = os.path.join(videopath, target_filename)
        open(filepath, 'w').write(pretty_xml_as_string)
        if fail != 0:
            print("Failed to convert %s objects" % (str(fail)))
    except Exception as error_obj:
        print(error_obj)
    print("[Exit]: json_to_xml")
    return response

def get_annotations(filepath):
    data = None
    try:
        with open(filepath) as f:
            data = json.load(f)
    except Exception as error_obj:
        raise
    return data

if __name__ == "__main__":
    try:
        videopath = sys.argv[1]
        imagename = sys.argv[2]

        try:
            sourcefile = sys.argv[3]
        except:
            sourcefile = os.path.join(videopath, 'json', imagename+'_label.json')

        try:
            targetfile = sys.argv[4]
        except:
            targetfile = os.path.join(videopath, 'json', imagename+'.xml')

        #Sample params array
        params = {
            'Sex': {1: 'Female', 2: 'Male', 9: 'Not Sure'},
            'Age': {1: 'Infant', 2: 'Kid', 3: 'Teen', 4: 'Adult', 5: 'Senior', 9: 'Not Sure'},
            'SkinColor': {1: 'Black', 2: 'White', 3: 'Yellow', 9: 'Not Sure'},
        }

        data = get_annotations(sourcefile)
        convert(data, videopath, imagename, targetfile, params)
    except Exception as error_obj:
        print(error_obj)
    print("[Exit]: In main - json_to_xml")




