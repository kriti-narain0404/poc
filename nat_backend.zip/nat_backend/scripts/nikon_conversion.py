import os, sys
import pandas as pd
import json
import re
from PIL import Image
import shutil
from PIL.ExifTags import TAGS

pattern1 = re.compile("^.*(_+\S*)$")
pattern2 = re.compile("^.*(_+[0-9]*)$")

# folders = ['nikon_set1_2_d2c5']

bodyparts_list = ['hairline', 'right ear', 'left ear', 'nose', 'right eye', 'left eye', 'center of lower lip',
             'right corner of mouth', 'left corner of mouth', 'jaw', 'right shoulder', 'left shoulder',
             'right elbow', 'left elbow', 'right wrist', 'left wrist', 'right hip', 'left hip',
             'right knee', 'left knee', 'right ankle', 'left ankle', 'right toe', 'left toe',
             'right fingertips 1', 'right fingertips 2', 'right fingertips 3', 'right fingertips 4', 'right fingertips 5',
             'left fingertips 6', 'left fingertips 7', 'left fingertips 8', 'left fingertips 9', 'left fingertips 10']

def process_parameters(parameters):
    try:
        params = {}
        for p in parameters:
            params[p["nam"]] = p["val"]
        for key, val in params.items():
            params[key] = int(params[key])
            if key == "Id":
                if val == 99:
                    params[key] = 0
                else:
                    params[key] = val
            elif key == "Sex":
                if val == 1:
                    params[key] = "Female"
                elif val == 2:
                    params[key] = "Male"
                elif val == 9:
                    params[key] = "Not Sure"
            elif key == "Age":
                if val == 1:
                    params[key] = "Infant"
                elif val == 2:
                    params[key] = "Kid"
                elif val == 3:
                    params[key] = "Teen"
                elif val == 4:
                    params[key] = "Adult"
                elif val == 5:
                    params[key] = "Senior"
                elif val == 9:
                    params[key] = "Not Sure"
            elif key == "SkinColor":
                if val == 1:
                    params[key] = "Black"
                elif val == 2:
                    params[key] = "White"
                elif val == 3:
                    params[key] = "Yellow"
                elif val == 9:
                    params[key] = "Not Sure"
            elif key == "EyeState":
                if val == 1:
                    params[key] = "Open"
                elif val == 2:
                    params[key] = "Close"
                elif val == 9:
                    params[key] = "Not Sure"
            elif key == "Mask":
                if val == 1:
                    params[key] = "Yes"
                elif val == 2:
                    params[key] = "No"
                elif val == 9:
                    params[key] = "Not Sure"
            elif key == "Sunglass":
                if val == 1:
                    params[key] = "Yes"
                elif val == 2:
                    params[key] = "No"
                elif val == 9:
                    params[key] = "Not Sure"
            elif key == "Hat":
                if val == 1:
                    params[key] = "Yes"
                elif val == 2:
                    params[key] = "No"
                elif val == 9:
                    params[key] = "Not Sure"
            elif key == "FacialExpression":
                if val == 1:
                    params[key] = "Smile"
                elif val == 2:
                    params[key] = "Sad"
                elif val == 3:
                    params[key] = "Surprise"
                elif val == 4:
                    params[key] = "Angry"
                elif val == 9:
                    params[key] = "Not Sure"
            elif key == "Action_Pose":
                if val == 1:
                    params[key] = "Standing"
                elif val == 2:
                    params[key] = "Sitting"
                elif val == 3:
                    params[key] = "Walking"
                elif val == 4:
                    params[key] = "Jumping"
                elif val == 5:
                    params[key] = "Sleeping"
                elif val == 6:
                    params[key] = "Playing"
                elif val == 7:
                    params[key] = "Riding"
                elif val == 8:
                    params[key] = "Crying"
                elif val == 9:
                    params[key] = "Smiling"
                elif val == 10:
                    params[key] = "Swimming"
                elif val == 11:
                    params[key] = "Eating"
                elif val == 12:
                    params[key] = "Running"
                elif val == 99:
                    params[key] = "Not Sure"
        return params
    except Exception as e:
        raise e

def process_annos(annos, width, height):
    result = []
    try:
        persons = {}
        keypoints = {}
        person_ids = set()
        for anno in annos:
            try:
                lbl = anno['label']
                if lbl == "person":
                    params = process_parameters(anno["bbox"]["parameters"])
                    person_id = params["Id"]
                    del params["Id"]
                    persons[person_id] = params
                else:
                    grp = pattern1.search(lbl)
                    visible = 0
                    if grp:
                        if grp.groups()[0] == "_i":
                            visible = 1
                            lbl = lbl.replace('_i', '')

                    grp = pattern2.search(lbl)
                    if grp:
                        person_id = grp.groups()[0].replace('_', '')
                        bodypart = lbl.replace('_'+person_id, '')
                        person_id = int(person_id)
                    else:
                        person_id = 0
                        bodypart = lbl

                    xi = round(anno["polygon"]["points"][0]["x"], 2)
                    yi = round(anno["polygon"]["points"][0]["y"], 2)

                    if person_id in keypoints:
                        keypoints[person_id][bodypart] = [visible,x,y]
                    else:
                        keypoints[person_id] = {bodypart: [visible,x,y]}
                person_ids.add(person_id)
            except:
                pass
           
        for person_id in person_ids:
            if person_id not in persons:
                persons[person_id] = {
                    "SkinColor": "Not Sure",
                    "EyeState": "Not Sure",
                    "FacialExpression": "Not Sure",
                    "Sex": "Not Sure",
                    "Sunglass": "Yes",
                    "Hat": "Not Sure",
                    "Action_Pose": "Not Sure",
                    "Mask": "Not Sure",
                    "Age": "Not Sure"
                }
        bodyparts = {i:[] for i in person_ids}
        for person_id, kps in keypoints.items():
            for bp in bodyparts_list:
                if bp in kps:
                    bodyparts[person_id].extend(kps[bp])
                else:
                    bodyparts[person_id].extend([1,0,0])

        for key, bodypart in bodyparts.items():
            if key in persons:
                persons[key]["keypoints"] = bodypart
            else:
                persons[key] = {
                    "keypoints": bodypart
                }
        for key, person in persons.items():
            result.append(person)
        return result
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        print("Error in process_annos", e, exc_type, fname, exc_tb.tb_lineno)
       
        raise e

def convert(data, videopath, imagename, targetfile):
    try:
        im = Image.open(os.path.join(videopath, 'images', imagename + '.jpg'))
        width, height = im.size
        result = process_annos(data, width, height)
        outjson = {
            "file_name": imagename + ".jpg",
            "dimensions": [width, height],
            "data": {
                "people": result
            }
        }
        with open(targetfile, 'w') as fp:
            json.dump(outjson, fp, indent=4, sort_keys=False)
    except Exception as error_obj:
        print(error_obj)

def get_annotations(filepath):
    data = None
    try:
        with open(filepath) as f:
            data = json.load(f)
    except Exception as error_obj:
        raise
    return data

if __name__ == "__main__":
    print("[Start]: In main - nikon_conversion")
    try:
        videopath = sys.argv[1]
        imagename = sys.argv[2]

        try:
            sourcefile = sys.argv[3]
        except:
            sourcefile = os.path.join(videopath, 'json', imagename+'_label.json')

        try:
            targetfile = sys.argv[4]
        except:
            targetfile = os.path.join(videopath, 'json', imagename+'_converted.json')

        data = get_annotations(sourcefile)
        convert(data, videopath, imagename, targetfile)
    except Exception as error_obj:
        print(error_obj)
    print("[Exit]: In main - nikon_conversion")
