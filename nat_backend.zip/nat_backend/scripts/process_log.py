import os
import re
import pandas as pd
import datetime
import math

log_path = 'C:\\NAT\\logs\\'
log_filename = os.path.join(log_path, 'nat_app.log')
out_filename = os.path.join(log_path, 'nat_app.log.csv')

with open(log_filename, 'r') as file:
    dfCols = ['Filename', 'Function', 'Start', 'Exit', 'DiffSecs', 'DiffMs']
    df = pd.DataFrame(columns=dfCols)
    fndict = {}
    for line in file:
        try:
            splitted_line = list(re.findall(r"[\w']+", line) )

            action = splitted_line[11]
            if action not in ['Start', 'Exit']:
                continue
            tm = ":".join(splitted_line[3:7])
            filename = ".".join(splitted_line[8:10])
            functioname = splitted_line[12]
            try:
                fndict[functioname][action] = tm
            except:
                fndict[functioname] = {
                    'filename': filename,
                    'Start': '',
                    'Exit': '',
                    'DiffMs': '',
                    'DiffSecs': ''
                }
                fndict[functioname][action] = tm

            try:
                if fndict[functioname]['Start'] and fndict[functioname]['Exit']:
                    start = datetime.datetime.strptime(fndict[functioname]['Start'], '%H:%M:%S:%f')
                    exit = datetime.datetime.strptime(fndict[functioname]['Exit'], '%H:%M:%S:%f')
                    diff = exit - start
                    secs = diff.seconds
                    micro = diff.microseconds
                    millis = math.ceil(micro/1000)
                    df = df.append({
                        'Filename': fndict[functioname]['filename'],
                        'Function': functioname,
                        'Start': fndict[functioname]['Start'],
                        'Exit': fndict[functioname]['Exit'],
                        'DiffSecs': secs,
                        'DiffMs': millis,
                    }, ignore_index=True)
                    del fndict[functioname]
            except Exception as e:
                pass

            
        except Exception as e:
            pass
    df.to_csv(out_filename)

