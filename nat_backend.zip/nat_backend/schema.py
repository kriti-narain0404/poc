import os
from flask import Flask
from flask_cors import CORS
from flask_graphql import GraphQLView
from collections import namedtuple, OrderedDict
from graphql import (
  GraphQLField, GraphQLNonNull, GraphQLArgument,
  GraphQLObjectType, GraphQLList, GraphQLBoolean, GraphQLString,
  GraphQLSchema, GraphQLInt, GraphQLFloat, GraphQLInputObjectType,
  GraphQLInputObjectField
)
from flaskext.mysql import MySQL
from nat_3D_Backend.utils.Save_JsonData import SaveJsonFile
from utils.ops_encrypt import EncryptDecrypt
import base64
# User defined packages
from structures.nat_gql_datatype import *
from controller.nat_mutations import NatMutation
from dao.user_dao import UserDAO
from utils.common_utils import CommonUtils
from controller.nat_queries import NatQuery
from structures.nat_gql_datatype import NatGQLDataTypes
from commons import constants as cfg
from controller.nat_config_controller import NATConfigController

from nat_3D_Backend.structures.nat_datatype_3D import NatDataTypes3d
from nat_3D_Backend.controller.nat_mutations_3D import NatMutation3D

QueryRootType = GraphQLObjectType(
    name='Query',
    fields=lambda: {

        'image': GraphQLField(
            NatGQLDataTypes.ImageType,
            args={
                'id': GraphQLArgument(GraphQLString)
            },
            resolver=lambda root, args, *_: NatQuery.get_image_single(args.get('id')),
        ),

        'defaultObjVideoImage': GraphQLField(
            NatGQLDataTypes.ObjVideoImageType,
            args={
                'project': GraphQLArgument(GraphQLString),
                'videoid': GraphQLArgument(GraphQLInt),
                'imageid': GraphQLArgument(GraphQLInt)

            },
            resolver=lambda root, args, *_: NatQuery.get_default_obj_video_img(
                args.get('project'), args.get('videoid'), args.get('imageid')
            ),
        ),

        'nextObjDetectImage': GraphQLField(
            NatGQLDataTypes.ObjDetectImageType,
            args={
                'project': GraphQLArgument(GraphQLString),
                'currinitentId': GraphQLArgument(GraphQLString)
            },
            resolver=lambda root, args, *_: NatQuery.get_next_obj_detect_img(
                args.get('project'), args.get('currentId')
            ),
        ),

        'objDetectLabelOpts': GraphQLField(
            NatGQLDataTypes.ObjDetectLabelOptsType,
            args={
                'project': GraphQLArgument(GraphQLString)
            },
            resolver=lambda root, args, *_: NatQuery.get_obj_detect_label_opts(
                args.get('project')
            ),
        ),

        'imageList': GraphQLField(
            NatGQLDataTypes.ImageListType,
            args={
                'project': GraphQLArgument(GraphQLString)
            },
            resolver=lambda root, args, *_: NatQuery.get_image_list(
                args.get('project')
            ),
        ),

        'getSettingObject': GraphQLField(
            NatGQLDataTypes.SettingObjectType,
            args={
                'userid': GraphQLArgument(GraphQLInt),
                'projectId': GraphQLArgument(GraphQLInt),
                'fromFile': GraphQLArgument(GraphQLInt, default_value=0),
                'video_id': GraphQLArgument(GraphQLInt, default_value=-1)
            },
            resolver=lambda root, args, *_: NatQuery.get_setting_object(
                args.get('userid'),
                args.get('projectId'),
                args.get('fromFile'),
                args.get("video_id")
            ),
        ),

        'downloadVideos': GraphQLField(
            NatGQLDataTypes.ObjVideoType,
            args={
                'userid': GraphQLArgument(GraphQLInt)
            },
            resolver=lambda root, args, *_: NatQuery.download_videos(
                args.get('userid')
            ),
        ),

        'modifiedFilesCount': GraphQLField(
            NatGQLDataTypes.ObjModifiedFilesCountType, args={},
            resolver=lambda root, args, *_: NatQuery.get_modified_files_count(),
        ),

        'getMetricsDetails': GraphQLField(
            NatGQLDataTypes.ObjResponseType,
            args={
              'videoid': GraphQLArgument(GraphQLInt),
            },
            resolver=lambda root, args, *_: NatQuery.get_metrics_details(
              args.get('videoid'))
        ),

        'getUserListObj': GraphQLField(
            NatGQLDataTypes.ObjUserListType,
            args={
                'userid': GraphQLArgument(GraphQLInt),
                'proId': GraphQLArgument(GraphQLInt)   #Passed because doesnot acceps blank
            },
            resolver=lambda root, args, *_: NatMutation.get_user_list_obj(
                args.get('userid'), args.get('proId')
            )
        ),
    }
)

MutationRootType = GraphQLObjectType(
    name='Mutation',
    fields=lambda: {

        'updateImageTags': GraphQLField(
            NatGQLDataTypes.ImageType,
            args={
                'id': GraphQLArgument(GraphQLString),
                'project': GraphQLArgument(GraphQLString),
                'tags': GraphQLArgument(GraphQLList(GraphQLString))
            },
            resolver=lambda root, args, *_: NatMutation.update_tags(
                args.get('id'),
                args.get('project'),
                args.get('tags')
            )
        ),

        'getProjectConfig': GraphQLField(
            NatGQLDataTypes.WorkDivType,
            args={
                'projectid': GraphQLArgument(GraphQLInt)   #Passed because doesnot acceps blank
            },
            resolver=lambda root, args, *_: NatMutation.get_project_config(args.get('projectid'))
        ),

        'getPipelineConfig': GraphQLField(
            NatGQLDataTypes.PipelineType,
            args={
                'projectid': GraphQLArgument(GraphQLInt)
            },
            resolver=lambda root, args, *_: NatMutation.get_pipeline_config(args.get('projectid'))
        ),

        'reopenVideo': GraphQLField(
            NatGQLDataTypes.ObjResponseType,
            args={
                'videoid': GraphQLArgument(GraphQLList(GraphQLInt))
            },
            resolver=lambda root, args, *_: NatMutation.reopen_video(
                args.get('videoid')
            )
        ),

        'updateSettings': GraphQLField(
            NatGQLDataTypes.ObjResponseType,
            args={
                'userid': GraphQLArgument(GraphQLInt)
            },
            resolver=lambda root, args, *_: NatMutation.load_settings_to_json(
                args.get('userid')
            )
        ),
        
        'afterSaveFrame': GraphQLField(
            NatGQLDataTypes.ObjResponseType,
            args={
                'videoid': GraphQLArgument(GraphQLInt),
                'videoname': GraphQLArgument(GraphQLString)
            },
            resolver=lambda root, args, *_: NatMutation.after_save_frame(
                args.get('videoid'),
                args.get('videoname')
            )
        ),

        'nextObjVideoImage': GraphQLField(
          NatGQLDataTypes.ObjVideoImageType,
          args={
            'project': GraphQLArgument(GraphQLString),
            'videoname': GraphQLArgument(GraphQLString),
            'videoid': GraphQLArgument(GraphQLInt),
            'imageid': GraphQLArgument(GraphQLInt),
            'video_type':  GraphQLArgument(GraphQLInt),
            'file': GraphQLArgument(GraphQLString),
            'base64Image': GraphQLArgument(GraphQLString),
            'auto_annotations': GraphQLArgument(GraphQLList(NatGQLDataTypes.AnnotationInputType)),
            'copy_mode': GraphQLArgument(GraphQLString),
            'configure_flag': GraphQLArgument(GraphQLInt),
            'project_id': GraphQLArgument(GraphQLInt),
            'userid': GraphQLArgument(GraphQLInt),
          },
          resolver=lambda root, args, *_: NatMutation.get_next_obj_video_img(
              0, args.get('project'), args.get('videoname'), args.get('videoid'),
              args.get('imageid'), args.get('video_type'), args.get('file'),
              args.get('base64Image'), args.get('auto_annotations'), args.get('copy_mode'),
              args.get('configure_flag'), args.get('project_id'), args.get('userid')
          ),
        ),

        'prevObjVideoImage': GraphQLField(
          NatGQLDataTypes.ObjVideoImageType,
          args={
            'project': GraphQLArgument(GraphQLString),
            'videoname': GraphQLArgument(GraphQLString),
            'videoid': GraphQLArgument(GraphQLInt),
            'imageid': GraphQLArgument(GraphQLInt),
            'video_type':  GraphQLArgument(GraphQLInt),
            'file': GraphQLArgument(GraphQLString),
            'base64Image': GraphQLArgument(GraphQLString),
            'auto_annotations': GraphQLArgument(GraphQLList(NatGQLDataTypes.AnnotationInputType)),
            'copy_mode': GraphQLArgument(GraphQLString),
            'configure_flag': GraphQLArgument(GraphQLInt),
            'project_id': GraphQLArgument(GraphQLInt),
            'userid': GraphQLArgument(GraphQLInt),
          },
          resolver=lambda root, args, *_: NatMutation.get_next_obj_video_img(1,
            args.get('project'), args.get('videoname'), args.get('videoid'),
            args.get('imageid'), args.get('video_type'), args.get('file'), args.get('base64Image'), args.get('auto_annotations'),
            args.get('copy_mode'), args.get('configure_flag'), args.get('project_id'), args.get('userid')
          ),
        ),

        'getProductivityMetrics': GraphQLField(
            NatGQLDataTypes.ProductivityResponseType,
            args={
              'userid': GraphQLArgument(GraphQLInt),
              'username': GraphQLArgument(GraphQLString),
              'userrole': GraphQLArgument(GraphQLString),
              'from_date': GraphQLArgument(GraphQLString),
              'to_date': GraphQLArgument(GraphQLString),
              'p_id': GraphQLArgument(GraphQLInt),
              'active_tab': GraphQLArgument(GraphQLString)
            },
            resolver=lambda root, args, *_: NatMutation.get_productivity_metrics_updated(
              args.get('userid'), args.get('username'), args.get('userrole'), args.get('from_date'), args.get('to_date'),args.get('p_id'), args.get("active_tab"))
          ),
		    'getPerformanceChart': GraphQLField(
            NatGQLDataTypes.ObjResponseType,
            args={
              'userid': GraphQLArgument(GraphQLInt),
              'username': GraphQLArgument(GraphQLString),
              'userrole': GraphQLArgument(GraphQLString),
              'p_id': GraphQLArgument(GraphQLInt),
            },
            resolver=lambda root, args, *_: NatMutation.get_performance_chart(
              args.get('userid'), args.get('username'), args.get('userrole'), args.get('p_id'))
          ),
		    'changeOrientation': GraphQLField(
            NatGQLDataTypes.ObjResponseType,
            args={
              'videoname': GraphQLArgument(GraphQLString),
              'filename': GraphQLArgument(GraphQLString),
              'orientation': GraphQLArgument(GraphQLInt),
            },
            resolver=lambda root, args, *_: NatMutation.change_orientation(
              args.get('videoname'), args.get('filename'), args.get('orientation'))
          ),
        'doFloodFill': GraphQLField(
          NatGQLDataTypes.ImgProcType,
          args={
            'videoid': GraphQLArgument(GraphQLInt),
            'imageid': GraphQLArgument(GraphQLInt),
            'videoname':GraphQLArgument(GraphQLString),
            'clickPointX': GraphQLArgument(GraphQLInt),
            'clickPointY': GraphQLArgument(GraphQLInt),
            'tolerance': GraphQLArgument(GraphQLInt)
          },
          resolver=lambda root, args, *_: NatMutation.start_flood_fill(
            args.get('videoid'), args.get('imageid'), args.get('videoname'), args.get('clickPointX'), args.get('clickPointY'),  args.get('tolerance')
          ),
        ),
	   	 'saveObjDetectImage': GraphQLField(
            NatGQLDataTypes.ObjDetectImageType,
            args={
                'id': GraphQLArgument(GraphQLString),
                'project': GraphQLArgument(GraphQLString),
                'annotations': GraphQLArgument(GraphQLList(NatGQLDataTypes.AnnotationInputType)),
                'classwise_data': GraphQLArgument(GraphQLString),
                'videopath': GraphQLArgument(GraphQLString),
                'videoid': GraphQLArgument(GraphQLInt),
                'width': GraphQLArgument(GraphQLInt),
                'height': GraphQLArgument(GraphQLInt),
                'userid': GraphQLArgument(GraphQLInt),
                'projectid': GraphQLArgument(GraphQLInt),
                'is_blur_mode_active': GraphQLArgument(GraphQLBoolean)
            },
            resolver=lambda root, args, *_: NatMutation.save_obj_detect_image(
                args.get('id'), args.get('project'), args.get('annotations'), args.get("classwise_data"),
                args.get('videopath'), args.get('videoid') , args.get('width'), args.get('height'),
                args.get('userid'), args.get('projectid'), args.get('is_blur_mode_active', False))
        ),
        # #################################################################
        'acknowledgeDataPipeline': GraphQLField(
          NatGQLDataTypes.ObjAcknowledgeType,
          args={
            'projectid': GraphQLArgument(GraphQLInt)
          },
          resolver=lambda root, args, *_: NatMutation.acknowledge_data_pipeline(args.get('projectid'))
        ),
        # #################################################################
        'checkSaveObjDetectImageForward': GraphQLField(
            NatGQLDataTypes.ObjDetectImageType,
            args={
                'id': GraphQLArgument(GraphQLString),
                'project': GraphQLArgument(GraphQLString),
                'annotations': GraphQLArgument(GraphQLList(NatGQLDataTypes.AnnotationInputType)),
                'videopath': GraphQLArgument(GraphQLString),
                'videoid': GraphQLArgument(GraphQLInt),
                'width': GraphQLArgument(GraphQLInt),
                'height': GraphQLArgument(GraphQLInt),
            },
            resolver=lambda root, args, *_: NatMutation.check_save_obj_detect_image_forward(
                args.get('id'), args.get('project'), args.get('annotations'), args.get('videopath'), args.get('videoid'))
        ),
        'checkSaveObjDetectImageBackward': GraphQLField(
            NatGQLDataTypes.ObjDetectImageType,
            args={
                'id': GraphQLArgument(GraphQLString),
                'project': GraphQLArgument(GraphQLString),
                'annotations': GraphQLArgument(GraphQLList(NatGQLDataTypes.AnnotationInputType)),
                'videopath': GraphQLArgument(GraphQLString),
                'videoid': GraphQLArgument(GraphQLInt),
                'width': GraphQLArgument(GraphQLInt),
                'height': GraphQLArgument(GraphQLInt),
            },
            resolver=lambda root, args, *_: NatMutation.check_save_obj_detect_image_backward(
                args.get('id'), args.get('project'), args.get('annotations'), args.get('videopath'), args.get('videoid'))
        ),
        'checkSaveObjDetectImage': GraphQLField(
            NatGQLDataTypes.ObjDetectImageType,
            args={
                'id': GraphQLArgument(GraphQLString),
                'project': GraphQLArgument(GraphQLString),
                'annotations': GraphQLArgument(GraphQLList(NatGQLDataTypes.AnnotationInputType)),
                'videopath': GraphQLArgument(GraphQLString),
                'videoid': GraphQLArgument(GraphQLInt),
                'width': GraphQLArgument(GraphQLInt),
                'height': GraphQLArgument(GraphQLInt),
            },
            resolver=lambda root, args, *_: NatMutation.check_save_obj_detect_image(
                args.get('id'), args.get('project'), args.get('annotations'), args.get('videopath'), args.get('videoid'))
        ),
        # #################################################################
	   	 'saveUserListObj': GraphQLField(
            NatGQLDataTypes.ObjResponseType,
            args={
                'userList': GraphQLArgument(GraphQLList(NatGQLDataTypes.UserListInputType))
            },
            resolver=lambda root, args, *_: NatMutation.save_user_list_obj(args.get('userList'))
        ),
      	 'saveScriptObj': GraphQLField(
            NatGQLDataTypes.ObjscriptListType,
            args={
                'scriptList': GraphQLArgument(GraphQLList(NatGQLDataTypes.ScriptListInputType))
            },
            resolver=lambda root, args, *
            _: NatMutation.save_script_list_obj(args.get('scriptList'))
        ),
	  'saveSettingObject': GraphQLField(
            NatGQLDataTypes.ObjResponseType,
            args={
                'userid': GraphQLArgument(GraphQLInt),
                'projectId': GraphQLArgument(GraphQLInt),
                'predType': GraphQLArgument(GraphQLString),
                'modelType': GraphQLArgument(GraphQLString),
                'outputFormat': GraphQLArgument(GraphQLString),
                'folderPath': GraphQLArgument(GraphQLString),
                'minHeight': GraphQLArgument(GraphQLInt),
                'minWidth': GraphQLArgument(GraphQLInt),
                'annoTip': GraphQLArgument(GraphQLString),
                'settingObject': GraphQLArgument(GraphQLList(NatGQLDataTypes.SettingDataInputType)),
                'class_added': GraphQLArgument(GraphQLList(NatGQLDataTypes.ClassAddedInputType)),
                'frames_to_interpolate': GraphQLArgument(GraphQLInt)
            },
            resolver=lambda root, args, *_: NatMutation.save_setting_object(
                args.get('userid'), args.get('projectId'), args.get('settingObject'), args.get('predType'), args.get('modelType'),
                args.get('outputFormat'), args.get('folderPath'), args.get('minHeight'),
                args.get('minWidth'), args.get('annoTip'), args.get('class_added'), args.get('frames_to_interpolate'))
        ),
        'savePreviewVideoData': GraphQLField(
            NatGQLDataTypes.ObjResponseType,
            args={
              'videoid': GraphQLArgument(GraphQLInt),
              'videoname': GraphQLArgument(GraphQLString),
              'taskName': GraphQLArgument(GraphQLString),
              'total_duration': GraphQLArgument(GraphQLString),
              'timestamp': GraphQLArgument( GraphQLList(NatGQLDataTypes.TimeStampInputType))
            },
            resolver=lambda root, args, *_: NatMutation.save_preview_video_details(
                args.get('videoid'),args.get('videoname'),args.get('taskName'),args.get('total_duration'),args.get('timestamp'))
        ),

	   	 'saveUserId': GraphQLField(
            NatGQLDataTypes.UserIdType,
            args={
                'userId': GraphQLArgument(GraphQLInt)
            },
            resolver=lambda root, args, *_: NatMutation.saveUserId(
                args.get('userId'))
        ),
      'uploadVideoData': GraphQLField(
          NatGQLDataTypes.ObjUploadVideoType,
          args={
             'videopath': GraphQLArgument(GraphQLString),

          },
          resolver=lambda root, args, *_: NatMutation.save_upload_video(
              args.get('videopath'))
      ),
        'imageUploadCloud': GraphQLField(
            NatGQLDataTypes.ObjResponseType,
            args={
                'userid': GraphQLArgument(GraphQLInt),
                'file': GraphQLArgument(GraphQLString),
                'location': GraphQLArgument(GraphQLString),
                'base64Image': GraphQLArgument(GraphQLString),
            },
            resolver=lambda root, args, *_: NatMutation.imageUploadCloud(args.get('userid'),
                args.get('file'), args.get('location'), args.get('base64Image'))

        ),
        'fileDownloadCloud': GraphQLField(
            NatGQLDataTypes.ObjAnnotationType,
            args={
                'imageid': GraphQLArgument(GraphQLInt),
                'videoid': GraphQLArgument(GraphQLInt),
                'imagename': GraphQLArgument(GraphQLString),
                'serverpath': GraphQLArgument(GraphQLString)
            },
            resolver=lambda root, args, *_: NatMutation.fileDownloadCloud(args.get('imageid'),
                args.get('videoid'), args.get('imagename'), args.get('serverpath'))

        ),

        'saveMask': GraphQLField(
            NatGQLDataTypes.ObjAnnotationType,
            args={
                'imageid': GraphQLArgument(GraphQLInt),
                'videoid': GraphQLArgument(GraphQLInt),
                'imagename': GraphQLArgument(GraphQLString),
                'serverpath': GraphQLArgument(GraphQLString),
                'base64Image': GraphQLArgument(GraphQLString)
            },
            resolver=lambda root, args, *_: NatMutation.saveMask(args.get('imageid'),
                                                                          args.get('videoid'), args.get('imagename'),
                                                                          args.get('serverpath'), args.get('base64Image'))

        ),

        'resetNotifications': GraphQLField(
            NatGQLDataTypes.ObjNotificationType,
            args={
                'userid': GraphQLArgument(GraphQLInt),
                'username': GraphQLArgument(GraphQLString)
            },
            resolver=lambda root, args, *_: NatMutation.reset_notifications(
                args.get('userid'), args.get('username') )
        ),
    'updateVideoAssigned': GraphQLField(
      NatGQLDataTypes.ObjResponseType,
      args={
        'videoid': GraphQLArgument(GraphQLList(GraphQLInt)),
        'assignuserid': GraphQLArgument(GraphQLInt),
        'userid': GraphQLArgument(GraphQLInt),

      },
      resolver=lambda root, args, *_: NatMutation.update_video_assigned(
        args.get('videoid'), args.get('assignuserid'),args.get('userid'))
    ),
    'updateVideoAssignedValidator': GraphQLField(
      NatGQLDataTypes.ObjResponseType,
      args={
        'videoid': GraphQLArgument(GraphQLList(GraphQLInt)),
        'assignuserid': GraphQLArgument(GraphQLInt),
        'userid': GraphQLArgument(GraphQLInt)

      },
      resolver=lambda root, args, *_: NatMutation.update_video_assigned_validator(
        args.get('videoid'), args.get('assignuserid'),args.get('userid'))
    ),
    'allImageDetail': GraphQLField(
      NatGQLDataTypes.ObjImageType,
          args={
            'videoid': GraphQLArgument(GraphQLString)

          },
          resolver=lambda root, args, *_: NatMutation.get_all_images_details(
            args.get('videoid')
          ),
    ),
    'getImageMetrics': GraphQLField(
      NatGQLDataTypes.ImageMetricsType,
      args={
        'videoid': GraphQLArgument(GraphQLInt),
        'imagename': GraphQLArgument(GraphQLString)

      },
      resolver=lambda root, args, *_: NatMutation.get_image_metrics(
        args.get('videoid'), args.get('imagename')
      ),

    ),

    'allVideoData': GraphQLField(
          NatGQLDataTypes.ObjVideoType,
      args={
        'userid': GraphQLArgument(GraphQLInt),
        'project_id': GraphQLArgument(GraphQLInt)

      },
      resolver=lambda root, args, *_: NatMutation.get_all_videos(
        args.get('userid'),args.get('project_id')
      ),

      ),
    'allVideoDataValidator': GraphQLField(
          NatGQLDataTypes.ObjVideoType,
      args={
        'userid': GraphQLArgument(GraphQLInt),
        'role': GraphQLArgument(GraphQLString),
        'project_id': GraphQLArgument(GraphQLInt)
      },
      resolver=lambda root, args, *_: NatMutation.get_all_videos_validator(
        args.get('userid'), args.get('role') ,args.get('project_id')
      ),

      ),
      
     'allProjectData': GraphQLField(
          NatGQLDataTypes.ObjProjectType,
      args={
        'userid': GraphQLArgument(GraphQLInt),
        'role': GraphQLArgument(GraphQLString)
      },
      resolver=lambda root, args, *_: NatMutation.user_projects(
        args.get('userid'), args.get('role')
      ),

     ),

     'userNotifications': GraphQLField(
        NatGQLDataTypes.NotificationCountType,
        args={
          'userid': GraphQLArgument(GraphQLInt)

        },
        resolver=lambda root, args, *_: NatMutation.get_all_user_notifications(
          args.get('userid')
        ),

      ),

    'updateVideoProcessed': GraphQLField(
      NatGQLDataTypes.ObjVideoProcessedType,
      args={
        'videoid': GraphQLArgument(GraphQLInt),
      },
      resolver=lambda root, args, *_: NatMutation.update_video_processed(
        args.get('videoid'))
    ),

    'pushVideo': GraphQLField(
      NatGQLDataTypes.ObjVideoPushType,
      args={
        'userid': GraphQLArgument(GraphQLInt),
        'username': GraphQLArgument(GraphQLString),
        'interim_ids': GraphQLArgument(GraphQLList(GraphQLInt)),
        'final_ids': GraphQLArgument(GraphQLList(GraphQLInt)),
      },
      resolver=lambda root, args, *_: NatMutation.push_video(
        args.get('userid'), args.get('username'), args.get('interim_ids'), args.get('final_ids'))
    ),
    'deleteVideo': GraphQLField(
      NatGQLDataTypes.ObjVideoDeleteType,
        args={
          'videoid': GraphQLArgument(GraphQLList(GraphQLInt)),
        },
        resolver=lambda root, args, *_: NatMutation.delete_video(
          args.get('videoid'))
      ),
    'getVideoData': GraphQLField(
      NatGQLDataTypes.ObjVideoDetailsType,
      args={
        'videoid': GraphQLArgument(GraphQLInt),
        'imageid': GraphQLArgument(GraphQLInt)
      },
      resolver=lambda root, args, *_: NatMutation.get_video_details(
        args.get('videoid'), args.get('imageid'))
      ),
        'getPreviewVideoData': GraphQLField(
            NatGQLDataTypes.ObjPreviewVideoDetailsType,
            args={
                'videoid': GraphQLArgument(GraphQLInt),
                'taskName': GraphQLArgument(GraphQLString)
            },
            resolver=lambda root, args, *_: NatMutation.get_preview_video_details(
                args.get('videoid'),
                args.get('taskName')
            )
        ),


        'createUser': GraphQLField(
            NatGQLDataTypes.CreateUserType,
            args={
                'name': GraphQLArgument(GraphQLString),
                'email': GraphQLArgument(GraphQLString),
                'password': GraphQLArgument(GraphQLString)
            },
            resolver=lambda root, args, *_: NatMutation.create_user(
                args.get('name'), args.get('email'), args.get('password'))
        ),
        'loginUser': GraphQLField(
          NatGQLDataTypes.ObjLoginUserType,
            args={
                'username': GraphQLArgument(GraphQLString),
                'password': GraphQLArgument(GraphQLString),
            },
            resolver=lambda root, args, *_: NatMutation.login_user(
                args.get('username'), args.get('password'))
        ),
        'loginTfa' : GraphQLField(
          NatGQLDataTypes.ObjLoginUserType,
            args = {
                'username' : GraphQLArgument(GraphQLString),
                'otp' : GraphQLArgument(GraphQLInt),
                'secret' : GraphQLArgument(GraphQLString),
            },
            resolver=lambda root, args, *_: NatMutation.login_by_tfa(
                args.get('username'), args.get('otp'), args.get('secret')
            )
        ),
        'generateSecret' : GraphQLField(
          NatGQLDataTypes.ObjSecretType,
            args = {
              'username' : GraphQLArgument(GraphQLString)
            },
            resolver = lambda root, args, *_: NatMutation.generate_tfa_secret(
              args.get('username')
            )
        ),
        
        'usersAssignationList': GraphQLField(
          NatGQLDataTypes.ObjUserAssignationListType,
            args={
                'userid': GraphQLArgument(GraphQLInt),
                'role': GraphQLArgument(GraphQLString),
                'projectId': GraphQLArgument(GraphQLInt)
            },
            resolver=lambda root, args, *_: NatMutation.users_assignation_list(
                args.get('userid'),args.get('role'), args.get('projectId') )
        ),

      	 'saveScriptObj': GraphQLField(
            NatGQLDataTypes.ObjscriptListType,
            args={
                'scriptList': GraphQLArgument(GraphQLList(NatGQLDataTypes.ScriptListInputType))
            },
            resolver=lambda root, args, *
            _: NatMutation.save_script_list_obj(args.get('scriptList'))
        ),

        'initProject': GraphQLField(
          NatGQLDataTypes.ObjNotificationType,
            args={
                'userid': GraphQLArgument(GraphQLInt),
                'folderpath': GraphQLArgument(GraphQLString),
                'projectType': GraphQLArgument(GraphQLString),
                'divisionType': GraphQLArgument(GraphQLString),
                'availdays': GraphQLArgument(GraphQLInt),
                'requiredays': GraphQLArgument(GraphQLInt),
                'productivity': GraphQLArgument(GraphQLInt),
                'avgFrame': GraphQLArgument(GraphQLInt),
                'totalFrame': GraphQLArgument(GraphQLInt),
                'availannotator': GraphQLArgument(GraphQLInt),
                'requireannotator': GraphQLArgument(GraphQLInt),
                'annoratio': GraphQLArgument(GraphQLInt),
                'availvalidator': GraphQLArgument(GraphQLInt),
                'scriptList': GraphQLArgument(GraphQLList(NatGQLDataTypes.ScriptListInputType)),
                'conversionScript': GraphQLArgument(GraphQLString),
                'conversionScripts': GraphQLArgument(GraphQLList(GraphQLString)),
            },
            resolver=lambda root, args, *_: NatMutation.init_project(
                args.get('userid'),
                args.get('folderpath'),
                args.get('projectType'),
                args.get('divisionType'),
                args.get('availdays'),
                args.get('requiredays'),
                args.get('productivity'),
                args.get('avgFrame'),
                args.get('totalFrame'),
                args.get('availannotator'),
                args.get('requireannotator'),
                args.get('annoratio'),
                args.get('availvalidator'),
                args.get('scriptList'),
                args.get('conversionScript'),
                args.get('conversionScripts'),
            )
        ),
        'initProjectReport': GraphQLField(
            NatGQLDataTypes.ObjReportType,
            args={
                'userid': GraphQLArgument(GraphQLInt),
            },
            resolver=lambda root, args, *_: NatMutation.init_project_report(
                 )
        ),
        'videoToFrames': GraphQLField(
            NatGQLDataTypes.ObjFramesDetailsType,
            args={
                'folderpath': GraphQLArgument(GraphQLString),
            },
            resolver=lambda root, args, *_: NatMutation.video_to_frames(
                    args.get('folderpath')
                 )
        ),
      'acceptRejectVideo': GraphQLField(
        NatGQLDataTypes.AcceptRejectVideoType,
        args={
          'userid': GraphQLArgument(GraphQLInt),
          'submitted': GraphQLArgument(GraphQLInt),
          'videoid': GraphQLArgument(GraphQLInt)

        },
        resolver=lambda root, args, *_: NatMutation.accept_reject_video(
          args.get('userid'), args.get('submitted'),args.get('videoid')
        )
      ),
	   	 'signup': GraphQLField(
            NatGQLDataTypes.ObjUserType,
            args={
                'username': GraphQLArgument(GraphQLString),
                'password': GraphQLArgument(GraphQLString),
                'first_name': GraphQLArgument(GraphQLString),
                'last_name': GraphQLArgument(GraphQLString),
                'mobile_number': GraphQLArgument(GraphQLString),
                'role': GraphQLArgument(GraphQLString),
                'security_question': GraphQLArgument(GraphQLString),
                'security_answer': GraphQLArgument(GraphQLString),
                # 'auth_pin': GraphQLArgument(GraphQLString),
                'auto_captcha': GraphQLArgument(GraphQLInt),
                'user_captcha': GraphQLArgument(GraphQLInt)
            },
            resolver=lambda root, args, *_: NatMutation.user_signup(
                args.get('username'), args.get('password'), args.get('first_name'), args.get('last_name'), args.get('mobile_number'), args.get('role'), args.get('security_question'), args.get('security_answer'), 
                # args.get('auth_pin'), 
                args.get('auto_captcha'), args.get('user_captcha'))
        ),
        'getquestion': GraphQLField(
            NatGQLDataTypes.ObjUserTypeQue,
            args={
                'username': GraphQLArgument(GraphQLString)
            },
            resolver=lambda root, args, *_: NatMutation.get_question(
                args.get('username'))
        ),
        'resetpassword': GraphQLField(
            NatGQLDataTypes.ObjResponseType,
            args={
                'username': GraphQLArgument(GraphQLString),
                'newPass': GraphQLArgument(GraphQLString)
            },
            resolver=lambda root, args, *_: NatMutation.reset_password(
                args.get('username'),args.get('newPass'))
        ),

        'nextObjMaskImage': GraphQLField(
            NatGQLDataTypes.ObjMaskImageType,
            args={
                'imageid': GraphQLArgument(GraphQLInt),
                'videoname': GraphQLArgument(GraphQLString),

            },
            resolver=lambda root, args, *_: NatMutation.get_next_obj_mask_img(
                args.get('imageid'), args.get('videoname')

            ),    
        ),

        # ***************** #
        # 3D - Backend API's Definations

        'jsonConfigLoader3d': GraphQLField(
            NatDataTypes3d.ObjConfigType,
            args={
                'video_id':GraphQLArgument(GraphQLInt),
            },
            resolver=lambda root,args,*_: NatMutation3D.jsonConfigLoader(
                args.get('video_id')
            ),
        ),

        'saveJsonData3d': GraphQLField(
            NatGQLDataTypes.ObjResponseType,
            args={
                'video_id':GraphQLArgument(GraphQLInt),
                'image_id':GraphQLArgument(GraphQLInt),
                'json_data':GraphQLArgument(GraphQLString),
                'project_id':GraphQLArgument(GraphQLInt),
                'auto_annotations': GraphQLArgument(GraphQLString),
                
                
            },
            resolver=lambda root,args,*_: NatMutation3D.saveJsonData(
                args.get('video_id'),args.get('image_id'),args.get('json_data'), args.get('project_id'), args.get('auto_annotations')
            )
        ),

        'uiViewer3d': GraphQLField(
            NatDataTypes3d.ObjUiViewerType,
            args={
                'video_id':GraphQLArgument(GraphQLInt),
                'image_id':GraphQLArgument(GraphQLInt),
                'signal':GraphQLArgument(GraphQLInt),
                'project_id': GraphQLArgument(GraphQLInt),
                'auto_annotations': GraphQLArgument(GraphQLString),
                'configure_type': GraphQLArgument(GraphQLInt),
                'copy_direction': GraphQLArgument(GraphQLString),
            },
            resolver=lambda root,args,*_: NatMutation3D.uiViewerLoader(
                args.get('video_id'),args.get('image_id'),args.get('signal'), args.get('project_id'), args.get('auto_annotations'), args.get('configure_type'), args.get('copy_direction')
            )
        ),

        'getTextModerationObject': GraphQLField(
            NatGQLDataTypes.ObjTextModerationType,
            args={
                'project_id': GraphQLArgument(GraphQLInt),
                'userid': GraphQLArgument(GraphQLInt),
                'videoid': GraphQLArgument(GraphQLInt),
                'video_type':  GraphQLArgument(GraphQLInt),
                'file': GraphQLArgument(GraphQLString)
            },
            resolver=lambda root, args, *_: NatMutation.get_text_moderation_obj(
                args.get('project_id'), args.get('userid'), args.get('videoid'),
                args.get('video_type'), args.get('file')
            )
        ),

        'saveTextModerationObject': GraphQLField(
            NatGQLDataTypes.ObjTextModerationType,
            args={
                'project_id': GraphQLArgument(GraphQLInt),
                'userid': GraphQLArgument(GraphQLInt),
                'videoid': GraphQLArgument(GraphQLInt),
                'annos': GraphQLArgument(GraphQLString),
                'video_type':  GraphQLArgument(GraphQLInt),
                'file': GraphQLArgument(GraphQLString)
            },
            resolver=lambda root, args, *_: NatMutation.save_text_moderation_obj(
                args.get('project_id'), args.get('userid'), args.get('videoid'),
                args.get('annos'), args.get('video_type'), args.get('file')
            )
        )
    }
)

Schema = GraphQLSchema(QueryRootType, MutationRootType)

def create_app(**kwargs):
    app = Flask(__name__)
    CORS(app, supports_credentials=True, resources={r'/*': {'origins': '*'}})
    app.add_url_rule(
        '/graphql',
        view_func=GraphQLView.as_view('graphql', schema=Schema, **kwargs)
    )

    return app

application = create_app(graphiql=True)
app = application


def app_DB():
  config_obj = NATConfigController.read_config()
  EncryptDecrypt.decrypt_incoming(config_obj.get(os.environ.get('ENV'),'API_URL_BASE'))
  
  app.config['MYSQL_DATABASE_USER'] = EncryptDecrypt.decrypt_incoming(config_obj.get(os.environ.get('ENV'), 'MYSQL_DATABASE_USER'))
  app.config['MYSQL_DATABASE_PASSWORD'] = EncryptDecrypt.decrypt_incoming(config_obj.get(os.environ.get('ENV'), 'MYSQL_DATABASE_PASSWORD'))
  app.config['MYSQL_DATABASE_DB'] = EncryptDecrypt.decrypt_incoming(config_obj.get(os.environ.get('ENV'), 'MYSQL_DATABASE_DB'))
  app.config['MYSQL_DATABASE_HOST'] = EncryptDecrypt.decrypt_incoming(config_obj.get(os.environ.get('ENV'), 'MYSQL_DATABASE_HOST'))
  mysql = MySQL(app,autocommit=True)

  return mysql

if cfg.mysql_db is None:
  cfg.mysql_db = app_DB()
