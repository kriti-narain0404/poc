import os
import json
import re
import csv
# Custom packages
from commons import constants as cfg
from structures.data_structures import *
from structures.nat_gql_datatype import *
from dao.data import Data
from dao.metrics_dao import MetricsDao
from utils.settings_utils import SettingsUtils
from utils.files import Files
from utils.logger import Logger
from utils.dashboard_utils import Dashboard
logger = Logger.get_logger()
c = cfg.ConstantsDashboard


class MetricsUtils(object):

    @staticmethod
    def make_parameter_object(d):
        logger.info("[Start]: make_parameter_object")
        metrics_objects = {
            'object_detection_accuracy': [],
            'object_deletion_count': [],
            'object_edited_count': [],
            'object_loc_accuracy': []
        }
        try:
            for key, val in d.items():
                for obj in val:
                    metrics_objects[key].append(
                        MetricsParameterObject(
                            label=obj.get('label', ''),
                            value=obj.get('value', 0)
                        )
                    )
        except Exception as error_obj:
            logger.error(error_obj)
            raise error_obj
        logger.info("[Exit]: make_parameter_object")
        return metrics_objects

    @staticmethod
    def make_parameter(metrics_objects):
        logger.info("[Start]: make_parameter")
        metrics = None
        try:
            metrics = MetricsParameter(
                object_detection_accuracy=metrics_objects['object_detection_accuracy'],
                object_deletion_count=metrics_objects['object_deletion_count'],
                object_edited_count=metrics_objects['object_edited_count'],
                object_loc_accuracy=metrics_objects['object_loc_accuracy'],
            )
        except Exception as error_obj:
            logger.error(error_obj)
            raise error_obj
        logger.info("[Exit]: make_parameter")
        return metrics

    @staticmethod
    def make_metrics_details():
        logger.info("[Start]: make_metrics_details")
        metricsdata = None
        try:
            metricsjson = MetricsDao.get_accuracy_table_to_json()

            metrics_objects = MetricsUtils.make_parameter_object(
                metricsjson['metrics'])

            videos = []
            for vid in metricsjson['videos']:
                frames = []
                for frame in vid['frames']:
                    metrics_frames = MetricsUtils.make_parameter_object(
                        frame['metrics'])
                    frames.append(
                        MetricsParameterFrames(
                            label=frame['label'],
                            metrics=MetricsUtils.make_parameter(metrics_frames)
                        )
                    )
                metrics_videos = MetricsUtils.make_parameter_object(
                    vid['metrics'])
                videos.append(
                    MetricsParameterVideo(
                        label=vid['label'],
                        frames=frames,
                        metrics=MetricsUtils.make_parameter(metrics_videos)
                    )
                )

            metricsdata = MetricsData(
                metrics=MetricsUtils.make_parameter(metrics_objects),
                videos=videos
            )
            # logger.debug(metricsdata)
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: make_metrics_details")
        return metricsdata

    @staticmethod
    def get_unique_labels(framename, annos1, annos2):
        logger.info("[Start]: get_unique_labels")
        labels = []
        try:
            for obj in annos1:
                labels.append(obj['label'])
            for obj in annos2:
                labels.append(obj['label'])
            labels = list(set(labels))
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: get_unique_labels")
        return labels

    @staticmethod
    def get_dirs_list(dirname):
        logger.info("[Start]: get_dirs_list")
        dirregex = dirname + '(.*)/json'
        videos = []
        try:
            for x in os.walk(dirname):
                s1 = re.search(dirregex, x[0])
                if s1 is not None:
                    # Loop throup files to get clip names list
                    frames = []
                    for filename in x[2]:
                        framename = filename.replace(".json", "").replace("_label", "").replace("metrics", "")
                        if framename:
                            frames.append(framename)
                    d = {'label': s1.group(1), "frames": set(frames)}
                    videos.append(d)
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Start]: get_dirs_list")
        return videos

    @staticmethod
    def generate_metrics():
        logger.info("[Start]: generate_metrics")
        try:
            dirname = SettingsUtils.get_value_by_key(SettingsUtils.KEY_DATAPATH)
            dirlist = MetricsUtils.get_dirs_list(dirname)
            metrics = {
                'metrics': {
                    'object_detection_accuracy': [],
                    'object_edited_count': [],
                    'object_deletion_count': [],
                    'object_loc_accuracy': []
                },
                'videos': []
            }
            total_data = {
                'predicted_count': 0,
                'annotated_count': 0,
                'object_deletion_count': 0,
                'object_edited_count': 0,
            }
            for video in dirlist:
                videoname = video['label']
                frames = video['frames']
                video_metrics = {
                    'object_detection_accuracy': [],
                    'object_edited_count': [],
                    'object_deletion_count': [],
                    'object_loc_accuracy': []
                }
                video_data = {
                    'predicted_count': 0,
                    'annotated_count': 0,
                    'object_deletion_count': 0,
                    'object_edited_count': 0,
                }
                video['frames'] = []
                for framename in frames:
                    frame_data = {
                        'predicted_count': 0,
                        'annotated_count': 0,
                        'object_deletion_count': 0,
                        'object_edited_count': 0,
                    }
                    jsonfilename = dirname + videoname + '/json/' + framename + '.json'
                    labeljsonfilename = dirname + videoname + '/json/' + framename + '_label.json'
                    json1 = json2 = None
                    try:
                        with open(jsonfilename, 'r') as f:
                            json1 = json.load(f)
                        with open(labeljsonfilename, 'r') as f:
                            json2 = json.load(f)
                        logger.debug('Success in reading %s %s'%(videoname, framename))
                        annos1 = json1[cfg.IMG][framename]['annotations']
                        annos2 = json2[cfg.IMG][framename]['annotations']
                        frame_metrics = {
                            'metrics': {},
                            'label': framename
                        }
                        unique_labels = MetricsUtils.get_unique_labels(framename, annos1, annos2)
                        
                        object_detection_accuracy = []
                        predicted_count = dict((x,0) for x in unique_labels)
                        annotated_count = dict((x,0) for x in unique_labels)
                        for obj in annos1:
                            predicted_count[obj['label']] += 1
                        for obj in annos2:
                            annotated_count[obj['label']] += 1
                        for key in unique_labels:
                            object_detection_accuracy.append({
                                'label': key,
                                'value': predicted_count[key] / annotated_count[key] * 100
                            })
                        frame_metrics['metrics']['object_detection_accuracy'] = object_detection_accuracy
                        frame_data['predicted_count'] += len(annos1)
                        frame_data['annotated_count'] += len(annos2)
                        # End: calculation object_detection_accuracy
                        # Start: calculation object_deletion_count
                        object_deletion_count = []
                        predicted_ids = dict((x,[]) for x in unique_labels)
                        annotated_ids = dict((x,[]) for x in unique_labels)
                        for obj in annos1:
                            predicted_ids[obj['label']].append(obj['id'])
                        for obj in annos2:
                            annotated_ids[obj['label']].append(obj['id'])
                        for key in unique_labels:
                            object_deletion_count.append({
                                'label': key,
                                'value': len(set(predicted_ids[key]) - set(annotated_ids[key]))
                            })
                        frame_metrics['metrics']['object_deletion_count'] = object_deletion_count 
                        frame_data['object_deletion_count'] += sum(k['value'] for k in object_deletion_count)       
                        # End: calculation object_deletion_count
                        # Start: calculation object_edited_count
                        edited_count = dict((x,0) for x in unique_labels)
                        object_edited_count = []
                        for obj in annos1:
                            item = list(filter(lambda x: x['id'] == obj['id'] and x['label'] != obj['label'], annos2))
                            if len(item):
                                edited_count[obj['label']] += 1
                        for key in unique_labels:
                            object_edited_count.append({
                                'label': key,
                                'value': edited_count[key]
                            })
                        frame_metrics['metrics']['object_edited_count'] = object_edited_count
                        frame_data['object_edited_count'] += sum(edited_count.values())  
                        # End: calculation object_edited_count
                        # Start: calculation object_loc_accuracy
                        # TODOS only bbox is considered here
                        object_loc_accuracy = []
                        for obj in annos1:
                            item = list(filter(lambda x: x['id'] == obj['id'], annos2))
                            if len(item):
                                item = item[0]
                                loc_accu = Data.obj_loc_accu(item['bbox']['xmin'], item['bbox']['xmax'], \
                                                        item['bbox']['ymin'], item['bbox']['ymax'], \
                                                        obj['bbox']['xmin'], obj['bbox']['xmax'], \
                                                        obj['bbox']['ymin'], obj['bbox']['ymax'])
                                object_loc_accuracy.append({
                                    'label': obj['label'], 
                                    'value': loc_accu,
                                })
                        frame_metrics['metrics']['object_loc_accuracy'] = object_loc_accuracy
                        # End: calculation object_loc_accuracy
                        video['frames'].append(frame_metrics)
                        video_metrics['object_detection_accuracy'].append({
                            'label': framename,
                            'value': frame_data['predicted_count'] / frame_data['annotated_count'] * 100 if frame_data['annotated_count']>0 else 0,
                        })
                        video_metrics['object_edited_count'].append({
                            'label': framename,
                            'value': frame_data['object_edited_count']
                        })
                        video_metrics['object_deletion_count'].append({
                            'label': framename,
                            'value': frame_data['object_deletion_count']
                        })

                        video_data['predicted_count'] += frame_data['predicted_count']
                        video_data['annotated_count'] += frame_data['annotated_count']
                        video_data['object_deletion_count'] += frame_data['object_deletion_count']
                        video_data['object_edited_count'] += frame_data['object_edited_count']
                    except Exception as e:
                        logger.info("Exception %s %s"%(videoname, framename))
                        logger.info(e)
                video_metrics['object_loc_accuracy'].append({
                    'label': '',
                    'value': 0
                })
                video['metrics'] = video_metrics
                metrics['videos'].append(video)
                metrics['metrics']['object_detection_accuracy'].append({
                    'label': videoname,
                    'value': video_data['predicted_count'] / video_data['annotated_count'] * 100 if video_data['annotated_count']>0 else 0
                })
                metrics['metrics']['object_edited_count'].append({
                    'label': videoname,
                    'value': video_data['object_edited_count']
                })
                metrics['metrics']['object_deletion_count'].append({
                    'label': videoname,
                    'value': video_data['object_deletion_count']
                })

            metrics['metrics']['object_loc_accuracy'].append({
                'label': '',
                'value': 0
            })
            MetricsDao.save_accuracy_json_to_table(metrics)
            with open(dirname+'metrics.json', 'w') as f:
                json.dump(metrics, f, indent=2)
                logger.debug("Written to file successfully")
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: generate_metrics")

    @staticmethod
    def create_or_update_productivity(videoid, video_name, validator_name, annotator_name, validate=False, frames_count=0):
        logger.info("[Start]: create_or_update_productivity")
        response = True
        try:
            no_objects = 0
            no_objects_error = 0
            datapath = SettingsUtils.get_value_by_key(SettingsUtils.KEY_DATAPATH)
            filepath = os.path.join(datapath, video_name, 'json')
            jsonlist = Files.get_labeljson_list(filepath)
            for filename in jsonlist:
                fp = os.path.join(filepath, filename)
                with open(fp, 'r') as f:
                    labeljson = json.load(f)
                    
                framename = filename.replace("_label.json", "")
                annos = labeljson[cfg.IMG][framename]['annotations']
                for anno in annos:
                    no_objects += 1
                    if anno['bbox'] is not None:
                        if anno['bbox']['score'] == 1:
                            no_objects_error += 1
                    elif anno['polygon'] is not None:
                        if anno['polygon']['score'] == 1:
                            no_objects_error += 1
            MetricsDao.create_or_update_productivity(videoid, video_name, validator_name, annotator_name, no_objects, no_objects_error, validate, frames_count)
        except Exception as error_obj:
            response = False
            logger.error(error_obj)
        logger.info("[Exit]: create_or_update_productivity")
        return response

    @staticmethod
    def get_project_path_combined_csvs(userid, pid):
        logger.info("[Start]: get_project_path")
        response = ''
        try:
            response = MetricsDao.get_project_path_dao(userid, pid)
            obj_dashboard = Dashboard(response)
            obj_dashboard.call_main()
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: get_project_path")
        return response

    @staticmethod
    def generate_productivity1_csv(filename):
        response = False
        logger.info("[Start]: generate_productivity1_csv")
        try:
            file = open(filename)
            csvreader = csv.reader(file)
            header = next(csvreader)
            data = {}
            list1 = []
            for rows in csvreader:
                list1.append(dict(zip(header, rows)))
            for i in list1:
                annotator_name = i.get('Assigned_User_Name')
                validator_name = i.get('Validator_name')
                count_anno = int(i.get("Count_of_annotation_added"))
                if annotator_name + "-" + validator_name not in data:
                    data[annotator_name + "-" + validator_name] = count_anno
                elif annotator_name + "-" + validator_name in data:
                    data[annotator_name + "-" + validator_name] += count_anno
            with open('../nat_frontend/static/productivity1.csv', 'w') as csvFile:
                writer = csv.writer(csvFile)
                data_to_write = [['Validator', 'Annotator', 'Success', 'Fail']]
                for key, val in data.items():
                    anno, validator = key.split("-")
                    data_to_write.append([validator, anno, val, 0])
                writer.writerows(data_to_write)
            csvFile.close()
            response = True
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Start]: generate_productivity1_csv")
        return response

    @staticmethod
    def generate_productivity_csv_updated(pid, p_path):
        logger.info("[Start]: generate_productivity_csv_updated")
        ext = ".csv"
        csv_file = ""
        csv_file_acc = ""
        response = False
        try:
            for file in os.listdir(p_path + c.DATA_PRODUCTIVITY_FOLDER):
                if str(pid) in file and file.endswith(ext):
                    csv_file = file
            for file in os.listdir(p_path + c.DATA_ACCURACY_FOLDER):
                if str(pid) in file and file.endswith(ext):
                    csv_file_acc = file
            if csv_file_acc:
                os.system("cp {} ../nat_frontend/static/accuracy.csv".format(os.path.join(p_path+c.DATA_ACCURACY_FOLDER, csv_file_acc)))
            if csv_file:
                response = MetricsUtils.generate_productivity1_csv(os.path.join(p_path+c.DATA_PRODUCTIVITY_FOLDER, csv_file))
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: generate_productivity_csv_updated")
        return response

    @staticmethod
    def generate_productivity_csv(userid, username, userrole, from_date, to_date):
        logger.info("[Start]: generate_productivity_csv")
        response = True
        try:
            response = MetricsDao.generate_productivity_csv(userid, username, userrole, from_date, to_date)
        except Exception as error_obj:
            response = False
            logger.error(error_obj)
        logger.info("[Exit]: generate_productivity_csv")
        return response

    @staticmethod
    def generate_accuracy_csv():
        logger.info("[Start]: generate_productivity_csv")
        response = True
        try:
            response = MetricsDao.generate_accuracy_csv()
        except Exception as error_obj:
            response = False
            logger.error(error_obj)
        logger.info("[Exit]: generate_productivity_csv")
        return response

    @staticmethod
    def create_or_update_accuracy(videoname, validate=False):
        logger.info("[Start]: create_or_update_accuracy")
        response = True
        try:
            insert = MetricsDao.insert_accuracy(videoname, validate)
            if insert:
                video_metrics = {'object_edited_count': [], 'object_loc_accuracy': [], 'object_deletion_count': [], 'object_detection_accuracy': []}
                frames = []
                frames_metrics = []

                datapath = SettingsUtils.get_value_by_key(SettingsUtils.KEY_DATAPATH)
                filepath = os.path.join(datapath, videoname, 'images')
                imageslist = Files.get_frames_list(filepath)
                
                for filename in imageslist:
                    frame_data = {
                        'predicted_count': 0,
                        'annotated_count': 0,
                        'object_deletion_count': 0,
                        'object_edited_count': 0,
                    }

                    f = os.path.splitext(filename)
                    framename = f[0]

                    jsonfilename = os.path.join(datapath, videoname, 'json', framename+'.json')
                    labeljsonfilename = os.path.join(datapath, videoname, 'json', framename+'_label.json')

                    json1 = json2 = None
                    try:
                        with open(jsonfilename, 'r') as f:
                            json1 = json.load(f)
                        with open(labeljsonfilename, 'r') as f:
                            json2 = json.load(f)
                        logger.debug('Success in reading %s %s'%(videoname, framename))
                        annos1 = json1[cfg.IMG][framename]['annotations']
                        annos2 = json2[cfg.IMG][framename]['annotations']
                        frame_metrics = {
                            'metrics': {},
                            'label': framename
                        }
                        unique_labels = MetricsUtils.get_unique_labels(framename, annos1, annos2)
                        
                        object_detection_accuracy = []
                        predicted_count = dict((x,0) for x in unique_labels)
                        annotated_count = dict((x,0) for x in unique_labels)
                        for obj in annos1:
                            predicted_count[obj['label']] += 1
                        for obj in annos2:
                            annotated_count[obj['label']] += 1
                        for key in unique_labels:
                            object_detection_accuracy.append({
                                'label': key,
                                'value': (predicted_count[key] / annotated_count[key] * 100) if annotated_count[key]>0 else 0
                            })
                        frame_metrics['metrics']['object_detection_accuracy'] = object_detection_accuracy
                        frame_data['predicted_count'] += len(annos1)
                        frame_data['annotated_count'] += len(annos2)
                        # End: calculation object_detection_accuracy
                        # Start: calculation object_deletion_count
                        object_deletion_count = []
                        predicted_ids = dict((x,[]) for x in unique_labels)
                        annotated_ids = dict((x,[]) for x in unique_labels)
                        for obj in annos1:
                            predicted_ids[obj['label']].append(obj['id'])
                        for obj in annos2:
                            annotated_ids[obj['label']].append(obj['id'])
                        for key in unique_labels:
                            object_deletion_count.append({
                                'label': key,
                                'value': len(set(predicted_ids[key]) - set(annotated_ids[key]))
                            })
                        frame_metrics['metrics']['object_deletion_count'] = object_deletion_count 
                        frame_data['object_deletion_count'] += sum(k['value'] for k in object_deletion_count)       
                        # End: calculation object_deletion_count
                        # Start: calculation object_edited_count
                        edited_count = dict((x,0) for x in unique_labels)
                        object_edited_count = []
                        for obj in annos1:
                            item = list(filter(lambda x: x['id'] == obj['id'] and x['label'] != obj['label'], annos2))
                            if len(item):
                                edited_count[obj['label']] += 1
                        for key in unique_labels:
                            object_edited_count.append({
                                'label': key,
                                'value': edited_count[key]
                            })
                        frame_metrics['metrics']['object_edited_count'] = object_edited_count
                        frame_data['object_edited_count'] += sum(edited_count.values())  
                        # End: calculation object_edited_count
                        # Start: calculation object_loc_accuracy
                        # TODOS only bbox is considered here
                        object_loc_accuracy = []
                        for obj in annos1:
                            item = list(filter(lambda x: x['id'] == obj['id'], annos2))
                            if len(item):
                                item = item[0]
                                loc_accu = Data.obj_loc_accu(item['bbox']['xmin'], item['bbox']['xmax'], \
                                                        item['bbox']['ymin'], item['bbox']['ymax'], \
                                                        obj['bbox']['xmin'], obj['bbox']['xmax'], \
                                                        obj['bbox']['ymin'], obj['bbox']['ymax'])
                                object_loc_accuracy.append({
                                    'label': obj['label'], 
                                    'value': loc_accu,
                                })
                        frame_metrics['metrics']['object_loc_accuracy'] = object_loc_accuracy
                        # End: calculation object_loc_accuracy
                        frames.append(framename)
                        video_metrics['object_detection_accuracy'].append({
                            'label': framename,
                            'value': (frame_data['predicted_count'] / frame_data['annotated_count'] * 100) if frame_data['annotated_count']>0 else 0,
                        })
                        video_metrics['object_edited_count'].append({
                            'label': framename,
                            'value': frame_data['object_edited_count']
                        })
                        video_metrics['object_deletion_count'].append({
                            'label': framename,
                            'value': frame_data['object_deletion_count']
                        })
                        frames_metrics.append(frame_metrics)
                    except Exception as e:
                        logger.info("Exception %s %s"%(videoname, framename))
                        logger.info(e)
                video_metrics = {
                    'metrics': video_metrics,
                    'frames': frames
                }
                MetricsDao.create_or_update_accuracy(videoname, video_metrics, frames_metrics, validate)
        except Exception as error_obj:
            response = False
            logger.error(error_obj)
        logger.info("[Exit]: create_or_update_accuracy")
        return response

    @staticmethod
    def generate_performance_chart_csv(userid, username, userrole, pid):
        logger.info("[Start]: generate_performance_chart_csv")
        response = True
        try:
            response = MetricsDao.generate_performance_chart_csv_dao(userid, username, userrole, pid)
        except Exception as error_obj:
            response = False
            logger.error(error_obj)
        logger.info("[Exit]: generate_performance_chart_csv")
        return response