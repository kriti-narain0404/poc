
from __future__ import print_function

import numpy as np
import cv2 as cv
import sys
from scipy.ndimage.morphology import binary_fill_holes
from utils.logger import Logger
logger = Logger.get_logger()

class FloodFill(object):

  @staticmethod
  def floodfill_working(imagePath, clickPointX, clickPointY, tolerance):
    logger.info("[Start]: floodfill_working")
    pointDict ={}
    try:
      img = cv.imread(imagePath)
      h, w = img.shape[:2]
      mask = np.zeros((h + 2, w + 2), np.uint8)
      seed_pt = None
      fixed_range = True
      connectivity = 4
      flooded = img.copy()
      mask[:] = 0
      lo = 1 * tolerance
      hi = 5 * tolerance
      flags = connectivity
      if fixed_range:
        # flags |= cv.FLOODFILL_FIXED_RANGE
        flags |= cv.FLOODFILL_MASK_ONLY
      num, im, mask1, rect = cv.floodFill(flooded, mask,
                                          (clickPointX, clickPointY),
                                          (255, 255, 255), (lo,) * 3, (hi,) * 3,
                                          flags)
      mask1 = mask1[1:h + 1, 1:w + 1]
      mask1 = binary_fill_holes(mask1).astype(np.uint8)
      cnts, hierarchy = cv.findContours(mask1, cv.RETR_TREE,
                                        cv.CHAIN_APPROX_SIMPLE)
      #cv.imwrite('/home/anurag/mask.png', mask1)

      cnts = np.array(cnts)

      arr = np.vstack(cnts)
      coordinates = np.zeros((arr.shape[0], arr.shape[2]), dtype=np.int)

      coordinates[:, 0] = arr[:, :, 0].flatten()
      coordinates[:, 1] = arr[:, :, 1].flatten()
      pointDict = {'x': coordinates[:, 0].tolist(),
                   'y': coordinates[:, 1].tolist()}
    except Exception as error_obj:
      logger.error(error_obj)

    logger.info("[Exit]: floodfill_working")
    return pointDict


