// C++ program for the above approach
//#include <iostream>
//#include <opencv2/opencv.hpp>
//#include <chrono>
//using namespace std::chrono;
//using namespace cv;
//using namespace std;

//typedef struct image {
//    int w;
//   int h;
//    int c;
//    void *data;
//} image;

//typedef struct box {
//    int x, y, w, h;
//} box;
#include "obj_tracking.h"

class InitTracking
{
public:
    Mat templateImage;
    Size cellSize;
    int nbins;
    Size blockSize;
    Mat HogfeatA;
    InitTracking(Mat Image, Size cell, int bin, Size block)
    {
        templateImage = Image;
        cellSize = cell;
        nbins = bin;
        blockSize = block;
    }
    void Init()
    {
        HOGDescriptor hogA(Size(templateImage.cols / cellSize.width * cellSize.width, templateImage.rows / cellSize.height * cellSize.height),
            Size(blockSize.height * cellSize.height, blockSize.width * cellSize.width),
            Size(cellSize.height, cellSize.width),
            cellSize,
            nbins);
        vector<float> dersA;
        vector<Point> locsA;
        hogA.compute(templateImage, dersA, Size(cellSize.height, cellSize.width), Size(0, 0));
        Mat Hogfeat(dersA.size(), 1, CV_32FC1);
        for (int i = 0; i < dersA.size(); i++)
            Hogfeat.at<float>(i, 0) = dersA.at(i);
        HogfeatA = Hogfeat;
    }
};

extern "C"
{

    //box ObjectTracking(Mat& imA, Mat& imB, Rect& recA, Rect& recB);
    int NormXCorr2(Mat& imA, Mat& imB, double* OutData);
    int MatchHoGDesFast(InitTracking &initObj, Mat& imB, double* OutData);
    // int main()
    // {
    //     Rect recA = Rect(570, 102, 697 - 570 + 1, 190 - 102 + 1);
    //     string path1 = "/home/shanam_a/obj_track_data/MAGNA_ANNOTATION_11064.png";
    //     for (int i = 1482; i < 1600; i++)
    //     {
    //         Mat imageA = imread(path1 + to_string(i) + ".bmp", IMREAD_COLOR);
    //         Mat imageB = imread(path1 + to_string(i+1) + ".bmp", IMREAD_COLOR);
    //         Rect recB;
    //         Mat imageAGray;
    //         Mat imageBGray;
    //         cvtColor(imageA, imageAGray, COLOR_BGR2GRAY);
    //         cvtColor(imageB, imageBGray, COLOR_BGR2GRAY);
    //         auto start = high_resolution_clock::now();
    //         ObjectTracking(imageAGray, imageBGray, recA, recB);
    //         // After function call
    //         auto stop = high_resolution_clock::now();
    //         auto duration = duration_cast<microseconds>(stop - start);
    //         // To get the value of duration use the count()
    //         // member function on the duration object
    //         cout << duration.count() << endl;
    //         rectangle(imageA, recA, cv::Scalar(0, 255, 0));
    //         rectangle(imageB, recB, cv::Scalar(0, 255, 0));
    //         recA = recB;
    //         imwrite("/home/shanam_a/out/" + to_string(i + 1) + ".jpg", imageB);
    //     }
    //     return 0;
    //}
    box ObjectTracking(const image *imageA, const image *imageB, const box *bboxA, int margin)
    {   
        box boxOut = {0};
        boxOut.x = bboxA->x;
        boxOut.y = bboxA->y;
        boxOut.w = bboxA->w;
        boxOut.h = bboxA->h;

        Rect recFinal;

        if (imageA == NULL)
        {    
            return boxOut;
        }    
        if (imageA->h <= 0 || imageA->w <= 0)
        {    
            return boxOut;
        }
        if (imageA->c != 1 && imageA->c != 3)
        {    
            return boxOut;
        }


        if (imageB == NULL)
        {    
            return boxOut;
        }    
        if (imageB->h <= 0 || imageB->w <= 0)
        {    
            return boxOut;
        }
        if (imageB->c != 1 && imageB->c != 3)
        {    
            return boxOut;
        }

        //cout << "aaaaaaaaa";
        cv::Mat imA = cv::Mat(cv::Size(imageA->w, imageA->h), imageA->c == 3 ? CV_8UC3 : CV_8UC1, imageA->data);
        cv::Mat imB = cv::Mat(cv::Size(imageB->w, imageB->h), imageB->c == 3 ? CV_8UC3 : CV_8UC1, imageB->data);
        Mat imageAGray;
        Mat imageBGray;
        cvtColor(imA, imageAGray, COLOR_BGR2GRAY);
        cvtColor(imB, imageBGray, COLOR_BGR2GRAY);

        Rect recA = Rect(bboxA->x, bboxA->y, bboxA->w, bboxA->h);
        //cout<< "CropA Image"<<endl;
        Mat cropA = imageAGray(recA);
        //cout<< "CropA Image Done"<<endl;
        Rect recB(recA);
        int exp = margin;

        int iterationCount = 5;
        int superfineIterationCount = 2;
        int widthObject = cropA.cols;
        int heightObject = cropA.rows;
        float stepWidth = (float)(widthObject * exp) / 100;
        stepWidth = stepWidth / (2*iterationCount+1);
        if (stepWidth <= 1.0f)
            stepWidth = 1.0f;
        float stepHeight = (float)(heightObject * exp) / 100;
        stepHeight = stepHeight / (2 * iterationCount + 1);
        if (stepHeight <= 1.0f)
            stepHeight = 1.0f;

        double outData = std::numeric_limits<double>::max();
        recFinal = recA;
        int mini,minj;
         Size cellSize(8, 8);
        int nbins = 9;
        Size blockSize(2, 2);
        InitTracking initObj(cropA, cellSize, nbins, blockSize);
        initObj.Init();
        // Coarse Search
        //cout<< "Coarse Search"<<endl;
        for (int i = -iterationCount; i <= iterationCount; i++)
        {
            for (int j = -iterationCount; j <= iterationCount; j++)
            {
                int srcX = (int)(j * stepWidth + 0.5f);
                int srcY = (int)(i * stepHeight + 0.5f);
                recB.x = recA.x + srcX;
                recB.y = recA.y + srcY;
                Mat cropB;
                try {
                    cropB = imageBGray(recB);
                }
                catch (std::exception& e) {
                    //Out of boundary
                    continue;
                }
                double data = 0.0;
                MatchHoGDesFast(initObj, cropB, &data);
                if (data < outData)
                {
                    outData = data;
                    mini = srcY;
                    minj = srcX;
                }
            }
        }
        // Superfine Search
        //cout<< "Superfine Search"<<endl;
        float restepWidth = stepWidth / (2* superfineIterationCount+1);
        if (restepWidth <= 1.0f)
            restepWidth = 1.0f;
        float restepHeight = stepHeight / (2 * superfineIterationCount + 1);
        if (restepHeight <= 1.0f)
            restepHeight = 1.0f;
        int superfinrMini = mini, superfinrMinj = minj;
        outData = std::numeric_limits<double>::max();
        if (stepWidth > 1.0f || stepHeight > 1.0f)
        {
            for (int i = -superfineIterationCount; i <= superfineIterationCount; i++)
            {
                for (int j = -superfineIterationCount; j <= superfineIterationCount; j++)
                {
                    int srcX = (int)(j * restepWidth + 0.5f);
                    int srcY = (int)(i * restepHeight + 0.5f);
                    recB.x = recA.x + minj + srcX;
                    recB.y = recA.y + mini + srcY;
                    Mat cropB;
                    try {
                        cropB = imageBGray(recB);
                    }
                    catch (std::exception& e) {
                        //Out of boundary
                        continue;
                    }
                    double data = 0.0;
                    MatchHoGDesFast(initObj, cropB, &data);
                    if (data < outData)
                    {
                        outData = data;
                        superfinrMini = mini + srcY;
                        superfinrMinj = minj + srcX;
                    }
                }
            }
        }
        //cout<< "Final Output"<<endl;
        recFinal.x += superfinrMinj;
        recFinal.y += superfinrMini;
        boxOut.x = recFinal.x;
        boxOut.y = recFinal.y;
        boxOut.w = recFinal.width;
        boxOut.h = recFinal.height;

        cv::rectangle(imB, recFinal, cv::Scalar(0, 255, 0));
        recA = recB;
        //imwrite("/home/shanam_a/project/output/temp.jpg", imB);
        return boxOut;
    }

    int MatchHoGDesFast(InitTracking &initObj, Mat& imB, double* OutData)
    {
        /*Size cellSize(8, 8);
        int nbins = 9;
        Size blockSize(2, 2);*/
        Mat imA = initObj.templateImage;
        HOGDescriptor hogB(Size(imA.cols / initObj.cellSize.width * initObj.cellSize.width, imA.rows / initObj.cellSize.height * initObj.cellSize.height),
            Size(initObj.blockSize.height * initObj.cellSize.height, initObj.blockSize.width * initObj.cellSize.width),
            Size(initObj.cellSize.height, initObj.cellSize.width),
            initObj.cellSize,
            initObj.nbins);;
        vector<float> dersB;
        vector<Point> locsB;
        hogB.compute(imB, dersB, Size(initObj.cellSize.height, initObj.cellSize.width), Size(0, 0));
        Mat HogfeatB(dersB.size(), 1, CV_32FC1);
        for (int i = 0; i < dersB.size(); i++)
            HogfeatB.at<float>(i, 0) = dersB.at(i);
        double distance = 0;
        for (int i = 0; i < initObj.HogfeatA.rows; i++)
            distance += abs(initObj.HogfeatA.at<float>(i, 0) - HogfeatB.at<float>(i, 0));
        // Cross Correlation coficient calculation 
        *OutData = distance;
        return 1;
    }
};
