#include <iostream>
#include <opencv2/opencv.hpp>
#include <chrono>
using namespace std::chrono;
using namespace cv;
using namespace std;

typedef struct image {
    int w;
    int h;
    int c;
    void *data;
} image;

typedef struct box {
    int x, y, w, h;
} box;


#ifdef __cplusplus
extern "C"
{
#endif
    box ObjectTracking(const image *imageA, const image *imageB, const box *bboxA, int margin);
    //int MatchHoGDesFast(Mat &imA, Mat &imB, double *OutData);
#ifdef __cplusplus
}
#endif
