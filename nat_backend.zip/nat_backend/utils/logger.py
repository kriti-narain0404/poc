"""
Created on Wed Jun 18 17:30:40 2018
@author: HCL Technologies Ltd
"""

import logging
import os
import base64
from controller.nat_config_controller import NATConfigController
from utils.ops_encrypt import EncryptDecrypt
from logging.handlers import RotatingFileHandler
config_obj = NATConfigController.read_config()


class Logger(object):
    """
    This class responsible to Logger Object to write application log
    """

    @staticmethod
    def get_logger():
        """
            This method returns a logger object and configures logging as per
            Parameters defined in configuration file
        Return:
            logger: It returns logger object.
        """
        logger = None
        try:
            logger = logging.getLogger(__name__)
            if not logger.handlers:
                LOGGER_FORMATTER = "[%(asctime)s] - %(levelname)s [%(filename)s:%(lineno)d] :\
            %(message)s"

                os.environ['ENV']=config_obj.get('DEFAULT','ENVIRONMENT')             
                logger_level = config_obj.get(os.environ.get('ENV'),'LOGGER_LEVEL')
                
                logging_file_path = EncryptDecrypt.decrypt_incoming(config_obj.get(os.environ.get("ENV"), "LOGGING_FILE_PATH"))                
                max_bytes = int(config_obj.get(os.environ.get("ENV"), "MAX_BYTES"))
                backup_count = int(config_obj.get(os.environ.get("ENV"), "BACKUP_COUNT"))
                handler = RotatingFileHandler(logging_file_path, 'w', max_bytes, backup_count)
                handler.doRollover()
                formatter = logging.Formatter(LOGGER_FORMATTER)
                handler.setFormatter(formatter)
                logger.addHandler(handler)
                logger.setLevel(logger_level)
        except Exception as error:
            logger.error(error)
            #raise ASRConfigError
            raise Exception()
        return logger
