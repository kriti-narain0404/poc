import os
import time 
from structures.data_structures import *
import numpy as np
from ctypes import *
import cv2
import json
#import commons.constants as const
from controller.nat_config_controller import NATConfigController
import utils.python_wrapper as wrapper
from utils.logger import Logger
from utils.settings_utils import SettingsUtils
from dao.data import Data
logger = Logger.get_logger()

class AutoTracking(object):
    @staticmethod
    def get_labelIDlist_from_json(jsonData):
        logger.info("[Start]: get_labelIDlist_from_json")

        listLabelID = []
        for i in jsonData:
            if 'bbox' in i.keys():
                label = i['bbox']['label']
                uniqueID = i['bbox']['parameters'][0]['val']
                listLabelID.append([label, uniqueID])
            elif 'polygon' in i.keys():
                label_poly = i['polygon']['label']
                uniqueID_poly = i['polygon']['parameters'][0]['val']
                listLabelID.append([label_poly, uniqueID_poly])
            logger.info("[Exit]: get_labelIDlist_from_json")
        return listLabelID


    @staticmethod
    def track_object(imgT, bboxT, imgS):
        logger.info("[Start]: track_object")
        cropped_template = imgT[bboxT[1]:bboxT[3], bboxT[0]:bboxT[2]]
        # Crop Source Image
        w = cropped_template.shape[1]
        h = cropped_template.shape[0]
        marginX = int(w*0.15)
        marginY = int(h * 0.15)
        if marginX <= 5:
            marginX = 5
        if marginY <= 5:
            marginY = 5
        left = bboxT[0] - marginX
        right = bboxT[2] + marginX
        top = bboxT[1] - marginY
        bottom = bboxT[3] + marginY
        if left < 0:
            left = 0
        if top < 0:
            top = 0
        if right > (imgS.shape[1]-1):
            right = imgS.shape[1]-1
        if bottom > (imgS.shape[0]-1):
            bottom = imgS.shape[0]-1
        cropped_source = imgS[top:bottom, left:right]
        # Apply template Matching
        #res = cv2.matchTemplate(cropped_source, cropped_template, cv2.TM_CCORR_NORMED)
        res = cv2.matchTemplate(cropped_source, cropped_template, cv2.TM_SQDIFF_NORMED)
        min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(res)
        (startX, startY) = min_loc
        startX = startX + left
        startY = startY + top
        endX = startX + w
        endY = startY + h
        logger.info("[Exit]: track_object")
        return [startX, startY, endX, endY]


    @staticmethod
    def update_bbox_using_tracking(imageNxtPath, imageTPath, jasonPathT, labelIDList, jsonPathNxt):
        logger.info("[Start]: update_bbox_using_tracking")

        #config_obj = NATConfigController.read_config()
        imgT = cv2.imread(imageTPath, 1)
        height, width, channels = imgT.shape
        margin = 20
        #margin = config_obj.get(os.environ.get('ENV'),'AUTO_TRACK_MARGIN')

        imageA = imgT.ctypes.data_as(POINTER(c_uint8))
        imgA = wrapper.IMAGENEW()
        imgA.h = height
        imgA.w = width
        imgA.c = channels
        imgA.data = imageA

        imgN = cv2.imread(imageNxtPath, 1)
        imageB = imgN.ctypes.data_as(POINTER(c_uint8))
        imgB = wrapper.IMAGENEW()
        imgB.h = height
        imgB.w = width
        imgB.c = channels
        imgB.data = imageB


        
        #imgT = cv2.imread(imageTPath, 0)
        #img_h, img_w , _ = imgT.shape
        filename_A = os.path.basename(imageTPath)
        filename_A = os.path.splitext(filename_A)[0]
        filename_B = os.path.basename(imageNxtPath)
        filename_B = os.path.splitext(filename_B)[0]
        
        with open(jasonPathT, encoding='utf-8', errors='ignore') as json_data:
            data = json.load(json_data, strict=False)

        if imageA  == None or imageB == None:
            return
        else:

            for i in data['img']:
                for j in data['img'][i]:
                    count = 0
                    for k in data['img'][i][j]:
                        try:
                            label = data['img'][i][j][count]['bbox']['label']
                            uniqueID = data['img'][i][j][count]['bbox']['parameters'][0]['val']
                        except:
                            count += 1
                            continue
                        
                        for IDLabel in labelIDList:
                            if IDLabel[0] == label and IDLabel[1] == uniqueID:
                                xmin = data['img'][i][j][count]['bbox']['xmin']
                                xmax = data['img'][i][j][count]['bbox']['xmax']
                                ymax = data['img'][i][j][count]['bbox']['ymax']
                                ymin = data['img'][i][j][count]['bbox']['ymin']
                                xA = xmin
                                yA = ymin
                                wA = xmax - xmin + 1
                                hA = ymax - ymin + 1
                                
                                bboxA = wrapper.BOX()
                                bboxA.x = int(xA)
                                bboxA.y = int(yA)
                                bboxA.w = int(wA)
                                bboxA.h = int(hA)
                                #print("boxa")
                                #print(f"xminA:{xmin}, yminA:{ymin}, xmaxA:{xmax}, ymaxA:{ymax}\n")
                                #print(f"xA:{bboxA.x}, yA:{bboxA.y}, wA:{bboxA.w}, hA:{bboxA.h}\n")
                                bboxB = wrapper.object_tracker(byref(imgA), byref(imgB), byref(bboxA), margin)
                                xminB = bboxB.x
                                yminB = bboxB.y
                                xmaxB = bboxB.w + xminB - 1
                                ymaxB = bboxB.h + yminB -1
                                #print("boxb")
                                #print(f"xB:{bboxB.x}, yB:{bboxB.y}, wB:{bboxB.w}, hB:{bboxB.h}\n")
                                #print(f"xminB:{xminB}, yminB:{yminB}, xmaxB:{xmaxB}, ymaxB:{ymaxB}\n")

                    
                                data['img'][i][j][count]['bbox']['xmin'] = xminB
                                data['img'][i][j][count]['bbox']['xmax'] = xmaxB
                                data['img'][i][j][count]['bbox']['ymax'] = ymaxB
                                data['img'][i][j][count]['bbox']['ymin'] = yminB
                        count += 1
            data['img'][filename_B] = data['img'].pop(filename_A)
            with open(jsonPathNxt, 'w') as fp:
                json.dump(data, fp)

        return



    
