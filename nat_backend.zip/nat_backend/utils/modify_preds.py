import os
from utils.files import Files
from commons import constants as cfg

fpath = os.path.join(SettingsUtils.get_value_by_key(SettingsUtils.KEY_DATAPATH), cfg.PREDS_FNAME)
preds = Files.load_json(fpath)


new_preds = {
    'metrics': preds['metrics'],
    'dset': preds['dset'],
    'imgs': {}
}

for id_,img in preds['imgs'].items():
    record = {
        "img_id": id_,
        "annotations": []
    }
    for box in img['bboxes']:
        anno_id = Files.gen_unique_id()
        
        box['points'] = []
        box['annoId'] = anno_id
        box['id'] = Files.gen_unique_id()
        record['annotations'].append({
            "id": anno_id,
            "label": box['label'],
            "bbox": box,
            "polygon": None
        })
        new_preds['imgs'][id_] = record



Files.save_json(fpath, new_preds)

