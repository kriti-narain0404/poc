import os
import urllib.request, urllib.error

# custom packages
from commons import constants as cfg
from structures.data_structures import *
from dao.user_dao import UserDAO
from dao.project_dao import ProjectDAO
from dao.workdiv_dao import WorkdivDao
from dao.data import *
from dao.login_activity_dao import LoginActiveInactive
from utils.logger import Logger


logger = Logger.get_logger()

class UserUtils(object):
    @staticmethod
    def login(user, password):
        logger.info("[Start]: login")
        response = None
        try:
            allow = False
            cur = cfg.mysql_db.get_db().cursor()
            result = UserDAO.find_by_username(user, cur)
            if result:
                userid = result[0]
                activated = result[2]
                auth_pin =  ""
                if (result[3] != None):
                    auth_pin = "True"
                    if (result[4] > 2):
                        auth_pin = "Locked"
                if activated:
                    if UserDAO.login_by_password(user, password):
                        allow = True
                else:
                    allow = True    # Will help show msg on the frontend
            else:
                logger.debug("User not found %s"%(user))

            last_project = None
            if allow:
                logger.debug("User found: %s %s"%(str(userid), user))
                query = "SELECT authority_name FROM nat_user_authority WHERE user_id=%s" % (userid)
                cur.execute(query)
                res3 = cur.fetchone()
                role = cfg.ROLE_ANNOTATOR
                if res3:
                    role = res3[0]
                    if role == "ADMIN":
                        query1 = ("select last_selected from nat_admin where user_id=%s")
                        cur.execute(query1,userid)
                        last_project = cur.fetchone()[0]
                    elif role == "VALIDATOR":
                        query1 = ("select last_selected from nat_validator where user_id=%s")
                        cur.execute(query1,userid)
                        last_project = cur.fetchone()[0]
                    elif role == "ANNOTATOR":
                        try:
                            query1 = ("select last_selected from nat_annotator where user_id=%s")
                            cur.execute(query1,userid)
                            last_project = cur.fetchone()[0]
                        except:
                            last_project = None
                response = {
                    'userid' : userid,
                    'username' : user,
                    'role' : role,
                    'activated' : activated,
                    'last_project': last_project,
                    'auth_pin': auth_pin
                }
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: login")
        
        return response

    @staticmethod
    def save_project_team(jsondata, loggedin_user):
        logger.info("[Start]: save_project_team")
        response = None
        try:
            cur = cfg.mysql_db.get_db().cursor()
            for admin in jsondata:
                if not admin['changed']:
                    continue
                logger.debug("Saving Project %s"%(admin["project"]))
                project = ProjectDAO.create_if_not_exists(admin["project"])
                project_id = project[0]
                UserDAO.clean_project_team(project_id)
                user = {
                    'login': admin["username"],
                    'role': admin['role'],
                    'project_id': project_id,
                    'userid': '',
                    'loggedin_user': loggedin_user
                }
                result = UserDAO.create_if_not_exists(user, cur)
                if result:
                    admin_id = user['userid'] = result[0]
                    resp_proj_admin = UserDAO.add_project_admin(user, cur)
                    nat_admin_id = resp_proj_admin[0]
                    for validator in admin["validators"]:
                        val_user = {
                            'login': validator["username"],
                            'role': validator['role'],
                            'project_id': project_id,
                            'userid': '',
                            'admin_id': admin_id,
                            'loggedin_user': loggedin_user
                        }
                        result = UserDAO.create_if_not_exists(val_user, cur)
                        if result:
                            validator_id = val_user['userid'] = result[0]
                            resp_proj_valid = UserDAO.add_project_validator(val_user, nat_admin_id, cur)
                            my_annotators = []
                            nat_validator_id = resp_proj_valid[0]
                            for annotator in validator["annotators"]:
                                anno_user = {
                                    'login': annotator["username"],
                                    'role': annotator['role'],
                                    'project_id': project_id,
                                    'userid': '',
                                    'admin_id': admin_id,
                                    'validator_id': validator_id,
                                    'loggedin_user': loggedin_user
                                }
                                result = UserDAO.create_if_not_exists(anno_user, cur)
                                annotator_id = 0
                                if result:
                                    annotator_id = anno_user['userid'] = result[0]
                                    my_annotators.append(anno_user)

                            if my_annotators:
                                UserDAO.add_project_annotators(my_annotators, nat_validator_id, cur)
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: save_project_team")
        return response

    @staticmethod
    def get_team(user_id,proId):
        '''
        Function for extracting the projects data and team data , with work division data to display
        args -
            user_id - (Int) user ID of current session admin user
        return -
            response - (ObjUserList | list) List of users with their projects and work division data 
        '''
        logger.info("[Start]: get_team")
        response = []
        try:
            cur = cfg.mysql_db.get_db().cursor()
            # userLists = []
            projects = ProjectDAO.get_all(user_id,cur,proId)
            userLists = UserUtils.make_project_team(user_id,projects=projects, cur=cur)
            workDiv = WorkdivDao.make_workdiv_obj(proId)
            response = ObjUserList(
                userList = userLists,
                workDiv = workDiv
            )
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: get_team")
        return response

    @staticmethod
    def make_project_team(user_id,projects=None, cur=None):
        logger.info("[Start]: make_project_team")
        
        response = []
        try:
            if cur is None:
                cur = cfg.mysql_db.get_db().cursor()

            if projects is None:
                projects = ProjectDAO.get_all(user_id,cur)
                
            if not projects:
                raise Exception('No projects found')
            
            query_prj_admins = "SELECT user_id, admin_name, project_id FROM nat_admin " 
            cur.execute(query_prj_admins)
            rows_prj_admins = list(cur.fetchall())
            str_list = str(rows_prj_admins)
            admins_dict = {}
            for row in rows_prj_admins:
                try:
                    admins_dict[row[2]].append(row)
                except:
                    admins_dict[row[2]] = [row]
            str_admins_list = str(admins_dict)
            query_prj_vals = "SELECT user_id, validator_name, admin_id, project_id" \
                             " FROM nat_validator"
            cur.execute(query_prj_vals)
            rows_prj_vals = list(cur.fetchall())
            vals_dict = {}
            for row in rows_prj_vals:
                try:
                    vals_dict[row[3]].append(row)
                except:
                    vals_dict[row[3]] = [row]

            query_prj_annos = "SELECT user_id, annotator_name, admin_id, validator_id, project_id " \
                              " FROM nat_annotator"
            cur.execute(query_prj_annos)
            rows_prj_annos = list(cur.fetchall())
            annos_dict = {}
            for row in rows_prj_annos:
                try:
                    annos_dict[row[4]].append(row)
                except:
                    annos_dict[row[4]] = [row]

            for project_id, project_name in projects.items():
                r = UserUtils.get_project_team(project_id, project_name=project_name, cur=cur,
                                               rows_prj_admins=admins_dict.get(project_id),
                                               rows_prj_vals=vals_dict.get(project_id),
                                               rows_prj_annos=annos_dict.get(project_id))
                response.extend(r)
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: make_project_team")
        return response

    @staticmethod
    def get_project_team(project_id, project_name='', cur=None, rows_prj_admins=None, rows_prj_vals=None, rows_prj_annos=None):
        logger.info("[Start]: get_project_team")
        response = None
        try:
            if cur is None:
                cur = cfg.mysql_db.get_db().cursor()

            if not project_name:
                project = ProjectDAO.get_by_id(project_id, cur=cur)
                project_name = project['project_name']

            if not rows_prj_admins:
                logger.debug("rows_prj_admins is None")
                query_prj_admins = "SELECT user_id, admin_name FROM nat_admin" \
                    " WHERE project_id=%s" % (project_id)
                cur.execute(query_prj_admins)
                rows_prj_admins = list(cur.fetchall())
            obj_prj_admins = []
            admin_ids = [row[0] for row in rows_prj_admins]
            

            if not rows_prj_vals:
                logger.debug("rows_prj_vals is None")
                query_prj_vals = "SELECT user_id, validator_name, admin_id" \
                    " FROM nat_validator" \
                    " WHERE project_id=%s" % (project_id)
                cur.execute(query_prj_vals)
                rows_prj_vals = list(cur.fetchall())
            dict_prj_vals = {admin_id: [] for admin_id in admin_ids}  # Init dict with admin ids as key and blank []
            obj_prj_vals = {admin_id: [] for admin_id in admin_ids}   # Will contain final objects of type Validator
            val_ids = {admin_id: [] for admin_id in admin_ids}  # Init dict with admin ids as key to store val ids wrt admin ids
           
            for row in rows_prj_vals:
                
                try:
                    dict_prj_vals[row[2]].append(row)
                    val_ids[row[2]].append(row[0])
                except:
                    pass
           

            for key, items in val_ids.items():
                val_ids[key] = list(set(items))

            if not rows_prj_annos:
                logger.debug("rows_prj_annos is None")
                query_prj_annos = "SELECT user_id, annotator_name, admin_id, validator_id "\
                    " FROM nat_annotator" \
                    " WHERE project_id=%s" % (project_id)
                cur.execute(query_prj_annos)
                rows_prj_annos = list(cur.fetchall())
            obj_prj_annos = {admin_id: { val_id: [] for val_id in val_ids[admin_id] } for admin_id in admin_ids}     # Init nested dict with admin ids and val ids as key and blank []
           
            for row in rows_prj_annos:
                try:
                    status_1 = False
                    status_1 = LoginActiveInactive(row[0]).active_status_1()
                    status_2 = False
                    status_2 = LoginActiveInactive(row[0]).active_status_2()
                    obj_prj_annos[row[2]][row[3]].append(Annotator(
                        status_1 = status_1,
                        status_2 = status_2,
                        username = row[1],
                        editmode = False,
                        role = cfg.ROLE_ANNOTATOR
                    ))
                except:
                    pass

            for key, item in dict_prj_vals.items():     # key is admin id
                for val in item:
                    try:
                        status_1 = False
                        status_1 = LoginActiveInactive(val[0]).active_status_1()
                        status_2 = False
                        status_2 = LoginActiveInactive(val[0]).active_status_2()
                        obj_prj_vals[key].append(Validator(
                            status_1 = status_1,
                            status_2 = status_2,
                            username = val[1],
                            editmode = False,
                            role = cfg.ROLE_VALIDATOR,
                            annotators = obj_prj_annos[key][val[0]]
                        ))
                    except:
                        pass

            for row in rows_prj_admins:
                try:
                    obj_prj_admins.append(UserList(
                        # userid = row[0],                # admin id
                        project = project_name,
                        project_id = project_id,
                        projectEditmode = False,
                        username = row[1],
                        editmode = False,
                        role = cfg.ROLE_ADMIN,
                        validators = obj_prj_vals[row[0]],
                        changed = False
                    ))
                except:
                    pass
            response = obj_prj_admins
            # workDiv = WorkdivDao.make_workdiv_obj()
            # response = ObjUserList(
            #     userList = obj_prj_admins,
            #     workDiv = workDiv
            # )
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: get_project_team")
        return response


    @staticmethod
    def get_users_assignation_list(userid, role, project_id):
        logger.info("[Start]: get_users_assignation_list")
        response = []
        try:
            cur = cfg.mysql_db.get_db().cursor()
            if role == cfg.ROLE_ADMIN:
                # query = "SELECT user_id, validator_name FROM nat_validator" \
                #     " WHERE admin_id=%s" % (userid)
                query = "SELECT user_id, validator_name FROM nat_validator" \
                    " WHERE project_id=%s AND admin_id=%s" % (project_id, userid)
                cur.execute(query)
                rows = cur.fetchall()
                for row in rows:
                    response.append({
                        'userid': row[0],
                        'username': row[1],
                        'role': cfg.ROLE_VALIDATOR,
                        'activated': 1
                    })
            elif role == cfg.ROLE_VALIDATOR:
                # query = "SELECT user_id, annotator_name FROM nat_annotator" \
                #     " WHERE validator_id=%s" % (userid)
                query = "SELECT user_id, annotator_name FROM nat_annotator" \
                    " WHERE project_id=%s AND validator_id=%s" % (project_id, userid)
                cur.execute(query)
                rows = cur.fetchall()
                for row in rows:
                    response.append({
                        'userid': row[0],
                        'username': row[1],
                        'role': cfg.ROLE_ANNOTATOR,
                        'activated': 1
                    })
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: get_users_assignation_list")
        return response
