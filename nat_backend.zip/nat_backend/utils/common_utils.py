import os
import hashlib
import secrets
from urllib import response
from structures.data_structures import ObjLoginUser, ObjSecret
import pyotp
import pyqrcode
from pyqrcode import QRCode

from utils.logger import Logger
logger = Logger.get_logger()

class my_dictionary(dict): 
  
    # __init__ function 
    def __init__(self): 
        self = dict() 
          
    # Function to add key:value 
    def add(self, key, value): 
        self[key] = value

class CommonUtils:
    @staticmethod
    def generate_password_hash(password):
        logger.info("[Start]: generate_password_hash")
        response = None
        try:
            if password is None:
                return None
            salt = os.urandom(16)
            key = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, 100000)
            response = salt + key
            response = response.hex()
        except Exception as error_obj:
            logger.info("[Exit]: generate_password_hash")
        return response

    @staticmethod
    def verify_password(password, password_hash):
        logger.info("[Start]: verify_password")
        response = False
        try:
            password_hash = bytearray.fromhex(password_hash)
            salt = password_hash[:16]
            key = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, 100000)
            p = salt + key
            if p == password_hash:
                response = True
        except Exception as error_obj:
            logger.info("[Exit]: verify_password")
        return response

    @staticmethod
    def verify_otp(otp, key):
        logger.info("[Start]: verify_otp")
        response = None
        try:
            if pyotp.TOTP(key).verify(otp):
                response = True
        except Exception as error_obj:
            logger.error(error_obj)
            logger.info("[Exit]: verify_otp")
        return response

    @staticmethod
    def generate_tfa_secret(username):
        logger.info("[Start] : generate_tfa_secret")
        secret=pyotp.random_base32()
        uri = "otpauth://totp/%s?secret=%s" % (username, secret)
        qr = pyqrcode.create(uri).text()
        print(qr)
        response =  ObjSecret(
            secret = secret,
            qr = qr
        )
        return response
        
