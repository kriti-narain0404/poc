import sys
from utils.logger import Logger
from commons.constants import ERROR_LIST
logger = Logger.get_logger()


class Error(object):

  @staticmethod
  def get_error_object(error_obj):
    '''
    This function is to check which type of error we have, if the error raised in any API which is present in
    ERROR_LIST then that error will be as a response, else the "Error from server" will be displayed.
    '''
    logger.info("[Start]: get_error_code")
    try:
      if error_obj in ERROR_LIST:
        error_msg = error_obj
      else:
        error_msg = "ServerError"

    except Exception as error_obj:
      logger.error(error_obj)
    logger.info("[Exit]: get_error_code")
    return error_msg