import os

# Custom packages
from structures.data_structures import *
from utils.logger import Logger
logger = Logger.get_logger()


class AnnotationUtils(object):

    @staticmethod
    def make_param(param):
      logger.info("[Start]: make_param")
      logger.info("[Exit]: make_param")
      return Param(
        nam=param['nam'],
        val=param['val']
      )




    @staticmethod
    def make_point(shape):
        logger.info("[Start]: make_point")
        logger.info("[Exit]: make_point")
        return Point(
            id=shape['id'],
            x=shape['x'],
            y=shape['y']
        )


    @staticmethod
    def make_points(anno):
        logger.info("[Start]: make_points")
        pts = []
        points = anno['points']
        for point in points:
            pts.append(AnnotationUtils.make_point(point))
        logger.info("[Exit]: make_points")
        return pts


    def make_params(anno):
        logger.info("[Start]: make_params")
        pms = []
        try:
            params = anno['parameters']
            for param in params:
                pms.append(AnnotationUtils.make_param(param))

        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: make_params")
        return pms

    @staticmethod
    def make_polygon(poly):
        logger.info("[Start]: make_polygon")
        polygon = None
        try:
          if poly is None:
              logger.info("[Exit]: make_polygon")
              return None
          else:
            polygon = Polygon(
              id=poly["id"],
              annoId=poly["annoId"],
              label=poly["label"],
              fill=poly["fill"],
              opacity=poly["opacity"],
              score=poly["score"],
              look=poly["look"],
              points=AnnotationUtils.make_points(poly),
              parameters=AnnotationUtils.make_params(poly),
          )
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: make_polygon")
        return polygon

    @staticmethod
    def make_bounding_box(box):
        logger.info("[Start]: make_bounding_box")
        bbox = None
        try:
          if box is None:
              logger.info("[Exit]: make_bounding_box")
              return None
          else:
            bbox = BoundingBox(
              id=box["id"],
              annoId=box['annoId'],
              label=box["label"],
              fill=box["fill"],
              opacity=box["opacity"],
              score=box["score"],
              xmin=box["xmin"],
              ymin=box["ymin"],
              xmax=box["xmax"],
              ymax=box["ymax"],
              points=AnnotationUtils.make_points(box),
              parameters=AnnotationUtils.make_params(box),
          )
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: make_bounding_box")
        return bbox

    @staticmethod
    def make_annotation(anno):
        logger.info("[Start]: make_annotation")
        anno = Annotation(
            id=anno["id"],
            label=anno["label"],
            bbox=AnnotationUtils.make_bounding_box(anno['bbox']),
            polygon=AnnotationUtils.make_polygon(anno['polygon'])
        )
        logger.info("[Exit]: make_annotation")
        return anno

    @staticmethod
    def make_annotations(annoList):
        logger.info("[Start]: make_annotations")
        annos = []
        for anno in annoList:
            annos.append(AnnotationUtils.make_annotation(anno))
        logger.info("[Exit]: make_annotations")
        return annos
