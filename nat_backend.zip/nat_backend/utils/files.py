import os
import random
from glob import glob
import shutil
import gzip
import pickle
import json
from contextlib import closing
from zipfile import ZipFile, ZIP_DEFLATED
import re
import uuid

from utils.logger import Logger
logger = Logger.get_logger()


class Files(object):

    @staticmethod
    def gen_unique_id(prefix='', length=10):
        logger.info("[Start]: gen_unique_id")
        logger.info("[Exit]: gen_unique_id")
        return prefix + str(uuid.uuid4()).upper().replace('-','')[:length]


    @staticmethod
    def get_fnames_from_fpaths(fpaths):
        logger.info("[Start]: get_fnames_from_fpaths")
        fnames = []
        try:
            for f in fpaths:
                if isinstance(f, tuple):
                    f = f[0]
                fnames.append(os.path.basename(f))
        except Exception as error_obj:
          logger.error(error_obj)
        logger.info("[Exit]: get_fnames_from_fpaths")
        return fnames


    @staticmethod
    def get_matching_files_in_dir(dirpath, regex):
        logger.info("[Start]: get_matching_files_in_dir")
        match_objs, match_fpaths = [], []
        try:
            fpaths = glob(os.path.join(dirpath,'*.*'))
            for i in range(len(fpaths)):
                match = re.search(regex, fpaths[i])
                if match is not None:
                    match_objs.append(match)
                    match_fpaths.append(fpaths[i])
        except Exception as error_obj:
          logger.error(error_obj)
        logger.info("[Exit]: get_matching_files_in_dir")
        return match_objs, match_fpaths


    @staticmethod
    def zipdir(basedir, archivename):
        logger.info("[Start]: zipdir")
        try:
            assert os.path.isdir(basedir)
            with closing(ZipFile(archivename, "w", ZIP_DEFLATED)) as z:
                for root, dirs, files in os.walk(basedir):
                    #NOTE: ignore empty directories
                    for fn in files:
                        absfn = os.path.join(root, fn)
                        zfn = absfn[len(basedir)+len(os.sep):] #XXX: relative path
                        z.write(absfn, zfn)
        except Exception as error_obj:
          logger.error(error_obj)
        logger.info("[Exit]: zipdir")


    @staticmethod
    def unzipdir(archive_path, dest_path, remove=True):
        logger.info("[Start]: unzipdir")
        try:
            ZipFile(archive_path).extractall(dest_path)
            if remove:
                os.remove(archive_path)
        except Exception as error_obj:
          logger.error(error_obj)
        logger.info("[Exit]: unzipdir")


    @staticmethod
    def save_json(fpath, dict_):
        logger.info("[Start]: save_json")
        try:
            with open(fpath, 'w') as f:
                json.dump(dict_, f, indent=4, ensure_ascii=False, sort_keys=True)
        except Exception as error_obj:
          logger.error(error_obj)
        logger.info("[Exit]: save_json")


    @staticmethod
    def load_json(fpath):
        logger.info("[Start]: load_json")
        json_ = None
        try:
            with open(fpath, 'r') as f:
                json_ = json.load(f)
        except Exception as error_obj:
          logger.error(error_obj)
        logger.info("[Exit]: load_json")
        return json_


    @staticmethod
    def pickle_obj(obj, fpath):
        logger.info("[Start]: pickle_obj")
        try:
            with open(fpath, 'wb') as f:
                pickle.dump(obj, f, pickle.HIGHEST_PROTOCOL)
        except Exception as error_obj:
          logger.error(error_obj)
        logger.info("[Exit]: pickle_obj")


    @staticmethod
    def unpickle_obj(fpath):
        logger.info("[Start]: unpickle_obj")
        try:
            with open(fpath, 'rb') as f:
                logger.info("[Exit]: unpickle_obj")
                return pickle.load(f)
        except Exception as error_obj:
          logger.error(error_obj)


    @staticmethod
    def get_fname_from_fpath(fpath):
        logger.info("[Start]: get_fname_from_fpath")
        logger.info("[Exit]: get_fname_from_fpath")
        return os.path.basename(fpath)


    @staticmethod
    def get_paths_to_files(root, file_ext=None, sort=True, strip_ext=False):
        logger.info("[Start]: get_paths_to_files")
        filepaths = fnames = []

        try:
            for (dirpath, dirnames, filenames) in os.walk(root):
                filepaths.extend(os.path.join(dirpath, f)
                    for f in filenames if file_ext is None or f.endswith(file_ext))
                fnames.extend([f for f in filenames if file_ext is None or f.endswith(file_ext)])
            if strip_ext:
                fnames = [os.path.splitext(f)[0] for f in fnames]
            if sort:
                return sorted(filepaths), sorted(fnames)
        except Exception as error_obj:
          logger.error(error_obj)
        logger.info("[Exit]: get_paths_to_files")
        return filepaths, fnames


    @staticmethod
    def get_random_image_path(dir_path):
        logger.info("[Start]: get_random_image_path")
        response = None
        try:
            filepaths = get_paths_to_files(dir_path)[0]
            response = filepaths[random.randrange(len(filepaths))]
        except Exception as error_obj:
          logger.error(error_obj)
        logger.info("[Exit]: get_random_image_path")
        return response


    @staticmethod
    def save_obj(obj, out_fpath):
        logger.info("[Start]: save_obj")
        try:
            with open(out_fpath, 'wb') as f:
                pickle.dump(obj, f)
        except Exception as error_obj:
          logger.error(error_obj)
        logger.info("[Exit]: save_obj")


    @staticmethod
    def load_obj(fpath):
        logger.info("[Start]: load_obj")
        logger.info("[Exit]: load_obj")
        return pickle.load(open(fpath, 'rb'))


    @staticmethod
    def compress_file(fpath):
        logger.info("[Start]: compress_file")
        try:
            gzip_fpath = fpath+'.gz'
            with open(fpath, 'rb') as f_in:
                with gzip.open(gzip_fpath, 'wb') as f_out:
                    shutil.copyfileobj(f_in, f_out)
        except Exception as error_obj:
          logger.error(error_obj)
        logger.info("[Exit]: compress_file")
        return gzip_fpath


    @staticmethod
    def write_lines(fpath, lines, compress=False):
        logger.info("[Start]: write_lines")
        try:
            lines_str = '\n'.join(lines)
            if compress:
                fpath += '.gz'
                lines_str = str.encode(lines_str)
                f = gzip.open(fpath, 'wb')
            else:
                f = open(fpath, 'w')
            f.write(lines_str)
            f.close()
        except Exception as error_obj:
          logger.error(error_obj)
        logger.info("[Exit]: write_lines")
        return fpath

    @staticmethod
    def get_frames_count(imagepath):
        logger.info("[Start]: get_frames_count")
        imagescount = 0
        try:
            for f in os.listdir(imagepath):
                if os.path.isfile(os.path.join(imagepath, f)) and (f.endswith('.jpg') or f.endswith('.png')):
                    imagescount += 1
        except Exception as error_obj:
          logger.error(error_obj)
        logger.info("[Exit]: get_frames_count")
        return imagescount

    @staticmethod
    def get_labeljson_count(filepath):
        logger.info("[Start]: get_labeljson_count")
        labeljsoncount = 0
        try:
            files = [f for f in os.listdir(filepath) if os.path.isfile(os.path.join(filepath, f))]
            logger.debug("Files - %s", str(files))
            labeljsoncount = 0
            for f in files:
                if f.endswith('_label.json'):
                    labeljsoncount += 1
        except Exception as error_obj:
          logger.error(error_obj)
        logger.info("[Exit]: get_labeljson_count")
        return labeljsoncount

    @staticmethod
    def get_labeljson_list(filepath):
        logger.info("[Start]: get_labeljson_list")
        jsonlist = []
        try:
            jsonlist = [f for f in os.listdir(filepath) if os.path.isfile(os.path.join(filepath, f)) and f.endswith('_label.json')]
            logger.debug("Files - %s", str(jsonlist))
        except Exception as error_obj:
          logger.error(error_obj)
        logger.info("[Exit]: get_labeljson_list")
        return jsonlist

    @staticmethod
    def get_frames_list(imagepath):
        logger.info("[Start]: get_frames_list")
        imageslist = []
        try:
            imageslist = [f for f in os.listdir(imagepath) if os.path.isfile(os.path.join(imagepath, f)) and (f.endswith('.jpg') or f.endswith('.png'))]
        except Exception as error_obj:
          logger.error(error_obj)
        logger.info("[Exit]: get_frames_list")
        return imageslist