import random
from PIL.ExifTags import TAGS
import PIL.Image, PIL.ImageOps

from structures.data_structures import *
from dao.data import Data
from commons import constants as cfg
from utils.logger import Logger

logger = Logger.get_logger()


class ImageUtils(object):

    @staticmethod
    def make_images_list(imageList, jsonList):
        logger.info("[Start]: make_images_list")
        imagedetails = None
        try:
            images = []
            for image in imageList:
                images.append(image)
            jsons = []
            for json in jsonList:
                jsons.append(json.replace(".json", "").replace("_label", ""))

            imagedetails = ObjImage(
                images=images,
                jsons=jsons
            )
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: make_images_list")
        return imagedetails

    

    @staticmethod
    def make_unlabeled_img(project, id_):
        logger.info("[Start]: make_unlabeled_img")

        image = None
        try:
            image = Image(
                id=id_,
                project=project,
                src=Data.img_url(id_),
                thumbnail=Data.img_url(id_),
                thumbnailWidth=cfg.DEFAULT_WIDTH,
                thumbnailHeight=cfg.DEFAULT_HEIGHT,
                tags=[],
                caption=id_,
                modelTags=[],
                modelProbs=[]
            )
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: make_unlabeled_img")
        return image

    # TODO: Need to decide whether to create new file or not

    @staticmethod
    def save_image_data(fold, id_, tags, dset=None, model_tags=None, model_probs=None):
        logger.info("[Start]: save_image_data")
        try:
            dset = ImageUtils.get_random_dset() if dset is None else dset
            entry = Data.make_entry(tags, model_tags, model_probs)
            Data.move_unlabeled_to_labeled(fold, dset, id_, entry)
            Data.save_fold(fold)
            Data.update_counts(fold["name"])
            logger.info("[Exit]: save_image_data")
        except Exception as error_obj:
            logger.error(error_obj)

    @staticmethod
    def get_random_dset(val_ratio=cfg.VAL_FOLD_RATIO):
        logger.info("[Start]: get_random_dset")
        try:
            if random.random() <= val_ratio:
                logger.info("[Exit]: get_random_dset")
                return cfg.VAL

        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: get_random_dset")
        return cfg.IMG

    @staticmethod
    def make_image(id_, fold, dset):
        logger.info("[Start]: make_image")
        image = None
        try:
            if dset == cfg.UNLABELED:
                return ImageUtils.make_unlabeled_img(fold['name'], id_)
            img_meta = fold[dset][id_]
            tags = [] if img_meta is None else img_meta['labels']
            mdl_tags = [] if img_meta is None else img_meta['model_labels']
            mdl_probs = [] if img_meta is None else img_meta['model_probs']

            image = Image(
                id=id_,
                project=fold['name'],
                src=Data.img_url(id_),
                thumbnail=Data.img_url(id_),
                thumbnailWidth=cfg.DEFAULT_WIDTH,
                thumbnailHeight=cfg.DEFAULT_HEIGHT,
                tags=tags,
                caption=id_,
                modelTags=mdl_tags,
                modelProbs=mdl_probs
            )
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: make_image")
        return image

    @staticmethod
    def get_orientation(filepath):
        logger.info("[Start]: get_orientation")
        response = 1
        try:
            im = PIL.Image.open(filepath)
            exif_data = im.getexif()
            labeled = {}
            for (key, val) in exif_data.items():
                labeled[TAGS.get(key)] = val
            response = labeled.get('Orientation')
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: get_orientation")
        return response

    @staticmethod
    def change_orientation(filepath, orientation):
        response = True
        logger.info("[Start]: change_orientation")
        try:
            im = PIL.Image.open(filepath)
            im_new = None
            if orientation == 1:
                pass
            elif orientation == 2:
                im_new = PIL.ImageOps.mirror(im)
            elif orientation == 3:
                im_new = im.rotate(180, expand=1)
            elif orientation == 4:
                im_new = PIL.ImageOps.mirror(im)
                im_new = im_new.rotate(180, expand=1)
            elif orientation == 5:
                im_new = PIL.ImageOps.mirror(im)
                im_new = im_new.rotate(270, expand=1)
            elif orientation == 6:
                im_new = im.rotate(270, expand=1)
            elif orientation == 7:
                im_new = PIL.ImageOps.mirror(im)
                im_new = im_new.rotate(90, expand=1)
            elif orientation == 8:
                im_new = im.rotate(90, expand=1)
            im_new.save(filepath, quality=95)
        except Exception as error_obj:
            response = False
            logger.error(error_obj)
        logger.info("[Exit]: change_orientation")
        return response

