import os

# Custom packages
from structures.data_structures import *
from utils.image_utils import ImageUtils
from dao.data import *
from utils.logger import Logger
logger = Logger.get_logger()

class EvalUtils(object):

    @staticmethod
    def make_metrics_details(videodetails):
        logger.info("[Start]: make_metrics_details")
        videometricsdata = None
        try:
          jsonfilename='metrics.json'
          mertics_path =videodetails[3]+"/json"
          metrics_data = Data.load_metrics_data(mertics_path,jsonfilename)
          videometricsdata = ObjImageId(
              videoid=videodetails[0],
              metricspath=mertics_path,
              imagename = metrics_data['name_cnl'],
              accuracyval = metrics_data['accuracy_cnl'],
              editval = metrics_data['edit_cnl'],
              updatedval = metrics_data['updated_cnl'],
              locaccval = metrics_data['locacc_cnl']
          )
          ImageUtils.get_all_images_detail(videodetails[0])
        except Exception as error_obj:
          logger.error(error_obj)
        logger.info("[Exit]: make_metrics_details")
        return videometricsdata

    @staticmethod
    def images_metrics_details(jsonpath, imagename):
        logger.info("[Start]: images_metrics_details")
        
        metrics_data = None
        try:
          metrics_data = imagename
        except Exception as error_obj:
          logger.error(error_obj)

        logger.info("[Exit]: images_metrics_details")
        return metrics_data
