#!/usr/bin/env python3

"""
Python 3 wrapper for identifying objects in images
"""

import os
from ctypes import *




class BOX(Structure):
    """
    Bounding box structure
    """
    _fields_ = [("x", c_int),
                ("y", c_int),
                ("w", c_int),
                ("h", c_int)]


class IMAGENEW(Structure):
    """
    Image structure
    """
    _fields_ = [("w", c_int),
                ("h", c_int),
                ("c", c_int),
                ("data", POINTER(c_uint8))]


# shared library
if os.name == "posix":
    cwd = os.path.dirname(__file__)
    so_file_dir =  os.path.join(cwd, "so_files")
    so_list = sorted(os.listdir(so_file_dir))
    # lib = CDLL(os.path.join(so_file_dir, so_list[0]), RTLD_GLOBAL)
else:
    print("[ERROR]: Unsupported OS")
    exit


# object_tracker = lib.ObjectTracking
# object_tracker.restype = BOX
object_tracker = None