import base64

class EncryptDecrypt:
    """
    Description          : This class has method for encrypting and decrypting the data
    """
    @staticmethod
    def encode_incoming(message):
        """
        Description       : this method is used to encrypt the incoming message
        :param message    : this is the input to be encrypted
        """
        if type(message) is not str:
            message = str(message)
        return base64.b64encode(bytes(message, 'utf-8')).decode('utf-8')

    @staticmethod
    def decrypt_incoming(message):
        """
        Description       : this method is used to dencrypt the incoming message
        :param message    : this is the input to be decrypted
        """
        return base64.b64decode(bytes(message, 'utf-8')).decode('utf-8')

