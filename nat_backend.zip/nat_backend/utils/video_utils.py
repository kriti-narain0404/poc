import os
import datetime
import re
import json


# custom packages
from commons import constants as cfg
from structures.data_structures import *
from dao.data import *
from utils.settings_utils import SettingsUtils
from utils.logger import Logger
logger = Logger.get_logger()
from dao.settings_dao import SettingsDao
from dao.data import Data
import base64


class VideoUtils(object):
    # TODO: Need to move to common script
    @staticmethod
    def atoi(text):
        logger.info("[Start]: atoi")
        logger.info("[Exit]: atoi")
        return int(text) if text.isdigit() else text

    # TODO: Need to move to common script
    @staticmethod
    def natural_keys(text):
        logger.info("[Start]: natural_keys")
        logger.info("[Exit]: natural_keys")
        return [ VideoUtils.atoi(c) for c in re.split('(\d+)', text) ]

    @staticmethod
    def make_video_details(videodetails, videoid, imageid):
        logger.info("[Start]: make_video_details")

        videodata = None
        folder_assign = videoid
        try:
            videos = []
            videoname = videodetails[1]
            lastfolder = os.path.basename(videodetails[2])
            cfg.LAST_PATH = lastfolder
            #project_path = os.path.join(cfg.BASE_PATH, cfg.PROJECT_NAME, cfg.LAST_PATH)
            #cfg.MEDIA_PATH = os.path.join(project_path, 'images')
            project_path = SettingsUtils.get_value_by_key(SettingsUtils.KEY_DATAPATH)
            cfg.MEDIA_PATH = os.path.join(project_path, videoname)
            Image_Path = os.path.join(cfg.MEDIA_PATH, 'images/')
            imagecount = len([name for name in os.listdir(Image_Path)])
            videourl = cfg.IMG_ENDPOINT + '/{:s}/{:s}'.format('noesis_data',videoname)
            videodata = ObjVideoDetails(
                videoid=videoid,
                videoname=videodetails[1],
                videourl=videourl,
                videopath=videodetails[2],
                imageid=imageid,
                imagecount=imagecount

            )
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: make_video_details")
        return videodata

    @staticmethod
    def make_timestamp(timestamp):
        logger.info("[Start]: make_timestamp")
        logger.info("[Exit]: make_timestamp")

        start_time = timestamp['starttime']
        end_time = timestamp['endtime']
        starttime = StartTime(
            hh=start_time['hh'],
            mm=start_time['mm'],
            ss=start_time['ss'],
        )
        endtime = EndTime(
            hh=end_time['hh'],
            mm=end_time['mm'],
            ss=end_time['ss'],
        )
        return TimeStamp (
            eventtype = timestamp['eventtype'],
            starttime = starttime,
            endtime = endtime)

    @staticmethod
    def make_preview_video_details(videoid,videoname):
        logger.info("[Start]: make_preview_video_details")
        timestamp = []
        videodata = None
        try:
            project_path = SettingsUtils.get_value_by_key(SettingsUtils.KEY_DATAPATH)
            cfg.MEDIA_PATH = os.path.join(project_path, videoname)
            json_path = cfg.MEDIA_PATH +'/timestamp.json'
            with open(json_path) as f:
                data = json.load(f)
                preview_video_name = data['videoname']
                total_duration=str(data['total_duration'])
                time_stamps=data['TimeStamp']
                for time_stamp in time_stamps:
                    timestamp.append(VideoUtils.make_timestamp(time_stamp))
            videourl = cfg.IMG_ENDPOINT + '/{:s}/{:s}'.format('noesis_data',videoname) +'/'+ preview_video_name
            videodata = ObjPreviewVideoDetails(
                videoid=videoid,
                videoname=preview_video_name,
                videourl=videourl,
                total_duration=total_duration,
                timestamp=timestamp

            )
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: make_preview_video_details")
        return videodata

    @staticmethod
    def make_video(video, users_dict):
        logger.info("[Start]: make_video")
        try:
            videoid=int(video[0])
            if video[5] is not None:
                if video[5] == b'\x01':
                    video[5] = True
                elif video[5] == b'\x00':
                    video[5] = False

            if video[6] is not None:
                if video[6] == b'\x01':
                    video[6] = True
                elif video[6] == b'\x00':
                    video[6] = False

            if video[15] is not None:
                if video[15] == b'\x01':
                    video[15] = True
                elif video[15] == b'\x00':
                    video[15] = False

        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: make_video")
        return Video(
                videoid=video[0],
                videoname=video[1],
                assigneuserid=video[7],
                assigned=video[5],
                processed =video[6],
                submitted =video[15],
                videodate= video[3],
                validatorassignid = video[12],
                annotatorusername = users_dict.get(video[7]),
                validatorusername = users_dict.get(video[12]),
                no_frames = video[16],
                no_labeljsons = video[17],
                video_type=video[19],

            #videodate =json.dumps(video[6], indent=4, sort_keys=True, default=str)
            )

    @staticmethod
    def make_video_list(videoList, users_dict):
        logger.info("[Start]: make_video_list")
        try:
            videos = []
            for video in videoList:
                videos.append(VideoUtils.make_video(list(video), users_dict) )
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: make_video_details")
        return videos

    @staticmethod
    def save_video_image(video_path, video_name, videoid, image_path, image_name):
        logger.info("[Start]: save_video_image")
        try:
            image_date = str(datetime.datetime.now())
            video_id = str(videoid)
            imagefile = image_name
            ext = os.path.splitext(imagefile)[-1].lower()
            if ext == cfg.IMG_EXT_JPG or ext == cfg.IMG_EXT_PNG:
                cur = cfg.mysql_db.get_db().cursor()
                query = "INSERT INTO image (`image_date` ,`image_name` ,`image_path`," \
                        "`image_url`,`image_meta_data`,`video_id`) " \
                        "VALUES ('" + image_date + "', '" + imagefile + "', '" + image_path + "'," \
                                                                                             "'" + image_path + "','" + " " + "','" + video_id + "')"
                cur.execute(query)
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: save_video_image")

    @staticmethod
    def save_upload_video(image_path, image_name, video_name, video_path, user_id):
        logger.info("[Start]: save_upload_video")
        try:
            cur = cfg.mysql_db.get_db().cursor()
            video_date = str(datetime.datetime.now())
            user_id = str(user_id)
            query = "INSERT INTO video (`assigned_user_id` ,`video_date` ,`video_name` ,`video_path`,`assigned`,`processed`, `video_type`) " \
              "VALUES ('" + user_id + "','" + video_date + "', '" + video_name + "', '" + video_path + "', True,False,1)"
            cur.execute(query)
            query = ("SELECT * FROM video where  video_name = %s ")
            cur.execute(query, video_name)
            result = list(cur.fetchone())
            videoid =result[0]
            VideoUtils.save_video_image(video_path, video_name, videoid, image_path, image_name)
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: save_upload_video")

    def save_image_cloud(base64Image, filename):
        logger.info("[Start]: save_image_cloud")
        try:
            data = base64Image[base64Image.find(",") + 1:]
            imagedata = base64.b64decode(data)
            #filename = filename
            with open(filename, 'wb') as f:
                f.write(imagedata)
        except Exception as error_obj:
            logger.error(error_obj)
            print ("save image cloud: ",error_obj)

        logger.info("[Exit]: save_image_cloud")

    @staticmethod
    def set_video_processed_if(video):
        logger.info("[Start]: set_video_processed_if - %s", video[1])
        is_processed = False
        try:
            cur = cfg.mysql_db.get_db().cursor()
            video_id = str(video[0])
            query = """ UPDATE video SET processed=True WHERE id =%s """
            cur.execute(query, video_id)
            logger.info("Video set as processed=True")
            is_processed = True
                
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: set_video_processed_if")
        return is_processed

    @staticmethod
    def update(video_id, props={}):
        logger.info("[Start]: update - %s", video_id)
        response = True
        try:
            if props is None:
                raise Exception("props is None")
            if len(props) == 0:
                raise Exception("props is empty")
            cur = cfg.mysql_db.get_db().cursor()
            setstr = []
            for key, val in props.items():
                setstr.append(key+"='"+str(val)+"'")
            setstr = ",".join(setstr)
            query = "UPDATE video SET "+setstr+" WHERE id=%s"
            cur.execute(query, video_id)
        except Exception as error_obj:
            logger.error(error_obj)
            response = False
        logger.info("[Exit]: update")
        return response

    @staticmethod
    def after_save_frame(video_id, videoname):
        logger.info("[Start]: after_save_frame")
        response = True
        try:
            props = {}
            datapath = SettingsUtils.get_value_by_key(SettingsUtils.KEY_DATAPATH)
            videopath = os.path.join(datapath, videoname)

            filepath = os.path.join(videopath, 'json')
            labeljsoncount = Files.get_labeljson_count(filepath)
            props['no_labeljsons'] = labeljsoncount

            #to be removed, put here because of bug
            imagepath = os.path.join(videopath, 'images')
            imagescount = Files.get_frames_count(imagepath)
            props['no_frames'] = imagescount

            VideoUtils.update(video_id, props)
        except Exception as error_obj:
            logger.error(error_obj)
            response = False
        logger.info("[Exit]: after_save_frame")
        return response

    @staticmethod
    def after_submit(video_id, videoname):
        logger.info("[Start]: after_submit - %s", video_id)
        response = True
        try:
            props = {}
            VideoUtils.update(video_id, props)
        except Exception as error_obj:
            logger.error(error_obj)
            response = False
        logger.info("[Exit]: after_submit")
        return response
