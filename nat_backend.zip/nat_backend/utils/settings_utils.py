import os
import json
import datetime
import time


from structures.data_structures import *
from dao.settings_dao import SettingsDao
from dao.user_dao import UserDAO
from utils.logger import Logger
from utils.ops_encrypt import EncryptDecrypt as ed
from nat_refactor.Commons.SaveSettings import SaveSettings
from nat_refactor.Commons.GetSettings import GetSettings
logger = Logger.get_logger()


class SettingsUtils(object):

    FILEPATH = 'commons/settings.json'

    KEY_DATAPATH = 'folderPath'
    KEY_PREDTYPE = 'predType'

    @staticmethod
    def get_value_by_key(key):
        logger.info("[Start]: get_value_by_key")
        logger.debug("Fetching value of %s"%(key))
        response = None
        try:
            found = False
            logger.debug("[Start]: reading_from_json_file")
            with open(SettingsUtils.FILEPATH) as json_file:
                data = json.load(json_file)
                if key in data:
                    response = data.get(key)
                    found = True
                    logger.debug("Found in file")
            logger.debug("[Exit]: reading_from_json_file")
            if not found:
                response = SettingsDao.get_value_by_key(key)
            if key == "settingObject":
                response = json.loads(response)
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: get_value_by_key")
        logger.debug("Response: %s"%(response))
        return response

    @staticmethod
    def save_json(userid, project_id, settingObject,predType,modelType,outputFormat,folderPath,minHeight,minWidth,annoTip, class_added, frames_to_interpolate):
        logger.info("[Start]: save_json")
        response = True
        try:
            folderPath = os.path.join(folderPath, '')
            role = UserDAO.get_role_by_userid(userid)

            table_data = {
                'setting_data': json.dumps(settingObject),
                'model_type': modelType,
                'pred_type': predType,
                'output_format': outputFormat,
                'anno_tip': annoTip,
                'min_width': minWidth,
                'min_height': minHeight,
                'folder_path': ed.encode_incoming(folderPath),
                'frames_to_interpolate': frames_to_interpolate,
                'last_modified_date': datetime.datetime.now()
            }

            settingData = {
                'settingObject': settingObject,
                'predType': predType,
                'modelType': modelType,
                'outputFormat': outputFormat,
                'minHeight': minHeight,
                'minWidth': minWidth,
                'annoTip': annoTip,
            }
            classes_all = [i["name"] for i in class_added]
            # classes_all = ["cat", "dog"]
            ### pass the classes_all in comment if csv method to load settings given that admin submits settings.
            # classes_all = [i["name"] for i in settingObject if i["selected"]]
            try:
                settingData['settingObject'] = json.dumps(settingObject)
            except:
                pass
            # add error catch.
            save_settings = SaveSettings(userid, project_id, logger)
            try:
                if classes_all and role == "ADMIN":
                    save_settings.insert_class_data(classes_all)
                save_settings.save_settings(table_data)
                settingData['settingObject'] = settingObject
                settingData['folderPath'] = folderPath
                with open(SettingsUtils.FILEPATH, 'w+') as json_file:
                    json.dump(settingData, json_file, sort_keys=True, indent=4)
            finally:
                save_settings.close()
        except Exception as error_obj:
            response = False
            logger.error(error_obj)
        logger.info("[Exit]: save_json")
        return response

    @staticmethod
    def save_preview_video_json(videoid, preview_video_name, videoname, total_duration, timestamp):
        logger.info("[Start]: save_preview_video_json")
        response = True
        try:
            project_path = SettingsUtils.get_value_by_key(SettingsUtils.KEY_DATAPATH)
            MEDIA_PATH = os.path.join(project_path, videoname)
            json_path = MEDIA_PATH + '/timestamp.json'
            videoData = {
                'videoname': preview_video_name,
                'total_duration': total_duration,
                'TimeStamp': timestamp,
            }
            json_object = json.dumps(videoData, indent=4)
            with open(json_path, "w") as outfile:
                outfile.write(json_object)

        except Exception as error_obj:
            response = False
            logger.error(error_obj)
        logger.info("[Exit]: save_preview_video_json")
        return response

    @staticmethod
    def get_settingObject(settingObject):
        logger.info("[Start]: get_settingObject")
        response = []
        try:
            data_obj = []
            for row in settingObject:
                data_obj.append(
                    SettingData(
                        id = row['id'],
                        name = row['name'],
                        selected = row['selected'],
                        type = row['type'],
                        color = row['color'],
                        length = row['length'],
                    )
                )
            response = data_obj
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: get_response")
        return response

    @staticmethod
    def get_response_updated(userid, projectid):
        """
        Description           : This method has the function of returning the settings for a particular userid
        userid                : The user for which the settings are asked. (Type: int)

        """
        logger.info("[Start]: get_response_updated")
        logger.info("[StartTime]: {timest}".format(timest=time.time()))
        response = None
        classes_to_be_entered = []
        get_settings = GetSettings(userid, projectid)
        try:
            response, classes_to_be_entered, admin_only = get_settings.get_settings()
        except Exception as error_obj:
            print(str(error_obj))
            logger.error(error_obj)
        finally:
            get_settings.close()
        logger.info("[Exit]: get_response")
        return response, classes_to_be_entered, admin_only


    @staticmethod
    def get_response():
        logger.info("[Start]: get_response")
        response = None
        try:
            data = SettingsDao.get_objects_dict()
            annoTip= data.get('annoTip')
            folderPath= data.get('folderPath')
            minHeight= data.get('minHeight')
            minWidth= data.get('minWidth')
            modelType= data.get('modelType')
            outputFormat= data.get('outputFormat')
            predType= data.get('predType')
            settingObject = data.get('settingObject')
            try:
                settingObject = json.loads(settingObject)
            except:
                settingObject = []

            try:
                with open(SettingsUtils.FILEPATH) as json_file:
                    try:
                        data = json.load(json_file)
                    except Exception as error_obj:
                        data = {}
                    folderPath = data.get('folderPath')
                    if 'annoTip' in data:
                        annoTip = data.get('annoTip')
                    if 'settingObject' in data:
                        sobj = data.get('settingObject')
                        sdict = {}
                        for ob in sobj:
                            sdict[ob["id"]] = ob
                        for ob in settingObject:
                            if ob["id"] in sdict:
                                ob["selected"] = sdict[ob["id"]]["selected"]
            except Exception as error_obj:
                data = {}
            response = SettingObject(
                annoTip=annoTip,
                folderPath=folderPath,
                minHeight=minHeight,
                minWidth=minWidth,
                modelType=modelType,
                outputFormat=outputFormat,
                predType=predType,
                settingObject=SettingsUtils.get_settingObject(settingObject)
                )
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: get_response")
        return response

    @staticmethod
    def update_json():
        logger.info("[Start]: update_json")
        response = False
        try:
            data = SettingsDao.get_objects_dict()
            annoTip= data.get('annoTip')
            folderPath= data.get('folderPath')
            minHeight= data.get('minHeight')
            minWidth= data.get('minWidth')
            modelType= data.get('modelType')
            outputFormat= data.get('outputFormat')
            predType= data.get('predType')
            settingObject = data.get('settingObject')
            try:
                settingObject = json.loads(settingObject)
            except:
                settingObject = []

            try:
                with open(SettingsUtils.FILEPATH) as json_file:
                    try:
                        data = json.load(json_file)
                    except Exception as error_obj:
                        data = {}
                    folderPath = data.get('folderPath')
                    if 'annoTip' in data:
                        annoTip = data.get('annoTip')
                    if 'settingObject' in data:
                        sobj = data.get('settingObject')
                        sdict = {}
                        for ob in sobj:
                            sdict[ob["id"]] = ob
                        for ob in settingObject:
                            if ob["id"] in sdict:
                                ob["selected"] = sdict[ob["id"]]["selected"]
            except Exception as error_obj:
                data = {}
            settingData = {
                'settingObject': settingObject,
                'folderPath': folderPath,
                'predType': predType,
                'modelType': modelType,
                'outputFormat': outputFormat,
                'minHeight': minHeight,
                'minWidth': minWidth,
                'annoTip': annoTip,
                }
            with open(SettingsUtils.FILEPATH, 'w+') as json_file:
                json.dump(settingData, json_file, sort_keys=True, indent=4)
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: update_json")
        return response

    @staticmethod
    def get_response_from_file():
        logger.info("[Start]: get_response_from_file")
        response = None
        try:
            data = {}
            with open(SettingsUtils.FILEPATH) as json_file:
                try:
                    data = json.load(json_file)
                except Exception as error_obj:
                    data = {}
            response = SettingObject(
                annoTip=data.get('annoTip'),
                folderPath=data.get('folderPath'),
                minHeight=data.get('minHeight'),
                minWidth=data.get('minWidth'),
                modelType=data.get('modelType'),
                outputFormat=data.get('outputFormat'),
                predType=data.get('predType'),
                settingObject=SettingsUtils.get_settingObject(data.get('settingObject'))
                )
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: get_response_from_file")
        return response


    
       

