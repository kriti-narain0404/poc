from utils.logger import Logger
from graphql import GraphQLError
from sys import exc_info
from dao.dashboard_dao import DashBoardDAO
logger = Logger.get_logger()
from utils.errors_utils import Error

class DashboardUtils:

    def __init__(self) -> None:
        pass

    def insert_data_for_user(self, userid, project_id, classes_to_enter, videoid):
        """
        Description      : This method enters the data for user in DB for classes selected upon call
        userid           : The user ID for which the data is to be fetched.
        projectid        : The project in which the user is working.
        classes_to_enter : A list containing the classes needed by the user for annotation
        """
        logger.info("[START]: Inside the fetch_data_of_user")
        return DashBoardDAO().insert_data_for_user(userid, project_id, classes_to_enter, videoid)

    def update_data_for_user(self, data, userid, project_id):
        """
        Description      : This method enters the data for user in DB for classes selected upon call
        userid           : The user ID for which the data is to be fetched.
        projectid        : The project in which the user is working.
        classes_to_enter : A list containing the classes needed by the user for annotation
        """
        logger.info("[START]: Inside the update_data_for_user")
        return DashBoardDAO().update_data_for_user(data, userid, project_id)

    def get_users_data(self, project_id, start_date, end_date):
        """
        Description      : This method gets data for productivity tab of the dashboard.
        project_id       : an integer value for a project
        start_date       : date from which the data is to be fetched for the project.
        end_date         : the date till which the data is to be fetched
        """
        logger.info("[START]: Inside get_users_data")
        return DashBoardDAO().fetch_users_work_details(project_id, start_date, end_date)

    def get_accuracy_data(self, project_id, start_date, end_date):
        logger.info("[Start]: Inside get_accuracy_data")
        return DashBoardDAO().fetch_accuracy_data(project_id, start_date, end_date)
