import os
import requests
import urllib.request, urllib.error

# custom packages
from commons import constants as cfg
from structures.data_structures import *
from dao.user_dao import UserDAO
from controller.nat_config_controller import NATConfigController
from dao.data import *
from utils.ops_encrypt import EncryptDecrypt
from utils.logger import Logger
logger = Logger.get_logger()
config_obj = NATConfigController.read_config()

class ScriptUtils(object):
    @staticmethod
    def check_connection():
        logger.info("[Start]: check_connection")
        response = False
        try:
            logger.debug("Testing connection to %s" % (EncryptDecrypt.decrypt_incoming(config_obj.get(os.environ.get('ENV'),'API_URL_BASE'))))
            urllib.request.urlopen(EncryptDecrypt.decrypt_incoming(config_obj.get(os.environ.get('ENV'),'API_URL_BASE')), timeout=1)
            response = True
        except urllib.error.URLError as err:
            pass
            # raise Exception('Unable to connect to Scripts Server')
        except Exception as e:
            logger.info(e)
        logger.info("[Exit]: check_connection")
        return response

    @staticmethod
    def merge(branch_from, branch_to, folder_name=''):
        logger.info("[Start]: merge")
        response = False
        try:
            if branch_from == branch_to:
                raise Exception("branch_from is same as branch_to")
            api_url_base = EncryptDecrypt.decrypt_incoming(config_obj.get(os.environ.get('ENV'),'API_URL_BASE'))
            api_url = '{0}v1/merge'.format(api_url_base)

            headers = {'Content-Type': 'application/json'}
            params = {'branch_from': branch_from, 'branch_to':branch_to, 'folder_name': folder_name}

            logger.debug("Requesting url {0}".format(api_url))
            resp = requests.post(api_url, headers=headers, params=params)
            logger.debug("Status code: {0}".format(resp.status_code))

            if resp.status_code == 200:
                data = resp.json()
                response = data
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: merge")
        return response
