import os
import json
import fnmatch
import csv
import numpy as np
import time
from csv import reader

import glob
from dao.data import Data as d
from commons import constants as cfg
c = cfg.ConstantsDashboard

class Dashboard:

    def __init__(self, path=None):
        self.path = path
        self.nat_projects_id = self.connect_with_DB()

    def connect_with_DB(self):
        cur = cfg.mysql_db.get_db().cursor()
        cur.execute("SELECT DISTINCT id FROM nat_project;")
        nat_project_list = []
        for project_id in cur.fetchall():
            nat_project_list.append(dict(zip(['id'], list(project_id))))
        return nat_project_list

    def find_files(self):
        """
        Description:
        This method finds files of the suitable extension in the root directory as provided by the user.
        :return: the absolute path of the files with particular extension in the root folder
        """
        matches = []
        for root, _, filenames in os.walk(self.json_path):
            for extensions in ["*.json"]:
                for filename in fnmatch.filter(filenames, extensions):
                    matches.append(os.path.join(root, filename))
        self.matches = d.natural_sort(matches)

    def create_event_csv_header(self, output_csv, data):
        with open(output_csv, "w") as csv_file:
            writer = csv.writer(csv_file)
            writer.writerow(data)
        csv_file.close()

    def write_events_to_csv(self,output_csv, data):
        with open(output_csv, "a") as csvfile:
            writer = csv.writer(csvfile)
            writer.writerows(data)
        csvfile.close()

    def read_json(self, file):
        json_read = json.load(open(file,))
        return json_read

    def get_dict_annotations(self, anno_data):
        response = {}
        for i in anno_data:
            if i['bbox']:
                bbox = [i['bbox']['xmin'], i['bbox']['ymin'], i['bbox']['xmax'], i['bbox']['ymax']]
                label = i['bbox']['label']
                param_list = i['bbox']['parameters']
                parameters = {}
                for param in param_list:
                    parameters[param["nam"]] = param["val"]
                value = [label, bbox, parameters]
                response[i['bbox']['id']] = dict(zip(c.key_for_annotation_dict, value))
        return response

    def get_attributes(self, json_dict):
        response = None
        keys_level0 = json_dict.keys()
        if 'img' in keys_level0:
            keys_level1 = json_dict["img"].keys()
            for key in keys_level1:
                try:
                    annotation_data = json_dict['img'][key]['annotations']
                    response = self.get_dict_annotations(annotation_data)
                except Exception as error_obj:
                    print("File has no key named annotations")
        return response

    def csv_data_extractor(self, output_csv):
        with open(output_csv, 'r') as read_obj:
            csv_reader = reader(read_obj)
            for r in csv_reader:
                keys = r
                break
            data = {}
            proj_data_list =[]
            if output_csv == self.accuracy_csv:
                try:
                    for row in csv_reader:
                        data_ = dict(zip(keys, row))
                        data[data_.get('Json_Name')] = data_
                except:
                    print("[INFO]: There is nothing in file except header")
                return data
            if output_csv == self.out_csv:
                try:
                    for row in csv_reader:
                        data_ = {}
                        for i in range(len(row)):
                            data_[keys[i]] = row[i]
                        data[data_.get('Json_Name')] = data_
                except:
                    print("[INFO]: There is nothing in file except header")
                return data, keys
            elif output_csv == self.proj_out_csv:
                try:
                    for row in csv_reader:
                        proj_data_list.append(dict(zip(keys, row)))
                except:
                    print("[INFO]: There is nothing in file except header")
                return proj_data_list

    def check_files(self):
        if not os.path.exists(self.out_csv):
            self.create_event_csv_header(self.out_csv,data=c.csv_header)

    def first_time_data_csv(self):
        json_data = {}
        json_data_csv = {}
        for file in self.matches:
            print("[FILE]: {} is being processed".format(file.split("/")[-1]))
            count_of_annotations = 0
            json_read = self.read_json(file)
            json_dump = json.dumps(json_read)
            json_data["{}".format(file.split("/")[-1])] = json_dump
            attr_present = self.get_attributes(json_read)
            count_of_annotations += len(attr_present)
            json_data_csv["{}".format(file.split("/")[-1])] = count_of_annotations
        return json_data, json_data_csv

    def load_np(self, np_obj=None, filename=None):
        json_data = None
        try:
            data = np_obj["arr_0"][0]
            json_data_dumped = data[filename]
            json_data = json.loads(json_data_dumped)
        except:
            pass
        return json_data

    def check_label(self, current_label, previous_label):
        return int(current_label!=previous_label)
    
    def check_bbox_coordinates(self, current_bbox, previous_bbox):
        return int(bool(np.sum(np.asarray(current_bbox) - np.asarray(previous_bbox))))

    def check_parameters(self,data):
        keys_para = list(data[0].keys())
        parameter_added = 0
        parameter_updated = 0
        for key in keys_para:
            if key in data[1]:
                if data[0][key] != data[1][key]:
                    parameter_updated += 1
            else:
                parameter_added += 1
        return parameter_added, parameter_updated

    def compare_data(self, actual=None, previous=None):
        label_updated = 0
        bbox_updated = 0
        anno_added = 0
        anno_deleted = 0
        parameter_updated = 0
        parameter_added = 0
        keys_added = []
        if actual and previous:
            previous_keys = list(previous.keys())
            actual_keys = list(actual.keys())
            for keys in actual_keys:
                if keys in previous:
                    try:
                        label_updated += self.check_label(actual[keys].get('label'), previous[keys].get('label'))                
                    except:
                        pass
                    try:
                        bbox_updated += self.check_bbox_coordinates(actual[keys].get('bbox'), previous[keys].get('bbox'))
                    except:
                        pass
                    try:
                        parameter_data = self.check_parameters([actual[keys].get("parameters"), previous[keys].get("parameters")])
                        parameter_updated += parameter_data[1]
                        parameter_added += parameter_data[0]
                    except:
                        pass
            if len(actual_keys)>len(previous_keys):
                anno_added += 1
            elif len(previous_keys)>len(actual_keys):
                anno_deleted += 1
        elif actual:
            anno_added += len(list(actual.keys()))
        elif previous:
            anno_deleted += len(list(previous.keys()))
        return label_updated, bbox_updated, anno_added, anno_deleted, parameter_updated, parameter_added

    def deleted_files_updation(self, signal, data_to_csv, date, time_, global_data, filename):
        keys_present, np_obj = signal
        data = np_obj["arr_0"][0]
        keys_in_prev = d.natural_sort(list(data.keys()))
        try:
            for i in keys_present:
                keys_in_prev.remove(i)
            if keys_in_prev:
                for i in keys_in_prev:
                    data_to_csv[i]['Count_of_annotation_deleted'] = data_to_csv[i]['Count_of_annotation_added']
                    data_to_csv[i]['Modified_datetime(YYYYMMDD-HHMMSS)'] = filename
                    data_to_csv[i]['Edit_count'] = str(int(data_to_csv[i]['Edit_count']) + 1)
        except:
            pass
        global_data += 1
        return data_to_csv, global_data

    def get_data(self, data):
        data_return = []
        k = d.natural_sort(list(data.keys()))
        for keys in k:
            im_info = data[keys]
            data_single_image = []
            for i in c.csv_header:
                data_single_image.append(im_info.get(i))
            data_return.append(data_single_image)
        return data_return

    def create_projectwise_compiled_csv(self, p_id):
        if not os.path.exists(self.path +c.DATA_PRODUCTIVITY_FOLDER):
            os.mkdir(self.path +c.DATA_PRODUCTIVITY_FOLDER)
        if not os.path.exists(self.path +c.DATA_ACCURACY_FOLDER):
            os.mkdir(self.path +c.DATA_ACCURACY_FOLDER)
        proj_out_csv = self.path +c.DATA_PRODUCTIVITY_FOLDER + "/project_"+str(p_id) +"_compiled.csv"
        accuracy_csv = self.path + c.DATA_ACCURACY_FOLDER + "/project_"+ "accuracy_" + str(p_id) + ".csv"
        if not os.path.exists(proj_out_csv):
            self.create_event_csv_header(proj_out_csv, data=c.project_csv_header)
        if not os.path.exists(accuracy_csv):
            self.create_event_csv_header(accuracy_csv, data=c.accuracy_csv_header)
        return proj_out_csv, accuracy_csv

    def get_data_from_DB(self, vid_name, p_id):
        cur = cfg.mysql_db.get_db().cursor()
        cur.execute("SELECT id, assigned_user_id, validator_assign_id FROM video where video_name = %s and project_id = %s",(vid_name,p_id))
        v_id = ""
        u_id = ""
        name = ""
        val_id = ""
        for vid_record in cur.fetchall():
            vid_record = list(vid_record)
            v_id = vid_record[0]
            u_id = vid_record[1]
            val_id = vid_record[2]
            cur.execute("SELECT first_name, last_name FROM nat_user where id = %s",(u_id,))
            for user_record in cur.fetchall():
                user_record = list(user_record)
                f_name = user_record[0]
                l_name = user_record[1]
                name = f_name + " " + l_name
        cur.execute("SELECT validator_name FROM nat_validator where project_id=%s and user_id=%s", (p_id, val_id))
        for data in cur.fetchall():
            val_id = list(data)[0]
        return  v_id, u_id, name, val_id

    def get_compiledData_from_folder_csv(self,vid_id,user_id, user_name): 
        out_csv_data = self.csv_data_extractor(self.out_csv)
        sum_anno_added = 0
        sum_coord_updated = 0
        sum_label_updated = 0
        sum_parameter_updated = 0
        sum_edit_counts = 0
        sum_anno_deleted = 0
        sum_anno_model = 0
        list_time_created = []
        list__time_modified = []
        for key, record in out_csv_data[0].items():
            sum_anno_model += int(record['Count_of_annotations'])
            sum_anno_added += int(record['Count_of_annotation_added'])
            sum_coord_updated += int(record['Count_of_coord/points_updated'])
            sum_label_updated += int(record['Count_of_label_updated'])
            sum_parameter_updated += int(record['Count_of_parameter_updated'])
            sum_edit_counts += int(record['Edit_count'])
            sum_anno_deleted += int(record['Count_of_annotation_deleted'])
            sum_anno_added -= int(record['Count_of_annotation_deleted'])
            list_time_created.append(record['Created_datetime(YYYYMMDD-HHMMSS)'])
            list__time_modified.append(record['Modified_datetime(YYYYMMDD-HHMMSS)'])
        video_name = self.out_csv.split('/')[-3]
        proj_data_record = {}
        for i in c.project_csv_header:
            proj_data_record[i] = ""    
            if i == "Video_Name":
                proj_data_record[i] = (video_name)
            if i =="Count_of_annotation_added":
                proj_data_record[i] = str(sum_anno_added)
            if i == "Count_of_annotations":
                proj_data_record[i] = str(sum_anno_model)
            if i == "Count_of_coord/points_updated":
                proj_data_record[i] = str(sum_coord_updated)
            if i == "Count_of_label_updated":
                proj_data_record[i] = str(sum_label_updated)
            if i == "Count_of_parameter_updated":
                proj_data_record[i] = str(sum_parameter_updated)
            if i == "Edit_count":
                proj_data_record[i] = str(sum_edit_counts)
            if i == "Count_of_annotation_deleted":
                proj_data_record[i] = str(sum_anno_deleted)
            if i == "Video_Id":
                proj_data_record[i] = str(vid_id)
            if i == "Assigned_User_Id":
                proj_data_record[i] = str(user_id)
            if i == "Assigned_User_Name":
                proj_data_record[i] = str(user_name)
            if i == "Created_datetime(YYYYMMDD-HHMMSS)":
                if len(list_time_created) == 0:
                    pass
                else:
                    proj_data_record[i] = str(max(list_time_created))
            if i == "Modified_datetime(YYYYMMDD-HHMMSS)":
                if len(list__time_modified) == 0:
                    pass
                else:
                    proj_data_record[i] = str(max(list__time_modified))
        proj_data_list = []
        for idx,i in enumerate(c.project_csv_header):
            proj_data_list.append(proj_data_record[i])
        return proj_data_list, video_name

    def write_data_to_proj_csv(self, p_csv_data,  v_name, project_data_list, val_id):
        # print('9'*100)
        # print(project_data_list,p_csv_data)
        write_flag = 0
        for record_row in p_csv_data:
            if record_row['Video_Name'] == v_name:
                write_flag = 1
        project_data_list[-1]=str(val_id)
        if write_flag == 0 or len(p_csv_data) == 0:
            self.write_events_to_csv(self.proj_out_csv, data=[project_data_list])
        data_for_single_video = dict(zip(c.project_csv_header, project_data_list))
        obj_det_acc = int(int(data_for_single_video.get("Count_of_annotations"))/(1e-8 + int(data_for_single_video.get("Count_of_annotations")) +
                                                                         int(data_for_single_video.get("Count_of_annotation_added"))))

        object_edit_count = int(data_for_single_video.get("Count_of_parameter_updated")) + int(data_for_single_video.get("Count_of_label_updated"))
        object_loc_acc = int(int(data_for_single_video.get("Count_of_coord/points_updated"))/(1+int(data_for_single_video.get("Count_of_annotations"))))
        object_del_count = int(data_for_single_video.get("Count_of_annotation_deleted"))
        v_name = data_for_single_video.get("Video_Name")
        data = [v_name, str(obj_det_acc), str(object_edit_count), str(object_loc_acc), str(object_del_count)]
        self.write_events_to_csv(self.accuracy_csv, [data])


    def call_main_v(self,vid_id,user_id, user_name, val_id):
        self.check_files()
        data_from_csv, csv_keys = self.csv_data_extractor(self.out_csv)
        filename = time.strftime("%Y%m%d-%H%M%S")
        date, time_ = filename.split("-")
        data_to_write = []
        global_check_data = 0
        if not data_from_csv:
            json_data, anno_count = self.first_time_data_csv()
            np.savez_compressed(
                "{}/{}".format(self.compressed_path, filename),
                [json_data])
            for key, value in anno_count.items():
                data_to_write.append(["{}".format(filename), "{}".format(filename), "{}".format(key) , "0",
                                     "{}".format(0), "{}".format(value), "0", "0", "0", "0", "{}".format(filename), "No"])
            self.write_events_to_csv(self.out_csv, data=data_to_write)
            with open('{}/latest_np_dump.txt'.format(self.compressed_path), 'w') as f:
                f.write("{}/{}.npz".format(self.compressed_path, filename))
            f.close()
        else:
            with open('{}/latest_np_dump.txt'.format(self.compressed_path)) as f:
                lines = f.readlines()
            previous_jsons = np.load(lines[0], allow_pickle=True)
            anno_count= {}
            json_data = {}
            present_files = []
            for file in self.matches:
                present_files.append(file.split("/")[-1])
                print("[FILE]: {} is being processed".format(file.split("/")[-1]))
                previous_json_read = self.load_np(np_obj=previous_jsons, filename="{}".format(file.split("/")[-1]))
                current_json_read = self.read_json(file)
                json_dump = json.dumps(current_json_read)
                json_data["{}".format(file.split("/")[-1])] = json_dump
                attr_present = self.get_attributes(current_json_read)
                if not previous_json_read:
                    key = file.split("/")[-1]
                    value = len(list(attr_present.keys()))
                    data_to_write = ["{}".format(filename), "{}".format(filename), "{}".format(key) , "0",
                                     "{}".format(0), "{}".format(value), "0", "0", "0", "0", "{}".format(filename), "No"]
                    global_check_data += 1
                    data_from_csv["{}".format(file.split("/")[-1])] = dict(zip(c.csv_header, data_to_write))
                else:
                    attr_previous = self.get_attributes(previous_json_read)
                    data_compare = self.compare_data(attr_present, attr_previous)
                    label_updated, bbox_updated, anno_added, anno_deleted, parameter_updated, parameter_added = data_compare
                    global_check_data += sum(data_compare)
                    if sum(data_compare):
                        key = file.split("/")[-1]
                        value = len(list(attr_present.keys()))
                        edit_count = int(data_from_csv["{}".format(file.split("/")[-1])].get('Edit_count'))
                        count_of_annotation_added = int(data_from_csv["{}".format(file.split("/")[-1])].get('Count_of_annotation_added'))
                        count_bbox_updated = int(data_from_csv["{}".format(file.split("/")[-1])].get('Count_of_coord/points_updated'))
                        count_label_updated = int(data_from_csv["{}".format(file.split("/")[-1])].get('Count_of_label_updated'))
                        count_parameter_updated = int(data_from_csv["{}".format(file.split("/")[-1])].get('Count_of_parameter_updated'))
                        edit_count += 1
                        count_of_annotation_added += anno_added
                        count_bbox_updated += bbox_updated
                        count_label_updated += count_label_updated
                        count_parameter_updated += parameter_updated
                        data_to_write = ["{}".format(data_from_csv["{}".format(file.split("/")[-1])].
                                                     get('Created_datetime(YYYYMMDD-HHMMSS)')), "{}".format(filename),
                                         "{}".format(key), "{}".format(edit_count), "{}".format(data_from_csv["{}".format(file.split("/")[-1])].
                                                     get('Count_of_annotations')), "{}".format(count_of_annotation_added),
                                         "{}".format(anno_deleted), "{}".format(count_bbox_updated), "{}".format(count_label_updated),
                                         "{}".format(count_parameter_updated), "{}".format(filename), "No"]
                        data_from_csv["{}".format(file.split("/")[-1])] = dict(zip(csv_keys, data_to_write))
            data_to_write, global_data = self.deleted_files_updation([present_files, previous_jsons], data_from_csv, date, time_, global_check_data, filename)
            data_to_csv = self.get_data(data_to_write)
            if global_data and data_to_csv:
                np.savez_compressed(
                    "{}/{}".format(self.compressed_path, filename),
                    [json_data])
                self.create_event_csv_header(self.out_csv,data=c.csv_header)
                self.write_events_to_csv(self.out_csv, data=data_to_csv)
                with open('{}/latest_np_dump.txt'.format(self.compressed_path), 'w') as f:
                    f.write("{}/{}.npz".format(self.compressed_path, filename))
                f.close()
            print("[INFO]: Done processing all files")
        project_data_list, vid_name = self.get_compiledData_from_folder_csv(vid_id,user_id, user_name)
        proj_csv_data = self.csv_data_extractor(self.proj_out_csv)
        self.write_data_to_proj_csv(proj_csv_data, vid_name, project_data_list, val_id)

    def remove_existing_proj_csv(self):
        csv_folders = [c.DATA_ACCURACY_FOLDER, c.DATA_PRODUCTIVITY_FOLDER]
        for i in csv_folders:
            csvs_list = glob.glob(os.path.join(self.path+i, "*.csv"))
            if len(csvs_list) != 0:
                for csv in csvs_list:
                    os.remove(csv)

    def call_main(self):
        self.remove_existing_proj_csv()
        for project_id_record in self.nat_projects_id:
            self.proj_out_csv, self.accuracy_csv = self.create_projectwise_compiled_csv(project_id_record['id'])
            folder_list = sorted(os.listdir(self.path))
            for vid_folder in folder_list:
                vid_folder_path = os.path.join(self.path,vid_folder)
                vid_id,user_id, user_name, val_id = self.get_data_from_DB(vid_folder, project_id_record['id'])
                if vid_id == "":
                    continue
                else:
                    json_folder, csv_folder, np_dump_folder = self.check_folders(vid_folder_path)
                    self.json_path = json_folder
                    self.find_files()
                    self.out_csv = csv_folder + c.CSV_NAME
                    self.compressed_path = np_dump_folder
                    self.call_main_v(vid_id,user_id, user_name, val_id)

    @staticmethod
    def check_folders(data):
        json_folder = data + c.JSON_FOLDER_NAME
        if not os.path.exists(json_folder):
            os.mkdir(json_folder)
        csv_folder = data + c.CSV_FOLDER_NAME
        if not os.path.exists(csv_folder):
            os.mkdir(csv_folder)
        np_dump_folder = data + c.NP_DUMP_NAME
        if not os.path.exists(np_dump_folder):
            os.mkdir(np_dump_folder)
        return json_folder, csv_folder, np_dump_folder

