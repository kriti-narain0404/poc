import os
import json
import traceback
from structures.data_structures import *
import datetime
from commons import constants as cfg
from utils.ops_encrypt import EncryptDecrypt as ed
from utils.logger import Logger
logger = Logger.get_logger()


class SettingsDao(object):
    @staticmethod
    def get_object_by_key(key):
        logger.info("[Start]: get_object_by_key")
        response = {}
        try:
            cur = cfg.mysql_db.get_db().cursor()
            query = """ SELECT id, `key`, value_data FROM nat_setting_data WHERE `key`='%s'""" % (key)
            cur.execute(query)
            r = cur.fetchone()
            if r:
                response = {
                    "id": r[0],
                    "key": r[1],
                    "value_data": r[2]
                }
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: get_object_by_key")
        return response

    @staticmethod
    def save_object(key, val):
        logger.info("[Start]: save_object")
        response = None
        try:
            cur = cfg.mysql_db.get_db().cursor()
            ob = SettingsDao.get_object_by_key(key)
            if ob:
                if ob['value_data'] != val:
                    query = """ UPDATE nat_setting_data SET value_data='%s'
                        WHERE id=%s """%(val, ob['id'])
                    cur.execute(query)
                    logger.debug("Updated key "+key)
            else:
                query = """INSERT INTO nat_setting_data(`key`, value_data) VALUES ('%s', '%s') """ % (key, val)
                cur.execute(query)
                logger.debug("Added key "+key)
            
            response = True
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: save_object")
        return response




    @staticmethod
    def get_objects_updated(userid, project_id):
        """
        Description              : This method is used to fetch the settings for a user from the nat_user_settings table.
        userid                   : This is the value for the user which is requesting the settings.(Type: int)
        project_id               : The project for which particular settings are asked.
        return                   : A list which contains dicts. If the user has logged in first time the settings of the admin are sent by default.
                                   If user already exists then the settings for admin and user are returned.
        """
        logger.info("[Start]: get_objects_updated")
        response=None
        admin_only_data=None
        try:
            cur = cfg.mysql_db.get_db().cursor()
            """
            The query below is used to get settings for the user and the admin from the database.
            """
            keys = ['user_id', 'setting_data', 'model_type', 'pred_type', 'output_format', 'anno_tip', 'min_width', 'min_height', 'folder_path', "frames_to_interpolate"]
            query = "SELECT user_id, setting_data, model_type, pred_type, output_format, anno_tip, min_width, min_height, folder_path, frames_to_interpolate" \
                    " FROM nat_user_setting WHERE project_id={project_id} AND user_id in ({userid}," \
                    "(SELECT user_id FROM nat_admin WHERE project_id={project_id}))".format(userid=userid,
                                                                                            project_id=project_id)
            cur.execute(query)
            rows = cur.fetchall()
            if len(rows)==1:
                value_data=[]
                for r in rows:
                    value_data = list(r)
                response = dict(zip(keys, value_data))
                admin_only_data = True
            else:
                response=[]
                for r in rows:
                    value_data = list(r)
                    response.append(dict(zip(keys, value_data)))
                admin_only_data = False
        except Exception as error_obj:
            logger.info("[in]")
            logger.error(error_obj)
        logger.info("[Exit]: get_objects_updated")
        return response, admin_only_data

    @staticmethod
    def insert_class_data(class_info, pid):
        """
        Description: This Method inserts a newly added class to the annotation_classes table
        class_info : This is a list of dict where key is "name" and value is classname.
        projectID  : An integer value which defines the project setting set by the admin.
        """
        logger.info("[START]: insert_class_data")
        response = True
        insert_data = []
        cur = cfg.mysql_db.get_db().cursor()
        # query to fetch already existing classes.
        query = "SELECT Class_Name from annotation_classes where Project_ID={}".format(pid)
        try:       
            cur.execute(query)
        except:
            logger.info("There is error in executing insert query, traceback:{}".format(traceback.format_exc(limit=1)))
            return False
        existing_classes = [class_[0] for class_ in cur.fetchall()]
        for k in class_info:
            #check if class already exist.
            if k not in existing_classes:
                insert_data.append(r"('{class_name}', '{pid}')".format(class_name=k, pid=pid))
        #query to insert the classes.
        query = "INSERT INTO annotation_classes (Class_Name, Project_ID) VALUES " + ','.join(insert_data)
        try:       
            cur.execute(query)
        except:
            logger.info("There is error in executing insert query, traceback:{}".format(traceback.format_exc(limit=1)))
            return False
        return response

    @staticmethod
    def insert_update_objects(settingdata, folder_path, userId, projectId, frames_to_interpolate):
        """
        Description              : This method helps in updation or insertion of the configuration from settings.
        settingData              : A dictionary containing some attributes for updation or insertion.
        folder_path              : The path to folder where images are present.
        userId                   : An integer value which defined the ID for the user.
        projectID                : An integer value which defines the project setting set by the admin.
        return                   : True if updation or insertion is done else False.
        """
        logger.info("[START]: Insert_Update_objects")
        response = False
        try:
            cur = cfg.mysql_db.get_db().cursor()
            query = "SELECT user_id, project_id FROM nat_user_setting WHERE user_id={userid} AND project_id={projectid}".format(userid=userId, projectid=projectId)
            cur.execute(query)
            rows = cur.fetchall()
            logger.info("[datetime_test]: {}".format(datetime.datetime.now()))
            if rows:
                query = "UPDATE nat_user_setting SET setting_data = '{setting_data}', model_type = '{model_type}', pred_type = '{pred_type}'," \
                        " output_format = '{output_format}', anno_tip = '{anno_tip}', min_width = '{min_width}', min_height = '{min_height}', frames_to_interpolate = '{frames_to_interpolate}', folder_path = '{folderPath}'" \
                        ", last_modified_date = '{date}' WHERE (user_id={userid} AND project_id={projectid})".format(setting_data=settingdata["settingObject"],
                                                                                                                     model_type=settingdata["modelType"],
                                                                                                                     pred_type=settingdata["predType"],
                                                                                                                     output_format=settingdata["outputFormat"],
                                                                                                                     anno_tip=settingdata["annoTip"],
                                                                                                                     min_width=settingdata["minWidth"],
                                                                                                                     min_height=settingdata["minHeight"],
                                                                                                                     frames_to_interpolate=frames_to_interpolate,
                                                                                                                     folderPath=ed.encode_incoming(folder_path),
                                                                                                                     date=datetime.datetime.now(),
                                                                                                                     userid=userId,
                                                                                                                     projectid=projectId)
                cur.execute(query)
            elif not rows:
                query = "INSERT INTO nat_user_setting (user_id, setting_data, model_type, pred_type," \
                        " output_format, anno_tip, min_width, min_height, folder_path, ceated_date, last_modified_date, project_id, frames_to_interpolate) VALUES" \
                        " ('{userid}', '{setting_data}', '{model_type}', '{pred_type}', '{output_format}', '{anno_tip}'," \
                        " '{min_width}', '{min_height}', '{folder_path}', '{date}', '{last_modified_date}', '{projectid}', '{frames_to_interpolate}')".format(userid=userId,
                                                                                                setting_data=settingdata["settingObject"],
                                                                                                model_type=settingdata["modelType"],
                                                                                                pred_type=settingdata["predType"],
                                                                                                output_format=settingdata["outputFormat"],
                                                                                                anno_tip=settingdata["annoTip"],
                                                                                                min_width=settingdata["minWidth"],
                                                                                                min_height=settingdata["minHeight"],
                                                                                                frames_to_interpolate = frames_to_interpolate,
                                                                                                folder_path=ed.encode_incoming(folder_path),
                                                                                                projectid=projectId,
                                                                                                date=datetime.datetime.now(),
                                                                                                last_modified_date=datetime.datetime.now())
                cur.execute(query)
                response = True
        except Exception as error_obj:
            logger.info("[in]")
            logger.error(error_obj)
        logger.info("[Exit]: Insert_Update_objects")
        return response

    @staticmethod
    def get_objects():
        logger.info("[Start]: get_objects")
        response = []
        try:
            cur = cfg.mysql_db.get_db().cursor()
            query = "SELECT id, `key`, value_data FROM nat_setting_data"
            cur.execute(query)
            rows = cur.fetchall()
            for r in rows:
                response.append({
                    "id": r[0],
                    "key": r[1],
                    "value_data": r[2]
                })
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: get_objects")
        return response

    @staticmethod
    def get_value_by_key(key):
        logger.info("[Start]: get_value_by_key")
        response = {}
        try:
            ob = SettingsDao.get_object_by_key(key)
            response = ob.get('value_data')
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: get_value_by_key")
        return response

    @staticmethod
    def get_objects_dict():
        logger.info("[Start]: get_objects_dict")
        response = {}
        try:
            objs = SettingsDao.get_objects()

            for obj in objs:
                response[obj['key']] = obj['value_data']
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: get_objects_dict")
        return response

    @staticmethod
    def clean_settings(cur=None):
        logger.info("[Start]: clean_settings")
        response = None
        try:
            if not cur:
                cur = cfg.mysql_db.get_db().cursor()
            query = """TRUNCATE nat_setting_data"""
            cur.execute(query)
            response = True
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: clean_settings")
        return response

    @staticmethod
    def bulk_insert(settingData, cur=None):
        logger.info("[Start]: bulk_insert")
        response = None
        try:
            if not cur:
                cur = cfg.mysql_db.get_db().cursor()
            if len(settingData):
                query = "INSERT INTO nat_setting_data(`key`, value_data) VALUES "
                params = []
                for key, val in settingData.items():
                    params.append(r"('{k}', '{v}')".format(k=key, v=val))
                query = query + ','.join(params)
                cur.execute(query)
                response = True
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: bulk_insert")
        return response

    @staticmethod
    def get_frames_to_interpolate(project_id):
        logger.info("[Start]: get_frames_to_interpolate")
        response = None
        cur = cfg.mysql_db.get_db().cursor()
        query_admin = "Select user_id from nat_admin where project_id={}".format(project_id)
        try:       
            cur.execute(query_admin)
            result = cur.fetchall()
            admin_id = result[0][0]
        except:
            logger.info("There is error in executing query, traceback:{}".format(traceback.format_exc(limit=1)))
            return response
        try:
            query = "Select frames_to_interpolate from nat_user_setting where project_id={} and user_id={}".format(project_id, admin_id)      
            cur.execute(query)
            res = cur.fetchall()
            frames = res[0][0]
            return frames
        except:
            logger.info("There is error in executing query, traceback:{}".format(traceback.format_exc(limit=1)))
            return response

        
    
