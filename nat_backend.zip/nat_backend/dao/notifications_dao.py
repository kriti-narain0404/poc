import json

# custom packages
from dao.data import *
from utils.logger import Logger
from commons import constants as cfg
logger = Logger.get_logger()

class NotificationsDao(object):
    @staticmethod
    def create_notifications(videoid, assignuserid, userid, cur=None):
        logger.info("[Start]: create notifications")
        response = None
        video_id = str(videoid)
        assigned_user_id = str(assignuserid)
        created_by_user_id = str(userid)
        read_status = str(0)
        try:
            if cur is None:
                cur = cfg.mysql_db.get_db().cursor()
            query = "INSERT INTO nat_user_notifications (`assigned_user_id`, `video_id`," \
                    "`read_status`, `created_by_user_id`) " \
                    "VALUES ('" + assigned_user_id +  "', '" + video_id + "', \
                      '" + read_status + "','"+ created_by_user_id + "')"
            cur.execute(query)
            response = True
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: create notifications")
        return response

    @staticmethod
    def get_unread_count(userid):
        logger.info("[Start]: get_unread_count")
        response = 0
        try:
            cur = cfg.mysql_db.get_db().cursor()
            query = """ SELECT count(id) FROM nat_user_notifications
                WHERE assigned_user_id=%s AND read_status=0""" % (userid)
            cur.execute(query)
            r = cur.fetchone()
            if r:
              response = r[0]
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: get_unread_count")
        return response

    @staticmethod
    def reset_unread_count(userid):
        logger.info("[Start]: reset_unread_count")
        response = 0
        try:
            cur = cfg.mysql_db.get_db().cursor()
            query = """UPDATE nat_user_notifications SET read_status=1
              WHERE assigned_user_id=%s""" % (userid)
            cur.execute(query)
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: reset_unread_count")
        return response

