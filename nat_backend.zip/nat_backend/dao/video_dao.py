import json

# custom packages
from dao.data import *
from utils.logger import Logger
from commons import constants as cfg

logger = Logger.get_logger()

class VideoDao(object):
    @staticmethod
    def get_video_details_by_id(videoid):
        logger.info("[Start]: get_video_details_by_id")
        response = None
        try:
            cur = cfg.mysql_db.get_db().cursor()
            query = "SELECT * FROM video where id = %s "
            cur.execute(query, videoid)
            result = cur.fetchone()
            if result:
                response = {
                    "id": result[0],
                    #"video_id": result[1],
                    "video_name": result[1],
                    "video_path": result[2],
                    #"video_url": result[4],
                    "video_date": result[3],
                    "assigned": result[5],
                    "processed": result[6],
                    "assigned_user_id": result[7],
                    "assigned_date": result[8],
                    "validator_assign_id": result[12],
                    "validator_assign_date": result[13],
                    "nat_work_division_id": result[14]
                }
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: get_video_details_by_id")
        return response

    @staticmethod
    def get_validation_scripts_list(videoid):
        logger.info("[Start]: get_active_validation_scripts_list")
        response = []
        try:
            cur = cfg.mysql_db.get_db().cursor()
            query = """SELECT validation_scripts FROM nat_work_division where id =
              (SELECT nat_work_division_id FROM video where id = %s) """
            cur.execute(query, videoid)
            result = cur.fetchone()
            if result:
              response = json.loads(result[0])
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: get_active_validation_scripts_list")
        return response

    @staticmethod
    def get_conversion_script(videoid):
        logger.info("[Start]: get_conversion_script")
        response = []
        try:
            cur = cfg.mysql_db.get_db().cursor()
            query = """SELECT conversion_script FROM nat_work_division where id =
              (SELECT nat_work_division_id FROM video where id = %s) """
            cur.execute(query, videoid)
            result = cur.fetchone()
            if result:
              response = result[0]
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: get_conversion_script")
        return response

    @staticmethod
    def accept_video(videoid):
        logger.info("[Start]: accept_video")
        response = False
        try:
            cur = cfg.mysql_db.get_db().cursor()
            query = """UPDATE video SET submitted=True WHERE id=%s """
            cur.execute(query, videoid)
            logger.debug("Set video submitted to True id - %s"%(videoid))
            response = True
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: accept_video")
        return response

    @staticmethod
    def reject_video(videoid):
        logger.info("[Start]: reject_video")
        response = False
        try:
            cur = cfg.mysql_db.get_db().cursor()
            query = """UPDATE video SET submitted=False, processed=False WHERE id=%s """
            cur.execute(query, videoid)
            logger.debug("Set video processed to False id - %s"%(videoid))
            response = True
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: reject_video")
        return response

    @staticmethod
    def get_video_name_by_id(videoid):
        logger.info("[Start]: get_video_name_by_id")
        response = None
        try:
            cur = cfg.mysql_db.get_db().cursor()
            query = "SELECT video_name FROM video where id = %s "
            cur.execute(query, videoid)
            result = cur.fetchone()
            if result:
                response = result[0]
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: get_video_name_by_id")
        return response


    @staticmethod
    def reopen(videoid):
        logger.info("[Start]: reopen")
        response = False
        try:
            cur = cfg.mysql_db.get_db().cursor()
            if type(videoid) != list:
                videoid = [videoid]
            query = """UPDATE video 
                SET assigned=False, processed=False, submitted=False, assigned_user_id=null, 
                validator_assign_id=null, validator_assign_date=null
                WHERE id IN (%s) """
            cur.execute(query, ",".join([str(i) for i in videoid]))
            response = True
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: reopen")
        return response
