import os

# custom packages
from commons import constants as cfg
from commons.constants import Ack_data_pipeline_constants as ack
from quriesdao.dbQueries import DbQueries
from structures.data_structures import *
from nat_3D_Backend.commons.getdb_conn import DBConnect
# from config.config import DatabaseConfig
from dao.data import *
from utils.logger import Logger
from nat_3D_Backend.commons.getdb_conn import DBConnect
from quriesdao.dbQueries import DbQueries
from graphql import GraphQLError
from sys import exc_info
from utils.errors_utils import Error

logger = Logger.get_logger()

class ProjectDAO(object):

    @staticmethod
    def get_by_id(project_id, cur=None):
        logger.info("[Start]: get_by_id")
        response = None
        try:
            if cur is None:
                cur = cfg.mysql_db.get_db().cursor()

            query = """SELECT id, project_name, project_creation_date, project_code 
                    FROM nat_project WHERE id='%s'""" % (project_id)
            cur.execute(query)
            r = cur.fetchone()
            if r:
                response = {
                    'id': r[0],
                    'project_name': r[1],
                    'project_creation_date': r[2],
                    'project_code': r[3]
                }
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: get_by_id")
        return response

    @staticmethod
    def find_by_name(project_name, cur=None):
        logger.info("[Start]: find_by_name - %s" % (project_name))
        response = None
        try:
            if cur is None:
                cur = cfg.mysql_db.get_db().cursor()

            query = "SELECT id FROM nat_project WHERE project_name='%s'" % (project_name)
            cur.execute(query)
            r = cur.fetchone()
            if r:
                response = r[0]
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: find_by_name")
        return response

    @staticmethod
    def create_new(project_name, cur=None):
        logger.info("[Start]: create_new")
        response = None
        try:
            if cur is None:
                cur = cfg.mysql_db.get_db().cursor()

            query = "INSERT INTO nat_project(project_name) values('%s')" % (project_name)
            r = cur.execute(query)
            if r:
                response = (cur.lastrowid,)
                logger.debug("Created project %s"%(project_name))
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: create_new")
        return response

    @staticmethod
    def create_if_not_exists(project_name, cur=None):
        logger.info("[Start]: create_if_not_exists")
        response = None
        try:
            if cur is None:
                cur = cfg.mysql_db.get_db().cursor()

            response = ProjectDAO.find_by_name(project_name, cur)
            if response:
                response = (response,)
                logger.info("create_if_not_exists - project found")
            else:
                # insert new project and get id
                response = ProjectDAO.create_new(project_name)
                logger.info("create_if_not_exists - project not found")
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: create_if_not_exists")
        return response

    @staticmethod
    def get_all(user_id,cur=None,proId=None):
        '''
        Function for extracting the project details from database of an admin user
        args -
            user_id - (Int) user ID of current session admin user
        return -
            response - (Dict) Details of project including project_id and project_name
        '''
        logger.info("[Start]: get_all")
        response = {}
        project_id = int(proId)
        try:
            if cur is None:
                cur = cfg.mysql_db.get_db().cursor()
            query = " SELECT id, project_name FROM nat_project where id=%s "           
            cur.execute(query,project_id)     
            r = cur.fetchall()
            for rec in r:
                response[rec[0]] = rec[1]
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: get_all")
        return response

    @staticmethod
    def get_all_projects(userid,user_role):
        '''
        Function for extracting the projects assigned to user for displaying the list of projects
        args -
            user_id - (Int) user ID of current session User
            user_role - (String) Role of the user (ADMIN/VALIDATOR/ANNOTATOR)
        return -
            response - (Dict) Details of project including project_id and project_name
        '''
        logger.info("[Start]: get_all_projects")
        response = None
        try:
            cur = cfg.mysql_db.get_db().cursor()
            user_id = int(userid)
            if user_role == cfg.ROLE_ADMIN or user_role == "ADMIN":
                query = ("select id,project_name from nat_project where id IN (select project_id from nat_admin where user_id=%s)")
                cur.execute(query,user_id)
            elif user_role == cfg.ROLE_VALIDATOR or user_role == "VALIDATOR":

                query = ("select id,project_name from nat_project where id IN (select project_id from nat_validator where user_id=%s)")
                cur.execute(query,user_id)
            elif user_role == cfg.ROLE_ANNOTATOR or user_role == "ANNOTATOR":
                query = ("select id,project_name from nat_project where id IN (select project_id from nat_annotator where user_id=%s)")
                cur.execute(query,user_id)
            r = cur.fetchall()
            projects = []
            for rec in sorted(r):
                projects.append(Project(project_id=rec[0],project_name=rec[1]))
            response = ObjProject(projects=projects)
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: get_all_projects")
        return response

    @staticmethod
    def get_pipeline_settings(project_id):
        """
        Description  : This method will fetch the latest pipeline settings from the db.
        project_id   : An int which is used to get data for the project pipeline
        return      : A dict containing information of the pipeline.
        """
        query = DbQueries.SELECT_QUERY.format(cfg.SELECT_ALL, cfg.PipelineSettings.TABLENAME,
                                              cfg.PipelineSettings.CONDITION.format(project_id))
        try:
            conn, cursor = DBConnect().get_db_cursor()
        except Exception as e:
            logger.error("error in the get pipeline while connecting to DB")
        try:
            cursor.execute(query)
        except Exception as e:
            logger.error("error while executing the query {}, error {}".format(query, e))
            raise GraphQLError(Error.get_error_object(exc_info()[0].__name__))
        pipeline_setting = cursor.fetchall()
        for k in cfg.PipelineSettings.NOT_REQUIRED_KEYS:
            del pipeline_setting[cfg.PipelineSettings.FIRST_ELEMENT][k]
        conn.close()
        return pipeline_setting[cfg.PipelineSettings.FIRST_ELEMENT]

    @staticmethod
    def get_acknowledgement_data(projectid):
        '''
        Description: This function will give the complete status of what all processes are running and available for
        data pipeline.
        args:
            projectid: unique project id to get all the details required.
        return:
            Running and available status in the form of a dictionary (string)
        '''
        logger.info("[Start]: get_acknowledge_data")
        response = ObjAcknowledge(acknowledge="")  
        try:
            conn, mycursor = DBConnect().get_db_cursor()
            component_availability_table = ack.DP_COMPONENT_AVAILABILITY
            select_query = DbQueries.SELECT_QUERY + ack.SELECT_QUERY_CONDITION
            query1 = select_query.format(ack.SELECT_ALL_SYMBOL, component_availability_table, ack.PROJECT_ID, projectid)
            mycursor.execute(query1)
            result = ack.INITIALIZE_NONE
            dict_filter = lambda x: [i for i in x if x[i] == ack.AVAILABLE_STATUS]
            for j in mycursor.fetchall():
                result = dict_filter(j)
            if result:
                columns_req = ", ".join(result)
                component_status_table = ack.DP_COMPONENT_STATUS
                query2 = select_query.format(columns_req, component_status_table, ack.PROJECT_ID, projectid)
                mycursor.execute(query2)
                all_components_running = ack.TRUE_STATUS
                temporary_obj = ack.INITIALIZE_NONE
                for temporary_obj in mycursor.fetchall():
                    for key, value in temporary_obj.items():
                        if temporary_obj[key] != ack.RUNNING_STATUS:
                            all_components_running = ack.FALSE_STATUS
                            break
                status_obj = temporary_obj
                status_obj.update({ack.COMPONENT_RUNNING_STATUS: all_components_running})
                response = ObjAcknowledge(acknowledge=json.dumps(status_obj))                
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: get_acknowledgement_data")
        return response