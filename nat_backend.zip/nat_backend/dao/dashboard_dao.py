from traceback import extract_stack
from json import loads
from nat_3D_Backend.commons.getdb_conn import DBConnect
from utils.logger import Logger
from quriesdao.dbQueries import DbQueries
from datetime import date
from graphql import GraphQLError
from sys import exc_info
from utils.errors_utils import Error
from json import loads
from commons.constants import ConstantsDashboard
import pandas as pd

logger = Logger.get_logger()
class DashBoardDAO:

    def __init__(self) -> None:
        pass

    def get_db_connection(self):
        logger.info("Inside get_db_connection")
        return DBConnect().get_db_cursor()

    def fetch_class_names(self, project_id, cursor):
        """
        Description  : This method fetches the class_name and it's id
        project_id   : The project id for which the classes are to be fetched.
        cursor       : a cursor for the DB.
        """
        response = None
        query = DbQueries.CLASS_NAMES_WITH_ID.format(pid=project_id)
        
        try:
            cursor.execute(query)
        except Exception as e:
            logger.error(e)
            raise GraphQLError(Error.get_error_object(exc_info()[0].__name__))

        classes_available = cursor.fetchall()
        if classes_available:
            response = {}
            for i in classes_available:
                response[i["ID"]] = i["Class_Name"]
                response[i['Class_Name']] = i["ID"]
        return response

    def insert_into_db(self, class_info, project_id, userid,required_feilds, cursor, conn, videoid, automation_data, date_of_model):
        """
        Description  : This method inserts the value for the user in the transaction table.
        class_info   : The classids which are not present in the db
        project_id   : The project upon which the user is working.
        userid       : Id of the user.
        """
        logger.info("[START]: Inside the insert_into_db")
        response = False
        current_date = date.today()
        if date_of_model and automation_data:
            values_to_be_inserted = [r"('0','0','0','0','0','0','0','0','{added_a}','0','0', '{c_id}', '{p_id}', '{today_date}', '{uid}', '{vid}', '{modeldate}')".format(c_id=cid, p_id=project_id, added_a=automation_data[cid] if cid in automation_data else 0, today_date=current_date, uid=userid, vid=videoid, modeldate=date_of_model) for cid in class_info]
            insertion_columns = r"({feilds}, project_id, date, user_id, video_id, model_date)".format(feilds=required_feilds)
        elif date_of_model:
            values_to_be_inserted = [r"('0','0','0','0','0','0','0','0','{added_a}','0','0', '{c_id}', '{p_id}', '{today_date}', '{uid}', '{vid}', '{modeldate}')".format(c_id=cid, p_id=project_id, added_a=0, today_date=current_date, uid=userid, vid=videoid, modeldate=date_of_model) for cid in class_info]
            insertion_columns = r"({feilds}, project_id, date, user_id, video_id, model_date)".format(feilds=required_feilds)
        else:
            values_to_be_inserted = [r"('0','0','0','0','0','0','0','0','{added_a}','0','0', '{c_id}', '{p_id}', '{today_date}', '{uid}', '{vid}')".format(c_id=cid, p_id=project_id, added_a=0, today_date=current_date, uid=userid, vid=videoid) for cid in class_info]
            insertion_columns = r"({feilds}, project_id, date, user_id, video_id)".format(feilds=required_feilds)
        query = DbQueries.INSERT.format(table_name='transaction_table_dashboard', table_columns=insertion_columns) + ", ".join(values_to_be_inserted)
        try:
            cursor.execute(query)
            conn.commit()
            response = True
        except Exception as e:
            logger.error(e)
            raise GraphQLError(Error.get_error_object(exc_info()[0].__name__))
        return response

    def fetch_automation_data(self, video_id, cursor):
        logger.info("[START]: fetch_automation_data")
        response = None
        query = DbQueries.SELECT_QUERY.format(ConstantsDashboard.CLASS_DATA_COLUMNS,
                                                  "video", "id={}".format(video_id))
        try:
            cursor.execute(query)
        except Exception as e:
            logger.error(e)
            raise GraphQLError(Error.get_error_object(exc_info()[0].__name__))
        response = cursor.fetchall()
        if len(response)>1:
            response = False
            logger.error("There are more than one video with same id, kindly check, traceback:{}".format(extract_stack(limit=1)))
            raise GraphQLError("There are more than one video with same id")
        return response

    def update_processed_flag(self, videoid, cursor, conn):
        response = True
        query = DbQueries.UPDATE.format(table_name="video", data=ConstantsDashboard.VIDEO_PROCESSED_FLAG+f"={ConstantsDashboard.PROCESSED_VIDEO_FLAG}", condition=f"id={videoid}")
        try:
            cursor.execute(query)
            conn.commit()
        except Exception as e:
            response = False
            logger.error(f"the flag couldn't be updated , traceback:{extract_stack(limit=1)}, error:{e}")
            raise GraphQLError(Error.get_error_object(exc_info()[0].__name__))
        return response

    def insert_data_for_user(self, userid, project_id, classes_to_be_added, videoid):
        """
        Description         : This method inserts the data for user on a particular day when he's annotating.
        userid              : The user ID for which the data is to be fetched.
        projectid           : The project in which the user is working.
        classes_to_be_added : A list containing the classes needed by the user for annotation
        """
        logger.info("[START]: Inside fetch_transaction_data")
        response = None
        current_date = date.today()
        # to make connection with DB
        conn, cursor = self.get_db_connection()
        if project_id:
            automated_data = self.fetch_automation_data(videoid, cursor)
            class_names = self.fetch_class_names(project_id, cursor)
            date_of_model = None
            automation_results_modified = None
            if automated_data:
                if automated_data[0].get(ConstantsDashboard.DATE_OF_MODEL) is not None and not automated_data[0].get(ConstantsDashboard.VIDEO_PROCESSED_FLAG):
                    automation_results = loads(automated_data[0].get(ConstantsDashboard.AUTOMATION_RESULTS))
                    automation_results_modified = {class_names[k]:v for k,v in automation_results.items()}
                    date_of_model = automated_data[0].get(ConstantsDashboard.DATE_OF_MODEL)
                elif automated_data[0].get(ConstantsDashboard.VIDEO_PROCESSED_FLAG)==1:
                    date_of_model = automated_data[0].get(ConstantsDashboard.DATE_OF_MODEL)
            required_fields = ", ".join(ConstantsDashboard.DASHBOARD_KEYS)
            if class_names:
                
                query = DbQueries.DASHBOARD_FETCH_DATA.format(required_feilds=required_fields, uid=userid, pid=project_id, today_date=current_date)
                
                try:
                    cursor.execute(query)
                except Exception as e:
                    logger.error(e)
                    raise GraphQLError(Error.get_error_object(exc_info()[0].__name__))
                
                data_from_db = cursor.fetchall()
                
                data_update_for_response = None

                class_data_for_insertion = None
                if data_from_db:
                    class_names_present = []
                    
                    response = {}
                    
                    for data in data_from_db:
                        
                        response[class_names[data.get("class_id")]] = {k:v for k,v in data.items() if k!='class_id'}
                        class_names_present.append(class_names[data.get("class_id")])
                    
                    class_to_be_added = [class_nm for class_nm in classes_to_be_added if class_nm not in class_names_present]
                    
                    if class_to_be_added:
                        class_parameters = {k:0 for k in ConstantsDashboard.DASHBOARD_KEYS[:-1]}
                        data_update_for_response = {class_:class_parameters for class_ in class_to_be_added}
                        response.update(data_update_for_response)
                        class_data_for_insertion = [k for k, v in class_names.items() if v in class_to_be_added]
                
                else:
                    response = {class_:{k:0 for k in ConstantsDashboard.DASHBOARD_KEYS[:-1]} for class_ in classes_to_be_added}
                    class_data_for_insertion = [k for k, v in class_names.items() if v in classes_to_be_added]
                
                if class_data_for_insertion:
                    response_ = self.insert_into_db(class_data_for_insertion, project_id, userid,required_fields, cursor, conn, videoid, automation_results_modified, date_of_model)
                    
                    if response_:
                        if automated_data[0].get(ConstantsDashboard.VIDEO_PROCESSED_FLAG) is not None and not automated_data[0].get(ConstantsDashboard.VIDEO_PROCESSED_FLAG):
                            self.update_processed_flag(videoid, cursor, conn)
                    
                    else:
                        logger.error("the data was not inserted for the user properly, traceback:{}".format(extract_stack(limit=1)))
                        raise GraphQLError("Data Insertion for user failed, kindly check the log file.")
            else:
                raise GraphQLError("There are no classes defined for this project")
        conn.close()
        return response
        
    def update_data_for_user(self, data, uid, projectid):
        """
        Description         : This method inserts the data for user on a particular day when he's annotating.
        userid              : The user ID for which the data is to be fetched.
        projectid           : The project in which the user is working.
        classes_to_be_added : A list containing the classes needed by the user for annotation
        """
        logger.info("[START]: Inside update_data_for_user")
        response = False
        # to make connection with DB
        
        conn, cursor = self.get_db_connection()
        data = loads(data)
        current_date = date.today()
        if data:
            class_names = self.fetch_class_names(projectid, cursor)
            bulk_update = []
            keys = ConstantsDashboard.DASHBOARD_KEYS
            for k,i in data.items():
                bulk_update.append((i.get(keys[0]), i.get(keys[1]), i.get(keys[2]), i.get(keys[3]),
                                    i.get(keys[4]), i.get(keys[5]), i.get(keys[6]), i.get(keys[7]),
                                    i.get(keys[8]), i.get(keys[9]), i.get(keys[10]), class_names[k], uid, projectid, current_date))
            set_postfix = "=%s,".join(keys[:-1])+"=%s"
            condition = "class_id=%s AND user_id=%s AND project_id=%s AND date=%s"
            query = DbQueries.UPDATE.format(table_name='transaction_table_dashboard', data=set_postfix, condition=condition)
            try:
                cursor.executemany(query, bulk_update)
                conn.commit()
                response = True
            except Exception as e:
                logger.error(e)
                raise GraphQLError(Error.get_error_object(exc_info()[0].__name__))
        return response

    def fetch_users_work_details(self, project_id, start_date, end_date):
        """
        Description      : This method gets data for productivity tab of the dashboard.
        project_id       : an integer value for a project
        start_date       : date from which the data is to be fetched for the project.
        end_date         : the date till which the data is to be fetched
        """
        # to make connection with DB
        conn, cursor = self.get_db_connection()
        query = DbQueries.SELECT_QUERY.format(ConstantsDashboard.FETCH_CONDITION_1,
                                                  ConstantsDashboard.FETCH_CONDITION_2,
                                                  ConstantsDashboard.FETCH_CONDITION_3.format(project_id, start_date,
                                                                                              end_date))
        # to execute query
        try:
            cursor.execute(query)
        except Exception as e:
            logger.error("")
            raise GraphQLError(Error.get_error_object(exc_info()[0].__name__))

        data_from_db = cursor.fetchall()
        conn.close()
        return data_from_db if data_from_db else None

    def fetch_accuracy_data(self, project_id, start_date, end_date):

        conn, cursor = self.get_db_connection()
        query = DbQueries.SELECT_QUERY.format(ConstantsDashboard.ACC_FETCH_0,
                                              ConstantsDashboard.ACC_FETCH_1,
                                              ConstantsDashboard.ACC_FETCH_2.format(project_id, start_date, end_date))
        # to execute query
        try:
            cursor.execute(query)
        except Exception as e:
            logger.error("")
            raise GraphQLError(Error.get_error_object(exc_info()[0].__name__))

        data_from_db = cursor.fetchall()
        model_data = []
        class_model_data = {}
        if data_from_db:
            dataframe = pd.DataFrame(data_from_db)
            model_data = dataframe.groupby(by=ConstantsDashboard.GROUPBY, as_index=True).sum().to_dict("index")
            class_model_data[ConstantsDashboard.DISPLAY_DATA_CLASS_KEY] = data_from_db
            class_model_data[ConstantsDashboard.DISPLAY_DATA_MODEL_KEY] = model_data
        conn.close()
        return class_model_data

                
