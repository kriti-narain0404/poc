import os

# custom packages
from structures.data_structures import *
from commons import constants as cfg
from dao.data import *
from utils.common_utils import CommonUtils
from utils.ops_encrypt import EncryptDecrypt as ed
from utils.logger import Logger
import json
logger = Logger.get_logger()

class UserDAO(object):
    cur_userid = None
    cur_username = None
    cur_userrole = None

    @staticmethod
    def find_by_username(username, cur=None):
        logger.info("[Start]: find_user_by_login - %s" % (username))
        response = None
        try:
            if cur is None:
                cur = cfg.mysql_db.get_db().cursor()
            query = "SELECT id, login, activated, tfa_secret, locked FROM nat_user WHERE login='%s'" % (username)
            cur.execute(query)
            response = cur.fetchone()
            response = list(response)
            if response[2] == b'\x01' and len(username) == len(response[1]):
                response[2] = True
            elif response[2] == b'\x00' and len(username) == len(response[1]):
                response[2] = False
            else:
                response = None
            response = tuple(response)
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: find_user_by_login")
        return response

    @staticmethod
    def find_by_userid(userid, cur=None):
        logger.info("[Start]: find_by_userid - %s" % (userid))
        response = None
        try:
            if UserDAO.cur_userid and UserDAO.cur_userid == userid and UserDAO.cur_username:
                response = (UserDAO.cur_userid, UserDAO.cur_username, )
            else:
                if cur is None:
                    cur = cfg.mysql_db.get_db().cursor()

                query = "SELECT id, login FROM nat_user WHERE id='%s'" % (userid)
                cur.execute(query)
                response = cur.fetchone()
                if UserDAO.cur_userid and UserDAO.cur_userid == userid:
                    UserDAO.cur_username = response[1]
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: find_by_userid")
        return response

    @staticmethod
    def get_login_by_userid(userid, cur=None):
        logger.info("[Start]: get_login_by_userid - %s" % (userid))
        response = None
        try:
            r = UserDAO.find_by_userid(userid)
            if r:
                response = r[1]
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: get_login_by_userid")
        return response

    @staticmethod
    def get_role_by_userid(userid, cur=None):
        logger.info("[Start]: get_role_by_userid - %s" % (userid))
        response = None
        try:
            if UserDAO.cur_userid and UserDAO.cur_userid == userid and UserDAO.cur_userrole:
                response = UserDAO.cur_userrole
            else:
                if cur is None:
                    cur = cfg.mysql_db.get_db().cursor()

                query = "SELECT authority_name FROM nat_user_authority WHERE user_id='%s'" % (userid)
                cur.execute(query)
                r = cur.fetchone()
                if r:
                    response = r[0]
                if UserDAO.cur_userid and UserDAO.cur_userid == userid:
                    UserDAO.cur_userrole = response
            logger.debug("Role found: %s"%(response))
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: get_role_by_userid")
        return response

    @staticmethod
    def get_validatorid_by_annoid(userid, cur=None):
        logger.info("[Start]: get_validatorid_by_annoid - %s" % (userid))
        response = None
        try:
            if cur is None:
                cur = cfg.mysql_db.get_db().cursor()

            query = "SELECT validator_id FROM nat_annotator WHERE user_id='%s'" % (userid)
            cur.execute(query)
            r = cur.fetchone()
            if r:
                response = r[0]
            logger.debug("Validator id found: %s"%(response))
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: get_validatorid_by_annoid")
        return response

    @staticmethod
    def get_validatorlogin_by_annoid(userid, cur=None):
        logger.info("[Start]: get_validatorid_by_annoid - %s" % (userid))
        response = None
        try:
            if cur is None:
                cur = cfg.mysql_db.get_db().cursor()

            query = """ SELECT id, login FROM nat_user WHERE nat_user.id=(
                SELECT validator_id FROM nat_annotator WHERE nat_annotator.user_id='%s')""" % (userid)
            cur.execute(query)
            r = cur.fetchone()
            if r:
                response = r[1]
            logger.debug("Validator id found: %s"%(response))
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: get_validatorid_by_annoid")
        return response

    @staticmethod
    def create_user_authority(data, cur=None):
        logger.info("[Start]: create_user_authority")
        response = False
        try:
            if cur is None:
                cur = cfg.mysql_db.get_db().cursor()

            query = "INSERT INTO nat_user_authority(user_id, authority_name) values(%s, '%s')" \
                    % (data.get('user_id'), data.get('authority_name').strip())
            cur.execute(query)
            response = True     # TODO: send actual response
            # response = cur.fetchone()
            logger.debug("create_user_authority user %s "%(data.get('user_id')))
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: create_user_authority")
        return response

    @staticmethod
    def update_user_authority(data, cur=None):
        logger.info("[Start]: update_user_authority")
        response = False
        try:
            if cur is None:
                cur = cfg.mysql_db.get_db().cursor()

            query = "UPDATE nat_user_authority SET authority_name='%s' WHERE user_id=%s" \
                    % (data.get('authority_name').strip(), data.get('user_id'))
            cur.execute(query)
            response = True     # TODO: send actual response
            # response = cur.fetchone()
            logger.debug("update_user_authority user %s "%(data.get('user_id')))
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: update_user_authority")
        return response

    @staticmethod
    def create_user(data, cur=None):
        logger.info("[Start]: create_user")
        response = None
        try:
            if cur is None:
                cur = cfg.mysql_db.get_db().cursor()

            password_hash = CommonUtils.generate_password_hash(data.get('password'))
            security_hash = CommonUtils.generate_password_hash(data.get('security'))
            if 'activated' not in data:
                data['activated'] = 0

            query = """INSERT INTO nat_user(login, first_name, last_name, password_hash, mobile_number, activated, created_by, security)
                        values('%s', '%s', '%s', '%s', '%s', %s, '%s', '%s')""" % (
                        data.get('login'),
                        data.get('first_name'),
                        data.get('last_name'),
                        password_hash,
                        ed.encode_incoming(data.get('mobile_number')),
                        data.get('activated'),
                        data.get('loggedin_user'),
                        security_hash,
                        # ed.encode_incoming(data.get('auth_pin'))

            )
            r = cur.execute(query)
            if r:
                response = (cur.lastrowid,)
                logger.debug("Created user %s"%(data.get('login')))
                user_authority = {
                    'user_id': response[0],     # userid
                    'authority_name': data.get('role')
                }

                UserDAO.create_user_authority(user_authority, cur=cur)

        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: create_user")
        return response
    
    @staticmethod
    def getquestion(username, cur=None):
        '''
        Input: username
        return: Security question and answer
        '''
        logger.info("[Start]: getquestion")
        response = None
        try:
            if cur is None:
                cur = cfg.mysql_db.get_db().cursor()
            query = "SELECT security FROM nat_user where login='%s'" % (username)
            r = cur.execute(query)
            if r:
                result = json.loads(ed.decrypt_incoming(cur.fetchall()[0][0]).replace("'",'"'))
                question = result['question']
                answer = result['answer']
                response = ObjUserQue(
                    question=question,
                    answer=answer
                )
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: getquestion")
        return response
    
    @staticmethod
    def resetpassword(username, newPass, cur=None):
        '''
        Input: username
        Return: Status of the operation, password is reset or not.
        This function will reset the password based on the value of username we get.
        '''

        logger.info("[Start]: resetpassword")
        response = ObjResponse(
            status=False
        )
        try:
            if cur is None:
                cur = cfg.mysql_db.get_db().cursor()
            query = "UPDATE nat_user SET password_hash='%s' where login = '%s'" % (CommonUtils.generate_password_hash(newPass), username)
            r = cur.execute(query)
            if r:
                response = ObjResponse(
                    status=True
                )
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: resetpassword")
        return response

    @staticmethod
    def update_user(user_id, data, cur=None):
        logger.info("[Start]: update_user")
        response = None
        try:
            if cur is None:
                cur = cfg.mysql_db.get_db().cursor()

            update_values = []
            update_query = []

            password_hash = ''
            if "first_name" in data:
                update_query.append("first_name='{first_name}'")
            if "last_name" in data:
                update_query.append("last_name='{last_name}'")
            if "password" in data:
                password_hash = CommonUtils.generate_password_hash(data.get('password'))
                update_query.append("password_hash='{password_hash}'")
            if "mobile_number" in data:
                update_query.append("mobile_number='{mobile_number}'")
            if "last_modified_by" in data:
                update_query.append("last_modified_by='{last_modified_by}'")
            if "activated" in data:
                update_query.append("activated={activated}")
            if len(update_query) == 0:
                raise Exception("update_query array is blank")

            query = "UPDATE nat_user SET " + ','.join(update_query) + " WHERE id={user_id}"
            query = query.format(
                first_name=data.get('first_name'),
                last_name=data.get('last_name'),
                password_hash=password_hash,
                mobile_number=ed.encode_incoming(data.get('mobile_number')),
                last_modified_by=data.get('last_modified_by'),
                activated=data.get('activated'),
                user_id=user_id
            )
            r = cur.execute(query)
            if r:
                logger.debug("Updated user %s"%(data.get('login')))
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: update_user")
        return response

    @staticmethod
    def create_if_not_exists(data, cur=None):
        logger.info("[Start]: create_if_not_exists")
        response = None
        try:
            if cur is None:
                cur = cfg.mysql_db.get_db().cursor()

            response = UserDAO.find_by_username(data.get('login'), cur)
            if response:
                
                logger.info("create_if_not_exists user found")
                user_id = response[0]
                user_authority = {
                    'user_id': user_id,     # userid
                    'authority_name': data.get('role')
                }
                resp = UserDAO.update_user(user_id, data, cur=cur)
                role = UserDAO.get_role_by_userid(user_id)
                if role and role != user_authority['authority_name']:
                    resp = UserDAO.update_user_authority(user_authority)
                else:
                    UserDAO.create_user_authority(user_authority)
                
            else:
                response = UserDAO.create_user(data)
                logger.info("create_if_not_exists user not found")
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: create_if_not_exists")
        return response

    @staticmethod
    def signup(data, cur=None):
        logger.info("[Start]: signup")
        response = None
        newuser = False
        try:
            if cur is None:
                cur = cfg.mysql_db.get_db().cursor()
            
            response = UserDAO.find_by_username(data.get('login'), cur)
            if response:
                if response[2] == False:
                    UserDAO.update_user(response[0], data, cur=cur)
                    newuser = True
                    logger.info("signup user found, activating")
            else:
                response = UserDAO.create_user(data, cur=cur)
                newuser = True
                logger.info("signup user not found")
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: signup")
        
        return response, newuser


    @staticmethod
    def validate_captcha(user_captcha, auto_captcha):
        logger.info("[Start]: signup")
        en_user_captcha = ed.encode_incoming(user_captcha)
        ed_auto_captcha = ed.encode_incoming(auto_captcha)
        response = None
        if en_user_captcha == "" or ed_auto_captcha == "":
            response == False
        if en_user_captcha == ed_auto_captcha:
            response = True
        else:
            response = False
        return response

    @staticmethod
    def clean_project_team(project_id, cur=None):
        logger.info("[Start]: clean_project_team")
        response = None
        try:
            if cur is None:
                cur = cfg.mysql_db.get_db().cursor()

            query = "set foreign_key_checks=0;"
            r = cur.execute(query)

            query = "DELETE FROM nat_annotator WHERE project_id=%s" % (project_id)
            r = cur.execute(query)
            
            logger.debug("Deleted annotators project %s" % (project_id))

            query = "DELETE FROM nat_validator WHERE project_id=%s" % (project_id)
            cur.execute(query)
            
            logger.debug("Deleted validators project %s" % (project_id))

            query = "DELETE FROM nat_admin WHERE project_id=%s" % (project_id)
            cur.execute(query)
           
            
            query = "set foreign_key_checks=1;"
            r = cur.execute(query)
            logger.debug("Deleted admins project %s" % (project_id))
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: clean_project_team")
        return response

    @staticmethod
    def add_project_admin(data, cur=None):
        logger.info("[Start]: add_project_admin")
        response = None
        try:
            if cur is None:
                cur = cfg.mysql_db.get_db().cursor()

            query = "INSERT INTO nat_admin(admin_name, user_id, project_id) values" \
                "('%s',%s,%s)" % (data.get('login'), data.get('userid'), data.get('project_id') )
            
            resp = cur.execute(query)
            if resp:
                response = (cur.lastrowid,)
            logger.debug(" :::===================response %s", response)
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: add_project_admin")
        return response

    @staticmethod
    def add_project_validator(data, nat_admin_id, cur=None):
        logger.info("[Start]: add_project_validator")
        response = None

        try:
            if cur is None:
                cur = cfg.mysql_db.get_db().cursor()

            query = "INSERT INTO nat_validator(validator_name, user_id, project_id, admin_id, nat_admin_id) values" \
                "('%s',%s,%s,%s,%s)" % (data.get('login'), data.get('userid'), data.get('project_id')
                    , data.get('admin_id'), nat_admin_id )
            
            resp = cur.execute(query)
            if resp:
              response = (cur.lastrowid,)
            logger.debug("response %s", response)
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: add_project_validator")
        return response

    @staticmethod
    def add_project_annotators(data, nat_validator_id, cur=None):
        logger.info("[Start]: add_project_annotators")
        response = None
        try:
            if cur is None:
                cur = cfg.mysql_db.get_db().cursor()

            query = "INSERT INTO nat_annotator(annotator_name, user_id, project_id, admin_id, validator_id, nat_validator_id) values"
            q_row = []
            for row in data:
                q_row.append("('%s',%s,%s,%s,%s,%s)" % (row.get('login'), row.get('userid'), row.get('project_id'),
                                                        row.get('admin_id'), row.get('validator_id'), nat_validator_id) )
            query = query + ','.join(q_row)
            response = cur.execute(query)
            logger.debug("response %s", response)
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: add_project_annotators")
        return response

    @staticmethod
    def get_users_dict(cur=None, excludeDemo=False):
        logger.info("[Start]: get_users_dict")
        response = {}
        try:
            if cur is None:
                cur = cfg.mysql_db.get_db().cursor()

            if excludeDemo:
                query = "SELECT id, login FROM nat_user WHERE id>3"  # Excluding demo users
            else:
                query = "SELECT id, login FROM nat_user"
            cur.execute(query)
            rows = cur.fetchall()
            for row in rows:
                response[row[0]] = row[1]
            logger.debug("response %s", response)
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: get_users_dict")
        return response

    @staticmethod
    def get_validators_logins_list(cur=None, excludeDemo=False):
        logger.info("[Start]: get_validators_logins_list")
        response = []
        try:
            if cur is None:
                cur = cfg.mysql_db.get_db().cursor()

            if excludeDemo:
                query = "SELECT validator_name FROM nat_validator WHERE user_id>3"  # Excluding demo users
            else:
                query = "SELECT validator_name FROM nat_validator"
            cur.execute(query)
            rows = cur.fetchall()
            for row in rows:
                response[row[0]] = row[1]
            logger.debug("response %s", response)
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: get_validators_logins_list")
        return response

    @staticmethod
    def get_annotators_list_by_validatorid(validator_id):
        logger.info("[Start]: get_annotators_list_by_validatorid")
        response = {}
        try:
            cur = cfg.mysql_db.get_db().cursor()
            query = "SELECT user_id, annotator_name FROM nat_annotator WHERE validator_id=%s" % (validator_id)
            cur.execute(query)
            rows = cur.fetchall()
            for row in rows:
                response[row[0]] = row[1]
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: get_annotators_list_by_validatorid")
        return response

    @staticmethod
    def get_annologin_by_validatorid(userid, cur=None):
        logger.info("[Start]: get_annologin_by_validatorid - %s" % (userid))
        response = None
        try:
            if cur is None:
                cur = cfg.mysql_db.get_db().cursor()

            query = """ SELECT id, login FROM nat_user WHERE nat_user.id=(
                SELECT user_id FROM nat_annotator WHERE nat_annotator.validator_id='%s')""" % (userid)
            cur.execute(query)
            r = cur.fetchone()
            if r:
                response = r[1]
            logger.debug("Annotator id found: %s"%(response))
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: get_annologin_by_validatorid")
        return response

    @staticmethod
    def login_by_password(username, password, cur=None):
        logger.info("[Start]: login_by_password - %s" % (username))
        response = False
        try:
            if cur is None:
                cur = cfg.mysql_db.get_db().cursor()

            query = "SELECT id, login, password_hash FROM nat_user WHERE login='%s'" % (username)
            cur.execute(query)
            r = cur.fetchone()
            if r:
                if CommonUtils.verify_password(password, r[2]):
                    response = True
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: login_by_password")
        return response

   

    @staticmethod
    def save_tfa_secret(username, secret, cur=None):
        logger.info("[Start]: save_tfa_secret - '%s'" %(secret))
        response = False
        try:
            if cur is None:
                cur = cfg.mysql_db.get_db().cursor()
            query = "UPDATE nat_user SET tfa_secret = '%s' WHERE login = '%s'" %(secret, username)
            cur.execute(query)
            response = True
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: save_tfa_secret")
        return response

    @staticmethod
    def set_current_userid(userid):
        logger.info("[Start]: set_current_userid")
        response = False
        try:
            UserDAO.cur_userid = userid
            response = True
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: set_current_userid")
        return response

    @staticmethod
    def set_current_username(username):
        logger.info("[Start]: set_current_username")
        response = False
        try:
            UserDAO.cur_username = username
            response = True
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: set_current_username")
        return response

    @staticmethod
    def set_current_userrole(role):
        logger.info("[Start]: set_current_userrole")
        response = False
        try:
            UserDAO.cur_userrole = role
            response = True
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: set_current_userrole")
        return response
