import os
import json

import re

from decorator import append
from pathlib import Path
import time
from collections import namedtuple, OrderedDict

from utils.files import Files
from commons import constants as cfg

import math
from sys import platform
import subprocess

from dao.video_dao import VideoDao
from utils.settings_utils import SettingsUtils
from utils.logger import Logger
logger = Logger.get_logger()

filter = "JSON file (*.json)|*.json|All Files (*.*)|*.*||"

annotate = []

consldt_mtx = {'name_cnl': [], 'accuracy_cnl': [], 'edit_cnl': [], 'updated_cnl': [], 'locacc_cnl': []}

DEFAULT_COLS = ['id', 'labels', 'model_labels']

BASIC_COLORS = []

# if platform == "linux" or platform == "linux2":
#   filename = os.open("/opt/NAT/upload/noesis_data/automation.json", 0)
# elif platform == "win32":
#   filename = os.open("D:/NAT/upload/noesis_data/automation.json", 0)
#
# if filename:
#     with open(filename, 'r') as f:
#         datastore = json.load(f)
#         for p in datastore['details']:
#           BASIC_COLORS.append(p['color'])

class Data(object):

    @staticmethod
    def get_fpath(proj_name, fname):
        logger.info("[Start]: get_fpath")
        file_path = None
        try:

         
          file_path = os.path.join(proj_name, fname)
        except Exception as error_obj:
          logger.error(error_obj)
        logger.info("[Exit]: get_fpath")
        return file_path

    @staticmethod
    def natural_sort(l):
        convert = lambda text: int(text) if text.isdigit() else text.lower()
        alphanum_key = lambda key: [convert(c) for c in re.split('([0-9]+)', key)]
        return sorted(l, key=alphanum_key)

    @staticmethod
    def sort_dir_image_list(dir_path):
        logger.info("[Start]: sort_dir_image_list")
        files = None
        try:
          dir_files = sorted(os.listdir(dir_path))  # list of directory files
          dir_files.sort()  # good initial sort but doesnt sort numerically very well
          #files = sorted(dir_files) # sort numerically in ascending order
          files = Data.natural_sort(dir_files) # sort numerically in ascending order
        except Exception as error_obj:
          logger.error(error_obj)
        logger.info("[Exit]: sort_dir_image_list")
        return files

    @staticmethod
    def sort_dir_labeljson_list(dir_path):
        logger.info("[Start]: sort_dir_labeljson_list")
        files = None
        try:
          dir_files = json_files = [f1 for f1 in os.listdir(dir_path) if f1.endswith('_label.json')]
          dir_files.sort()  # good initial sort but doesnt sort numerically very well
          #files = sorted(dir_files) # sort numerically in ascending order
          files = Data.natural_sort(dir_files)  # sort numerically in ascending order
        except Exception as error_obj:
          logger.error(error_obj)
        logger.info("[Exit]: sort_dir_labeljson_list")
        return files

    @staticmethod
    def get_image_name(dir_files, image_id):
      logger.info("[Start]: get_image_name")
      image_name = None
      images_list = []
      try:
        for file in dir_files:  # filter out all non jpgs and png
          if cfg.IMG_EXT_JPG in file  or cfg.IMG_EXT_PNG or cfg.IMG_EXT_JPG1 in file  or cfg.IMG_EXT_PNG1 or cfg.IMG_EXT_jpeg in file  or cfg.IMG_EXT_JPEG in file :
            images_list.append(file)
        image_name = images_list[image_id]
      except Exception as error_obj:
        logger.error(error_obj)
      logger.info("[Exit]: get_image_name")
      return image_name

    @staticmethod
    def pred_obj_detect_img(image_path,jsonfileName):
        logger.info("[Start]: pred_obj_detect_img")
        nat_json = cfg.MODEL_OBJ.run_inference(image_path)

        # TODO: temporary fix to add parameters in json
        try:
            imagename = os.path.split(jsonfileName)[1]
            imagename = imagename.replace(".json","")
            logger.info(imagename)
            annos = nat_json["imgs"][imagename]["annotations"]
            for anno in annos:
                if anno["bbox"] is not None:
                    anno["bbox"]["parameters"] = []
            nat_json["imgs"][imagename]["annotations"] = annos
        except Exception as error_obj:
            logger.error(error_obj)

        Files.save_json(jsonfileName, nat_json)
        logger.info("[Exit]: pred_obj_detect_img")
        return None

    @staticmethod
    def init_dataset(name, input_dir, file_ext, labeljson, width, height, imageid):
        logger.info("[Start]: init_dataset")
        fpaths, ids = Files.get_paths_to_files(input_dir, file_ext=cfg.IMG_EXT,
                                                     strip_ext=True)
        input_dir = input_dir + '/' + 'json'
        fold = {
            # 'name': name,
            # 'file_ext': file_ext,
            'width': width,
            'height': height,
            'inputs_dir': input_dir,
            'img': {},
            #'label_names': label_names,
            # 'trn': {},
            # 'val': {},
            # 'tst': {}, #auditing purposes
            # 'unlabeled': {}, #these need to be queried and popped by key
            # 'metrics': {},
            'created': time.strftime("%m/%d/%Y %H:%M:%S", time.localtime())
        }
        try:
         
          if not os.path.exists(Data.get_fpath(input_dir, labeljson)):
            logger.debug("Creating label.json")
            Files.save_json(Data.get_fpath(input_dir, labeljson), fold)

        except Exception as error_obj:
          logger.error(error_obj)
        logger.info("[Exit]: init_dataset")
        return fold

    @staticmethod
    def make_entry(labels=None, model_labels=None, model_probs=None):
        logger.info("[Start]: make_entry")
        labels = [] if labels is None else labels
        model_labels = [] if model_labels is None else model_labels
        model_probs = [] if model_probs is None else model_probs
        logger.info("[Exit]: make_entry")
        return {
            'labels': labels,
            'model_labels': model_labels,
            'model_probs': model_probs,
        }

    @staticmethod
    def make_predicted_annotations(annotations,annotations1,annotations2):
        logger.info("[Start]: make_predicted_annotations")
        annos = []
        try:
          for anno in annotations:
              annos.append(anno)
              #annotate.append(anno)
          for anno1 in annotations1:
              annos.append(anno1)
          for anno2 in annotations2:
              annos.append(anno2)
        except Exception as error_obj:
          logger.error(error_obj)
        logger.info("[Exit]: make_predicted_annotations")
        return annos

    @staticmethod
    def load_model_preds(img_id, project,jsonfileName,labeljsonfileName):
        logger.info("[Start]: load_model_preds")
        fpath = Data.get_fpath(project, jsonfileName)
        fpath1 = Data.get_fpath(project, labeljsonfileName)
        preds = Files.load_json(fpath)
        preds1 = Files.load_json(fpath1)
        img1 = dict()
        img2 = dict()
        img1['annotations'] = ''
        img2['annotations'] = ''
        if img_id in preds['imgs']: # or img_id in preds1['val']:
            logger.debug("Loading preds from model json")
            img = preds['imgs'][img_id]
        if preds1 is not None and img_id in preds1[cfg.IMG]:
            logger.debug("Loading preds from label.json")
            if img_id in preds1[cfg.IMG]:
              img1 = preds1[cfg.IMG][img_id]
        logger.info("[Exit]: load_model_preds")
        return {
            "img_id": img_id,
            "annotations": Data.make_predicted_annotations(
                img['annotations'], img1['annotations'], img2['annotations'])
        }
        return None

    @staticmethod
    def load_metrics_data(metricspath,jsonfileName):
        logger.info("[Start]: load_metrics_data")
        fpath = Data.get_fpath(metricspath, jsonfileName)
        metricsdata = Files.load_json(fpath)

        logger.info("[Exit]: load_metrics_data")
        return metricsdata

    @staticmethod
    def load_obj_detect_img(img_id, project,jsonfileName,labeljsonfileName, include_preds=True):
        logger.info("[Start]: load_obj_detect_img")
        try:
          project = os.path.join(project, 'json')
          fold = Data.load_fold(project,labeljsonfileName)
          if fold is None:
            logger.debug("Fold not found in label.json. Sending from predictions.")
            img = Data.load_model_preds(img_id, project,jsonfileName,labeljsonfileName)
            logger.info("[Exit]: load_obj_detect_img")
            return img
          else:
            logger.debug("Sending fold from label.json")
            for dset in [cfg.IMG]:
                if img_id in fold[dset]:
                    img = fold[dset][img_id]
                    # if dset == cfg.UNLABELED and include_preds:
                    #   img = Data.load_model_preds(img_id, project,jsonfileName,labeljsonfileName)
                    logger.info("[Exit]: load_obj_detect_img")
                    return img
        except Exception as error_obj:
          logger.error(error_obj)
        logger.info("[Exit]: load_obj_detect_img")
        return None

    @staticmethod
    def load_image_metrics(jsonpath,jsonfileName):
        logger.info("[Start]: load_image_metrics")
        fold = Data.load_fold(jsonpath,jsonfileName)
        logger.info("[Exit]: load_image_metrics")
        return None
    
    @staticmethod
    def get_label_and_uniqueID(count, i, j, annotation_type, json):
      label = json['img'][i][j][count][annotation_type]['label']
      uniqueID = json['img'][i][j][count][annotation_type]['parameters'][0]['val']
      annotation_type_flag = True  
      return label, uniqueID, annotation_type_flag    

    @staticmethod
    def get_curr_obj_and_copy(json_flag, current_json, labelIDList, current_annotation_dict, current_bbox_list):
      
      for i in current_json['img']:
            for j in current_json['img'][i]:
                count = 0
                for k in current_json['img'][i][j]:
                    c_bbox = False
                    c_poly = False
                   
                    if current_json['img'][i][j][count]['bbox']:
                      c_label, c_uniqueID, c_bbox = Data.get_label_and_uniqueID(count, i, j, 'bbox', current_json)
                      
                    elif current_json['img'][i][j][count]['polygon']:
                      c_label, c_uniqueID, c_poly = Data.get_label_and_uniqueID(count, i, j, 'polygon', current_json)                      
                    else:
                      count += 1
                      continue
                   
                    for IDLabel in labelIDList:
                      if c_bbox == True:
                        annotation_type = "bbox"  
                      elif c_poly == True:
                        annotation_type = "poly"

                      if IDLabel[0] == c_label and IDLabel[1] == c_uniqueID:
                          
                          key = str(c_label)+str(c_uniqueID)+annotation_type
                          if json_flag == 0:
                            current_annotation_dict[key] = current_json['img'][i][j][count]
                          elif json_flag == 1:
                            current_json['img'][i][j][count] = current_annotation_dict[key]
                            del current_annotation_dict[key]
                          else:
                            key = str(c_label)+str(c_uniqueID)
                            
                            current_bbox_list.append(current_json['img'][i][j][count])

                    count += 1
      return current_annotation_dict, i, j, current_bbox_list

    @staticmethod
    def compare_json(current_image_path, next_image_path,current_json_path, next_json_path, labelIDList):
      logger.info("Inside compare JSON copy mode Manual")
      current_bbox_list = []
      current_annotation_dict = {}
      if os.path.isfile(next_json_path):
        with open(current_json_path, encoding='utf-8', errors='ignore') as f:
          current_json = json.load(f)
        f.close()
        with open(next_json_path, encoding='utf-8', errors='ignore') as g:
          next_json = json.load(g)
        g.close()
        
        json_flag = 0
        current_annotation_dict, i, j, current_bbox_list=Data.get_curr_obj_and_copy(json_flag, current_json, labelIDList, current_annotation_dict, current_bbox_list)
        json_flag = 1
        current_annotation_dict, i, j, current_bbox_list=Data.get_curr_obj_and_copy(json_flag, next_json, labelIDList, current_annotation_dict, current_bbox_list)

        
        if current_annotation_dict:
          for key,value in current_annotation_dict.items():
            next_json['img'][i][j].append(value)

        with open(next_json_path, 'w') as fp:
            json.dump(next_json, fp)
            
      else:
        
        with open(current_json_path, encoding='utf-8', errors='ignore') as f:
          current_json = json.load(f)
          json_flag = 2
          f.close()
        next_jsonname = os.path.splitext(os.path.basename(next_image_path))[0]
        current_jsonname = os.path.splitext(os.path.basename(current_image_path))[0]
        
        current_annotation_dict, i, j, current_bbox_list=Data.get_curr_obj_and_copy(json_flag, current_json, labelIDList, current_annotation_dict, current_bbox_list)
        current_json['img'][i][j] = current_bbox_list
        current_json['img'][next_jsonname] = current_json['img'].pop(current_jsonname)
        with open(next_json_path, 'w') as fp:
          json.dump(current_json, fp)
        

    @staticmethod
    def get_obj_detect_label_opts(project):
        logger.info("[Start]: get_obj_detect_label_opts")
        #fold = Data.load_fold(project)
        label = None
        labels = []
        try:
          label = Data.load_label(project)
          for i, v in enumerate(label['label_names']):
              labels.append({
                  'value': v,
                  'text': v,
                  'color': BASIC_COLORS[i]
              })
        except Exception as error_obj:
          logger.error(error_obj)
        logger.info("[Exit]: get_obj_detect_label_opts")
        return labels

    @staticmethod
    def make_obj_detect_entry(annos):
      logger.info("[Start]: make_obj_detect_entry")
      
      annotate_id = []
      id_list = []
      annotate_local = []
      try:
        for anno in annos:
          if 'bbox' in anno.keys():
            anno['polygon'] = None
            anno['imageTag'] = None

          elif 'polygon' in anno.keys():
            anno['bbox'] = None
            anno['imageTag'] = None

          elif 'imageTag' in anno.keys():
            anno['bbox'] = None
            anno['polygon'] = None

          annotate_local.append(anno)
          annotate.append(anno)
        for i in range(len(annotate)):
          annotate_id.append(annotate[i]['id'])
        # for anno in annos:
        #   if anno['id'] not in annotate_id:
        #     if 'bbox' in anno.keys():
        #       anno['polygon'] = None
        #     elif 'polygon' in anno.keys():
              # elif 'Line' in anno.keys():
        #       anno['bbox'] = None
        #     annotate.append(anno)
        #for i in range(len(delannos)):
          #for j in range(len(annotate)):
            #if delannos[i] == annotate[j]['id']:
              #id_list.append(j)
        for n in range(len(id_list)):
          del annotate[n]
        #delannos = []
        logger.info("[Exit]: make_obj_detect_entry")
      except Exception as error_obj:
        logger.error(error_obj)
      return {
        # 'annotations': annotate,
        'annotations': annotate_local,
      }
    @staticmethod
    def add_or_update_entry(fold, dset, id_, entry):
        logger.info("[Start]: add_or_update_entry")
        fold[dset][id_] = entry
        logger.info("[Exit]: add_or_update_entry")


    @staticmethod
    def move_unlabeled_to_labeled(fold, dset, id_, entry):
        logger.info("[Start]: move_unlabeled_to_labeled")
        Data.add_or_update_entry(fold, dset, id_, entry)
        logger.info("[Exit]: move_unlabeled_to_labeled")

    @staticmethod
    def load_fold(name,labeljsonfileName):
        logger.info("[Start]: load_fold")
        load_fold = None
        try:
          # type: (object) -> object
          fpath = Data.get_fpath(name, labeljsonfileName)
          if os.path.isfile(fpath):
            load_fold = Files.load_json(fpath)
        except Exception as error_obj:
          logger.error(error_obj)
        logger.info("[Exit]: load_fold")
        return load_fold

    @staticmethod
    def load_label(name):
        logger.info("[Start]: load_label")
        load_label = None
        try:
          # type: (object) -> object
          fpath = Data.get_fpath(name, cfg.LABEL_FNAME)
          load_label = Files.load_json(fpath)
        except Exception as error_obj:
          logger.error(error_obj)
        logger.info("[Exit]: load_label")
        return load_label

    @staticmethod
    def save_fold(fold,path, filename):
        logger.info("[Start]: save_fold")
        save_fold = None
        try:
          fpath = Data.get_fpath(path, filename)
          save_fold = Files.save_json(fpath, fold)
        except Exception as error_obj:
          logger.error(error_obj)
        logger.info("[Exit]: save_fold")
        return save_fold

    @staticmethod
    def delete_file(path, filename):
        logger.info("[Start]: delete_file")
        try:
            fpath = Data.get_fpath(path, filename)
            if os.path.exists(fpath):
                os.remove(fpath)
        except Exception as error_obj:
          logger.error(error_obj)
        logger.info("[Exit]: delete_file")
        return 0


    @staticmethod
    def img_url(fname):
        logger.info("[Start]: img_url")
        logger.info("[Exit]: img_url")
        return cfg.IMG_ENDPOINT + '/{:s}'.format(fname + cfg.IMG_EXT)

    @staticmethod
    def id_to_fname(img_id):
        logger.info("[Start]: id_to_fname")
        logger.info("[Exit]: id_to_fname")
        return img_id + cfg.IMG_EXT_PNG

    @staticmethod
    def id_to_videoname(img_id):
        logger.info("[Start]: id_to_videoname")
        logger.info("[Exit]: id_to_videoname")
        return img_id

    @staticmethod
    def make_url(project, fname):
        logger.info("[Start]: make_url")
        pname ='noesis_data'
        logger.info("[Exit]: make_url")
        return cfg.IMG_ENDPOINT + '/{:s}/{:s}/{:s}'.format(
            pname,project, fname)

    @staticmethod
    def make_video_url(project, fname):
        logger.info("[Start]: make_video_url")
        pname ='noesis_data'
        logger.info("[Exit]: make_video_url")
        return cfg.VIDEO_ENDPOINT + '/{:s}/{:s}/{:s}'.format(
            pname,project, fname)

    @staticmethod
    def get_img_count(fold, dset):
        logger.info("[Start]: get_img_count")
        logger.info("[Exit]: get_img_count")
        return len(fold[dset].keys())

    @staticmethod
    def load_metrics(fpath):
        logger.info("[Start]: load_metrics")
        if os.path.isfile(fpath):
            logger.info("[Exit]: load_metrics")
            return Files.load_json(fpath)
        logger.info("[Exit]: load_metrics")
        return {
            "experiments":{},
            "latest":{},
            "counts":{}
        }

    @staticmethod
    def get_metrics(id_, videopath):
        logger.info("[Start]: get_metrics")
        labeljsonfileName = id_ + '_label.json'
        predjsonfileName = id_ + '.json'
        metricsjsonfileName = 'metrics.json'
        metrics_pred = Data.load_metrics(Data.get_fpath(videopath, predjsonfileName))
        metrics_label = Data.load_metrics(Data.get_fpath(videopath, labeljsonfileName))

        metrics_p_anno = metrics_pred['imgs'][id_]['annotations']
        metrics_l_anno = metrics_label[cfg.IMG][id_]['annotations']
        total_l_count = len(metrics_l_anno)
        total_p_count = len(metrics_p_anno)
        total_mod_count = 0
        loc_accu = 0
        obj_label = ''
        left_obj_count = int(math.fabs(total_p_count - total_l_count))
        clip_accuracy = int((1 - (left_obj_count/ (total_l_count + total_p_count)))*100)
        for i in range(len(metrics_l_anno)):
          for j in range(len(metrics_p_anno)):
            if metrics_l_anno[i]['id'] == metrics_p_anno[j]['id']:
              # for bounding box modification
              if metrics_l_anno[i]['bbox']['xmax'] != metrics_p_anno[j]['bbox']['xmax'] or \
                metrics_l_anno[i]['bbox']['xmin'] != metrics_p_anno[j]['bbox']['xmin'] or \
                metrics_l_anno[i]['bbox']['ymax'] != metrics_p_anno[j]['bbox']['ymax'] or \
                metrics_l_anno[i]['bbox']['ymin'] != metrics_p_anno[j]['bbox']['ymin']:
                total_mod_count += 1
                obj_label = metrics_p_anno[j]['label']
                loc_accu = Data.obj_loc_accu(metrics_l_anno[i]['bbox']['xmin'], metrics_l_anno[i]['bbox']['xmax'], \
                                        metrics_l_anno[i]['bbox']['ymin'], metrics_l_anno[i]['bbox']['ymax'], \
                                        metrics_p_anno[j]['bbox']['xmin'], metrics_p_anno[j]['bbox']['xmax'], \
                                        metrics_p_anno[j]['bbox']['ymin'], metrics_p_anno[j]['bbox']['ymax'])
              # for polygon modification

        metrics = {
            'name': id_,
            'accuracy': clip_accuracy,
            'edit': total_mod_count,
            'updated': left_obj_count,
            'localization_accuracy': loc_accu,
            'created': time.strftime("%m/%d/%Y %H:%M:%S", time.localtime())
        }

        consldt_mtx['name_cnl'].append(id_)
        consldt_mtx['accuracy_cnl'].append(clip_accuracy)
        consldt_mtx['edit_cnl'].append(total_mod_count)
        consldt_mtx['updated_cnl'].append(left_obj_count)
        consldt_mtx['locacc_cnl'].append(loc_accu)
        metrics_label['metrics'] = metrics
        Files.save_json(Data.get_fpath(videopath, labeljsonfileName), metrics_label)
        Files.save_json(Data.get_fpath(videopath, metricsjsonfileName), consldt_mtx)
        logger.info("[Exit]: get_metrics")

    @staticmethod
    def obj_loc_accu(x11, x12, y11,y12,x21,x22,y21,y22):
        logger.info("[Start]: obj_loc_accu")
        intrsctn_wd = int(math.fabs(x12 - x21))
        intrsctn_ht = int(math.fabs(y12 - y21))
        union_wd	= int(math.fabs(x22 - x11))
        union_ht	= int(math.fabs(y22 - y11))
        intrsctn_area = intrsctn_wd*intrsctn_ht
        union_area	= union_wd*union_ht
        loc_accuracy = int((intrsctn_area/union_area)*100)
        logger.info("[Exit]: obj_loc_accu")
        return loc_accuracy

    @staticmethod
    def get_img_count(fold, dset):
        logger.info("[Start]: get_img_count")
        l = 0
        try:
          l = len(fold[dset].keys())
        except Exception as error_obj:
          logger.error(error_obj)
        logger.info("[Exit]: get_img_count")
        return l

    @staticmethod
    def get_img_counts(proj_name):
        logger.info("[Start]: get_img_counts")
        fold = Data.load_fold(proj_name,'')
        logger.info("[Exit]: get_img_counts")
        return {
            cfg.IMG: Data.get_img_count(fold, cfg.IMG),
            cfg.VAL: Data.get_img_count(fold, cfg.VAL),
            cfg.TEST: Data.get_img_count(fold, cfg.TEST),
            cfg.UNLABELED: Data.get_img_count(fold, cfg.UNLABELED)
        }

    @staticmethod
    def load_counts(fpath):
        logger.info("[Start]: load_counts")
        if os.path.isfile(fpath):
            logger.info("[Exit]: load_counts")
            return Files.load_json(fpath)
        logger.info("[Exit]: load_counts")
        return {
            "experiments":{},
            "latest":{},
            "counts":{}
        }

    @staticmethod
    def update_counts(project_name):
        logger.info("[Start]: update_counts")
        counts = Data.get_img_counts(project_name)
        metrics_fpath = Data.get_fpath(
            project_name, cfg.METRICS_FNAME)
        metrics = Data.load_metrics(metrics_fpath)
        metrics["counts"] = counts
        Files.save_json(metrics_fpath, metrics)
        logger.info("[Exit]: update_counts")
        return metrics
