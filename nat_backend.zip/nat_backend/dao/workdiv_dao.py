import os
import json
import datetime
from structures.data_structures import *
from commons import constants as cfg
from nat_3D_Backend.commons.getdb_conn import DBConnect
from quriesdao.dbQueries import DbQueries
from graphql import GraphQLError
from sys import exc_info
from utils.errors_utils import Error
from dao.project_dao import ProjectDAO

from utils.logger import Logger
logger = Logger.get_logger()

class WorkdivDao(object):
    @staticmethod
    def save_workdiv(userid, folderpath, divisionType, availdays, requiredays, productivity,
        avgFrame, totalFrame, availannotator, requireannotator, annoratio, availvalidator, scriptList, project_id, conversionScript, conversionScripts):
        logger.info("[Start]: save_workdiv")
        response = None
        try:
            cur = cfg.mysql_db.get_db().cursor()
            work_name = os.path.basename(os.path.normpath(folderpath))
            created_by_date = datetime.datetime.fromtimestamp(datetime.datetime.now().timestamp())
            query = """INSERT INTO nat_work_division(work_name, work_division_type,
                no_of_days_count, no_of_frames_count, productivity, aver_obj_per_frame,
                folder_path, required_days, avail_anno, required_anno, anno_ratio, avail_valid,
                work_status, created_by_date, created_by_user_id, updated_by_user_id, validation_scripts, nat_project_id,
                conversion_script, conversion_scripts) VALUES
                ('%s', '%s', %s, %s, %s, %s, '%s', %s, %s, %s, %s, %s, %s, '%s', %s, %s, '%s', %s, '%s', '%s')""" % (
                    work_name, divisionType,
                    availdays, totalFrame, productivity, avgFrame,
                    folderpath, requiredays, availannotator, requireannotator, annoratio, availvalidator,
                    1, created_by_date, userid, userid, json.dumps(scriptList), project_id,
                    conversionScript, ",".join(conversionScripts)
                )
            cur.execute(query)
            response = cur.lastrowid
            logger.debug("New work initiated (%s, %s)" % (response, work_name))
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: save_workdiv")
        return response

    @staticmethod
    def update_workdiv(userid, workdiv_id, scriptList, conversionScript):
        logger.info("[Start]: update_workdiv")
        response = None
        try:
            cur = cfg.mysql_db.get_db().cursor()
            query = """UPDATE nat_work_division
                SET validation_scripts='%s',
                conversion_script='%s' 
                WHERE id=%s""" % (
                    json.dumps(scriptList),
                    conversionScript,
                    workdiv_id
                )
            cur.execute(query)
            response = cur.lastrowid
            logger.debug("Updated work (%s, %s)" % (response, workdiv_id))
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: update_workdiv")
        return response

    @staticmethod
    def get_workdiv_by_folderpath(folderpath):
        logger.info("[Start]: get_workdiv_by_folderpath")
        response = None
        try:
            cur = cfg.mysql_db.get_db().cursor()
            query = "SELECT * FROM nat_work_division WHERE folder_path='%s'" % (folderpath)
            # query = "SELECT * FROM nat_work_division WHERE folder_path='%s' AND work_status=1" % (folderpath)
            cur.execute(query)
            r = cur.fetchone()
            if r:
                response = r
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: get_workdiv_by_folderpath")
        return response

    @staticmethod
    def get_latest_details(workdiv_id):
        logger.info("[Start]: get_latest_details")
        response = None
        try:
            cur = cfg.mysql_db.get_db().cursor()
            query = """SELECT * FROM nat_work_div_details WHERE work_division_id=%s
                AND execution_status=1 ORDER BY id desc LIMIT 1 """ % (workdiv_id)
            cur.execute(query)
            r = cur.fetchone()
            if r:
                response = r
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: get_latest_details")
        return response

    @staticmethod
    def make_workdiv_obj(project_id):
        logger.info("[Start]: make_workdiv_obj")
        response = None
        try:
            query = DbQueries.SELECT_QUERY.format(cfg.SELECT_ALL, cfg.PipelineSettings.TABLENAME,
                                                  cfg.PipelineSettings.CONDITION.format(project_id))
            try:
                conn, cursor = DBConnect().get_db_cursor()
            except Exception as e:
                logger.error("error in the get pipeline while connecting to DB")
                raise
            try:
                cursor.execute(query)
            except Exception as e:
                logger.error("error while executing the query {}, error {}".format(query, e))
                raise GraphQLError(Error.get_error_object(exc_info()[0].__name__))
            pipeline_setting = cursor.fetchall()
            if pipeline_setting:
                for k in cfg.PipelineSettings.NOT_REQUIRED_KEYS:
                    del pipeline_setting[cfg.PipelineSettings.FIRST_ELEMENT][k]
                pipeline_setting = pipeline_setting[cfg.PipelineSettings.FIRST_ELEMENT]
                response = WorkDiv(
                    userid = pipeline_setting.get(cfg.PipelineSettings.USER_ID),
                    projectid  = pipeline_setting.get(cfg.PipelineSettings.PROJECT_ID),
                    sourcebucket = pipeline_setting.get(cfg.PipelineSettings.SOURCE_BUCKET),
                    sourcepath = pipeline_setting.get(cfg.PipelineSettings.SOURCE_PATH),
                    destBucket = pipeline_setting.get(cfg.PipelineSettings.DESTINATION_BUCKET),
                    destpath=pipeline_setting.get(cfg.PipelineSettings.DESTINATION_PATH),
                    projectType = pipeline_setting.get(cfg.PipelineSettings.PROJECT_NAME),
                    divisionType = pipeline_setting.get(cfg.PipelineSettings.DIVISON_TYPE),
                    requiredays=pipeline_setting.get(cfg.PipelineSettings.DAYS_REQUIRED),
                    avgFrame=pipeline_setting.get(cfg.PipelineSettings.AVGOBJPERFRAME),
                    availannotator=pipeline_setting.get(cfg.PipelineSettings.ANNO_AVAIL),
                    annoratio=pipeline_setting.get(cfg.PipelineSettings.RATIO),
                    availdays = pipeline_setting.get(cfg.PipelineSettings.DAYS_AVAIL),
                    productivity = pipeline_setting.get(cfg.PipelineSettings.PRODUCTIVITY),
                    totalFrame = pipeline_setting.get(cfg.PipelineSettings.FRAME_COUNT),
                    requireannotator = pipeline_setting.get(cfg.PipelineSettings.ANNO_REQ),
                    availvalidator = pipeline_setting.get(cfg.PipelineSettings.VAL_AVAIL),
                    conversionScript = pipeline_setting.get(cfg.PipelineSettings.CONVERSIONSCRIPT),
                    time = pipeline_setting.get(cfg.PipelineSettings.TIME),
                    frequency = pipeline_setting.get(cfg.PipelineSettings.FREQUENCY),
                    filetype = pipeline_setting.get(cfg.PipelineSettings.FILETYPE),
                    pipelineseq = pipeline_setting.get(cfg.PipelineSettings.PIPELINE_SEQ),
                    status = pipeline_setting.get(cfg.PipelineSettings.STATUS)
                )
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: make_workdiv_obj")
        return response

    @staticmethod
    def get_frames_count_datewise():
        logger.info("[Start]: get_frames_count_datewise")
        response = {}
        try:
            cur = cfg.mysql_db.get_db().cursor()
            query = """SELECT execution_date, per_day_count
              FROM nat_work_div_details ORDER BY id"""
            cur.execute(query)
            recset = cur.fetchall()
            for rec in recset:
                try:
                    d = rec[0].strftime('%Y%m%d')
                    try:
                        response[d] = response[d] + rec[1]
                    except:
                        response[d] = rec[1]
                except:
                    pass
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: get_frames_count_datewise")
        return response
