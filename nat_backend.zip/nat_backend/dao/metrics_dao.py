import os
import json
import re
import csv
import time
from datetime import datetime
import fnmatch
# Custom packages
from commons import constants as cfg
from structures.data_structures import *
from structures.nat_gql_datatype import *
from dao.data import Data
#from config.config import DatabaseConfig
from utils.logger import Logger
from dao.workdiv_dao import WorkdivDao
from utils.common_utils import my_dictionary
from utils.ops_encrypt import EncryptDecrypt as ed
logger = Logger.get_logger()


class MetricsDao(object):
    @staticmethod
    def save_accuracy_json_to_table(metrics_json):
        logger.info("[Start]: save_accuracy_json_to_table")
        try:
            cur = cfg.mysql_db.get_db().cursor()
            cur.execute("TRUNCATE accuracy_metrics")
            # query = """ INSERT INTO accuracy_metrics(`label`, `metrics`, `videos`, `frames`)
            #     VALUES('%s', '%s', '%s', '%s') """
            videos = []
            frames = {}
            queries = []
            for vid in metrics_json['videos']:
                videos.append(vid.get('label'))
                frames[vid.get('label')] = []
                for frm in vid.get('frames'):
                    frames[vid.get('label')].append(frm.get('label'))
            queries.append(""" INSERT INTO accuracy_metrics(`level`, `metrics`, `videos`)
                VALUES(1, '%s', '%s') """ % (json.dumps(metrics_json['metrics']), json.dumps(videos) ) )

            for vid in metrics_json['videos']:
                queries.append(""" INSERT INTO accuracy_metrics(`level`, `metrics`, `label`, `frames`)
                    VALUES(2, '%s', '%s', '%s') """
                    % (json.dumps(vid.get('metrics')), vid.get('label'), json.dumps(frames.get(vid.get('label'))) ) )
                for frm in vid.get('frames'):
                    queries.append(""" INSERT INTO accuracy_metrics(`level`, `metrics`, `label`, `video_name`)
                        VALUES(3, '%s', '%s', '%s') """
                        % (json.dumps(frm.get('metrics')), frm.get('label'), vid.get('label') ) )

            for query in queries:
                cur.execute(query)

        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: save_accuracy_json_to_table")

    @staticmethod
    def get_accuracy_table_to_json():
        logger.info("[Start]: get_accuracy_table_to_json")
        response = {'metrics': None, 'videos': []}
        try:
            cur = cfg.mysql_db.get_db().cursor()
            cur.execute("""SELECT `level`, `label`, `metrics`, `video_name`, `videos`, `frames`
                FROM accuracy_metrics""")

            videos = {}
            for row in cur:
                if row[0] == 1:
                    response = {
                        'metrics': json.loads(row[2]),
                        'videos': []
                    }
                elif row[0] == 2:
                    videos[row[1]] = {
                        'label': row[1],
                        'metrics': json.loads(row[2]),
                        'frames': []
                    }
                elif row[0] == 3:
                    videos[row[3]]['frames'].append({
                        'label': row[1],
                        'metrics': json.loads(row[2])
                    })

            for key, vid in videos.items():
                response['videos'].append(vid)

            

        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: get_accuracy_table_to_json")
        return response

    @staticmethod
    def create_or_update_productivity(videoid, video_name, validator_name, annotator_name, no_objects, no_objects_error, validate, frames_count):
        logger.info("[Start]: create_or_update_productivity")
        response = True
        try:
            cur = cfg.mysql_db.get_db().cursor()

            query = """SELECT * FROM productivity_metrics
                WHERE video_name='%s' AND annotator_name='%s'""" % (video_name, annotator_name)
            cur.execute(query)
            r = cur.fetchone()
            if r:
                if validate and r[6] == 0:
                    query = """UPDATE productivity_metrics
                        SET no_objects=%s, no_objects_error=%s, validated=True
                        WHERE video_name='%s' AND annotator_name='%s'""" % (str(no_objects), str(no_objects_error), video_name, annotator_name)
                    cur.execute(query)
            else:
                today_date = datetime.now().strftime('%Y-%m-%d')
                query = """INSERT INTO productivity_metrics (video_name, validator_name, annotator_name, date, no_objects, no_objects_error, video_id, frames_count)
                    VALUES('%s', '%s', '%s', '%s', %s, %s, %s, %s)""" % (video_name, validator_name, annotator_name, today_date, str(no_objects), str(no_objects_error), videoid, frames_count)
                cur.execute(query)
        except Exception as error_obj:
            response = False
            logger.error(error_obj)
        logger.info("[Exit]: create_or_update_productivity")
        return response


    @staticmethod
    def get_project_path_dao(userid, pid):
        logger.info("[Start]: get_project_path_dao")
        response = ''
        try:
            cur = cfg.mysql_db.get_db().cursor()
            query = "SELECT folder_path FROM nat_user_setting WHERE user_id={uid} AND project_id={pid}".format(uid=userid
                                                                                                               ,pid=pid)
            cur.execute(query)
            rows = cur.fetchone()
            response = ed.decrypt_incoming(list(rows)[0])
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: get_project_path_dao")
        return response

    @staticmethod
    def generate_productivity_csv(userid, username, userrole, from_date, to_date):
        logger.info("[Start]: generate_productivity_csv")
        response = True
        try:
            cur = cfg.mysql_db.get_db().cursor()

            if userrole == cfg.ROLE_VALIDATOR:
                query1 = """SELECT validator_name, annotator_name,
                    SUM(no_objects) AS no_objects, SUM(no_objects_error) AS no_objects_error
                    FROM productivity_metrics
                    WHERE validator_name='%s'
                    AND `date` between '%s' AND '%s'
                    GROUP BY validator_name, annotator_name""" % (username, from_date, to_date)
                query2 = """SELECT annotator_name, `date`,
                    SUM(no_objects) AS no_objects, SUM(no_objects_error) AS no_objects_error
                    FROM productivity_metrics
                    WHERE validator_name='%s'
                    AND `date` between '%s' AND '%s'
                    GROUP BY annotator_name, `date`""" % (username, from_date, to_date)
            else:
                query1 = """SELECT validator_name, annotator_name,
                    SUM(no_objects) AS no_objects, SUM(no_objects_error) AS no_objects_error
                    FROM productivity_metrics
                    WHERE `date` between '%s' AND '%s'
                    GROUP BY validator_name, annotator_name""" % (from_date, to_date)
                query2 = """SELECT annotator_name, `date`,
                    SUM(no_objects) AS no_objects, SUM(no_objects_error) AS no_objects_error
                    FROM productivity_metrics
                    WHERE `date` between '%s' AND '%s'
                    GROUP BY annotator_name, `date`""" % (from_date, to_date)

            cur.execute(query1)
            recs = list(cur.fetchall())
            new_recs = []
            if recs:
                for rec in recs:
                    r = list(rec)
                    r[2] = int(rec[2])-int(rec[3])
                    new_recs.append(r)
            new_recs.insert(0, ['Validator', 'Annotator', 'Success', 'Fail'])
            
            with open('../static/productivity1.csv', 'w') as csvFile:
                writer = csv.writer(csvFile)
                writer.writerows(new_recs)
            csvFile.close()

            cur.execute(query2)
            recs = list(cur.fetchall())
            new_recs = []
            if recs:
                for rec in recs:
                    r = list(rec)
                    r[2] = int(rec[2])-int(rec[3])
                    new_recs.append(r)
            new_recs.insert(0, ['Annotator', 'Date', 'Success', 'Fail'])
            
            with open('../static/productivity2.csv', 'w') as csvFile:
                writer = csv.writer(csvFile)
                writer.writerows(new_recs)
            csvFile.close()
        except Exception as error_obj:
            response = False
            logger.error(error_obj)
        logger.info("[Exit]: generate_productivity_csv")
        return response

    @staticmethod
    def generate_accuracy_csv():
        logger.info("[Start]: generate_accuracy_csv")
        response = True
        try:
            cur = cfg.mysql_db.get_db().cursor()
            query = """SELECT `level`, `label`, `metrics`, `video_name`, `videos`, `frames`
                FROM accuracy_metrics"""

            cur.execute(query)
            rows = list(cur.fetchall())

            csvData = [
                ["level", "video_name", "frame_name", "label", "object_detection_accuracy", "object_edited_count", "object_deletion_count", "object_loc_accuracy"]
            ]
            for row in rows:
                metrics_dict = json.loads(row[2])
                tempData = my_dictionary()
                for metric, metric_arr in metrics_dict.items():
                    for arr in metric_arr:
                        if arr['label'] not in tempData:
                            tempData.add(arr['label'], {
                                "object_detection_accuracy": 0,
                                "object_edited_count": 0,
                                "object_deletion_count": 0,
                                "object_loc_accuracy": 0
                            })
                        tempData[arr['label']][metric] = arr['value']
                for label, data in tempData.items():
                    framename = ""
                    if row[0] == 3:
                        framename = row[1]
                    videoname = ""
                    if row[0] == 2:
                        videoname = row[1]
                    elif row[0] == 3:
                        videoname = row[3]
                    csvData.append([
                        row[0], videoname, framename, label, data.get("object_detection_accuracy"), data.get("object_edited_count"), data.get("object_deletion_count"), data.get("object_loc_accuracy")
                    ])

            # csvData.append(["1", "", "", "basketball_d1c1", "80", "2", "6", "80"])
            # csvData.append(["1", "", "", "basketball_d1c2", "87", "1", "7", "80"])
            # csvData.append(["1", "", "", "basketball_d1c3", "95", "4", "8", "80"])
            # csvData.append(["1", "", "", "basketball_d1c4", "69", "7", "9", "80"])
            # csvData.append(["1", "", "", "basketball_d1c5", "99", "5", "10", "80"])
            # csvData.append(["1", "", "", "basketball_d1c6", "89", "3", "11", "80"])
            # csvData.append(["1", "", "", "basketball_d1c7", "67", "9", "8", "80"])
            # csvData.append(["1", "", "", "basketball_d1c8", "78", "2", "14", "80"])
            # csvData.append(["1", "", "", "basketball_d1c9", "80", "1", "18", "80"])
            # csvData.append(["1", "", "", "basketball_d1c10", "85", "4", "20", "80"])

            # csvData.append(["2", "basketball_d1c1", "", "IMG_0001", "98", "0", "1", "70"])
            # csvData.append(["2", "basketball_d1c1", "", "IMG_0002", "78", "0", "1", "90"])
            # csvData.append(["2", "basketball_d1c1", "", "IMG_0003", "89", "0", "2", "75"])
            # csvData.append(["2", "basketball_d1c1", "", "IMG_0004", "88", "0", "1", "85"])
            # csvData.append(["2", "basketball_d1c1", "", "IMG_0005", "61", "1", "1", "60"])
            # csvData.append(["2", "basketball_d1c1", "", "IMG_0006", "66", "1", "0", "80"])
            # csvData.append(["2", "basketball_d1c1", "", "IMG_0007", "70", "0", "0", "90"])
            # csvData.append(["2", "basketball_d1c1", "", "IMG_0008", "90", "0", "0", "90"])

            # csvData.append(["3", "basketball_d1c1", "IMG_0001", "car", "58", "0", "0", "60"])
            # csvData.append(["3", "basketball_d1c1", "IMG_0001", "person", "30", "0", "0", "80"])
            # csvData.append(["3", "basketball_d1c1", "IMG_0001", "signal", "2", "0", "0", "70"])
            # csvData.append(["3", "basketball_d1c1", "IMG_0001", "food", "7", "0", "1", "62"])
            # csvData.append(["3", "basketball_d1c1", "IMG_0001", "hoarding", "1", "0", "0", "78"])
            with open('../static/accuracy.csv', 'w') as csvFile:
                writer = csv.writer(csvFile)
                writer.writerows(csvData)
            csvFile.close()
        except Exception as error_obj:
            response = False
            logger.error(error_obj)
        logger.info("[Exit]: generate_accuracy_csv")
        return response

    @staticmethod
    def insert_accuracy(video_name, validate):
        logger.info("[Start]: insert_accuracy")
        response = False
        try:
            cur = cfg.mysql_db.get_db().cursor()

            query = """SELECT * FROM accuracy_metrics WHERE level=2 AND label='%s'""" % (video_name)
            cur.execute(query)
            r = cur.fetchone()

            if r:
                if validate and r[6] == 0:
                    response = True
            else:
                response = True

        except Exception as error_obj:
            response = False
            logger.error(error_obj)
        logger.info("[Exit]: insert_accuracy")
        return response

    @staticmethod
    def create_or_update_accuracy(video_name, video_metrics, frames_metrics, validate):
        logger.info("[Start]: create_or_update_accuracy")
        response = True
        try:
            cur = cfg.mysql_db.get_db().cursor()
            query = """DELETE FROM accuracy_metrics WHERE level=2 AND label='%s'""" % (video_name)
            query = """DELETE FROM accuracy_metrics WHERE level=3 AND video_name='%s'""" % (video_name)

            if video_metrics['frames']:
                query = """INSERT INTO accuracy_metrics(`level`, `label`, `metrics`, `frames`, `validated`)
                    VALUES(2, '%s', '%s', '%s', %s)""" % (
                        video_name, json.dumps(video_metrics['metrics']), json.dumps(video_metrics['frames']), validate
                    )
            cur.execute(query)
            for frame_metrics in frames_metrics:
                query = """INSERT INTO accuracy_metrics(`level`, `label`, `metrics`, `video_name`, `validated`)
                    VALUES(3, '%s', '%s', '%s', %s)""" % (
                        frame_metrics['label'], json.dumps(frame_metrics['metrics']), video_name, validate
                    )
                cur.execute(query)
            MetricsDao.save_accuracy_consolidated()
        except Exception as error_obj:
            response = False
            logger.error(error_obj)
        logger.info("[Exit]: create_or_update_accuracy")
        return response

    @staticmethod
    def save_accuracy_consolidated():
        logger.info("[Start]: save_accuracy_consolidated")
        response = True
        try:
            cur = cfg.mysql_db.get_db().cursor()

            query = """SELECT `label`, `metrics` FROM accuracy_metrics WHERE level=2"""
            cur.execute(query)

            metrics = {'object_edited_count': [], 'object_loc_accuracy': [], 'object_deletion_count': [], 'object_detection_accuracy': []}
            videos = []
            for row in cur:
                videos.append(row[0])

                video_metric = json.loads(row[1])
                object_edited_count = object_loc_accuracy = object_deletion_count = object_detection_accuracy = 0

                for m in video_metric['object_edited_count']:
                    object_edited_count = object_edited_count + int(m['value'])
                for m in video_metric['object_loc_accuracy']:
                    object_loc_accuracy = object_loc_accuracy + int(m['value'])
                for m in video_metric['object_deletion_count']:
                    object_deletion_count = object_deletion_count + int(m['value'])
                for m in video_metric['object_detection_accuracy']:
                    object_detection_accuracy = object_detection_accuracy + int(m['value'])
                if len(video_metric['object_detection_accuracy']) > 0:
                    object_detection_accuracy = object_detection_accuracy / len(video_metric['object_detection_accuracy'])

                metrics['object_edited_count'].append({'label': row[0], 'value': object_edited_count})
                metrics['object_loc_accuracy'].append({'label': row[0], 'value': object_loc_accuracy})
                metrics['object_deletion_count'].append({'label': row[0], 'value': object_deletion_count})
                metrics['object_detection_accuracy'].append({'label': row[0], 'value': object_detection_accuracy})

            if videos:
                query = """DELETE FROM accuracy_metrics WHERE `level`=1"""
                cur.execute(query)

                query = """INSERT INTO accuracy_metrics(`level`, `metrics`, `videos`)
                    VALUES(1, '%s', '%s')""" % (
                        json.dumps(metrics), json.dumps(videos)
                    )
                cur.execute(query)
        except Exception as error_obj:
            response = False
            logger.error(error_obj)
        logger.info("[Exit]: save_accuracy_consolidated")
        return response

    @staticmethod
    def get_video_names(pid, cur):
        logger.info("[Start]: get_video_names")
        video_names= []
        try:
            query = "SELECT video_name FROM video WHERE project_id={pid}".format(pid=pid)
            cur.execute(query)
            rows = cur.fetchall()
            for i in rows:
                video_names.append(list(i)[0])
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: get_video_names")
        return video_names

    @staticmethod
    def get_json_images_count(p_path, v_name):
        logger.info("[Start]: get_json_images_count")
        json_count = 0
        path_to_find = os.path.join(p_path, v_name)
        for root, _, filenames in os.walk(path_to_find):
            for extensions in cfg.PossibleExtensions.JSON_EXT:
                for i in filenames:
                    if extensions in i:
                        json_count += 1
        logger.info("[Exit]: get_json_images_count")
        return json_count

    @staticmethod
    def burndown_csv_header(data_path, pid):
        logger.info("[Start]: burndown_csv_header")
        csv_name = data_path + "/burndown_" + str(pid) + "_.csv"
        if os.path.exists(csv_name):
            pass
        else:
            with open(csv_name, "w") as csv_file:
                writer = csv.writer(csv_file)
                writer.writerows([cfg.BURNDOWN_CSV_DATA])
            csv_file.close()
        logger.info("[Exit]: burndown_csv_header")
        return csv_name

    @staticmethod
    def csv_data_extractor(output_csv):
        data = []
        with open(output_csv, 'r') as read_obj:
            csv_reader = csv.reader(read_obj)
            header = next(csv_reader)
            for r in csv_reader:
                data_dict = {}
                for i in range(len(r)):
                    data_dict[header[i]] = r[i]
                data.append(data_dict)
        return data

    @staticmethod
    def get_data_to_write(signal):
        data = []
        for i in signal:
            temp_data = []
            for k, v in i.items():
                temp_data.append(v)
            data.append(temp_data)
        return data

    @staticmethod
    def write_data_to_csv(csv_name, json_count, prod_number, date, csv_data_existing, pid, csv_path):
        if csv_data_existing:
            os.system(" rm -rf {}".format(csv_name))
            MetricsDao.burndown_csv_header(csv_path, pid)
            today_signal = False
            for i in csv_data_existing:
                if i.get('date') == date:
                    i['count1'] = str(prod_number)
                    i['count2'] = str(json_count)
                    today_signal = True

            data_to_write = MetricsDao.get_data_to_write(signal=csv_data_existing)
            if not today_signal:
                data_to_write.append([date, str(prod_number), str(json_count)])
            with open(csv_name, "a") as csvfile:
                writer = csv.writer(csvfile)
                writer.writerows(data_to_write)
            csvfile.close()
        else:
            data = [date, str(prod_number), str(json_count)]
            with open(csv_name, "a") as csvfile:
                writer = csv.writer(csvfile)
                writer.writerows([data])
            csvfile.close()

    @staticmethod
    def get_prod_number(pid, cur):
        logger.info("[Start]: get_prod_number")
        response = 0
        try:
            query = "SELECT `productivity`, `avail_anno`, `aver_obj_per_frame` FROM nat_work_division where" \
                    " nat_project_id={pid}".format(pid=pid)
            cur.execute(query)
            rows = cur.fetchone()
            data_for_calc = list(rows)
            response = int((data_for_calc[0] * data_for_calc[1])/data_for_calc[2])
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: get_prod_number")
        return response

    @staticmethod
    def generate_performance_chart_csv_dao(userid, username, userrole, pid):
        logger.info("[Start]: generate_performance_chart_csv_dao")
        response = True
        try:
            cur = cfg.mysql_db.get_db().cursor()
            project_path = MetricsDao.get_project_path_dao(userid, pid)
            if os.path.exists(project_path+cfg.BURNDOWN_FOLDER):
                pass
            else:
                os.mkdir(project_path+cfg.BURNDOWN_FOLDER)
            video_names = MetricsDao.get_video_names(pid, cur)
            json_count = 0
            for vid_name in video_names:
                json_ = MetricsDao.get_json_images_count(project_path, vid_name)
                json_count += json_
            prod_number = MetricsDao.get_prod_number(pid, cur)
            csv_name = MetricsDao.burndown_csv_header(os.path.join(project_path, cfg.BURNDOWN_FOLDER), pid)
            csv_data_existing = MetricsDao.csv_data_extractor(output_csv=csv_name)
            date = time.strftime("%Y%m%d")
            MetricsDao.write_data_to_csv(csv_name, json_count, prod_number, date, csv_data_existing, pid,
                                         os.path.join(project_path, cfg.BURNDOWN_FOLDER))
            path_to_copy = "../nat_frontend/static/burndown.csv"
            os.system("cp {} {}".format(csv_name, path_to_copy))
        except Exception as error_obj:
            response = False
            logger.error(error_obj)
        logger.info("[Exit]: generate_performance_chart_csv_dao")
        return response

    @staticmethod
    def get_frames_count_datewise():
        logger.info("[Start]: get_frames_count_datewise")
        response = {}
        try:
            cur = cfg.mysql_db.get_db().cursor()
            query = """SELECT date, frames_count
              FROM productivity_metrics"""
            cur.execute(query)
            recset = cur.fetchall()
            for rec in recset:
                try:
                    d = rec[0].strftime('%Y%m%d')
                    try:
                        response[d] = response[d] + rec[1]
                    except:
                        response[d] = rec[1]
                except:
                    pass
        except Exception as error_obj:
            logger.error(error_obj)
        logger.info("[Exit]: get_frames_count_datewise")
        return response
