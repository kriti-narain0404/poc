from datetime import datetime
# Custom packages
from commons import constants as cfg
from utils.logger import Logger
import traceback
logger = Logger.get_logger()

class LoginActiveInactive:
    """

    """
    def __init__(self, userid):
        self.userid = userid
        self.cur = self.get_cursor()

    def get_lastlogin(self):
        query = "Select Last_login from nat_user where id={userid}".format(userid=self.userid)
        self.cur.execute(query)
        last_login = []
        for rows in self.cur.fetchall():
            last_login.append(rows)
        if len(last_login)>1:
            logger.error("there are more than one users with same name")
        return last_login

    def get_cursor(self):
        cur = None
        try:
            cur = cfg.mysql_db.get_db().cursor()
        except Exception as e:
            logger.error("couldn't create the connection to db, traceback:{0}".format(traceback.format_exc(limit=1)))
        return cur

    def update_last_login(self):
        query = "UPDATE nat_user SET Last_login='{last_login}' WHERE id={userid}".format(last_login=datetime.now(),
                                                                                       userid=self.userid)
        self.cur.execute(query)

    def get_difference(self, curr_datetime, last_login):
        difference_in_seconds = (curr_datetime - last_login).total_seconds()
        return round(difference_in_seconds/3600)

    def active_status_1(self):
        last_login = self.get_lastlogin()[0][0]
        if not last_login:
            return False
        else:
            curr_datetime = datetime.now()
            if self.get_difference(curr_datetime, last_login) < cfg.TIME_DIFFERENCE_1:
                return True
            else:
                return False

    def active_status_2(self):
        last_login = self.get_lastlogin()[0][0]
        if not last_login:
            return False
        else:
            curr_datetime = datetime.now()
            if self.get_difference(curr_datetime, last_login) < cfg.TIME_DIFFERENCE_2:
                return True
            else:
                return False