from nat_refactor.utils.logger import Logger
from nat_refactor.constants.constants import Constants
from datetime import datetime
import argparse


class ArchiveTransactionData(object):

    logger = Logger().get_logger()

    def __init__(self):
        self._db = None
        self._cur = None

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, exc_traceback):
        self.close()

    @property
    def db(self):
        if self._db is None:
            from nat_refactor.utils.database_ops import DbBase
            self._db = DbBase()
        return self._db

    @property
    def cur(self):
        if self._cur is None:
            self._cur = self.db.db_conn.cursor()
        return self._cur

    def run(self):
        cur_dt = datetime.now().strftime('%Y-%m-%d')
        self.logger.debug(f'Current Date: {cur_dt}')

        cols = "`, `".join(Constants.TABLE_ARCHIVE_TRANSACTION_DASHBOARD_COLUMNS)
        query = f"INSERT INTO {Constants.TABLE_ARCHIVE_TRANSACTION_DASHBOARD} (`{cols}`) " \
                f"SELECT `{cols}` FROM {Constants.TABLE_TRANSACTION_DASHBOARD} " \
                "WHERE date < %s"
        self.logger.debug(query)
        self.cur.execute(query, (cur_dt,))
        self.db.db_conn.commit()

        del_query = f"DELETE FROM {Constants.TABLE_TRANSACTION_DASHBOARD} WHERE date < %s"
        self.logger.debug(del_query)
        self.cur.execute(del_query, (cur_dt,))
        self.db.db_conn.commit()

    def close(self):
        if self._cur is not None:
            self._cur.close()
            self._cur = None
        self.db.clean()

    @classmethod
    def get_arguments(cls):
        parser = argparse.ArgumentParser(description='Archive User Transaction Data')
        parser.add_argument('--config-path', dest='config_path', required=False, default=None,
                            help='Path of Config File')
        return parser.parse_args()

    @classmethod
    def main(cls):
        args = cls.get_arguments()
        if args.config_path:
            Constants.CONFIG_FILE_PATH = args.config_path
            # print(args.config_path)
        with cls() as obj:
            obj.run()


if __name__ == '__main__':
    ArchiveTransactionData.main()
