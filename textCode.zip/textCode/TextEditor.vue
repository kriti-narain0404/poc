<template>
	<v-app id="app" :dark="isDarkMode == true">
		<home-header />
		<!--************************ Using Vue2-Editor Library***************** -->

		<div class="container-fluid">
			<div class="row d-flex">
				<div class="col-8">
					<vue-editor
						v-model="content"
						:editorToolbar="customToolbar"
					></vue-editor>
					 

				</div>

				<!-- Settings Container -->
				<div class="col-4" style="background-color: #202020; ">
					<div class="right-toolbar" style="">
							<!-- ************************Submit Button***************************** -->

								<v-btn
									@click="handleSavingContent()"
									class="cust-btn cust-submit-btn cust-primary-btn"
									>Submit</v-btn
								>

						<!-- <v-card
							id="set"
							v-show="isTagOpen"
							:isOpen.sync="isTagOpen"
							class="annotation-setting-parameters--height"
						>
							<v-card-actions class="setting-card-action"> -->
								<v-layout row wrap class="setting-card-parameters"
								v-show="isTagOpen"
							:isOpen.sync="isTagOpen"
								>
									<v-flex class="class-list-container">
										<v-flex
											class="single-class-container close"
											v-for="(settingItem, i) in classObj"
											:key="i"
										>
											<p class="class-label" :title="settingItem.name">
												{{ settingItem.name }}
											</p>
											<v-flex style="display: flex; width: 100%;">
												
												<v-layout class="attributes-container">
													
												<v-flex
													class="single-attribute-outer-container"
													v-if="settingItem.param && extractParam.subClass"
													v-for="(extractParam, index) in settingItem.param"
												>
												<div :style="{'width': '10px', 'margin':'3px 0','background-color': settingItem.color }"> </div>
													<v-flex
														class="single-attribute"
														v-if="extractParam.subClass"
													>
														<p
															class="attribute-label"
															:title="extractParam.name"
														>
															{{ extractParam.name }}
														</p>
														<select
															:title="parameterLabel[[i, index]]"
															v-model="parameterLabel[[i, index]]"
															:id="settingItem.name + index"
															size="1"															 
															onblur="this.size=0;"														 														 
															 
														>
															<option
																class="select-option "
																v-for="objects in extractParam.subClass"
																:value="objects.name"
																:key="objects.id"
																>{{ objects.name }}</option
															>
														</select>
													</v-flex>
													<input
														v-if="extractParam.paralength > 0"
														:id="settingItem.name + index"
														class="index setting-lbl-li setting-card--input-hidden"
														v-model="parameterLabel[[i, index]]"
														type="text"
														v-bind:maxlength="extractParam.paralength"
														v-on:keypress="isNumberKey"
														v-bind:placeholder="extractParam.name"
													/>
												</v-flex>
											</v-layout>
											<input
												name="myfield"
												type="radio"
												v-bind:value="settingItem.name"
												v-model="radioSelect"
												v-on:click="isTagOpen = !isTagOpen"
												@click="giveLabel(settingItem, i)"
												@keydown.esc="isTagOpen = false"
											/>
										
										</v-flex>
											
										</v-flex>
									</v-flex>
								</v-layout>
							<!-- </v-card-actions>
						</v-card> -->
					</div>
				</div>
			</div>
			<!-- Editor Text Part -->

			<!-- Settings Part -->
		</div>

	
		<!-- ************************Label Tool ******************************* -->

		<!-- ***************Saving PopUp************************************ -->
		<v-dialog
			v-model="showNotification"
			width="auto"
			class="dialog-container"
			v-if="showNotification == true"
		>
			<v-card>
				<v-card-title class="dialog-title">
					<v-layout row wrap>
						<v-flex>
							<v-subheader>
								<p class="dialog-header">
									Your changes has been saved successfully.
								</p>
							</v-subheader>
						</v-flex>
					</v-layout>
				</v-card-title>
			</v-card>
		</v-dialog>

		<!-- *************************Hover POpUp***************************** -->
		<v-dialog
			v-model="showPopUp"
			width="auto"
			class="dialog-container"
			v-if="showPopUp == true"
		>
			<v-card>
				<v-card-title class="dialog-title">
					<v-layout row wrap>
						<v-flex v-for="settingItem in intentText">
							<v-subheader>
								<p class="dialog-header">
									{{ settingItem }}
								</p>
							</v-subheader>
						</v-flex>
					</v-layout>
				</v-card-title>
			</v-card>
		</v-dialog>
	</v-app>
</template>

<!--******************************* CSS/JS Imports -->
<script src="../components/ToolsJS/Text_Moderation/TextEditor.js"></script>
<style scoped src="@/assets/css/textEditor.css"></style>
